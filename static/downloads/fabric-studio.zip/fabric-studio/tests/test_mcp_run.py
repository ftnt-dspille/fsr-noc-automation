"""The run tool: what counts as a read, what needs the person's approval, and how a request is checked and sent.

The classifier is the safety boundary here, so it is tested hard: anything that is not plainly a read must need
approval."""
from __future__ import annotations

import importlib

import pytest
from conftest import import_server
from mcp.server.mcpserver.exceptions import ToolError

from fabric_studio.mcp import fortios as fos
from fabric_studio.mcp import fortios_cli as cli

READS = [
    ("get system status", "FGT"), ("show full-configuration system interface", "FGT"),
    ("show system interface | grep port", "FGT"), ("execute ping 8.8.8.8", "FGT"), ("get system status", "FMG"),
    ("ls /var/log", "LXC"), ("df -h", "LXC"), ("ps aux | grep nginx", "LXC"), ("cat /etc/os-release", "LXC"),
    ("ip addr show", "LXC"), ("ip -br a", "LXC"), ("systemctl status nginx", "LXC"), ("docker ps", "LXC"),
    ("journalctl -u nginx | tail -n 20", "LXC"), ("uname -a", "BASIC"), ("ip route get 1.1.1.1", "LXC"),
    ("ip addr show dev eth0", "LXC"), ("hostname", "LXC"), ("hostname -f", "LXC"), ("date", "LXC"), ("date +%s", "LXC"),
    ("dmesg", "LXC"), ("dmesg -T", "LXC"), ("ifconfig", "LXC"), ("ifconfig eth0", "LXC"), ("ss -tlnp", "LXC"),
    ("ps aux | sort -k3 -r | head", "LXC"), ("ls -l | grep conf | wc -l", "LXC"),
]
NOT_READS = [
    ("execute reboot", "FGT"), ("execute factoryreset", "FGT"), ("config system interface", "FGT"),
    ("diagnose debug enable", "FGT"), ("exec ping 8.8.8.8", "FGT"), ("get system status; execute reboot", "FGT"),
    ("show system interface | head", "FGT"),                    # FortiOS has grep, not head: not a plain filter
    ("rm -rf /", "LXC"), ("systemctl restart nginx", "LXC"), ("ip link set eth0 down", "LXC"),
    ("docker rm x", "LXC"), ("tail -f /var/log/syslog", "LXC"), ("cat /etc/passwd > /tmp/x", "LXC"),
    ("ls; rm x", "LXC"), ("ls && reboot", "LXC"), ("ls || reboot", "LXC"), ("ls `reboot`", "LXC"), ("ls $(reboot)", "LXC"),
    ("ls | sh", "LXC"), ("ls | tee /tmp/x", "LXC"), ("echo hi", "LXC"), ("env", "LXC"), ("find / -delete", "LXC"),
    ("ls\nrm x", "LXC"), ("ls\rrm x", "LXC"), ("", "LXC"), ("   ", "LXC"), ("cat <<EOF", "LXC"), ("ls &", "LXC"),
    ("ls /tmp\x00", "LXC"), ("sudo ls", "LXC"), ("/bin/rm x", "LXC"), ("LS", "FGT"),
    ("ifconfig eth0 down", "LXC"), ("hostname newname", "LXC"), ("date -s 10:00", "LXC"), ("date 010112002020", "LXC"),
    ("journalctl --vacuum-size=1M", "LXC"), ("dmesg -c", "LXC"), ("ss -K", "LXC"), ("ss -tK", "LXC"),
    ("ip addr add 1.1.1.1/24 dev eth0", "LXC"), ("ip route add default via 1.1.1.1", "LXC"),
    ("ip link set eth0 down", "LXC"), ("ip netns exec x sh", "LXC"), ("ls | sort -o /tmp/x", "LXC"),
    ("ls | uniq a b", "LXC"), ("ping 1.1.1.1", "LXC"), ("top", "LXC"), ("ls | tail -f", "LXC"), ("systemctl stop x", "LXC"),
    ("docker exec x sh", "LXC"), ("docker logs -f x", "LXC"), ("journalctl -f", "LXC"),
]


@pytest.mark.parametrize("command,vm_type", READS)
def test_a_plain_read_runs_without_asking(command, vm_type):
    from fabric_studio.mcp.rawexec import classify_command
    assert classify_command(command, vm_type)[0] is True


@pytest.mark.parametrize("command,vm_type", NOT_READS)
def test_anything_else_needs_approval(command, vm_type):
    from fabric_studio.mcp.rawexec import classify_command
    assert classify_command(command, vm_type)[0] is False


@pytest.mark.parametrize("text,method,path,query", [
    ("GET /api/v2/monitor/system/status", "GET", "/api/v2/monitor/system/status", {}),
    ("/api/v2/cmdb/firewall/address", "GET", "/api/v2/cmdb/firewall/address", {}),
    ("post /api/v2/cmdb/firewall/address", "POST", "/api/v2/cmdb/firewall/address", {}),
    ("GET /api/v2/cmdb/firewall/address?filter=name==all&format=name", "GET", "/api/v2/cmdb/firewall/address",
     {"filter": "name==all", "format": "name"}),
    ("DELETE /api/v2/cmdb/firewall/address/my%20addr", "DELETE", "/api/v2/cmdb/firewall/address/my%20addr", {}),
])
def test_an_api_request_is_parsed(text, method, path, query):
    from fabric_studio.mcp.rawexec import parse_api
    assert parse_api(text) == (method, path, query)


@pytest.mark.parametrize("bad", ["", "GET", "PATCH /api/v2/x", "GET /api/v2/../../etc/passwd", "GET /api/v2//x",
                                 "GET /api/v2/./cmdb/x", "GET http://evil/x", "GET api/v2/x", "GET /api/v2/x%2e%2e/y",
                                 "GET /api/v2/a b", "GET /api/v2/x\n/y", "GET /api/v2/%2f"])
def test_a_request_that_could_leave_the_api_is_refused(bad):
    from fabric_studio.mcp.rawexec import parse_api
    with pytest.raises(ToolError):
        parse_api(bad)


def test_fortios_secrets_are_hidden_in_output():
    from fabric_studio.mcp.rawexec import scrub_text
    t = fos.Target(host="h", name="fgt", fabric="f", https_port=1, ssh_port=2, password="s3cret")
    out = scrub_text("config user local\n    edit \"bob\"\n        set passwd ENC SH2abcDEF==\n        set status enable\n"
                     "        set psksecret ENC xyz\n        set comment uses ENC abc= here\nlogin s3cret ok", t)
    assert "SH2abc" not in out and "ENC" not in out and "s3cret" not in out
    assert "set passwd <hidden>" in out and "set psksecret <hidden>" in out and "set status enable" in out


# ── the tool ─────────────────────────────────────────────────────────────────

T = fos.Target(host="pod", name="fgt", fabric="lab", user="admin", https_port=13000, ssh_port=11000, password="s3cret")


@pytest.fixture
def r(monkeypatch):
    import_server()
    mod = importlib.import_module("fabric_studio.mcp.rawexec")
    dev = importlib.import_module("fabric_studio.mcp.device")
    state = {"type": "FGT", "need": None, "relay_ip": None}

    def resolve(host, device, fabric, types=None, need=("SSH",), relay=False):
        state["need"] = need
        return T, {"vm_type": state["type"], "name": "fgt",
                   **({"relay_ip": state["relay_ip"]} if relay and state["relay_ip"] else {})}
    monkeypatch.setattr(dev, "resolve", resolve)
    monkeypatch.setattr(mod.dev, "resolve", resolve)
    sent = []
    monkeypatch.setattr(mod, "_ssh_fortios", lambda t, c, timeout: (sent.append(("fortios", c)), {"output": "Version: v7.6.6 password ENC abc"})[1])
    monkeypatch.setattr(mod, "_ssh_linux", lambda t, c, timeout: (sent.append(("linux", c)), {"output": "root\n", "exit_status": 0})[1])
    monkeypatch.setattr(mod, "_refuse_if_locked", lambda h: None)
    mod.sent, mod.state = sent, state
    mod.call = lambda **kw: mod.run.__wrapped__(host="pod", device="fgt", **kw)
    return mod


def test_a_read_runs_at_once_on_the_right_kind_of_session(r):
    out = r.call(command="get system status")
    assert out["executed"] and out["via"] == "ssh" and out["read_only"] and r.sent == [("fortios", "get system status")]
    r.state["type"] = "LXC"
    assert r.call(command="whoami")["output"] == "root\n" and r.sent[-1] == ("linux", "whoami")


def test_output_has_fortios_secrets_hidden(r):
    assert "ENC" not in r.call(command="get system status")["output"]


def test_a_command_that_is_not_a_read_returns_a_plan_and_runs_nothing(r):
    out = r.call(command="execute reboot")
    assert out["dry_run"] and out["read_only"] is False and out["command"] == "execute reboot" and r.sent == []
    assert "needs the person's approval" in out["warnings"][0]


def test_an_approved_command_runs(r):
    out = r.call(command="execute reboot", confirm=True)
    assert out["executed"] and r.sent == [("fortios", "execute reboot")]


def test_a_locked_pod_refuses_a_change_but_not_a_read(r, monkeypatch):
    def locked(h):
        raise ToolError("locked")
    monkeypatch.setattr(r, "_refuse_if_locked", locked)
    assert r.call(command="get system status")["executed"]
    assert r.call(command="execute reboot")["dry_run"]
    with pytest.raises(ToolError, match="locked"):
        r.call(command="execute reboot", confirm=True)


def test_exactly_one_of_command_or_api_is_required(r):
    for kw in ({}, {"command": "ls", "api": "GET /x"}):
        with pytest.raises(ToolError, match="exactly one of command"):
            r.call(**kw)


def test_the_timeout_is_bounded(r):
    for bad in (0, 301):
        with pytest.raises(ToolError, match="timeout_s"):
            r.call(command="ls", timeout_s=bad)


def test_a_command_with_a_control_character_is_refused_outright(r):
    with pytest.raises(ToolError, match="control characters"):
        r.call(command="ls\x00")


def test_an_api_read_runs_and_a_write_is_planned(r, monkeypatch):
    class Resp:
        status_code = 200
        text = ""
        def json(self): return {"results": {"hostname": "fgt", "password": "ENC x"}}
    calls = []
    monkeypatch.setattr(fos, "call", lambda t, level, m, p, q, b, raw=False: (calls.append((level, m, p, q)), Resp())[1])
    out = r.call(api="GET /api/v2/monitor/system/status?vdom=root")
    assert out["status"] == 200 and out["body"]["results"]["password"] == "<hidden>" and r.state["need"] == ("HTTPS",)
    assert calls == [("ro", "GET", "monitor/system/status", {"vdom": "root"})]
    plan = r.call(api="POST /api/v2/cmdb/firewall/address", body={"name": "x"})
    assert plan["dry_run"] and plan["request"] == "POST /api/v2/cmdb/firewall/address" and plan["body"] == {"name": "x"}
    assert len(calls) == 1
    r.call(api="POST /api/v2/cmdb/firewall/address", body={"name": "x"}, confirm=True)
    assert calls[-1][0] == "rw" and calls[-1][1] == "POST"


@pytest.mark.parametrize("path", ["/api/v2/cmdb/system/admin/admin", "/api/v2/cmdb/system/api-user", "/api/v2/cmdb/system/accprofile/x",
                                  "/api/v2/cmdb/SYSTEM/ADMIN"])
def test_the_accounts_the_tool_signs_in_with_cannot_be_written_over_the_api(r, path):
    with pytest.raises(ToolError, match="could lock it out"):
        r.call(api=f"PUT {path}", body={"x": 1}, confirm=True)


def test_reading_the_admin_accounts_is_allowed_and_their_secrets_are_hidden(r, monkeypatch):
    class Resp:
        status_code = 200
        text = ""
        def json(self): return {"results": [{"name": "admin", "password": "ENC x", "api-key": "k"}]}
    monkeypatch.setattr(fos, "call", lambda *a, **k: Resp())
    body = r.call(api="GET /api/v2/cmdb/system/admin")["body"]
    assert body["results"][0]["password"] == "<hidden>" and body["results"][0]["api-key"] == "<hidden>"


def test_a_fortigate_api_path_must_be_under_cmdb_monitor_or_log(r):
    with pytest.raises(ToolError, match="starts with /api/v2/cmdb/"):
        r.call(api="GET /logout")


def test_an_unavailable_api_points_at_ssh(r, monkeypatch):
    def off(*a, **k):
        raise fos.RestUnavailable("fgt is an unlicensed (evaluation) FortiGate VM. License it.")
    monkeypatch.setattr(fos, "call", off)
    with pytest.raises(ToolError, match=r"API is not available on fgt.*command=\.\.\."):
        r.call(api="GET /api/v2/monitor/system/status")


def test_another_device_gets_basic_auth_and_a_hint_when_it_refuses(r, monkeypatch):
    import requests
    seen = {}

    class Resp:
        status_code = 401
        text = "Unauthorized"
        def json(self): raise ValueError
    monkeypatch.setattr(requests, "request", lambda m, url, **kw: (seen.update(url=url, auth=kw["auth"]), Resp())[1])
    r.state["type"] = "FWB"   # FMG/FAZ use JSON-RPC sessions instead
    out = r.call(api="GET /sys/status")
    assert seen["auth"] == ("admin", "s3cret") and seen["url"] == "https://pod:13000/sys/status"
    assert out["status"] == 401 and "SSH" in out["hint"]


def test_long_output_is_clipped_and_says_so(r, monkeypatch):
    monkeypatch.setattr(r, "_ssh_linux", lambda t, c, timeout: {"output": "x" * 30000, "exit_status": 0})
    r.state["type"] = "LXC"
    out = r.call(command="cat /var/log/big")
    assert len(out["output"]) == 20000 and out["truncated"] and "filter it" in out["note"]


def test_a_script_for_a_fortios_device_is_a_change_not_a_read(r):
    out = r.call(command="config system dns\nset primary 1.1.1.1\nend")
    assert out["dry_run"] and r.sent == []


def test_the_fortios_session_stops_a_script_at_its_first_refusal(monkeypatch):
    importlib.reload(importlib.import_module("fabric_studio.mcp.rawexec"))
    from fabric_studio.mcp import rawexec

    class Shell:
        def __init__(self): self.sent = []
        async def run(self, line, timeout_s=60):
            self.sent.append(line)
            return "Command fail. Return code -5" if line == "set bad x" else ""
    sh = Shell()
    import asyncio
    monkeypatch.setattr(cli, "session", lambda t, fn, timeout_s=180: asyncio.run(fn(sh)))
    out = rawexec._ssh_fortios(T, "config firewall address\nset bad x\nset ok y\nend", 10)
    assert out["failed_line"] == "set bad x" and sh.sent == ["config firewall address", "set bad x", "abort"]
    assert "Return code -5" in out["output"]


# ── found in the two-site lab ─────────────────────────────────────────────────

def test_read_only_diagnose_phrases_are_exact():
    from fabric_studio.mcp import rawexec as rx
    assert rx.classify_command("diagnose dvm device list", "FMG")[0]
    assert rx.classify_command("diagnose vpn tunnel list name to-site2", "FGT")[0]
    assert rx.classify_command("execute log fortianalyzer test-connectivity", "FGT")[0]
    assert not rx.classify_command("diagnose sys session clear", "FGT")[0]
    assert not rx.classify_command("diagnose sys ha status extra", "FGT")[0]   # a non-list phrase takes no args
    assert not rx.classify_command("diagnose dvm device delete fgt1", "FMG")[0]


def test_jsonrpc_encrypted_list_and_adm_pass_are_hidden():
    from fabric_studio.mcp import fortios as f
    out = f.mask({"adm_pass": ["ENC", "abc"], "name": "fgt1", "other": ["ENC", "zzz"]})
    assert out == {"adm_pass": "<hidden>", "name": "fgt1", "other": "<hidden>"}


def test_jsonrpc_session_login_request_logout(monkeypatch):
    import requests

    from fabric_studio.mcp import fortios as f
    from fabric_studio.mcp import rawexec as rx
    sent = []

    class R:
        def __init__(self, data):
            self.data, self.status_code = data, 200

        def json(self):
            return self.data

    def post(url, json, **kw):
        sent.append(json)
        if json["params"][0]["url"] == "/sys/login/user":
            return R({"session": "S1", "result": [{"status": {"code": 0, "message": "OK"}}]})
        return R({"result": [{"status": {"code": 0, "message": "OK"}, "data": [{"name": "fgt1"}]}]})
    monkeypatch.setattr(requests, "post", post)
    monkeypatch.setattr(f, "check_cooldown", lambda t: None)
    t = f.Target(host="pod.example.com", name="fmg", fabric="lab", https_port=13002, ssh_port=11002,
                 user="admin", password="pw")
    res = rx._jsonrpc(t, "GET", "/dvmdb/adom/root/device", {"fields": ["name"]})
    assert res == {"status": 0, "message": "OK", "data": [{"name": "fgt1"}]}
    assert [s["params"][0]["url"] for s in sent] == ["/sys/login/user", "/dvmdb/adom/root/device", "/sys/logout"]
    assert sent[1]["method"] == "get" and sent[1]["session"] == "S1" and sent[1]["params"][0]["fields"] == ["name"]
    assert "pw" not in str(res)


def test_jsonrpc_login_without_rpc_permit_says_how_to_allow_it(monkeypatch):
    import pytest
    import requests

    from fabric_studio.mcp import fortios as f
    from fabric_studio.mcp import rawexec as rx

    class R:
        status_code = 200

        def json(self):
            return {"result": [{"status": {"code": -11, "message": "No permission for the resource"}}]}
    monkeypatch.setattr(requests, "post", lambda *a, **k: R())
    monkeypatch.setattr(f, "check_cooldown", lambda t: None)
    t = f.Target(host="pod.example.com", name="fmg", fabric="lab", https_port=1, ssh_port=2, user="admin", password="pw")
    with pytest.raises(f.DeviceError, match="rpc-permit read-write"):
        rx._jsonrpc(t, "GET", "/dvmdb/device", None)


def test_key_only_guest_is_not_called_a_wrong_password(monkeypatch):
    from fabric_studio.mcp import fortios as f
    monkeypatch.setattr(f, "offered_auth", lambda t: {"publickey"})
    t = f.Target(host="pod.example.com", name="client1", fabric="lab", https_port=1, ssh_port=2, user="root",
                 password="pw")
    msg = str(f.login_refused(t, guest=True))
    assert "accepts only SSH keys" in msg
    f._REFUSED.clear()


def test_quoted_string_reads_back_the_same():
    from fabric_studio.mcp import fortios as f
    assert f.same("fmg", '"192.0.2.40"', "192.0.2.40")


def test_secrets_are_not_comparable_rather_than_mismatched():
    from fabric_studio.mcp import fortios as f
    assert f.mismatches({"psksecret": "ENC xyz", "proposal": "aes256-sha256"},
                        {"psksecret": "s3cret", "proposal": "aes256-sha256"}) == []
    assert f.unverifiable({"psksecret": "x", "proposal": "y"}) == ["psksecret"]


def test_jsonrpc_body_may_not_override_the_url():
    import pytest

    from fabric_studio.mcp import fortios as fos
    from fabric_studio.mcp import rawexec as rx
    t = fos.Target(host="h", name="fmg", fabric="f", https_port=1, ssh_port=2)
    with pytest.raises(fos.DeviceError, match="may not carry its own url"):
        rx._jsonrpc(t, "set", "/dvmdb/adom/root", {"url": "/sys/login/user"})


def test_public_access_goes_direct_closed_access_goes_through_the_pod(r, monkeypatch):
    relayed = []
    monkeypatch.setattr(r.podrelay, "command",
                        lambda t, ip, c, timeout, linux: (relayed.append((ip, c, linux)), {"output": "ok"})[1])
    direct = r.call(command="get system status")
    assert "through" not in direct and r.sent and not relayed
    r.state["relay_ip"] = "192.0.2.31"
    res = r.call(command="get system status")
    assert relayed == [("192.0.2.31", "get system status", False)]
    assert "pod" in res["through"]


def test_api_through_the_pod_is_shaped_like_a_direct_one(r, monkeypatch):
    r.state["relay_ip"] = "192.0.2.31"
    monkeypatch.setattr(r.podrelay, "api", lambda t, ip, vt, m, p, q, b: (200, '{"results": {"password": "x"}}'))
    res = r.call(api="GET /api/v2/monitor/system/status")
    assert res["status"] == 200 and res["body"]["results"]["password"] != "x"


def test_relayed_output_is_scrubbed_like_direct(r, monkeypatch):
    r.state["relay_ip"] = "192.0.2.31"
    monkeypatch.setattr(r.podrelay, "command",
                        lambda t, ip, c, timeout, linux: {"output": "set password ENC AbCdEf123\nset psksecret ENC x"})
    out = r.call(command="show system admin")["output"]
    assert "AbCdEf123" not in out and "<hidden>" in out
