"""Offline shape tests for the Fabric Studio MCP server (``tools/fs_mcp/server``).

No pod required. Each test monkeypatches the seams the server module imports
(``fs_admin.*``, ``_resolve``/``_pod_creds``/``_client`` in the server, the
backend DB) and asserts every tool's return contract - so an accidental shape
change is caught before a live run. The three guest-SSH tools are async
(``asyncio_mode = "auto"`` runs them natively).
"""
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest
from mcp.server.mcpserver.exceptions import ToolError

# ── helpers ──────────────────────────────────���────────────────────���──────────

def _import_server():
    from conftest import import_server
    return import_server()


def _patch_fs_admin(monkeypatch, **overrides):
    """Replace ``fs_admin`` helpers named in ``overrides`` on the server's alias,
    and stub ``_client`` so the tools never build a real FabricStudioClient."""
    m = _import_server()
    monkeypatch.setattr(m, "_client", lambda host: MagicMock())
    for name, fn in overrides.items():
        monkeypatch.setattr(m.fs_admin, name, fn)
    return m


# ── get_pod_hostname ─────────���──────────────────────────────────────────���─────

class _Resp:
    def __init__(self, status_code, payload=None, text=""):
        self.status_code = status_code
        self._p = payload
        self.text = text

    def json(self):
        if self._p is None:
            raise ValueError("no json")
        return self._p


def test_get_pod_hostname_ok():
    import fabric_studio.admin as fa

    client = MagicMock()
    client.get.return_value = _Resp(200, {"object": "fortisoar-80-beta"})
    assert fa.get_pod_hostname(client) == "fortisoar-80-beta"


def test_get_pod_hostname_non200():
    import fabric_studio.admin as fa

    client = MagicMock()
    client.get.return_value = _Resp(404, {})
    assert fa.get_pod_hostname(client) is None


def test_get_pod_hostname_exception():
    import fabric_studio.admin as fa

    client = MagicMock()
    client.get.side_effect = RuntimeError("boom")
    assert fa.get_pod_hostname(client) is None


# ── list_pods ──────���──────────────────────────────────────────���───────────────

def _seed_db_with_pods(pods):
    """Insert Pod (+ Device) rows into the isolated per-test DB."""
    from sqlmodel import SQLModel

    from fabric_studio.db import engine, get_session
    from fabric_studio.models import Device, Pod

    SQLModel.metadata.create_all(engine)
    with get_session() as s:
        for p in pods:
            row = Pod(host=p["host"], pod_type=p.get("pod_type", "fs"),
                      username=p.get("username", "admin"),
                      tags=p.get("tags", []))
            s.add(row)
            s.commit()
            s.refresh(row)
            for i in range(p.get("device_count", 0)):
                s.add(Device(pod_id=row.id, vm_id=100 + i,
                             name=f"d{i}", vm_type="FGT", port_idx=i))
            s.commit()


def test_list_pods_surfaces_hostname_online_tags_device_count(monkeypatch):
    _seed_db_with_pods([
        {"host": "pod.example.com", "username": "admin", "tags": ["builder"],
         "device_count": 2},
        {"host": "down.example.com", "tags": [], "device_count": 0},
    ])
    m = _import_server()

    def fake_pod_creds(host, user, pw):
        return ("admin", "pw")

    def fake_client_ctor(host, user, pw, timeout_s=None, **kw):
        if host == "down.example.com":
            raise ConnectionError("unreachable")
        return MagicMock()  # __init__ "logged in"

    monkeypatch.setattr(m, "_pod_creds", fake_pod_creds)
    monkeypatch.setattr(m, "FabricStudioClient", fake_client_ctor)
    monkeypatch.setattr(m.fs_admin, "get_pod_hostname",
                        lambda c: "fortisoar-80-beta" if c is not None else None)

    out = m.list_pods()
    assert len(out) == 2
    by_host = {r["host"]: r for r in out}

    up = by_host["pod.example.com"]
    assert up["online"] is True
    assert up["hostname"] == "fortisoar-80-beta"
    assert up["tags"] == ["builder"]
    assert up["username"] == "admin"
    assert up["pod_type"] == "fs"
    assert up["device_count"] == 2
    assert up["pod_id"] is not None

    down = by_host["down.example.com"]
    assert down["online"] is False
    assert down["hostname"] is None
    assert down["device_count"] == 0


def test_list_pods_db_error_returns_error_row(monkeypatch, tmp_path):
    monkeypatch.setenv("FSH_INSTANCES_FILE", str(tmp_path / "none.json"))  # empty registry
    m = _import_server()
    monkeypatch.setattr(m, "ThreadPoolExecutor",  # never reached
                        lambda *a, **k: pytest.fail("should not probe"))
    # Force the DB select to blow up.
    import sqlmodel

    def boom(*a, **k):
        raise RuntimeError("db down")
    monkeypatch.setattr(sqlmodel, "select", boom)
    out = m.list_pods()
    assert isinstance(out, list) and len(out) == 1
    assert "error" in out[0]


# ── list_snapshots ─────────────────────────────���────────────────────���─────────

def test_list_snapshots_passes_through_diff_and_size(monkeypatch):
    m = _patch_fs_admin(monkeypatch, list_home_firmwares=lambda c, vt: [
        {"id": 842, "vm_type": "FSM", "major": 7, "minor": 5, "patch": 1,
         "version_s": "FSM_Supervisor-with-data", "build": 620, "status": "ready",
         "path": "firmwares/x", "is_diff": False, "diff_from": None,
         "size": 10485760},
        {"id": 850, "vm_type": "FSM", "major": 7, "minor": 5, "patch": 1,
         "version_s": "", "build": 620, "status": "ready", "path": "firmwares/d",
         "is_diff": True, "diff_from": 842, "size": 102400},
    ])
    out = m.list_snapshots("h")
    assert out[0]["version"] == "7.5.1FSM_Supervisor-with-data"
    assert out[0]["is_diff"] is False and out[0]["diff_from"] is None
    assert out[0]["size"] == 10485760
    assert out[1]["is_diff"] is True and out[1]["diff_from"] == 842
    assert out[1]["version"] == "7.5.1"


# ── list_fabrics / list_vms ─────────────────���────────────────────────────────

def test_list_fabrics_shape(monkeypatch):
    m = _patch_fs_admin(monkeypatch, list_fabrics=lambda c: [
        {"id": 10, "name": "fortisiem", "status": "running"}])
    out = m.list_fabrics("h")
    assert out == [{"id": 10, "name": "fortisiem", "status": "running"}]


def test_list_vms_shape(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_client", lambda host: MagicMock())
    monkeypatch.setattr(m, "resolve_fabric_id", lambda c, fabric: 10)
    monkeypatch.setattr(m.fs_admin, "list_fabric_vms", lambda c, fid: [
        {"id": 75, "name": "FSM_Supervisor", "vm_type": "FSM", "firmware": 842}])
    monkeypatch.setattr(m.fs_admin, "list_all_firmwares", lambda c: [
        {"id": 842, "vm_type": "FSM", "major": 7, "minor": 4, "patch": 1, "build": 1234}])
    out = m.list_vms("h")
    assert out == [{"id": 75, "name": "FSM_Supervisor", "vm_type": "FSM",
                    "firmware": 842, "version": "7.4.1 build 1234"}]


# ── vm_state / fs_license_pool / fs_license_assignment / forticloud ──────────

def test_vm_state_shape(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_resolve",
                        lambda host, vm, fabric, vt: (MagicMock(), 10, {"id": 75, "name": "soar01", "vm_type": "SOAR"}))
    monkeypatch.setattr(m.fs_admin, "get_vm_runtime_state",
                        lambda c, vid: {"exists": True,
                                        "status": {"powered": True,
                                                   "post_boot_prepared": True},
                                        "task": None})
    monkeypatch.setattr(m.fs_admin, "get_vm_license_mode",
                        lambda c, fid, vid: {"mode": "AUTO", "served": 5})
    out = m.vm_state("h")
    assert out["vm_id"] == 75
    assert out["runtime_exists"] is True
    assert out["status"]["powered"] is True
    assert out["license_mode"] == "AUTO"
    assert out["license_served_id"] == 5


def test_fs_license_pool_shape(monkeypatch):
    m = _patch_fs_admin(monkeypatch, list_fs_licenses=lambda c: [
        {"id": 1, "name": "FSM-VL-0001", "vm_type": "FSM"}])
    out = m.fs_license_pool("h")
    assert out == [{"id": 1, "serial": "FSM-VL-0001", "vm_type": "FSM"}]


def test_fs_license_assignment_resolves_serial(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_resolve",
                        lambda host, vm, fabric, vt: (MagicMock(), 10, {"id": 75, "name": "soar01", "vm_type": "SOAR"}))
    monkeypatch.setattr(m.fs_admin, "get_vm_license_mode",
                        lambda c, fid, vid: {"mode": "AUTO", "served": 5})
    monkeypatch.setattr(m.fs_admin, "get_fs_license",
                        lambda c, sid: {"name": "FSM-VL-0001"})
    out = m.fs_license_assignment("h")
    assert out == {"vm_id": 75, "mode": "AUTO", "served_id": 5,
                   "served_serial": "FSM-VL-0001"}


def test_fs_license_assignment_no_served(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_resolve",
                        lambda host, vm, fabric, vt: (MagicMock(), 10, {"id": 75, "name": "soar01", "vm_type": "SOAR"}))
    monkeypatch.setattr(m.fs_admin, "get_vm_license_mode",
                        lambda c, fid, vid: {"mode": "FIRMWARE", "served": None})
    out = m.fs_license_assignment("h")
    assert out["served_id"] is None and out["served_serial"] is None


def test_forticloud_status_shape(monkeypatch):
    m = _patch_fs_admin(
        monkeypatch,
        get_forticloud_account=lambda c: {"flexvm": {"username": "flexuser"}},
        forticloud_registered=lambda c: True)
    out = m.forticloud_status("h")
    assert out == {"registered": True, "username": "flexuser"}


# ── list_tasks / task_log ─────────────────���────────────────────���──────────────

def test_list_tasks_shape(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_client", lambda host: MagicMock())
    monkeypatch.setattr(m.fs_admin, "list_running_tasks", lambda c: [
        {"id": 1, "name": "Install", "returncode": None}])
    out = m.list_tasks("h")
    assert out["running"] == [{"id": 1, "name": "Install", "returncode": None}]
    assert out["recent_for_vm"] == []  # vm omitted → no recent


def test_list_tasks_recent_for_vm(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "resolve_fabric_id", lambda c, fabric: 10)
    monkeypatch.setattr(m, "resolve_vm",
                        lambda c, fid, vm, vt: {"id": 75, "name": "x"})

    def fake_get(endpoint, headers=None):
        class R:
            status_code = 200

            def json(self_):
                return {"object": [{"id": 9, "name": "Sync", "returncode": 0}]}
        return R()

    monkeypatch.setattr(m, "_client", lambda host: SimpleNamespace(get=fake_get))
    out = m.list_tasks("h", vm="x")
    assert out["recent_for_vm"] == [{"id": 9, "name": "Sync", "returncode": 0}]


def test_task_log_tail_truncates(monkeypatch):
    long_log = "\n".join(f"line {i}" for i in range(100))
    m = _patch_fs_admin(monkeypatch, get_task_log=lambda c, tid: long_log)
    out = m.task_log("h", 42, tail_lines=5)
    assert out["task_id"] == 42
    assert out["tail_lines"] == 5
    assert out["truncated"] is True
    assert out["log"].count("\n") == 4  # 5 lines
    assert out["full_length"] == len(long_log)


def test_task_log_tail_zero_is_full(monkeypatch):
    log = "only\nthree\nlines"
    m = _patch_fs_admin(monkeypatch, get_task_log=lambda c, tid: log)
    out = m.task_log("h", 1, tail_lines=0)
    assert out["truncated"] is False
    assert out["log"] == log
    assert out["full_length"] == len(log)


# ── vm_detail ───────────────────────────────────────���────────────────────���────

def test_vm_detail_aggregates_every_slice(monkeypatch):
    m = _import_server()
    fake_client = MagicMock()
    monkeypatch.setattr(m, "_resolve",
                        lambda host, vm, fabric, vt: (fake_client, 10, {"id": 75}))
    monkeypatch.setattr(m.fs_admin, "get_vm_runtime_state",
                        lambda c, vid: {"exists": True, "status": {"powered": True},
                                        "task": None})
    monkeypatch.setattr(m.fs_admin, "get_vm_license_mode",
                        lambda c, fid, vid: {"mode": "AUTO", "served": 5})
    monkeypatch.setattr(m.fs_admin, "get_runtime_vm",
                        lambda c, vid: {"port_idx": 1})
    monkeypatch.setattr(m.fs_admin, "list_vm_accesses", lambda c, fid, vid: [
        {"type": "SSH", "mode": "PUBLIC", "dport": 22},
        {"type": "HTTPS", "mode": "PUBLIC", "dport": 443},
    ])
    monkeypatch.setattr(m.fs_admin, "get_vm_parameters",
                        lambda c, vid: {"cpu_count": "4", "memory": "8192"})
    monkeypatch.setattr(m.fs_admin, "list_vm_disks",
                        lambda c, vid: [{"extra": False, "capacity": 0}])

    out = m.vm_detail("h")
    assert out["vm_id"] == 75
    assert out["license_mode"] == "AUTO"
    assert out["port_idx"] == 1
    assert out["params"]["cpu_count"] == "4"
    assert out["disks"] == [{"extra": False, "capacity": 0}]
    ports = {a["type"]: a["external_port"] for a in out["accesses"]}
    assert ports["SSH"] == 11001      # base 11000 + port_idx 1
    assert ports["HTTPS"] == 13001     # base 13000 + port_idx 1


def test_vm_detail_no_port_idx_yields_null_external_port(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_resolve",
                        lambda host, vm, fabric, vt: (MagicMock(), 10, {"id": 75, "name": "soar01", "vm_type": "SOAR"}))
    monkeypatch.setattr(m.fs_admin, "get_vm_runtime_state",
                        lambda c, vid: {"exists": False, "status": None, "task": None})
    monkeypatch.setattr(m.fs_admin, "get_vm_license_mode",
                        lambda c, fid, vid: {"mode": "FIRMWARE", "served": None})
    monkeypatch.setattr(m.fs_admin, "get_runtime_vm",
                        lambda c, vid: {"port_idx": None})
    monkeypatch.setattr(m.fs_admin, "list_vm_accesses", lambda c, fid, vid: [
        {"type": "SSH", "mode": "PUBLIC", "dport": 22}])
    monkeypatch.setattr(m.fs_admin, "get_vm_parameters", lambda c, vid: {})
    monkeypatch.setattr(m.fs_admin, "list_vm_disks", lambda c, vid: [])
    out = m.vm_detail("h")
    assert out["accesses"][0]["external_port"] is None
    assert out["runtime_exists"] is False


# ── vm_access ──────────────���────────────────────���─────────────────────────────

def test_vm_access_external_port_math_and_probe(monkeypatch):
    m = _import_server()
    fake_client = MagicMock()
    monkeypatch.setattr(m, "_resolve",
                        lambda host, vm, fabric, vt: (fake_client, 10, {"id": 75}))
    monkeypatch.setattr(m.fs_admin, "get_runtime_vm",
                        lambda c, vid: {"port_idx": 1})
    monkeypatch.setattr(m.fs_admin, "list_vm_accesses", lambda c, fid, vid: [
        {"type": "SSH", "mode": "PUBLIC", "dport": 22},
        {"type": "HTTPS", "mode": "PUBLIC", "dport": 443},
    ])
    monkeypatch.setattr(m.fs_admin, "probe_vm_accesses",
                        lambda c, fid, vid, host, timeout=6.0: [
                            {"type": "SSH", "port": 11001, "ok": True, "detail": "SSH-2.0"},
                            {"type": "HTTPS", "port": 13001, "ok": True, "detail": "200"}])
    out = m.vm_access("h", probe=True)
    assert out["port_idx"] == 1
    ssh = next(a for a in out["accesses"] if a["type"] == "SSH")
    assert ssh["external_port"] == 11001 and ssh["ok"] is True
    https = next(a for a in out["accesses"] if a["type"] == "HTTPS")
    assert https["external_port"] == 13001


def test_vm_access_probe_false_skips_probe(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_resolve",
                        lambda host, vm, fabric, vt: (MagicMock(), 10, {"id": 75, "name": "soar01", "vm_type": "SOAR"}))
    monkeypatch.setattr(m.fs_admin, "get_runtime_vm",
                        lambda c, vid: {"port_idx": 1})
    monkeypatch.setattr(m.fs_admin, "list_vm_accesses", lambda c, fid, vid: [
        {"type": "SSH", "mode": "PUBLIC", "dport": 22}])

    def fail_probe(*a, **k):
        pytest.fail("probe must not run when probe=False")
    monkeypatch.setattr(m.fs_admin, "probe_vm_accesses", fail_probe)
    out = m.vm_access("h", probe=False)
    assert out["accesses"][0]["ok"] is None


# ── vm_disks / fabric_topology ────────────���────────────────────���──────────────

def test_vm_disks_shape(monkeypatch):
    m = _import_server()
    fake_client = MagicMock()
    monkeypatch.setattr(m, "_resolve",
                        lambda host, vm, fabric, vt: (fake_client, 10, {"id": 75}))
    monkeypatch.setattr(m.fs_admin, "list_vm_disks", lambda c, vid: [
        {"extra": False, "capacity": 0}, {"extra": True, "capacity": 20480}])
    assert m.vm_disks("h") == [{"extra": False, "capacity": 0},
                               {"extra": True, "capacity": 20480}]


def test_fabric_topology_shape(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_client", lambda host: MagicMock())
    monkeypatch.setattr(m, "resolve_fabric_id", lambda c, fabric: 10)
    monkeypatch.setattr(m.fs_admin, "list_networks", lambda c, fid: [
        {"id": 1, "name": "mgmt", "ipv4network": "10.0.0.0"}])
    monkeypatch.setattr(m.fs_admin, "list_switches", lambda c, fid: [
        {"id": 2, "name": "sw1", "mgmt": True}])
    out = m.fabric_topology("h")
    assert out == {"fabric_id": 10,
                   "networks": [{"id": 1, "name": "mgmt",
                                 "ipv4network": "10.0.0.0"}],
                   "switches": [{"id": 2, "name": "sw1", "mgmt": True}]}


def test_fabric_resources_totals_and_fw_defaults(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_client", lambda host: MagicMock())
    monkeypatch.setattr(m, "resolve_fabric_id", lambda c, fabric: 10)
    monkeypatch.setattr(m.fs_admin, "list_fabric_vms", lambda c, fid: [
        {"id": 1, "name": "fgt", "vm_type": "FGT"},
        {"id": 2, "name": "faz", "vm_type": "FAZ"},
        {"id": 3, "name": "lxc", "vm_type": "LXC"}])
    params = {1: {"cpu_count": 2, "memory": 4096},
              2: {"cpu_count": "8", "memory": 8192},
              3: {"cpu_count": 0, "memory": 0}}
    monkeypatch.setattr(m.fs_admin, "get_vm_parameters", lambda c, vid: params[vid])
    monkeypatch.setattr(m.fs_admin, "list_vm_disks", lambda c, vid: (
        [{"extra": False, "capacity": 0}, {"extra": True, "capacity": 20480}]
        if vid == 2 else []))
    out = m.fabric_resources("h")
    assert out["fabric_id"] == 10
    assert out["vms"][1] == {"id": 2, "name": "faz", "vm_type": "FAZ",
                             "cpu_count": 8, "memory_mib": 8192, "disk_mib": 20480}
    assert out["total"] == {"vm_count": 3, "cpu_count": 10, "memory_mib": 12288,
                            "memory_gib": 12.0, "disk_mib": 20480}
    assert out["fw_default_vms"] == ["lxc"]


# ── pod_health ────────���────────────────────���──────────────────────────────────

def test_pod_health_shape(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_pod_creds", lambda host, u, p: ("admin", "pw"))
    monkeypatch.setattr(m, "_known_host", lambda host: True)

    # Seed a pod so the DB lookup yields a pod_type.
    _seed_db_with_pods([{"host": "pod.example.com"}])

    captured = {}

    class FakeRT:
        def get_system_health(self):
            return {"hostname": "fortisoar-80-beta", "version": "8.0.0",
                    "disk": {"vgs": []}, "errors": []}

    def fake_runtime_for(pod_type, server, username, password):
        captured.update(pod_type=pod_type, server=server)
        return FakeRT()

    monkeypatch.setattr(m, "runtime_for", fake_runtime_for)
    out = m.pod_health("pod.example.com")
    assert out["hostname"] == "fortisoar-80-beta"
    assert out["version"] == "8.0.0"
    assert out["disk"] == {"vgs": []}
    assert captured["pod_type"] == "fs"


def test_pod_health_no_health_method(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_pod_creds", lambda host, u, p: ("admin", "pw"))
    monkeypatch.setattr(m, "_known_host", lambda host: True)

    class FakeRT:
        pass  # no get_system_health

    monkeypatch.setattr(m, "runtime_for",
                        lambda *a, **k: FakeRT())
    # Seed a pod so the DB path is exercised.
    _seed_db_with_pods([{"host": "h"}])
    out = m.pod_health("h")
    assert "errors" in out and out["hostname"] is None


# ── guest-SSH trio (async) ──────���────────────────────���────────────────────────

@pytest.mark.asyncio
async def test_read_guest_license_shape(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_resolve",
                        lambda host, vm, fabric, vt: (MagicMock(), 10, {"id": 75, "name": "soar01", "vm_type": "SOAR"}))

    async def fake_guest(host, c, fid, v):
        return ("1.2.3.4", "serial: FSR-VL-0001\nlicensed: true")
    monkeypatch.setattr(m, "_guest_csadm_license", fake_guest)
    monkeypatch.setattr(m, "csadm_license_details",
                        lambda out: {"licensed": True, "serial": "FSR-VL-0001"})

    out = await m.read_guest_license("h")
    assert out["mgmt_ip"] == "1.2.3.4"
    assert out["license"]["serial"] == "FSR-VL-0001"
    assert out["usable"] is True
    assert out["auth_block"] is False


@pytest.mark.asyncio
async def test_guest_config_status_shape(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_resolve",
                        lambda host, vm, fabric, vt: (MagicMock(), 10, {"id": 75, "name": "soar01", "vm_type": "SOAR"}))
    monkeypatch.setattr(m, "_pod_creds", lambda host, u, p: ("admin", "pw"))
    monkeypatch.setattr(m, "_known_host", lambda host: True)
    monkeypatch.setattr(m, "_ssh_creds", lambda: ("csadmin", "<guest-password>"))
    monkeypatch.setattr(m, "_soar_mgmt_ip", lambda c, fid, v: "1.2.3.4")

    async def fake_jump(host, pu, pp, ip, su, sp, cmd, t, flag):
        return (0, "CONFIGURED", "")
    monkeypatch.setattr(m, "_jump_exec", fake_jump)

    out = await m.guest_config_status("h")
    assert out["state"] == "CONFIGURED"
    assert out["configured"] is True


@pytest.mark.asyncio
async def test_validate_license_match_shape(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_resolve",
                        lambda host, vm, fabric, vt: (MagicMock(), 10, {"id": 75, "name": "soar01", "vm_type": "SOAR"}))

    async def fake_guest(host, c, fid, v):
        return ("1.2.3.4", "serial: X\nlicensed: true")
    monkeypatch.setattr(m, "_guest_csadm_license", fake_guest)
    monkeypatch.setattr(m, "csadm_license_details",
                        lambda out: {"serial": "X", "licensed": True})
    monkeypatch.setattr(m.fs_admin, "validate_license_match",
                        lambda c, fid, v, lic: {"match": True, "assigned": "X"})

    out = await m.validate_license_match("h")
    assert out == {"match": True, "assigned": "X"}


# ── topology enrichment in the instance listings ──────────────────────────────

def test_pod_overview_tags_each_fabric_with_its_topology(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_connect", lambda host, t=20, creds=None: MagicMock())
    monkeypatch.setattr(m.fs_admin, "list_fabrics",
                        lambda c: [{"id": 1, "name": "soar-801-validate", "status": "ready"},
                                   {"id": 2, "name": "mystery-fabric", "status": "ready"}])
    monkeypatch.setattr(m.fs_admin, "runtime_vms", lambda c: [])
    monkeypatch.setattr(m.fs_admin, "list_fabric_vms", lambda c, fid: [])
    monkeypatch.setattr(m.inst, "lockouts", lambda: {})
    monkeypatch.setattr(m.inst, "is_locked", lambda locks, name=None: False)
    monkeypatch.setattr(m, "_fabric_topologies",
                        lambda: {"soar-801-validate": "soar_801_validate"})

    ov = m._pod_overview("h", only_running=False)
    by_name = {f["name"]: f for f in ov["fabrics"]}
    # a fabric a local topology declares is tagged; an unknown one is None, not missing
    assert by_name["soar-801-validate"]["topology"] == "soar_801_validate"
    assert by_name["mystery-fabric"]["topology"] is None


def test_fabric_topologies_reads_intent_declarations(monkeypatch, tmp_path):
    topo = tmp_path / "ws" / "topologies" / "soar_801_validate"
    topo.mkdir(parents=True)
    (topo / "intent.yaml").write_text("# a topology\nfabric: soar-801-validate\nnodes: []\n")
    monkeypatch.setenv("FS_WORKSPACE", str(tmp_path / "ws"))
    m = _import_server()
    m._fabric_topologies.cache_clear()
    assert m._fabric_topologies() == {"soar-801-validate": "soar_801_validate"}


def test_fabric_topologies_is_empty_without_a_workspace():
    m = _import_server()
    m._fabric_topologies.cache_clear()
    assert m._fabric_topologies() == {}


# ── mutating tools: dry-run guard + confirm path ──────────────────────────────

def _patch_resolve(m, monkeypatch, vm):
    monkeypatch.setattr(m, "_resolve", lambda host, v, fab, vt=None: (MagicMock(), 10, vm))


def test_set_vm_access_public_dry_run_makes_no_calls(monkeypatch):
    m = _patch_fs_admin(monkeypatch)
    _patch_resolve(m, monkeypatch, {"id": 78, "name": "fsr-agent"})
    monkeypatch.setattr(m.fs_admin, "get_runtime_vm", lambda c, vid: {"port_idx": 4})
    monkeypatch.setattr(m.fs_admin, "list_vm_accesses", lambda c, fid, vid: [
        {"type": "SSH", "mode": "PRIVATE", "dport": 22, "id": 171}])
    called = []
    monkeypatch.setattr(m.fs_admin, "ensure_public_access",
                        lambda *a, **k: called.append("ensure") or [])
    monkeypatch.setattr(m.fs_admin, "install_vm",
                        lambda *a, **k: called.append("install") or {})
    out = m.set_vm_access_public("pod", vm="fsr-agent", fabric="f", types=["SSH"])
    assert out["dry_run"] is True and out["would_set_public"] == ["SSH"]
    assert called == []                      # confirm=False => no mutation


def test_set_vm_access_public_confirm_sets_and_reinstalls(monkeypatch):
    m = _patch_fs_admin(monkeypatch)
    _patch_resolve(m, monkeypatch, {"id": 78, "name": "fsr-agent"})
    monkeypatch.setattr(m.fs_admin, "get_runtime_vm", lambda c, vid: {"port_idx": 4})
    monkeypatch.setattr(m.fs_admin, "list_vm_accesses", lambda c, fid, vid: [
        {"type": "SSH", "mode": "PRIVATE", "dport": 22, "id": 171}])
    monkeypatch.setattr(m.fs_admin, "ensure_public_forwards_allowed", lambda c: [])
    monkeypatch.setattr(m.fs_admin, "ensure_public_access", lambda c, fid, vid, types: ["SSH"])
    monkeypatch.setattr(m.fs_admin, "install_vm", lambda c, vid: {"id": 380})
    monkeypatch.setattr(m.fs_admin, "wait_task", lambda c, tid, timeout_s=0: {})
    monkeypatch.setattr(m.fs_admin, "get_task", lambda c, tid: {"returncode": 0})
    out = m.set_vm_access_public("pod", vm="fsr-agent", fabric="f", confirm=True)
    assert out["changed_to_public"] == ["SSH"]
    assert out["reinstalled"]["returncode"] == 0
    # SSH forward base 11000 + idx 4
    assert any(a["type"] == "SSH" and a["external_port"] == 11004 for a in out["accesses"])


def test_set_vm_access_public_rejects_unknown_type(monkeypatch):
    m = _patch_fs_admin(monkeypatch)
    _patch_resolve(m, monkeypatch, {"id": 78, "name": "x"})
    out = m.set_vm_access_public("pod", vm="x", fabric="f", types=["BOGUS"])
    assert "error" in out


def test_system_host_reports_installed_and_ports(monkeypatch):
    m = _patch_fs_admin(monkeypatch)
    monkeypatch.setattr(m, "resolve_fabric_id", lambda c, fab: 10)
    monkeypatch.setattr(m.fs_admin, "get_system_host", lambda c, fid: {
        "id": 63, "ports": [{"name": "int1", "id": 486, "ipv4addr": "10.254.1.254",
                             "peer": 506, "dhcp_service": True, "egress_nat": False}]})
    monkeypatch.setattr(m.fs_admin, "list_switches", lambda c, fid: [
        {"id": 66, "name": "Management", "ports": [506], "auto_address_network": 29}])
    monkeypatch.setattr(m.fs_admin, "get_vm_runtime_state", lambda c, vid: {"exists": False})
    monkeypatch.setattr(m.fs_admin, "devices_needing_dhcp_install", lambda c, fid: [])
    out = m.system_host("pod", fabric="f")
    assert out["device_id"] == 63 and out["installed"] is False
    assert out["ports"][0]["uplinks_switch"] == "Management"


def test_set_vm_port_dhcp_dry_run_autodetects_network_and_warns(monkeypatch):
    m = _patch_fs_admin(monkeypatch)
    _patch_resolve(m, monkeypatch, {"id": 78, "name": "fsr-agent"})
    monkeypatch.setattr(m.fs_admin, "get_vm_ports", lambda c, fid, vid: [
        {"name": "eth0", "id": 550, "peer": 510, "ipv4addr": "10.254.1.1",
         "ipv4netmask": "255.255.255.0"}])
    monkeypatch.setattr(m.fs_admin, "list_switches", lambda c, fid: [
        {"id": 66, "name": "Management", "ports": [510], "auto_address_network": 29}])
    monkeypatch.setattr(m.fs_admin, "list_networks", lambda c, fid: [
        {"id": 29, "name": "Management", "ipv4gateway": "10.254.1.254",
         "ipv4netmask": "255.255.255.0"}])
    monkeypatch.setattr(m.fs_admin, "get_system_host", lambda c, fid: {"id": 63, "ports": []})
    monkeypatch.setattr(m.fs_admin, "get_vm_runtime_state", lambda c, vid: {"exists": False})
    monkeypatch.setattr(m.fs_admin, "devices_needing_dhcp_install", lambda c, fid: [])
    called = []
    monkeypatch.setattr(m.fs_admin, "set_port_ipv4", lambda *a, **k: called.append("set"))
    out = m.set_vm_port_dhcp("pod", vm="fsr-agent", fabric="f")
    assert out["dry_run"] is True
    assert out["network"] == {"id": 29, "name": "Management", "gateway": "10.254.1.254"}
    assert out["dhcp_server_device"] == 63 and out["reservation_ip"] == "10.254.1.1"
    assert "install_system_host" in (out["warning"] or "")   # teaches the ordering
    assert called == []


def test_set_vm_port_dhcp_confirm_sets_reservation_and_reinstalls(monkeypatch):
    m = _patch_fs_admin(monkeypatch)
    _patch_resolve(m, monkeypatch, {"id": 78, "name": "fsr-agent"})
    ports = [{"name": "eth0", "id": 550, "peer": 510, "ipv4addr": "10.254.1.1",
              "ipv4netmask": "255.255.255.0", "network": None, "dhcp_server": None}]
    monkeypatch.setattr(m.fs_admin, "get_vm_ports", lambda c, fid, vid: ports)
    monkeypatch.setattr(m.fs_admin, "list_switches", lambda c, fid: [
        {"id": 66, "name": "Management", "ports": [510], "auto_address_network": 29}])
    monkeypatch.setattr(m.fs_admin, "list_networks", lambda c, fid: [
        {"id": 29, "name": "Management", "ipv4gateway": "10.254.1.254",
         "ipv4dns1": "10.254.1.254", "ipv4dns2": None, "ipv4netmask": "255.255.255.0"}])
    monkeypatch.setattr(m.fs_admin, "get_system_host", lambda c, fid: {"id": 63, "ports": []})
    monkeypatch.setattr(m.fs_admin, "get_vm_runtime_state", lambda c, vid: {"exists": True})
    monkeypatch.setattr(m.fs_admin, "latest_device_task", lambda c, hid: {"returncode": 0})
    seen = {}
    monkeypatch.setattr(m.fs_admin, "set_port_auto_config",
                        lambda c, fid, vid, pid, en: seen.update(autocfg=en))
    monkeypatch.setattr(m.fs_admin, "set_port_ipv4",
                        lambda c, fid, vid, pid, ip, mask, addrmode="STA", dhcp_server=None, network=None:
                        seen.update(ip=ip, srv=dhcp_server, net=network))
    monkeypatch.setattr(m.fs_admin, "_patch",
                        lambda c, ep, body, op: seen.update(netparams=body["object"]))
    monkeypatch.setattr(m.fs_admin, "install_vm", lambda c, vid: {"id": 381})
    monkeypatch.setattr(m.fs_admin, "wait_task", lambda c, tid, timeout_s=0: {})
    monkeypatch.setattr(m.fs_admin, "get_task", lambda c, tid: {"returncode": 0})
    out = m.set_vm_port_dhcp("pod", vm="fsr-agent", fabric="f", confirm=True)
    # must NOT disable auto_config (that renders inet manual -> no address)
    assert "autocfg" not in seen
    assert seen["ip"] == "10.254.1.1"
    assert seen["srv"] == 63 and seen["net"] == 29
    assert seen["netparams"]["auto_params_network"] == 29
    assert seen["netparams"]["ipv4gateway"] == "10.254.1.254"
    assert out["applied"] is True and out["reinstalled"]["returncode"] == 0
    assert out["network_params"]["auto_params_network"] == "Management"   # by name


def test_set_vm_port_auto_sets_clean_static_and_netparams(monkeypatch):
    m = _patch_fs_admin(monkeypatch)
    _patch_resolve(m, monkeypatch, {"id": 78, "name": "fsr-agent"})
    monkeypatch.setattr(m.fs_admin, "get_vm_ports", lambda c, fid, vid: [
        {"name": "eth0", "id": 550, "peer": 510, "ipv4addr": "10.254.1.1",
         "ipv4netmask": "255.255.255.0"}])
    monkeypatch.setattr(m.fs_admin, "list_switches", lambda c, fid: [
        {"id": 66, "name": "Management", "ports": [510], "auto_address_network": 29}])
    monkeypatch.setattr(m.fs_admin, "list_networks", lambda c, fid: [
        {"id": 29, "name": "Management", "ipv4gateway": "10.254.1.254",
         "ipv4dns1": "10.254.1.254", "ipv4netmask": "255.255.255.0"}])
    patches = []
    monkeypatch.setattr(m.fs_admin, "_patch",
                        lambda c, ep, body, op: patches.append((op, body["object"])))
    monkeypatch.setattr(m.fs_admin, "install_vm", lambda c, vid: {"id": 399})
    monkeypatch.setattr(m.fs_admin, "wait_task", lambda c, tid, timeout_s=0: {})
    monkeypatch.setattr(m.fs_admin, "get_task", lambda c, tid: {"returncode": 0})
    out = m.set_vm_port_auto("pod", vm="fsr-agent", fabric="f", confirm=True)
    port_obj = next(o for op, o in patches if op == "set_port_static_auto")
    # clean static: FS manages, STA mode, NO dhcp_server (cleared)
    assert port_obj["auto_config"] is True and port_obj["addrmode"] == "STA"
    assert port_obj["dhcp_server"] is None and port_obj["ipv4addr"] == "10.254.1.1"
    vm_obj = next(o for op, o in patches if op == "set_vm_netparams")
    assert vm_obj["auto_params_network"] == 29
    assert out["applied"] is True and out["mode"] == "auto/static"


def test_set_vm_port_auto_dry_run_by_name(monkeypatch):
    m = _patch_fs_admin(monkeypatch)
    _patch_resolve(m, monkeypatch, {"id": 78, "name": "fsr-agent"})
    monkeypatch.setattr(m.fs_admin, "get_vm_ports", lambda c, fid, vid: [
        {"name": "eth0", "id": 550, "peer": 510, "ipv4addr": "10.254.1.1"}])
    monkeypatch.setattr(m.fs_admin, "list_switches", lambda c, fid: [
        {"id": 66, "name": "Management", "ports": [510], "auto_address_network": 29}])
    monkeypatch.setattr(m.fs_admin, "list_networks", lambda c, fid: [
        {"id": 29, "name": "Management", "ipv4gateway": "10.254.1.254"}])
    called = []
    monkeypatch.setattr(m.fs_admin, "_patch", lambda *a, **k: called.append(1))
    out = m.set_vm_port_auto("pod", vm="fsr-agent", fabric="f", network="Management")
    assert out["dry_run"] is True and out["network"]["name"] == "Management"
    assert called == []


def test_resolve_network_by_name_and_id(monkeypatch):
    m = _patch_fs_admin(monkeypatch)
    monkeypatch.setattr(m.fs_admin, "list_networks", lambda c, fid: [
        {"id": 29, "name": "Management"}, {"id": 27, "name": "Internet Access"}])
    c = MagicMock()
    assert m._resolve_network(c, 10, "Management")["id"] == 29
    assert m._resolve_network(c, 10, "management")["id"] == 29      # case-insensitive
    assert m._resolve_network(c, 10, "internet access")["id"] == 27
    assert m._resolve_network(c, 10, 27)["name"] == "Internet Access"  # id still works
    assert m._resolve_network(c, 10, "nope") is None
    assert m._resolve_network(c, 10, None) is None


def test_set_vm_port_dhcp_accepts_network_by_name(monkeypatch):
    m = _patch_fs_admin(monkeypatch)
    _patch_resolve(m, monkeypatch, {"id": 78, "name": "fsr-agent"})
    monkeypatch.setattr(m.fs_admin, "get_vm_ports", lambda c, fid, vid: [
        {"name": "eth0", "id": 550, "peer": 510, "ipv4addr": "10.254.1.1"}])
    monkeypatch.setattr(m.fs_admin, "list_switches", lambda c, fid: [
        {"id": 66, "name": "Management", "ports": [510], "auto_address_network": 29}])
    monkeypatch.setattr(m.fs_admin, "list_networks", lambda c, fid: [
        {"id": 29, "name": "Management", "ipv4gateway": "10.254.1.254",
         "ipv4dns1": "10.254.1.254", "ipv4netmask": "255.255.255.0"}])
    monkeypatch.setattr(m.fs_admin, "get_system_host", lambda c, fid: {"id": 63, "ports": []})
    monkeypatch.setattr(m.fs_admin, "latest_device_task", lambda c, hid: {"returncode": 0})
    # passing the NAME (not the id 29) resolves to the Management network
    out = m.set_vm_port_dhcp("pod", vm="fsr-agent", fabric="f", network="Management")
    assert out["network"]["id"] == 29 and out["network"]["name"] == "Management"


def test_install_system_host_dry_run(monkeypatch):
    m = _patch_fs_admin(monkeypatch)
    monkeypatch.setattr(m, "resolve_fabric_id", lambda c, fab: 10)
    monkeypatch.setattr(m.fs_admin, "get_system_host", lambda c, fid: {
        "id": 63, "ports": [{"name": "int1", "id": 486, "peer": 506}]})
    monkeypatch.setattr(m.fs_admin, "list_switches", lambda c, fid: [
        {"id": 66, "name": "Management", "ports": [506]}])
    monkeypatch.setattr(m.fs_admin, "get_vm_runtime_state", lambda c, vid: {"exists": False})
    monkeypatch.setattr(m.fs_admin, "devices_needing_dhcp_install", lambda c, fid: [])
    called = []
    monkeypatch.setattr(m.fs_admin, "install_device", lambda c, d: called.append(d) or {})
    out = m.install_system_host("pod", fabric="f", enable_dhcp_ports=["int1"])
    assert out["dry_run"] is True and out["would_install"] is True
    assert out["would_synchronize_after"] is True
    assert called == []


def test_install_system_host_rebuilds_guest_forwards_never_syncs_host(monkeypatch):
    # Regression: synchronizing the HOST wipes mgmt1's runtime egress address and
    # kills the whole fabric's egress. install_system_host must rebuild forwards
    # by syncing each public-access GUEST, and never touch the host (id 63).
    m = _patch_fs_admin(monkeypatch)
    monkeypatch.setattr(m, "resolve_fabric_id", lambda c, fab: 10)
    monkeypatch.setattr(m.fs_admin, "get_system_host", lambda c, fid: {"id": 63, "ports": []})
    monkeypatch.setattr(m.fs_admin, "list_switches", lambda c, fid: [])
    monkeypatch.setattr(m.fs_admin, "get_vm_runtime_state", lambda c, vid: {"exists": False})
    monkeypatch.setattr(m.fs_admin, "latest_device_task", lambda c, hid: {"returncode": 0})
    monkeypatch.setattr(m.fs_admin, "devices_needing_dhcp_install", lambda c, fid: [])
    monkeypatch.setattr(m.fs_admin, "install_device", lambda c, d: {"id": 408})
    monkeypatch.setattr(m.fs_admin, "list_fabric_vms", lambda c, fid: [
        {"id": 77, "name": "collector"}, {"id": 78, "name": "fsr-agent"},
        {"id": 79, "name": "no-public"}])
    monkeypatch.setattr(m.fs_admin, "list_vm_accesses", lambda c, fid, vid: {
        77: [{"type": "SSH", "mode": "PUBLIC"}],
        78: [{"type": "SSH", "mode": "PUBLIC"}],
        79: [{"type": "SERIAL", "mode": "PRIVATE"}]}[vid])
    synced: list = []
    monkeypatch.setattr(m.fs_admin, "synchronize_device",
                        lambda c, vid: synced.append(vid) or {"id": 500 + vid})
    monkeypatch.setattr(m.fs_admin, "wait_task", lambda c, tid, timeout_s=0: {})
    monkeypatch.setattr(m.fs_admin, "get_task", lambda c, tid: {"returncode": 0})
    out = m.install_system_host("pod", fabric="f", confirm=True)
    assert out["install_returncode"] == 0
    assert synced == [77, 78]           # both public guests, in order
    assert 63 not in synced             # NEVER the host
    rebuilt = {r["vm_id"] for r in out["guest_forwards_rebuilt"]}
    assert rebuilt == {77, 78}
    assert "synchronized" not in out    # old host-sync key is gone






# ── _tool: sync tools run off the event loop under a deadline ─────────────────

async def test_tool_runs_sync_function_in_a_worker_thread():
    import threading

    m = _import_server()

    @m._tool
    def probe() -> str:
        return threading.current_thread().name

    assert await probe() != threading.current_thread().name


async def test_tool_aborts_a_call_past_its_deadline():
    import time

    m = _import_server()

    @m._tool(deadline_s=0.05)
    def slow() -> str:
        time.sleep(0.5)
        return "late"

    with pytest.raises(ToolError, match=r"exceeded 0\.05s"):
        await slow()


async def test_tool_long_deadline_lets_a_slow_call_finish():
    import time

    m = _import_server()
    assert m._LONG_TOOL_DEADLINE_S > 900  # outlasts the longest timeout_s a tool accepts

    @m._tool(deadline_s=5)
    def slow() -> str:
        time.sleep(0.1)
        return "done"

    assert await slow() == "done"


# ── a model-controlled `host` must never receive a shared credential ───────────────

def test_login_refuses_an_unknown_host_without_touching_shared_credentials(monkeypatch):
    m = _import_server()
    called = []
    monkeypatch.setattr(m, "_pod_creds", lambda h, u, p: called.append(h) or ("admin", "shared"))
    for host in ("evil.example.com", "evil.example.com/x?", "https://evil.example.com", "", "<your-pod>"):
        with pytest.raises(ValueError, match="not a managed instance"):
            m._login(host)
    assert called == []


def test_login_uses_shared_credentials_only_for_a_pod_in_the_database(monkeypatch):
    m = _import_server()
    _seed_db_with_pods([{"host": "known.example.com"}])
    seen = []
    monkeypatch.setattr(m, "_pod_creds", lambda h, u, p: seen.append(h) or ("admin", "shared"))
    assert m._login("known.example.com") == ("admin", "shared")
    assert seen == ["known.example.com"]


def test_login_prefers_a_registered_instances_own_login(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m.inst, "creds_for", lambda h: ("me", "own") if h == "reg.example.com" else None)
    monkeypatch.setattr(m, "_pod_creds", lambda h, u, p: pytest.fail("shared credentials used"))
    assert m._login("reg.example.com") == ("me", "own")


def test_a_registered_name_is_answered_with_its_host_not_told_to_register(monkeypatch):
    m = _import_server()
    monkeypatch.setattr(m, "_pod_creds", lambda h, u, p: pytest.fail("shared credentials used"))
    monkeypatch.setattr(m.inst, "load_registry", lambda: {"10.1.2.3": {"name": "pod-a"}})
    monkeypatch.setattr(m.inst, "creds_for", lambda h: None)
    with pytest.raises(ValueError, match=r"name of the managed instance at 10\.1\.2\.3"):
        m._login("pod-a")


def test_guest_and_system_tools_log_in_through_the_same_guard(monkeypatch):
    """The guest-SSH and pod_health tools used to call _pod_creds directly, skipping the guard."""
    m = _import_server()
    monkeypatch.setattr(m, "_client", lambda host: MagicMock())
    monkeypatch.setattr(m, "_pod_creds", lambda h, u, p: pytest.fail("shared credentials used"))
    with pytest.raises(ValueError, match="not a managed instance"):
        m.pod_health("evil.example.com")


# ── list_firmwares ────────────────────────────────────────────────────────────────

def test_list_firmwares_marks_local_remote_and_stub_images(monkeypatch):
    m = _patch_fs_admin(monkeypatch, list_all_firmwares=lambda c, vt=None: [
        {"id": 139, "vm_type": "FAZ", "major": 7, "minor": 6, "patch": 4, "version_s": "F", "build": 3579,
         "status": "ready", "size": 500, "repository": {"name": "fortinet"}, "path": "firmwares/faz.zip"},
        {"id": 138, "vm_type": "FAZ", "major": 7, "minor": 6, "patch": 3, "version_s": "F", "build": 3492,
         "status": "remote", "size": 400, "repository": {"name": "fortinet"}, "path": "firmwares/faz3.zip"},
        {"id": 7, "vm_type": "FAZ", "major": 7, "minor": 2, "patch": 0, "version_s": "", "build": 1,
         "status": "downloaded", "size": 0, "repository": {"name": "home"}, "path": "x"}])
    rows = {r["id"]: r for r in m.list_firmwares("pod.example.com", "FAZ")}
    assert rows[139]["local"] and rows[139]["usable"] and rows[139]["version"] == "7.6.4F"
    assert rows[139]["repository"] == "fortinet"
    assert not rows[138]["local"] and rows[138]["status"] == "remote"
    assert rows[7]["local"] and not rows[7]["usable"]            # a 0-byte stub is not usable
    local_only = m.list_firmwares("pod.example.com", "FAZ", include_remote=False)
    assert {r["id"] for r in local_only} == {139, 7}
