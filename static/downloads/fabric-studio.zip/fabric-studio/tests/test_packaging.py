"""The package metadata the install instructions rely on."""
from __future__ import annotations

import importlib
import tomllib
from pathlib import Path

PYPROJECT = tomllib.loads((Path(__file__).resolve().parents[1] / "pyproject.toml").read_text())


def test_console_script_resolves_to_main():
    module, _, attr = PYPROJECT["project"]["scripts"]["fabric-studio-mcp"].partition(":")
    assert callable(getattr(importlib.import_module(module), attr))


def test_mcp_extra_pins_the_sdk_the_server_imports():
    """mcp 2.x renamed FastMCP to MCPServer; a 1.x install cannot import the server."""
    assert any(d.startswith("mcp>=2") and "<3" in d for d in PYPROJECT["project"]["optional-dependencies"]["mcp"])
    from mcp.server.mcpserver import MCPServer

    import fabric_studio.mcp.server as s
    assert isinstance(s.mcp, MCPServer)


def test_wheel_ships_every_subpackage():
    find = PYPROJECT["tool"]["setuptools"]["packages"]["find"]
    assert find["where"] == ["src"] and find["include"] == ["fabric_studio*"]
    root = Path(__file__).resolve().parents[1] / "src" / "fabric_studio"
    for sub in ("client", "mcp", "pod", "channels", "parsers"):
        assert (root / sub / "__init__.py").is_file(), f"{sub} is not a package, so the wheel would skip it"


def test_server_registers_the_documented_tool_count():
    import asyncio

    from conftest import import_server

    s = import_server()  # a fresh server: other tests register throwaway tools on the shared one
    assert len(asyncio.run(s.mcp.list_tools())) == 17
