"""The device tool: how values are compared and sent, what a plan says, and that a change is read back.

A small fake FortiGate stands in for the REST API, so no pod is needed; the live behaviour is checked
separately against a real appliance."""
from __future__ import annotations

import copy
import importlib
from typing import Any, ClassVar

import pytest
from conftest import import_server
from mcp.server.mcpserver.exceptions import ToolError

from fabric_studio.mcp import fortios as fos


class FakeFGT:
    """cmdb tables held in memory, speaking just enough of the REST API: list, get, create, update, delete."""

    def __init__(self):
        self.tables: dict[str, Any] = {
            "system/interface": [
                {"name": "port1", "ip": "10.254.254.30 255.255.255.0", "allowaccess": "ping https ssh",
                 "status": "up", "description": ""},
                {"name": "port2", "ip": "0.0.0.0 0.0.0.0", "allowaccess": "", "status": "down", "description": ""}],
            "firewall/address": [{"name": "lan", "subnet": "10.0.1.0 255.255.255.0", "comment": ""}],
            "firewall/policy": [{"policyid": 1, "name": "allow", "srcaddr": [{"name": "lan"}], "action": "accept"}],
            "system/dns": {"primary": "208.91.112.53", "secondary": "208.91.112.52", "domain": ""},
            "system/admin": [{"name": "admin", "password": "ENC SH2abc", "accprofile": "super_admin"}],
        }
        self.calls: list[tuple[str, str]] = []
        self.discard = False  # accept writes and hold nothing: the silent-discard failure
        self.fail: dict[str, Any] | None = None

    MKEYS: ClassVar[dict[str, str]] = {"system/interface": "name", "firewall/address": "name", "firewall/policy": "policyid",
             "system/admin": "name"}

    def call(self, t, level, method, path, params=None, body=None):
        self.calls.append((level, f"{method} {path}"))
        assert path.startswith("cmdb/"), path
        rest = path[len("cmdb/"):]
        section = next((s for s in sorted(self.tables, key=len, reverse=True) if rest == s or rest.startswith(s + "/")), rest)
        name = rest[len(section) + 1:] if rest != section else None
        table = self.tables.get(section)
        if params and params.get("action") == "schema":
            return {"results": {"mkey": self.MKEYS.get(section)}}
        if self.fail and method != "GET":
            raise fos.DeviceError(self.fail["msg"])
        if method == "GET":
            return {"results": copy.deepcopy(table if name is None else [o for o in table if str(o[self.MKEYS[section]]) == name])}
        if self.discard:
            return {"results": {}}
        if isinstance(table, dict):
            table.update(body)
        elif method == "POST":
            table.append(body)
        elif method == "PUT":
            next(o for o in table if str(o[self.MKEYS[section]]) == name).update(body)
        elif method == "DELETE":
            table[:] = [o for o in table if str(o[self.MKEYS[section]]) != name]
        return {"results": {}}


@pytest.fixture
def dev(monkeypatch):
    import_server()
    mod = importlib.import_module("fabric_studio.mcp.device")
    fos.forget()
    fake = FakeFGT()
    target = fos.Target(host="pod.example.com", name="fgt", fabric="lab", https_port=13000, ssh_port=11000, password="s3cret")
    monkeypatch.setattr(mod, "_target", lambda host, device, fabric: target)
    monkeypatch.setattr(fos, "call", fake.call)
    monkeypatch.setattr(fos, "has_key", lambda t, level: level == "ro")
    monkeypatch.setattr(mod, "_refuse_if_locked", lambda host: None)
    mod.fake = fake
    mod.run = lambda action, **kw: mod.device.__wrapped__(action=action, host="pod.example.com", device="fgt", **kw)
    return mod


# ── values: comparing and sending ────────────────────────────────────────────

@pytest.mark.parametrize("field,have,want,same", [
    ("allowaccess", "ping https ssh", ["ssh", "https", "ping"], True),
    ("allowaccess", "ping https", "https ping", True),
    ("allowaccess", "ping https", ["https"], False),
    ("status", "up", "up", True),
    ("status", "up", "down", False),
    ("srcaddr", [{"name": "a"}, {"name": "b"}], ["b", "a"], True),
    ("srcaddr", [{"name": "a"}], ["a", "b"], False),
    ("mtu", "1500", 1500, True),
    ("mtu", "1500", 1400, False),
    ("tcp-mss-sender", "enable", True, True),
    ("tcp-mss-sender", "enable", False, False),
    ("description", "a b", "b a", False),   # free text is never compared as a set
])
def test_values_compare_the_way_fortios_stores_them(field, have, want, same):
    assert (fos.canon(field, have) == fos.canon(field, want)) is same


def test_values_are_sent_as_the_rest_api_wants_them():
    assert fos.wire("allowaccess", ["https", "ssh"]) == "https ssh"
    assert fos.wire("srcaddr", ["a", "b"]) == [{"name": "a"}, {"name": "b"}]
    assert fos.wire("ips-sniffer-mode", True) == "enable"
    assert fos.wire("anything", ["x"], current="a b") == "x"   # an option field is one string, whatever its name
    assert fos.wire("ip", "10.0.0.1 255.255.255.0") == "10.0.0.1 255.255.255.0"


def test_secrets_never_leave_the_device():
    out = fos.mask({"name": "admin", "password": "ENC xyz", "psksecret": "p", "api-key": "k", "nested": [{"passwd": "x"}],
                    "comment": "ENC looks-like-a-secret", "ip": "10.0.0.1"})
    assert out == {"name": "admin", "password": "<hidden>", "psksecret": "<hidden>", "api-key": "<hidden>",
                   "nested": [{"passwd": "<hidden>"}], "comment": "<hidden>", "ip": "10.0.0.1"}


@pytest.mark.parametrize("section,path", [("interfaces", "system/interface"), ("system/interface", "system/interface"),
                                          ("Policies", "firewall/policy"), ("vpn.ipsec/phase1-interface", "vpn.ipsec/phase1-interface")])
def test_a_section_is_an_alias_or_a_cmdb_path(section, path):
    assert fos.section_path(section) == path


@pytest.mark.parametrize("bad", ["system/./admin", "system/../system/admin", "firewall/./address", "system/.hidden",
                                 "system/admin/.", "./system/admin", "system//admin", "SYSTEM/./ADMIN"])
def test_a_dot_segment_cannot_reach_a_protected_section(bad):
    with pytest.raises(fos.DeviceError):
        fos.section_path(bad)


@pytest.mark.parametrize("bad", ["../../monitor/system/status", "system", "system/interface?x=1", "http://evil/x", "system/ interface", ""])
def test_a_section_cannot_become_another_url(bad):
    with pytest.raises(fos.DeviceError):
        fos.section_path(bad)


# ── reading ──────────────────────────────────────────────────────────────────

def test_config_without_a_section_lists_the_names_to_use(dev):
    assert "interfaces" in dev.run("config")["sections"]


def test_config_reads_a_table_and_hides_secrets(dev):
    out = dev.run("config", section="admins")
    assert out["key"] == "name" and out["objects"][0]["password"] == "<hidden>"
    assert out["count"] == 1


def test_config_reads_one_object_or_says_what_exists(dev):
    assert dev.run("config", section="interfaces", name="port2")["objects"][0]["status"] == "down"
    with pytest.raises(ToolError, match=r"no object 'port9'.*port1, port2"):
        dev.run("config", section="interfaces", name="port9")


def test_config_reads_a_single_object_section(dev):
    out = dev.run("config", section="dns")
    assert out["key"] is None and out["objects"][0]["primary"] == "208.91.112.53"


def test_reading_never_mints_the_write_key_or_writes(dev):
    dev.run("config", section="interfaces")
    assert {c[0] for c in dev.fake.calls} == {"ro"} and all(c[1].startswith("GET") for c in dev.fake.calls)


# ── changing: plan, approval, read-back ──────────────────────────────────────

def test_a_change_without_confirm_returns_a_real_before_after_and_writes_nothing(dev):
    out = dev.run("set", section="interfaces", name="port2", values={"ip": "10.0.2.1 255.255.255.0", "status": "up"})
    assert out["dry_run"] and out["op"] == "update"
    assert {c["field"]: (c["from"], c["to"]) for c in out["changes"]} == {
        "ip": ("0.0.0.0 0.0.0.0", "10.0.2.1 255.255.255.0"), "status": ("down", "up")}
    assert all(c[1].startswith("GET") for c in dev.fake.calls)


def test_the_plan_says_the_first_change_creates_the_write_user(dev):
    out = dev.run("set", section="addresses", name="lan", values={"comment": "x"})
    assert any("read-write API user" in w for w in out["warnings"])


def test_an_approved_change_is_applied_and_read_back(dev):
    out = dev.run("set", section="interfaces", name="port2", values={"ip": "10.0.2.1 255.255.255.0", "allowaccess": ["https", "ssh"]}, confirm=True)
    assert out["executed"] and out["verified"] and out["mismatches"] == []
    assert dev.fake.tables["system/interface"][1]["allowaccess"] == "https ssh"
    assert ("rw", "PUT cmdb/system/interface/port2") in dev.fake.calls


def test_a_change_that_is_already_in_place_is_a_noop(dev):
    out = dev.run("set", section="interfaces", name="port1", values={"allowaccess": ["ssh", "https", "ping"]}, confirm=True)
    assert out["noop"] and out["executed"] is False
    assert not any(c[0] == "rw" for c in dev.fake.calls)


def test_a_new_object_is_created_with_its_name(dev):
    out = dev.run("set", section="addresses", name="dmz", values={"subnet": "10.0.9.0 255.255.255.0"}, confirm=True)
    assert out["op"] == "create" and out["verified"]
    assert {"name": "dmz", "subnet": "10.0.9.0 255.255.255.0"} in dev.fake.tables["firewall/address"]


def test_a_numeric_object_key_is_sent_as_a_number(dev):
    dev.run("set", section="policies", name="2", values={"name": "deny", "action": "deny"}, confirm=True)
    assert dev.fake.tables["firewall/policy"][-1]["policyid"] == 2


def test_a_list_of_names_is_sent_as_a_table(dev):
    out = dev.run("set", section="policies", name="1", values={"srcaddr": ["lan", "dmz"]}, confirm=True)
    assert out["verified"] and dev.fake.tables["firewall/policy"][0]["srcaddr"] == [{"name": "lan"}, {"name": "dmz"}]


def test_a_single_object_section_is_changed_without_a_name(dev):
    out = dev.run("set", section="dns", values={"primary": "1.1.1.1"}, confirm=True)
    assert out["verified"] and dev.fake.tables["system/dns"]["primary"] == "1.1.1.1"


def test_a_change_the_device_does_not_keep_is_reported_unverified(dev):
    dev.fake.discard = True
    out = dev.run("set", section="interfaces", name="port2", values={"status": "up"}, confirm=True)
    assert out["executed"] and out["verified"] is False
    assert out["mismatches"] == [{"field": "status", "wanted": "up", "stored": "down"}]
    assert "does not hold" in out["warning"]


def test_a_rejected_change_names_what_fortios_said(dev):
    dev.fake.fail = {"msg": "FortiOS rejected the request (HTTP 424, error -5): a value is not valid for this field"}
    with pytest.raises(ToolError, match="not valid for this field"):
        dev.run("set", section="interfaces", name="port2", values={"status": "sideways"}, confirm=True)


def test_an_unknown_field_is_refused_with_the_real_ones(dev):
    with pytest.raises(ToolError, match=r"no field.*allowacess.*allowaccess"):
        dev.run("set", section="interfaces", name="port1", values={"allowacess": "ping"})


def test_a_table_section_needs_a_name_and_lists_the_choices(dev):
    with pytest.raises(ToolError, match=r"name says which one.*port1, port2"):
        dev.run("set", section="interfaces", values={"status": "up"})


def test_delete_plans_then_removes_and_confirms_it_is_gone(dev):
    plan = dev.run("delete", section="addresses", name="lan")
    assert plan["dry_run"] and plan["op"] == "delete" and plan["deletes"]["name"] == "lan"
    out = dev.run("delete", section="addresses", name="lan", confirm=True)
    assert out["executed"] and out["verified"] and dev.fake.tables["firewall/address"] == []


def test_deleting_what_is_not_there_is_a_noop(dev):
    assert dev.run("delete", section="addresses", name="ghost", confirm=True)["noop"]


def test_a_single_object_section_cannot_be_deleted(dev):
    with pytest.raises(ToolError, match="single-object"):
        dev.run("delete", section="dns")


@pytest.mark.parametrize("section", ["admins", "system/admin", "system/api-user", "system/accprofile"])
def test_the_accounts_the_tool_signs_in_with_are_not_changeable(dev, section):
    with pytest.raises(ToolError, match="could lock it out"):
        dev.run("set", section=section, name="admin", values={"accprofile": "x"}, confirm=True)
    assert dev.fake.calls == []


def test_a_change_to_the_network_warns_it_can_cut_access(dev):
    out = dev.run("set", section="interfaces", name="port2", values={"status": "up"})
    assert any("cut the tool's own access" in w for w in out["warnings"])


def test_a_bad_request_is_refused_before_any_pod_is_touched(dev, monkeypatch):
    monkeypatch.setattr(dev, "_target", lambda *a: pytest.fail("a pod was contacted"))
    for kw in ({"section": None, "values": {"a": 1}}, {"section": "interfaces", "name": "p", "values": None},
               {"section": "interfaces", "name": "p", "values": {"Bad Field": 1}},
               {"section": "interfaces", "name": "../x", "values": {"a": 1}},
               {"section": "interfaces", "name": "..", "values": {"a": 1}}):
        with pytest.raises(ToolError):
            dev.run("set", **kw)


def test_an_unknown_action_is_rejected(dev):
    with pytest.raises(ToolError, match="action must be"):
        dev.run("reboot")


def test_a_locked_pod_refuses_a_change_but_still_plans_it(dev, monkeypatch):
    def locked(host):
        raise ToolError("locked")
    monkeypatch.setattr(dev, "_refuse_if_locked", locked)
    assert dev.run("set", section="addresses", name="lan", values={"comment": "x"})["dry_run"]
    with pytest.raises(ToolError, match="locked"):
        dev.run("set", section="addresses", name="lan", values={"comment": "x"}, confirm=True)


def test_the_tool_is_registered_as_mutating_and_a_password_never_appears_in_an_error(dev):
    t = fos.Target(host="h", name="fgt", fabric="f", https_port=1, ssh_port=2, password="s3cret")
    assert "s3cret" not in repr(t)
    assert fos._scrub("login with s3cret failed", t) == "login with <hidden> failed"
    import fabric_studio.mcp.server as srv
    tool = next(x for x in srv.mcp._tool_manager.list_tools() if x.name == "device")
    assert tool.annotations.destructive_hint is True
    assert "ctx" not in tool.parameters["properties"] and "approval" not in tool.parameters["properties"]


# ── the key: minted once, replaced once, refused once ────────────────────────

class FakeResponse:
    def __init__(self, status, data=None):
        self.status_code, self._data = status, data or {}

    def json(self):
        return self._data


@pytest.fixture
def wire_(monkeypatch):
    import fabric_studio.mcp.fortios as f
    importlib.reload(f)
    f.forget()
    monkeypatch.setattr(f, "_store_key", lambda t, level, key: f._KEYS.__setitem__((t.ident, level), key))
    monkeypatch.setattr(f, "_drop_key", lambda t, level: f._KEYS.pop((t.ident, level), None))
    monkeypatch.setattr(f, "_load_key", lambda t, level: f._KEYS.get((t.ident, level)))
    f.target = f.Target(host="h", name="fgt", fabric="f", https_port=13000, ssh_port=11000, password="pw")
    f.minted = []
    return f


def test_a_key_is_minted_on_first_use_and_then_reused(wire_, monkeypatch):
    f = wire_
    monkeypatch.setattr(f, "mint", lambda t, level, **kw: (f.minted.append(level), f._store_key(t, level, "K1"), "K1")[2])
    monkeypatch.setattr(f, "_send", lambda t, key, m, p, params, body: FakeResponse(200, {"results": {"ok": 1}}))
    f.call(f.target, "ro", "GET", "monitor/system/status")
    f.call(f.target, "ro", "GET", "monitor/system/status")
    assert f.minted == ["ro"]


def test_a_rejected_stored_key_is_replaced_once(wire_, monkeypatch):
    f = wire_
    f._KEYS[(f.target.ident, "ro")] = "STALE"
    monkeypatch.setattr(f, "mint", lambda t, level, **kw: (f.minted.append(level), f._store_key(t, level, "FRESH"), "FRESH")[2])
    seen = []

    def send(t, key, m, p, params, body):
        seen.append(key)
        return FakeResponse(401 if key == "STALE" else 200, {"results": {}})
    monkeypatch.setattr(f, "_send", send)
    f.call(f.target, "ro", "GET", "monitor/system/status")
    assert seen == ["STALE", "FRESH"] and f.minted == ["ro"]


def test_a_key_the_device_still_refuses_after_minting_is_explained(wire_, monkeypatch):
    f = wire_
    monkeypatch.setattr(f, "mint", lambda t, level, **kw: (f._store_key(t, level, "K"), "K")[1])
    monkeypatch.setattr(f, "_send", lambda *a: FakeResponse(401))
    monkeypatch.setattr(f, "cli_read", lambda t, cmd, timeout_s=30: "Version: FortiGate-VM64-KVM v7.6.6\nLicense Status: Valid\n")
    with pytest.raises(f.DeviceError, match="refused a freshly created API key"):
        f.call(f.target, "ro", "GET", "monitor/system/status")


def test_an_unlicensed_device_is_named_as_the_reason_a_key_is_refused(wire_, monkeypatch):
    f = wire_
    monkeypatch.setattr(f, "mint", lambda t, level, **kw: (f._store_key(t, level, "K"), "K")[1])
    monkeypatch.setattr(f, "_send", lambda *a: FakeResponse(401))
    monkeypatch.setattr(f, "cli_read", lambda t, cmd, timeout_s=30: "License Status: Invalid\nHostname: x\n")
    with pytest.raises(f.DeviceError, match=r"unlicensed \(evaluation\) FortiGate VM"):
        f.call(f.target, "ro", "GET", "monitor/system/status")


def test_a_refused_login_is_not_retried_inside_the_cooldown(wire_, monkeypatch):
    f = wire_
    f._REFUSED[f.target.ident] = (9e12, "fgt refused the login; will not retry")
    with pytest.raises(f.LoginRefused, match="will not retry"):
        f.mint(f.target, "ro")


def test_fortios_errors_carry_their_meaning(wire_):
    f = wire_
    r = FakeResponse(424, {"http_status": 424, "status": "error", "error": -15, "cli_error": "duplicate entry"})
    with pytest.raises(f.DeviceError, match=r"already exists.*duplicate entry"):
        f._unwrap(f.target, r, "rw")
    with pytest.raises(f.DeviceError, match="does not allow that"):
        f._unwrap(f.target, FakeResponse(403, {"http_status": 403}), "ro")


def test_a_pod_can_be_named_by_its_registered_name_or_host(dev, monkeypatch):
    monkeypatch.setattr(dev.inst, "load_registry", lambda: {"10.0.0.5": {"name": "pod-a"}, "10.0.0.6": {"name": "pod-b"}})
    assert dev._pod_host("pod-a") == "10.0.0.5" and dev._pod_host("POD-B") == "10.0.0.6"
    assert dev._pod_host("10.0.0.5") == "10.0.0.5" and dev._pod_host("unknown") == "unknown"


def test_status_says_plainly_whether_the_device_is_licensed(dev):
    out = dev._license({"forticare": {"registration_status": "registered",
                                      "support": {"comprehensive": {"support_level": "Premium", "expires": 1807660800}}}})
    assert out == {"licensed": True, "support_level": "Premium", "support_expires": "2027-04-14"}
    assert dev._license({})["licensed"] is False
