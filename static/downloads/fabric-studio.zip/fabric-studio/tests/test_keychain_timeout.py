"""A keyring read that never returns (a macOS access dialog waiting) fails fast."""
import threading

import pytest

from fabric_studio import keychain


def test_blocked_keyring_raises_instead_of_hanging(monkeypatch):
    gate = threading.Event()
    monkeypatch.setattr(keychain.keyring, "get_password", lambda s, a: gate.wait(5) and None)
    monkeypatch.setenv("FSH_KEYCHAIN_TIMEOUT_S", "0.2")
    monkeypatch.setattr(keychain, "_security_cli", lambda a, s: (False, None))   # it blocks too
    with pytest.raises(keychain.KeychainBlocked, match="Always Allow"):
        keychain.get_secret("pod-default")
    gate.set()


def test_blocked_keyring_falls_back_to_security_cli(monkeypatch):
    gate = threading.Event()
    monkeypatch.setattr(keychain.keyring, "get_password", lambda s, a: gate.wait(5) and None)
    monkeypatch.setenv("FSH_KEYCHAIN_TIMEOUT_S", "0.2")
    monkeypatch.setattr(keychain, "_security_cli", lambda a, s: (True, "from-security"))
    assert keychain.get_secret("x") == "from-security"
    gate.set()


def test_answering_keyring_returns_value(monkeypatch):
    monkeypatch.setattr(keychain.keyring, "get_password", lambda s, a: "pw")
    assert keychain.get_secret("x") == "pw"


def test_keyring_error_degrades_to_none(monkeypatch):
    def boom(s, a):
        raise keychain.keyring.errors.KeyringError("locked")
    monkeypatch.setattr(keychain.keyring, "get_password", boom)
    assert keychain.get_secret("x") is None


def test_blocked_write_raises_instead_of_hanging(monkeypatch):
    gate = threading.Event()
    monkeypatch.setattr(keychain.keyring, "set_password", lambda s, a, p: gate.wait(5))
    monkeypatch.setenv("FSH_KEYCHAIN_TIMEOUT_S", "0.2")
    with pytest.raises(keychain.KeychainBlocked):
        keychain.set_secret("x", "v")
    gate.set()


def test_delete_of_a_missing_item_is_false(monkeypatch):
    def gone(s, a):
        raise keychain.keyring.errors.PasswordDeleteError("none")
    monkeypatch.setattr(keychain.keyring, "delete_password", gone)
    assert keychain.delete_secret("x") is False
