"""The firmware tool: workspace-only uploads, a refresh after import, the name to use in image:."""
import pytest
from conftest import import_server
from mcp.server.mcpserver.exceptions import ToolError

import_server()
import importlib

fw = importlib.import_module("fabric_studio.mcp.firmware")
call = fw.firmware.__wrapped__ if hasattr(fw.firmware, "__wrapped__") else fw.firmware


class Pod:
    def __init__(self):
        self.rows, self.pending, self.refreshes, self.uploads, self.timeout_s = [], [], 0, [], 60


@pytest.fixture
def pod(monkeypatch, tmp_path):
    p = Pod()
    monkeypatch.setenv("FS_WORKSPACE", str(tmp_path))
    monkeypatch.setattr(fw, "_client", lambda h: p)
    monkeypatch.setattr(fw.fs_admin, "list_home_firmwares", lambda c: list(p.rows))

    def upload(c, path, dest_name=None):
        p.uploads.append(dest_name)
        p.pending.append({"id": 900, "name": dest_name, "path": f"firmwares/{dest_name}", "vm_type": "LXC",
                          "status": "ready", "size": 5})

    def refresh(c):   # an import is listed only after a refresh
        p.refreshes += 1
        p.rows += p.pending
        p.pending.clear()
    monkeypatch.setattr(fw.fs_admin, "upload_firmware", upload)
    monkeypatch.setattr(fw.fs_admin, "refresh_home_repository", refresh)
    monkeypatch.setattr(fw.time, "sleep", lambda s: None)
    return p


def test_upload_refreshes_and_returns_the_image_name(pod, tmp_path):
    (tmp_path / "LXC_x_toolbox_amd64.zip").write_bytes(b"zip")
    plan = call("upload", host="h", path="LXC_x_toolbox_amd64.zip")
    assert plan["dry_run"] and not pod.uploads
    out = call("upload", host="h", path="LXC_x_toolbox_amd64.zip", confirm=True)
    assert out["uploaded"] and pod.refreshes >= 1 and out["firmware"]["id"] == 900
    assert out["use_as"] == "image: 'LXC_x_toolbox_amd64.zip'"


def test_a_name_already_on_the_pod_is_not_uploaded_again(pod, tmp_path):
    (tmp_path / "a.qcow2").write_bytes(b"q")
    pod.rows.append({"id": 1, "name": "a.qcow2", "path": "firmwares/a.qcow2", "vm_type": "BASIC"})
    out = call("upload", host="h", path="a.qcow2", confirm=True)
    assert out["uploaded"] is False and not pod.uploads


def test_files_outside_the_workspace_are_refused(pod, tmp_path):
    outside = tmp_path.parent / "secret.qcow2"
    outside.write_bytes(b"x")
    with pytest.raises(ToolError, match="workspace"):
        call("upload", host="h", path=str(outside), confirm=True)
    (tmp_path / "notes.txt").write_text("x")
    with pytest.raises(ToolError, match="not a firmware"):
        call("upload", host="h", path="notes.txt", confirm=True)
