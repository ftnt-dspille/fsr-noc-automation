"""The device tool's second way in: the CLI over SSH, for when the API is not available.

Parsing is checked against text shaped like real ``show full-configuration`` output; the session is a scripted
fake, so what is verified is which lines are sent, in what order, and what happens on a refusal."""
from __future__ import annotations

import asyncio
import importlib

import pytest
from conftest import import_server
from mcp.server.mcpserver.exceptions import ToolError

from fabric_studio.mcp import fortios as fos
from fabric_studio.mcp import fortios_cli as cli

ADDRESSES = '''config firewall address
    edit "all"
        set uuid 1b4c0d3e-0000-0000-0000-000000000001
        set subnet 0.0.0.0 0.0.0.0
    next
    edit "lan one"
        set subnet 10.0.1.0 255.255.255.0
        set comment "the \\"main\\" lan"
    next
    edit "wildcard.google.com"
        set type fqdn
        set fqdn "*.google.com"
    next
end
'''
GROUP = '''config firewall addrgrp
    edit "g1"
        set member "all" "lan one"
    next
    edit "g2"
        set member "all"
    next
end
'''
POLICY = '''config firewall policy
    edit 1
        set name "allow"
        set srcintf "port2"
        set action accept
        config sub
            edit 7
                set x 1
            next
        end
    next
end
'''
DNS = '''config system dns
    set primary 8.8.8.8
    set secondary 0.0.0.0
    set protocol dot
end
'''
IFACE = '''config system interface
    edit "port1"
        set ip 10.254.254.30 255.255.255.0
        set allowaccess ping https ssh
        set status up
    next
end
'''


def test_quoted_words_keep_their_spaces_and_escapes():
    assert cli.tokenize('set comment "the \\"main\\" lan" x') == [("set", False), ("comment", False),
                                                                ('the "main" lan', True), ("x", False)]


def test_a_table_is_parsed_into_the_objects_the_api_would_return():
    key, objs = cli.parse(ADDRESSES, "firewall/address")
    assert key == "name" and [o["name"] for o in objs] == ["all", "lan one", "wildcard.google.com"]
    assert objs[1]["subnet"] == "10.0.1.0 255.255.255.0"            # bare words are one string
    assert objs[1]["comment"] == 'the "main" lan'
    assert objs[2]["fqdn"] == "*.google.com"


def test_several_quoted_words_are_a_table_and_one_is_text():
    _, objs = cli.parse(GROUP, "firewall/addrgrp")
    assert objs[0]["member"] == ["all", "lan one"] and objs[1]["member"] == "all"


def test_a_numeric_edit_is_named_the_way_the_api_names_it_and_sub_tables_nest():
    key, objs = cli.parse(POLICY, "firewall/policy")
    assert key == "policyid" and objs[0]["policyid"] == "1" and "id" not in objs[0]
    assert objs[0]["sub"] == [{"id": "7", "x": "1"}]


def test_a_single_object_section_is_one_object_and_an_empty_table_is_an_empty_list():
    assert cli.parse(DNS, "system/dns") == (None, [{"primary": "8.8.8.8", "secondary": "0.0.0.0", "protocol": "dot"}])
    assert cli.parse("config firewall policy\nend\n", "firewall/policy") == ("policyid", [])
    assert cli.parse("config firewall address\nend\n", "firewall/address") == (None, [])


def test_an_empty_string_is_printed_by_fortios_as_two_single_quotes_and_read_as_empty():
    _, objs = cli.parse("config system interface\n    edit \"port2\"\n        set description ''\n    next\nend\n", "system/interface")
    assert objs[0]["description"] == "" and fos.same("description", objs[0]["description"], "")


def test_one_named_object_is_read_with_its_own_command_and_a_missing_one_is_empty(shell):
    shell.replies['show full-configuration system interface "port2"'] = IFACE.replace("port1", "port2")
    key, objs = cli.read_objects(T, "system/interface", None, "port2")
    assert key == "name" and objs[0]["name"] == "port2"
    assert shell.sent == ['show full-configuration system interface "port2"']
    shell.replies['show full-configuration system interface "nope"'] = "entry not found in datasource"
    assert cli.read_objects(T, "system/interface", None, "nope") == ("name", [])
    shell.replies["show full-configuration firewall policy 1900"] = "entry not found in datasource"
    assert cli.read_objects(T, "firewall/policy", None, "1900") == ("policyid", [])


def test_what_is_parsed_compares_equal_to_what_the_api_holds():
    _, objs = cli.parse(IFACE, "system/interface")
    assert fos.diff(objs[0], {"allowaccess": ["https", "ssh", "ping"], "status": "up"}) == []
    assert fos.diff(objs[0], {"status": "down"})[0] == {"field": "status", "from": "up", "to": "down"}


@pytest.mark.parametrize("field,value,current,text", [
    ("status", "up", None, "up"),
    ("subnet", "10.0.2.0 255.255.255.0", None, "10.0.2.0 255.255.255.0"),
    ("comment", "a b", None, '"a b"'),
    ("comment", "dead beef", None, '"dead beef"'),     # letters that are also hex digits are still words
    ("range", "10.0.0.1 10.0.0.9", None, "10.0.0.1 10.0.0.9"),
    ("ip6", "fe80::1 64", None, "fe80::1 64"),
    ("comment", 'say "hi"\\', None, '"say \\"hi\\"\\\\"'),
    ("allow-routing", True, None, "enable"),
    ("mtu", 1400, None, "1400"),
    ("member", ["a", "b c"], None, '"a" "b c"'),
    ("allowaccess", ["https", "ssh"], None, "https ssh"),
    ("something", ["x"], "a b", "x"),     # an option list is bare words when the device holds one string
])
def test_values_are_spelled_for_the_cli(field, value, current, text):
    assert cli.cli_value(field, value, current) == text


@pytest.mark.parametrize("value", ["a\nb", "a\rconfig system admin", "x\x00y", ["ok", "bad\nname"], {"a": 1}, [["x"]]])
def test_a_value_that_could_become_another_command_is_refused(value):
    with pytest.raises(fos.DeviceError):
        cli.cli_value("comment", value)


def test_an_object_name_cannot_break_out_of_its_quotes():
    assert cli._name('a"b') == '"a\\"b"' and cli._name("12") == "12"
    with pytest.raises(fos.DeviceError):
        cli._name("a\nb")


def test_scripts_for_each_kind_of_change():
    assert cli.script("firewall/address", "name", "x", "create", {"subnet": "10.0.0.0 255.0.0.0"}, None) == [
        "config firewall address", 'edit "x"', "set subnet 10.0.0.0 255.0.0.0", "next", "end"]
    assert cli.script("firewall/policy", "policyid", "1900", "update", {"action": "accept"}, {}) == [
        "config firewall policy", "edit 1900", "set action accept", "next", "end"]
    assert cli.script("system/dns", None, None, "update", {"primary": "1.1.1.1"}, {}) == [
        "config system dns", "set primary 1.1.1.1", "end"]
    assert cli.script("firewall/address", "name", "x", "delete", {}, {}) == [
        "config firewall address", 'delete "x"', "end"]
    assert cli.script("vpn.ipsec/phase1-interface", "name", "t", "update", {"comment": ""}, {})[:3] == [
        "config vpn ipsec phase1-interface", 'edit "t"', "unset comment"]   # empty is unset, not a quoted empty string


class FakeShell:
    """Answers each line from a table; anything not listed prints nothing, as a line that worked does."""

    def __init__(self, replies=None):
        self.sent, self.replies = [], replies or {}

    async def run(self, line, timeout_s=60):
        self.sent.append(line)
        return self.replies.get(line, "")


@pytest.fixture
def shell(monkeypatch):
    sh = FakeShell()
    monkeypatch.setattr(cli, "session", lambda t, fn, timeout_s=180: asyncio.run(fn(sh)))
    return sh


T = fos.Target(host="pod", name="fgt", fabric="f", https_port=13000, ssh_port=11000, password="s3cret")


def test_a_change_is_sent_one_line_at_a_time(shell):
    cli.apply(T, "create", "firewall/address", "name", "x", {"subnet": "10.0.0.0 255.0.0.0"}, None)
    assert shell.sent == ["config firewall address", 'edit "x"', "set subnet 10.0.0.0 255.0.0.0", "next", "end"]


def test_the_first_refused_line_aborts_the_context_and_is_reported(shell):
    shell.replies['set subnet nonsense'] = "value parse error before 'nonsense'\nCommand fail. Return code -5"
    with pytest.raises(fos.DeviceError, match=r"rejected the line 'set subnet nonsense'.*not valid.*value parse error"):
        cli.apply(T, "create", "firewall/address", "name", "x", {"subnet": "nonsense"}, None)
    assert shell.sent[-1] == "abort" and "next" not in shell.sent and "end" not in shell.sent


def test_a_secret_never_appears_in_a_rejection(shell):
    shell.replies["set password hunter2"] = "Command fail. Return code -5"
    with pytest.raises(fos.DeviceError) as e:
        cli.apply(T, "update", "user/local", "name", "bob", {"password": "hunter2"}, {})
    assert "hunter2" not in str(e.value) and "<hidden>" in str(e.value)


def test_validate_sends_the_real_lines_and_aborts_instead_of_committing(shell):
    cli.validate(T, "update", "firewall/address", "name", "x", {"comment": "c"}, {"name": "x"})
    assert shell.sent == ["config firewall address", 'edit "x"', "set comment c", "abort"]
    shell.sent.clear()
    cli.validate(T, "update", "system/dns", None, None, {"primary": "1.1.1.1"}, {})
    assert shell.sent == ["config system dns", "set primary 1.1.1.1", "abort"]


def test_validate_reports_a_field_the_section_does_not_have(shell):
    shell.replies["set subnett 10.0.0.0 255.0.0.0"] = "node_check_object fail! for subnett 10.0.0.0 255.0.0.0"
    with pytest.raises(fos.DeviceError, match="rejected the line 'set subnett"):
        cli.validate(T, "update", "firewall/address", "name", "x", {"subnett": "10.0.0.0 255.0.0.0"}, {"name": "x"})
    assert shell.sent[-1] == "abort"


def test_a_vdom_is_entered_and_left(shell):
    cli.apply(T, "update", "system/dns", None, None, {"primary": "1.1.1.1"}, {}, vdom="root")
    assert shell.sent[:2] == ["config vdom", 'edit "root"'] and shell.sent[-1] == "end"


def test_the_pager_is_advanced_and_a_confirmation_is_never_answered_yes():
    """The session itself, against a scripted stream."""
    class Stream:
        def __init__(self, chunks):
            self.chunks = list(chunks)

        async def read(self, n):
            if self.chunks:
                await asyncio.sleep(0)
                return self.chunks.pop(0)
            await asyncio.sleep(10)

    class Stdin:
        def __init__(self):
            self.written = []

        def write(self, s):
            self.written.append(s)

        async def drain(self):
            pass

    class Proc:
        def __init__(self, chunks):
            self.stdout, self.stdin = Stream(chunks), Stdin()

    async def go(chunks, line="get system status"):
        sh = cli._Shell(Proc(chunks), T)
        return sh, await sh.run(line, timeout_s=5)

    async def paged():
        proc = Proc(["get system status\r\nVersion: v7.6.6\r\n--More-- "])
        sh = cli._Shell(proc, T)
        task = asyncio.create_task(sh.run("get system status", timeout_s=5))
        await asyncio.sleep(0.8)
        proc.stdout.chunks.append("License Status: Valid\r\nfgt # ")
        return proc, await task

    proc, out = asyncio.run(paged())
    assert " " in proc.stdin.written and "Version: v7.6.6" in out and "License Status: Valid" in out
    assert "--More--" not in out and not out.rstrip().endswith("#")

    async def confirm():
        sh = cli._Shell(Proc(["execute x\r\nDo you want to continue? (y/n)"]), T)
        with pytest.raises(fos.DeviceError, match="never answers yes"):
            await sh.run("execute x", timeout_s=5)
        return sh.proc.stdin.written
    assert asyncio.run(confirm())[-1] == "n\r"


# ── the tool falls back to the CLI ───────────────────────────────────────────

@pytest.fixture
def dev(monkeypatch):
    import_server()
    mod = importlib.import_module("fabric_studio.mcp.device")
    fos.forget()
    objs = {"system/interface": [{"name": "port2", "status": "down", "description": ""}]}
    calls = []

    def no_api(*a, **k):
        raise fos.RestUnavailable("fgt is an unlicensed (evaluation) FortiGate VM. License it first.")
    monkeypatch.setattr(fos, "call", no_api)
    monkeypatch.setattr(fos, "read_objects", no_api)
    monkeypatch.setattr(cli, "read_objects", lambda t, path, vdom=None, name=None: ("name", [dict(o) for o in objs[path]]))
    monkeypatch.setattr(cli, "validate", lambda *a, **k: calls.append("validate"))
    monkeypatch.setattr(cli, "apply", lambda t, op, path, key, name, values, cur, vdom=None:
                        (calls.append(f"apply {op} {name}"), objs[path][0].update(values)))
    monkeypatch.setattr(mod, "_target", lambda *a: T)
    monkeypatch.setattr(mod, "_refuse_if_locked", lambda h: None)
    mod.calls = calls
    mod.run = lambda action, **kw: mod.device.__wrapped__(action=action, host="pod", device="fgt", **kw)
    return mod


def test_reading_falls_back_to_ssh_and_says_so(dev):
    out = dev.run("config", section="interfaces")
    assert out["via"] == "cli" and out["objects"][0]["name"] == "port2"


def test_a_plan_over_ssh_validates_the_change_and_warns_how_it_will_go(dev):
    out = dev.run("set", section="interfaces", name="port2", values={"status": "up"})
    assert out["via"] == "cli" and out["changes"] == [{"field": "status", "from": "down", "to": "up"}]
    assert dev.calls == ["validate"]
    assert any("goes over SSH as the admin account" in w and "unlicensed" in w for w in out["warnings"])
    assert not any("read-write API user" in w for w in out["warnings"])


def test_an_approved_change_over_ssh_is_applied_and_read_back(dev):
    out = dev.run("set", section="interfaces", name="port2", values={"status": "up"}, confirm=True)
    assert out["executed"] and out["verified"] and out["via"] == "cli"
    assert dev.calls == ["validate", "apply update port2"]


def test_a_noop_over_ssh_makes_no_change_and_no_check(dev):
    out = dev.run("set", section="interfaces", name="port2", values={"status": "down"}, confirm=True)
    assert out["noop"] and dev.calls == []


def test_an_unknown_field_is_left_to_fortios_over_ssh(dev, monkeypatch):
    """The CLI hides empty fields, so it cannot be told a field does not exist; FortiOS says so on validate."""
    def refuse(*a, **k):
        raise fos.DeviceError("FortiOS rejected the line 'set statuz up'")
    monkeypatch.setattr(cli, "validate", refuse)
    with pytest.raises(ToolError, match="rejected the line 'set statuz up'"):
        dev.run("set", section="interfaces", name="port2", values={"statuz": "up"})


def test_status_falls_back_to_ssh(dev, monkeypatch):
    monkeypatch.setattr(cli, "status", lambda t: {"device": "fgt", "version": "v7.6.6", "license": {"licensed": False}})
    out = dev.run("status")
    assert out["via"] == "cli" and out["version"] == "v7.6.6" and out["api"].startswith("not available")


def test_a_refused_login_is_not_a_reason_to_try_the_other_way(dev, monkeypatch):
    def refused(*a, **k):
        raise fos.LoginRefused("fgt refused the login; will not retry")
    monkeypatch.setattr(fos, "read_objects", refused)
    monkeypatch.setattr(cli, "read_objects", lambda *a, **k: pytest.fail("tried SSH after a refused login"))
    with pytest.raises(ToolError, match="will not retry"):
        dev.run("config", section="interfaces")


def test_the_status_of_the_api_does_not_change_the_answer_when_it_works(dev, monkeypatch):
    monkeypatch.setattr(fos, "read_objects", lambda t, path, vdom=None: ("name", [{"name": "port2", "status": "down"}]))
    assert dev.run("config", section="interfaces")["via"] == "api"


def test_a_failed_https_probe_is_the_api_being_unavailable_not_the_device_being_gone(monkeypatch):
    import requests
    fos.forget()
    monkeypatch.setattr(requests, "request", lambda *a, **k: (_ for _ in ()).throw(requests.exceptions.ConnectTimeout()))
    with pytest.raises(fos.RestUnavailable, match="cannot reach fgt over HTTPS"):
        fos._send(T, "k", "GET", "monitor/system/status", None, None)


def test_prompt_after_an_error_line_on_fortimanager():
    """FortiManager's config-mode prompt has no hostname; after an error line it must still be seen."""
    from fabric_studio.mcp import fortios as f
    assert f.CLI_PROMPT_RX.search("set allowaccess fgfm\n\ncommand parse error before 'fgfm'\n\n(port2)#")
    assert f.CLI_PROMPT_RX.search("fgt1 (port2) # ")
    assert not f.CLI_PROMPT_RX.search("set comment '(port2)#' and more")
