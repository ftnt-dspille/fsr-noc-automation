"""The consolidated read-only tools (pods, fabric, vm, tasks) route to the right implementation."""
from __future__ import annotations

import asyncio

import pytest
from conftest import import_server
from mcp.server.mcpserver.exceptions import ToolError


@pytest.fixture
def s(monkeypatch):
    m = import_server()
    for n in ("whats_up", "pod_health", "pods_health", "list_firmwares", "find_device", "licenses_overview",
              "fs_license_pool", "forticloud_status", "list_vms", "fabric_topology", "vm_state", "vm_access",
              "device_credentials_hint", "task_log", "list_tasks"):
        monkeypatch.setattr(m, n, lambda *a, _n=n, **k: {"called": _n, "args": a, "kw": k})
    monkeypatch.setattr(m, "_client", lambda host: object())
    monkeypatch.setattr(m, "resolve_fabric_id", lambda c, fabric: 1)
    return m


def test_the_server_exposes_a_small_tool_set():
    names = {t.name for t in asyncio.run(import_server().mcp.list_tools())}
    assert {"pods", "fabric", "vm", "tasks", "diagnose", "build", "device"} <= names
    assert "list_pods" not in names and "vm_state" not in names and len(names) == 17


def test_pods_routes_each_view(s):
    assert s.pods("online")["called"] == "whats_up"
    assert s.pods("health", host="h")["called"] == "pod_health"
    assert s.pods("health")["called"] == "pods_health"
    assert s.pods("firmwares", host="h", vm_type="FGT")["args"][:2] == ("h", "FGT")
    assert s.pods("find", query="fmg")["called"] == "find_device"
    assert set(s.pods("licenses", host="h")) == {"overview", "pool", "forticloud"}


def test_pods_rejects_unknown_views_and_missing_arguments(s):
    with pytest.raises(ToolError, match="unknown view"):
        s.pods("nope")
    with pytest.raises(ToolError, match="needs host"):
        s.pods("firmwares")
    with pytest.raises(ToolError, match="needs query"):
        s.pods("find")


def test_fabric_returns_requested_sections_and_isolates_a_failing_one(s, monkeypatch):
    def boom(*a, **k):
        raise RuntimeError("pod said no")

    monkeypatch.setattr(s, "fabric_topology", boom)
    out = s.fabric("h", include=["vms", "topology"])
    assert out["vms"]["called"] == "list_vms" and "pod said no" in out["topology"]["error"]
    assert list(s.fabric("h")) == ["vms"]
    with pytest.raises(ToolError, match="unknown include"):
        s.fabric("h", include=["nope"])


def test_vm_sections(s):
    out = asyncio.run(s.vm("h", vm="fmg", include=["state", "credentials"]))
    assert out["state"]["called"] == "vm_state" and out["credentials"]["args"][:2] == ("h", "fmg")
    with pytest.raises(ToolError, match="unknown include"):
        asyncio.run(s.vm("h", include=["nope"]))


def test_tasks_reads_a_log_when_given_an_id(s):
    assert s.tasks("h", task_id=1309)["called"] == "task_log"
    assert s.tasks("h", vm="faz")["called"] == "list_tasks"


def test_guest_checks_refuse_a_non_soar_vm_before_connecting(monkeypatch):
    import logging

    s = import_server()
    monkeypatch.setattr(s, "_resolve", lambda *a, **k: (object(), 1, {"id": 3, "name": "faz", "vm_type": "FAZ"}))
    monkeypatch.setattr(s, "_jump_exec", lambda *a, **k: pytest.fail("must not open an SSH session"))
    for fn in (s.read_guest_license, s.guest_config_status, s.validate_license_match):
        with pytest.raises(ToolError, match="FortiSOAR"):
            asyncio.run(fn("h", vm="faz"))
    with pytest.raises(ToolError, match="FortiSOAR"):        # every requested section failed alike: the call fails
        asyncio.run(s.vm("h", vm="faz", include=["guest_license"]))
    assert logging.getLogger("asyncssh").level >= logging.WARNING  # a guest command line carries the password


def test_guest_login_comes_only_from_the_environment(monkeypatch):
    s = import_server()
    for k in ("FS_SOAR_SSH_USER", "FS_SOAR_SSH_PASS", "VM_USER_SOAR01", "VM_PASS_SOAR01"):
        monkeypatch.delenv(k, raising=False)
    with pytest.raises(ToolError, match="FS_SOAR_SSH_PASS"):
        s._ssh_creds()  # no built-in default password
    monkeypatch.setenv("FS_SOAR_SSH_PASS", "x")
    assert s._ssh_creds() == ("csadmin", "x")
    import inspect
    for fn in (s.read_guest_license, s.guest_config_status, s.validate_license_match, s.vm):
        assert not {"ssh_user", "ssh_pass"} & set(inspect.signature(fn).parameters)


def test_when_every_section_fails_alike_the_call_fails(s, monkeypatch):
    def down(*a, **k):
        raise ToolError("cannot reach h over HTTPS: it timed out")

    for n in ("fabric_topology", "fabric_resources", "system_host", "list_vms"):
        monkeypatch.setattr(s, n, down)
    monkeypatch.setitem(s._FABRIC_SECTIONS, "vms", lambda host, fabric: down())
    with pytest.raises(ToolError, match="cannot reach h"):
        s.fabric("h", include=["vms"])
