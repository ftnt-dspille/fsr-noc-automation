# fabric-studio

A Python library for working with [Fabric Studio](https://www.fortinet.com) pods (the Fortinet lab
platform that succeeds FortiPoC), and an **MCP server** that lets Claude inspect and operate them in
plain language.

## What's in it

| Module | What |
|---|---|
| `fabric_studio.client` | Fabric Studio REST client with a per-pod login guard |
| `fabric_studio.admin` | The Fabric Studio mutation API: fabrics, VMs, power, firmware, snapshots, licenses, access, networks, tasks |
| `fabric_studio.resolve` | Names to ids; a SOAR guest's management address |
| `fabric_studio.keychain`, `.credentials` | Pod and device logins from the OS keychain, environment or database |
| `fabric_studio.channels` | SSH, jump-host and console transports to the devices behind a pod |
| `fabric_studio.parsers` | Device CLI output (FortiOS, FortiManager, FortiSOAR) to data |
| `fabric_studio.pod` | Pod runtime adapters and port helpers |
| `fabric_studio.mcp` | The MCP server (`fabric-studio-mcp`); needs the `mcp` extra |
| `skills/fabric-studio/` | An agent skill that teaches an agent to use the library and the MCP server |

The rest (`pod_shell`, `topology_graph`, `settings`, `crypto`, `db`, `models`) are internals the above
build on.

## Install

This is not published to PyPI. Python 3.11 or later; [uv](https://docs.astral.sh/uv/) fetches it if you lack it.
Download the repository as a zip (the Fabric Studio docs, MCP server chapter, Install page, carry the
current one), or use a checkout of this repository, then install from the folder:

```bash
unzip fabric-studio.zip

# the MCP server, as a standalone command
uv tool install "./fabric-studio[mcp]"

# the library, into a project environment
uv pip install ./fabric-studio
```

For development: `uv sync --extra mcp` in a checkout, then `uv run pytest`.

## For agents

`skills/fabric-studio/SKILL.md` is a skill any coding agent can read: how to connect, the model-versus-runtime
split, which function does which job, and the mistakes that cost people real runs. `api-index.md` beside
it lists every function. A test keeps both in step with the code.

For Claude Code, copy the folder into place:

```bash
cp -r skills/fabric-studio ~/.claude/skills/        # all your projects
cp -r skills/fabric-studio .claude/skills/          # one project
```

Other agents can be pointed at `SKILL.md` directly.

## The MCP server

```bash
claude mcp add fabric-studio --scope user -- fabric-studio-mcp
```

Put the name first: `--env` takes several values, so `claude mcp add --env K=V fabric-studio ...`
swallows the server name. For Claude Desktop, use the full path from `which fabric-studio-mcp` as the
`command` in `claude_desktop_config.json`.

It has 19 tools, few and broad on purpose. Five read:

| Tool | Use it for |
|---|---|
| `pods` | Anything about pods. Pick a `view`: `online`, `overview`, `health`, `licenses`, `reach`, `lockouts`, `instances`, `known`, `find`, `firmwares`, `snapshots`. |
| `fabric` | One fabric. `include` any of `fabrics`, `vms`, `topology`, `resources`, `system_host`. |
| `vm` | One VM. `include` any of `state`, `detail`, `access`, `disks`, `license`, `license_match`, `guest_license`, `guest_config`, `credentials`. |
| `tasks` | Running tasks and a VM's recent ones; with a `task_id`, that task's log (the reason an install failed). |
| `diagnose` | Start here when something is failing: checks every VM and returns ranked findings. |

Three do more than one thing: `build` makes a whole fabric from a topology (`topologies`, `examples`, `validate`,
`plan`, `apply`, `status`; `examples` shows how the topologies it can see already do a thing, such as a client
behind a FortiGate or a Linux guest with key login, as YAML to copy); `device` looks at and configures a FortiGate by name (`status`, `config`, `set`, `delete`); and
`run` runs a command over SSH or makes an API call on any device whose access is public (FortiManager and
FortiAnalyzer calls go through a JSON-RPC session: `run api="get /dvmdb/adom/root/device"`). All three are read-only
except for an approved change: `apply`, `set`, `delete` and any `run` that is not a plain read show a plan first.
`device` reads the device's configuration as structured data, shows the real before and after of a change, and reads
the result back to say whether the device kept it. It uses the device's API when that accepts it and its command
line over SSH when it does not (an unlicensed VM refuses API keys), and says which in `via`.

`register` connects a FortiGate to a FortiManager or FortiAnalyzer of the same fabric: it reads what is in
place, plans only the missing steps (the manager's API permission, accepting FortiGate VMs, pointing the gate at
the manager, authorizing it), and passes the gate's login from Fabric Studio straight to the manager.

Seven change a pod (`set_vm_access_public`, `install_system_host`, `set_vm_port_dhcp`,
`set_vm_port_auto`, `snapshot_vm`, which takes a `diff` or `full` snapshot of a VM, `vm_lifecycle`, which
turns a VM `on` or `off`, `restart`s or `reinstall`s it, or cancels a stuck task, and `set_vm_license`, which
chooses `NONE` (unlicensed) or `AUTO` for a VM) and three change the local registry (`add_instance`, `remove_instance`,
`engage_lockout`). Every tool carries MCP
annotations (read-only, or destructive for the pod-changing ones), so a client can prompt correctly.

The pod-changing ones report what they would do until you pass `confirm=true`. Even then the agent
cannot approve for you: the server runs the change as a dry run, then **asks you** (MCP elicitation)
to approve that exact plan, and runs it only if you say yes. A client that cannot ask gets a refusal;
set `FS_MCP_ASSUME_CONFIRMED=1` in the server's environment for an unattended run. Several of these
reinstall the guest unless you ask for `reinstall=false`.

A pod that carries a lockout refuses `vm_lifecycle` and `set_vm_license`: a lockout is a deliberate freeze,
and the server cannot lift one. While a change runs, the server sends the client a progress update every
ten seconds.

Besides tools, the server offers **resources** you can attach (`fabric-studio://pods`,
`fabric-studio://pods/<host>/fabric`, `fabric-studio://pods/<host>/firmwares`) and **prompts** you can pick
(`troubleshoot-failed-install`, `snapshot-before-change`, `pod-health-check`; slash commands in Claude Code).

When a fabric is failing and you do not know why, start with `diagnose`: one read-only call that checks
every VM, reads the logs of failed installs, and returns ranked findings with the next step.

### Connect a pod

The server keeps a registry of pods at `~/.fsh/instances.json`. It stores hostnames and where each
login lives, never a password. Create `~/.fsh/.env.mypod` (mode 600):

```bash
FS_POD_HOST=fabric-studio.example.com
FS_POD_USER=admin
FS_POD_PASS=<your-password>
```

then ask Claude to find your env files and register it (`discover_instances`, `add_instance`). With
`store="keychain"` the password is copied into the OS keychain instead. No tool accepts a password
argument or returns one.

### Configuration

| Variable | Meaning |
|---|---|
| `FSH_INSTANCES_FILE` | Registry file (default `~/.fsh/instances.json`) |
| `FS_ENV_DIRS` | Extra folders to read `.env*` login files from (path-separated) |
| `FS_WORKSPACE` | Lab workspace folders to read `.env*`, `fabric.toml`, `pods.txt` and `topologies/` from (path-separated; none by default) |
| `FS_SOAR_SSH_USER`, `FS_SOAR_SSH_PASS` | Guest login for the FortiSOAR `vm` sections that SSH into a VM (`VM_USER_SOAR01` / `VM_PASS_SOAR01` still work). Server environment only; no tool takes a password. There is no default password: without one those sections report that it is not configured |

### Extending it

`fabric_studio.mcp.server` exposes the `mcp` server object and the `_tool` decorator. Import it and
register your own tools; they run in a worker thread under a deadline, so a slow pod can't freeze the
server. Tools that wait on a reinstall should use `@_tool(deadline_s=_LONG_TOOL_DEADLINE_S)`.

## Notes

- Fabric Studio rate-limits logins and can ban a workstation that logs in too often. The client reuses
  one session per pod and backs off after a failure (`LoginCooldown ... retry in Ns`: wait, don't loop).
- Everything imports from the one `fabric_studio` package (`fabric_studio.client`, `fabric_studio.admin`, ...), so
  nothing here can collide with another package in the same environment.
