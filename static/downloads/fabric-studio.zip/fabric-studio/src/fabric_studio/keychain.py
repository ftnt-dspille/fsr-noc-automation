"""Keychain-backed access for secrets (pod / device passwords, FortiCare creds).

Keeps credentials OUT of ``.env`` / git / shell history: store a secret once
with ``tools/fsh_secret.py`` and the tools read it back at run-time via the
`keyring <https://pypi.org/project/keyring/>`_ library. ``keyring`` talks to the
platform secret store directly (the login Keychain on macOS, the Secret Service
on Linux, Credential Manager on Windows) -- the password never lands on an argv,
in a dotfile, or in the repo.

Convention: every secret is stored under service ``fabric-studio-fixer``
(``SERVICE``), keyed by an ``account`` string:

  * a **pod host** (e.g. ``fabric-studio.example.com``) → the
    FS pod login password, resolved by ``resolve_pod_login``.
  * ``pod-default`` (``DEFAULT_POD_ACCOUNT``) → the password for every pod with
    no per-host entry (pods that share one login).
  * a named secret like ``forticare-user`` / ``forticare-pass`` → the SOAR
    ``.bin`` FortiCare credentials, resolved by ``get_secret``.

No usable backend (``keyring`` missing, or a headless host with no keyring
daemon): every getter returns ``None`` and the callers fall back to the DB Pod
row / env, so nothing breaks on Linux/CI.
"""
from __future__ import annotations

import os
import subprocess
import sys
import threading

try:
    import keyring
    import keyring.errors
except ImportError:  # pragma: no cover - keyring is a declared dependency
    keyring = None

SERVICE = "fabric-studio-fixer"
DEFAULT_POD_ACCOUNT = "pod-default"


class CredsError(Exception):
    """No usable credentials found (raised by ``resolve_pod_login``)."""


class KeychainBlocked(CredsError):
    """The keyring did not answer in time: on macOS, an access dialog is waiting."""


def _security_cli(account: str, service: str) -> tuple[bool, str | None]:
    """macOS only: read the item with ``security``. ``(True, value)`` when it answered
    (``value`` is ``None`` for no such item), ``(False, None)`` when it blocked too."""
    if sys.platform != "darwin":
        return False, None
    try:
        p = subprocess.run(["security", "find-generic-password", "-s", service, "-a", account, "-w"],
                           capture_output=True, text=True, timeout=_timeout_s())
    except (OSError, subprocess.TimeoutExpired):
        return False, None
    if p.returncode == 0:
        return True, p.stdout.rstrip("\n") or None
    return (True, None) if p.returncode == 44 else (False, None)   # 44: item not found


def _timeout_s() -> float:
    try:
        return float(os.environ.get("FSH_KEYCHAIN_TIMEOUT_S", "20"))
    except ValueError:
        return 20.0


def get_secret(account: str, service: str = SERVICE) -> str | None:
    """Read a secret from the platform keyring, or ``None`` if absent / no
    usable backend. Any keyring error (locked store, no daemon) degrades to
    ``None`` so callers fall back to DB / env.

    A read that does not return within ``FSH_KEYCHAIN_TIMEOUT_S`` (20 s) raises
    ``KeychainBlocked``. On macOS that means an "allow access" dialog is waiting
    for the user (the usual cause: the venv's Python was rebuilt, so every item
    needs approving again); without the limit the caller hangs with no sign why.
    """
    if keyring is None:
        return None
    done, value = _bounded(lambda: keyring.get_password(service, account) or None, account, on_error=None)
    if not done:
        # The item's access list may trust Apple's own ``security`` tool (it does for
        # items stored with it) even when it no longer trusts this Python.
        found, value = _security_cli(account, service)
        if found:
            return value
        raise _blocked(account)
    return value["value"]  # type: ignore[index]


def _blocked(account: str) -> KeychainBlocked:
    return KeychainBlocked(
        f"The system keychain did not answer for {account!r} within {_timeout_s():g}s. "
        f"On macOS a dialog asking to let python3 use this item is waiting (it may be "
        f"behind other windows): click Always Allow, then try again.")


def _bounded(fn, account: str, *, on_error: object) -> tuple[bool, object]:
    """Run one keyring call in a daemon thread, at most ``FSH_KEYCHAIN_TIMEOUT_S``. Returns ``(done, value)``;
    ``done`` is False when the call is still waiting (a macOS access dialog). A ``KeyringError`` gives
    ``on_error``; any other error is raised here, not swallowed in the thread."""
    box: dict[str, object] = {}

    def call() -> None:
        try:
            box["value"] = fn()
        except keyring.errors.KeyringError as e:
            box["value"], box["keyring_error"] = on_error, e
        except Exception as e:
            box["error"] = e

    t = threading.Thread(target=call, name=f"keychain:{account}", daemon=True)
    t.start()
    t.join(_timeout_s())
    if t.is_alive():
        return False, None
    if "error" in box:
        raise box["error"]  # type: ignore[misc]
    return True, box


def set_secret(account: str, password: str, service: str = SERVICE) -> None:
    """Create/update a secret in the platform keyring. Raises ``CredsError`` if
    no keyring backend is available or the store rejects the write."""
    if keyring is None:
        raise CredsError("keyring is not installed (`uv pip install keyring`)")
    done, box = _bounded(lambda: keyring.set_password(service, account, password), account, on_error=None)
    if not done:
        raise _blocked(account)
    if "keyring_error" in box:  # type: ignore[operator]
        raise CredsError(f"keyring could not store secret: {box['keyring_error']}")  # type: ignore[index]


def delete_secret(account: str, service: str = SERVICE) -> bool:
    """Remove a secret. Returns True if one was deleted, False if none existed
    or there's no usable backend."""
    if keyring is None:
        return False
    done, box = _bounded(lambda: keyring.delete_password(service, account), account, on_error=None)
    return done and "keyring_error" not in box  # type: ignore[operator]


_DB_LOOKUP_WARNED: set[str] = set()


def _db_lookup_is_expected(e: BaseException) -> bool:
    """Is this DB miss a normal deployment shape rather than a fault?

    The Pod table is optional (see ``resolve_pod_login``): plenty of installs
    never migrate it, or don't have sqlmodel at all. Both raise on every single
    call, so reporting them as warnings buries a tool's real output -- a prune
    run resolves credentials three times and printed six lines of stack-adjacent
    noise before its first result. A genuinely broken DB (corrupt file, bad
    permissions) is a different thing and still gets reported.
    """
    if isinstance(e, ImportError):          # sqlmodel/fabric_studio.db not installed
        return True
    msg = str(e).lower()
    return "no such table" in msg or "no such column" in msg   # never migrated


def _note_db_lookup_failure(host: str, e: BaseException) -> None:
    """Report a DB credential-lookup failure at most once per host per process,
    and not at all for the expected shapes above (unless ``FSH_DEBUG`` is set)."""
    if os.environ.get("FSH_DEBUG"):
        print(f"[debug] DB pod-cred lookup failed for {host}: {e!r}", file=sys.stderr)
        return
    if _db_lookup_is_expected(e) or host in _DB_LOOKUP_WARNED:
        return
    _DB_LOOKUP_WARNED.add(host)
    print(f"[warn] DB pod-cred lookup failed: {e}", file=sys.stderr)


def resolve_pod_login(host: str, user: str | None = None,
                      pw: str | None = None) -> tuple[str, str]:
    """Resolve (username, password) for an FS pod, preferring the Keychain for
    the password so it never lives in ``.env``. Order:

      1. explicit ``user``+``pw`` (CLI flags) win outright;
      2. **password** ← Keychain (account = ``host``), else the DB Pod row, else
         ``$POD_PASSWORD``, else Keychain ``pod-default`` (the shared login);
      3. **username** ← flag, else the DB Pod row, else ``$POD_USERNAME``, else
         ``"admin"``.

    Raises ``CredsError`` if no password can be found anywhere -- the caller
    (each tool's ``_pod_creds``) turns that into a clean ``sys.exit``."""
    if user and pw:
        return user, pw

    db_user = db_pw = None
    try:  # DB is a convenience, not a requirement.
        from sqlmodel import select

        from fabric_studio.credentials import resolve_pod_credentials
        from fabric_studio.db import get_session
        from fabric_studio.models import Pod
        with get_session() as s:
            pod = s.exec(select(Pod).where(Pod.host == host)).first()
            if pod:
                db_user, db_pw = resolve_pod_credentials(pod)
    except Exception as e:
        _note_db_lookup_failure(host, e)

    resolved_user = user or db_user or os.environ.get("POD_USERNAME") or "admin"
    blocked: KeychainBlocked | None = None
    host_pw = None
    if not pw:
        try:
            host_pw = get_secret(host)
        except KeychainBlocked as e:   # one blocked item: fall through, like a missing one
            blocked = e
            print(f"[warn] {e} Falling back to the shared pod login.", file=sys.stderr)
    resolved_pw = (pw or host_pw or db_pw
                   or os.environ.get("POD_PASSWORD") or get_secret(DEFAULT_POD_ACCOUNT))
    if not resolved_pw:
        if blocked:
            raise blocked
        raise CredsError(
            f"No password for pod {host!r}: store one with "
            f"`uv run python -m tools.fsh_secret set {host}` (or `set {DEFAULT_POD_ACCOUNT}` "
            f"for every pod), pass --pod-pass, "
            f"or add a Pod row / $POD_PASSWORD.")
    return resolved_user, resolved_pw
