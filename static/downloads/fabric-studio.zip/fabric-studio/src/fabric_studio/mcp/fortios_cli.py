"""FortiOS over SSH: the second way into a device, for when the API is not one.

An unlicensed (evaluation) VM refuses API keys, and HTTPS access can be closed, so the device tool must also be
able to read and change a FortiGate from its CLI. This module gives the CLI the same shape as the API:

* ``read_objects`` runs ``show full-configuration`` and parses it into the objects the REST API would return, so
  the tool's diffing, masking and read-back work unchanged.
* ``apply`` builds a CLI script from the requested values and runs it one line at a time, waiting for the prompt
  after each and stopping at the first error, so a rejected value is reported with FortiOS's own words and nothing
  half-applies silently.
* Nothing the agent supplies reaches the CLI as a command: field names, section paths and object names are
  validated, values are quoted and escaped, and a value with a control character is refused outright.

The session answers the pager (``--More--``) by advancing it, and never changes the device's console setting. A
confirmation prompt is never answered ``y``: it is declined and reported.
"""
from __future__ import annotations

import asyncio
import contextlib
import re
from collections.abc import Awaitable, Callable
from typing import Any

from fabric_studio.mcp import fortios as fos

CONTROL_RX = re.compile(r"[\x00-\x1f\x7f]")
TOKEN_RX = re.compile(r"^[A-Za-z0-9_.:/@+-]+$")
# an IPv4 address or mask, a range, a number; or an IPv6 address (which has a colon). Never plain letters: ``a`` and
# ``b`` are hex digits, and a comment like ``a b`` would otherwise be sent bare and read as two words.
NUMERIC_RX = re.compile(r"^(?:[0-9][0-9.\-/]*|[0-9A-Fa-f]*:[0-9A-Fa-f:./]+)$")
MORE_RX = re.compile(r"--More--\s*\Z")
CONFIRM_RX = re.compile(r"\(y/n\)|\[y/n\]|\(yes/no\)", re.I)
# what FortiOS prints when a line was refused; a line that worked prints nothing
FAIL_RX = re.compile(r"command parse error|command fail|return code -\d+|node_check_object fail|value parse error|"
                     r"unknown action|invalid|not found|already exist|duplicate|is used|in use|cannot|failed", re.I)
RETURN_CODE_RX = re.compile(r"return code (-\d+)", re.I)
IDLE_S = 0.3
MAX_OUTPUT = 4_000_000
# the field that names an object in the API, where the CLI only says ``edit 1``
KEY_BY_SECTION = {"firewall/policy": "policyid", "router/static": "seq-num", "system/zone": "name"}


class _Shell:
    """One logged-in CLI session. ``run`` sends a line and returns what it printed, with the echo, the prompt and
    the pager removed."""

    def __init__(self, proc: Any, t: fos.Target):
        self.proc, self.t = proc, t
        self.transcript = ""

    async def run(self, line: str, timeout_s: int = 60) -> str:
        start = len(self.transcript)
        self.proc.stdin.write(line + "\r")
        await self.proc.stdin.drain()
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout_s
        while loop.time() < deadline:
            try:
                chunk = await asyncio.wait_for(self.proc.stdout.read(4096), timeout=IDLE_S)
            except TimeoutError:
                seen = fos.ANSI_RX.sub("", self.transcript[start:])
                if MORE_RX.search(seen):  # the pager: advance it, never change the console setting
                    self.proc.stdin.write(" ")
                    await self.proc.stdin.drain()
                    self.transcript += "\n"  # so the same --More-- is not answered twice
                elif CONFIRM_RX.search(seen[-200:]):
                    self.proc.stdin.write("n\r")
                    await self.proc.stdin.drain()
                    raise fos.DeviceError("FortiOS asked for a confirmation, which this tool never answers yes to; "
                                          "nothing was changed by that command") from None
                elif fos.CLI_PROMPT_RX.search(seen):
                    return _body(seen, line)
                continue
            if not chunk:
                raise fos.DeviceError("the device closed the SSH session")
            self.transcript += chunk
            if MORE_RX.search(fos.ANSI_RX.sub("", chunk)):   # answer the pager the moment it appears, not after a pause
                self.proc.stdin.write(" ")
                await self.proc.stdin.drain()
                self.transcript += "\n"
            if len(self.transcript) - start > MAX_OUTPUT:
                raise fos.DeviceError("the device sent more output than this tool reads; ask for one section")
        raise fos.DeviceError(f"timed out waiting for the device after {line.split()[0]!r}")


def _body(seen: str, line: str) -> str:
    """The command's own output: not its echo, not the pager, not the prompt that follows it."""
    text = re.sub(r"--More--\s*", "", seen).replace("\r", "")
    rows = text.split("\n")
    if rows and rows[0].strip().endswith(line.strip()[-20:]):
        rows = rows[1:]  # the echoed command
    if rows and fos.CLI_PROMPT_RX.search(rows[-1]):
        rows = rows[:-1]  # the prompt
    return "\n".join(rows).strip("\n")


@contextlib.asynccontextmanager
async def _open(t: fos.Target, timeout_s: int = 30):
    import asyncssh
    fos.check_cooldown(t)
    try:
        async with asyncssh.connect(t.host, port=t.ssh_port, username=t.user, password=t.password, known_hosts=None,
                                    client_keys=[], **fos.SSH_OPTS) as conn:
            proc = await conn.create_process(term_type="xterm")
            sh = _Shell(proc, t)
            state = {"transcript": "", "cursor": 0}
            if await fos._read_until(proc.stdout, [fos.CLI_PROMPT_RX], timeout_s, state) is None:
                raise fos.DeviceError(f"{t.name} never showed its CLI prompt")
            sh.transcript = state["transcript"]
            try:
                yield sh
            finally:
                with contextlib.suppress(Exception):
                    proc.stdin.write("exit\r")
    except asyncssh.PermissionDenied:
        raise fos.login_refused(t) from None
    except (OSError, asyncssh.Error, TimeoutError) as e:
        raise fos.Unreachable(f"cannot reach {t.name} over SSH at {t.host}:{t.ssh_port} ({type(e).__name__}). Its "
                              "SSH access must be PUBLIC, and the guest must have finished booting.") from None


def session(t: fos.Target, fn: Callable[[_Shell], Awaitable[Any]], timeout_s: int = 180) -> Any:
    """Run ``fn(shell)`` in one SSH session. One session at a time per device."""
    async def go() -> Any:
        async with _open(t) as sh:
            return await asyncio.wait_for(fn(sh), timeout=timeout_s)
    with fos._lock_for(t.ident):
        try:
            return asyncio.run(go())
        except TimeoutError:
            raise fos.DeviceError(f"{t.name} did not finish within {timeout_s}s") from None


# ── reading ──────────────────────────────────────────────────────────────────

def tokenize(line: str) -> list[tuple[str, bool]]:
    """Words of a CLI line as ``(text, was_quoted)``; a quoted word may hold spaces and ``\\"`` / ``\\\\``."""
    out: list[tuple[str, bool]] = []
    i, n = 0, len(line)
    while i < n:
        c = line[i]
        if c.isspace():
            i += 1
        elif c == '"':
            i += 1
            buf = []
            while i < n and line[i] != '"':
                if line[i] == "\\" and i + 1 < n:
                    buf.append(line[i + 1])
                    i += 2
                else:
                    buf.append(line[i])
                    i += 1
            i += 1
            out.append(("".join(buf), True))
        else:
            j = i
            while j < n and not line[j].isspace():
                j += 1
            out.append((line[i:j], False))
            i = j
    return out


def _value(tokens: list[tuple[str, bool]]) -> Any:
    """A ``set`` value as the API would show it: one word is text, several quoted words are a table's members,
    several bare words are one string (an address and its mask, the allowed access of an interface)."""
    if not tokens:
        return ""
    if len(tokens) == 1:
        return "" if tokens[0] == ("''", False) else tokens[0][0]   # FortiOS prints an empty string as ''

    if all(q for _, q in tokens):
        return [t for t, _ in tokens]
    return " ".join(t for t, _ in tokens)


def _object(lines: list[str], i: int, name: str, quoted: bool) -> tuple[dict[str, Any], int]:
    key = "id" if (re.fullmatch(r"\d+", name) and not quoted) else "name"
    obj: dict[str, Any] = {key: name}
    while i < len(lines):
        toks = tokenize(lines[i])
        i += 1
        if not toks:
            continue
        head = toks[0][0]
        if head == "next":
            break
        if head == "set" and len(toks) >= 2:
            obj[toks[1][0]] = _value(toks[2:])
        elif head == "config" and len(toks) >= 2:
            sub, i = _block(lines, i)
            obj[toks[-1][0]] = sub
    return obj, i


def _block(lines: list[str], i: int) -> tuple[Any, int]:
    """Everything up to the matching ``end``: a list of objects (a table) or one dict (a single-object section)."""
    table: list[dict[str, Any]] | None = None
    single: dict[str, Any] = {}
    while i < len(lines):
        toks = tokenize(lines[i])
        i += 1
        if not toks:
            continue
        head = toks[0][0]
        if head == "end":
            break
        if head == "edit" and len(toks) >= 2:
            obj, i = _object(lines, i, toks[1][0], toks[1][1])
            table = (table or []) + [obj]
        elif head == "set" and len(toks) >= 2:
            single[toks[1][0]] = _value(toks[2:])
        elif head == "config" and len(toks) >= 2:
            sub, i = _block(lines, i)
            single[toks[-1][0]] = sub
    if table is not None:
        return table, i
    return (single if single else []), i   # a section with no fields at all is an empty table


def parse(text: str, section: str) -> tuple[str | None, list[dict[str, Any]]]:
    """``show full-configuration`` text to ``(key field, objects)`` as the API would give them; a single-object
    section is ``(None, [object])``."""
    lines = [ln for ln in text.replace("\r", "").split("\n") if ln.strip() and not ln.lstrip().startswith("#")]
    start = next((n for n, ln in enumerate(lines) if ln.split()[:1] == ["config"]), None)
    if start is None:
        return None, []
    block, _ = _block(lines, start + 1)
    if isinstance(block, dict):
        return None, [block]
    key = KEY_BY_SECTION.get(section) or (next(iter(block[0])) if block else None)
    if block and key and key not in block[0]:   # the CLI says ``id``; the API names the field
        for o in block:
            o[key] = o.pop("id", o.get("name"))
    return key, block


def default_key(path: str, name: Any = None) -> str:
    """The field that names an object of an empty table, which the CLI cannot show."""
    return KEY_BY_SECTION.get(path) or ("id" if name is not None and re.fullmatch(r"\d+", str(name)) else "name")


def _tokens(path: str) -> str:
    return " ".join(re.split(r"[/.]", path))


def read_objects(t: fos.Target, path: str, vdom: str | None = None,
                 name: Any = None) -> tuple[str | None, list[dict[str, Any]]]:
    """``(key field, objects)``. With ``name`` only that object is read: a whole table such as the interfaces pages
    through a great deal of nested configuration, and one object is what a change or a look needs."""
    async def go(sh: _Shell) -> str:
        if vdom:
            await sh.run("config vdom")
            await sh.run(f"edit {_quote(vdom)}")
        out = await sh.run(f"show full-configuration {_tokens(path)}" + (f" {_name(name)}" if name is not None else ""),
                           timeout_s=120)
        if vdom:
            await sh.run("end")
        return out
    text = session(t, go)
    if "config " not in text:
        if name is not None:
            return default_key(path, name), []   # no such object (yet): a create has nothing to read
        if re.search(r"command parse error|not found|unknown", text, re.I):
            raise fos.DeviceError(f"{t.name} has no configuration section {path!r}")
    return parse(text, path)


# ── writing ──────────────────────────────────────────────────────────────────

def _quote(text: str) -> str:
    if CONTROL_RX.search(text):
        raise fos.DeviceError("a value cannot contain a newline or other control character")
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _name(name: Any) -> str:
    text = str(name)
    return text if re.fullmatch(r"\d+", text) else _quote(text)


def cli_value(field: str, value: Any, current: Any = None) -> str:
    """One value in CLI spelling. Plain words go bare; anything else is quoted and escaped, and a list of names is
    a quoted word each (a table's members), or bare words for an option list such as ``allowaccess``."""
    if isinstance(value, bool):
        return "enable" if value else "disable"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, dict):
        raise fos.DeviceError(f"{field}: a nested table cannot be set over SSH; give its members as a list of names")
    if isinstance(value, list):
        items = [v.get("name") if isinstance(v, dict) else v for v in value]
        if any(i is None or isinstance(i, (dict, list)) for i in items):
            raise fos.DeviceError(f"{field}: give a list of plain names")
        if field in fos.SPACE_LISTS or isinstance(current, str):
            if not all(TOKEN_RX.fullmatch(str(i)) for i in items):
                raise fos.DeviceError(f"{field}: {items} are not plain words")
            return " ".join(str(i) for i in items)
        return " ".join(_quote(str(i)) for i in items)
    text = str(value)
    if CONTROL_RX.search(text):
        raise fos.DeviceError("a value cannot contain a newline or other control character")
    if TOKEN_RX.fullmatch(text):
        return text
    parts = text.split()
    if len(parts) > 1 and all(NUMERIC_RX.fullmatch(p) for p in parts):
        return " ".join(parts)   # an address and its mask, or a range
    return _quote(text)


def script(path: str, key: str | None, name: Any, op: str, values: dict[str, Any],
           current: dict[str, Any] | None) -> list[str]:
    """The CLI lines for one change: config, edit, set..., next, end (or config, delete, end)."""
    lines = [f"config {_tokens(path)}"]
    if op == "delete":
        return [*lines, f"delete {_name(name)}", "end"]
    if key is not None:
        lines.append(f"edit {_name(name)}")
    # an empty value is not a quoted empty string: the CLI clears a field with ``unset``
    lines += [f"unset {f}" if v is None or v == "" or v == [] else f"set {f} {cli_value(f, v, (current or {}).get(f))}"
              for f, v in values.items()]
    if key is not None:
        lines.append("next")
    return [*lines, "end"]


def _redact(line: str) -> str:
    parts = line.split(None, 2)
    return f"{parts[0]} {parts[1]} <hidden>" if len(parts) == 3 and parts[0] == "set" and fos.SENSITIVE_RX.search(parts[1]) else line


def _explain(line: str, out: str) -> fos.DeviceError:
    code = RETURN_CODE_RX.search(out)
    hint = fos.ERROR_HINTS.get(int(code.group(1))) if code else None
    said = " ".join(out.split())[:300]
    return fos.DeviceError(f"FortiOS rejected the line {_redact(line)!r}" + (f" ({hint})" if hint else "")
                           + (f": FortiOS said: {said}" if said else ""))


def validate(t: fos.Target, op: str, path: str, key: str | None, name: Any, values: dict[str, Any],
             current: dict[str, Any] | None, vdom: str | None = None) -> None:
    """Check a change without making it: send the real lines, then ``abort`` instead of committing. FortiOS checks
    each ``set`` as it arrives, so a misspelled field or a value it will not take is reported in its own words
    now, at plan time, and nothing is stored."""
    full = script(path, key, name, op, values, current)
    apply(t, op, path, key, name, values, current, vdom, lines=[*full[:len(full) - (2 if key is not None else 1)], "abort"])


def apply(t: fos.Target, op: str, path: str, key: str | None, name: Any, values: dict[str, Any],
          current: dict[str, Any] | None, vdom: str | None = None, lines: list[str] | None = None) -> None:
    """Run the change. The first refused line aborts the context (nothing half-applies) and is reported."""
    lines = lines if lines is not None else script(path, key, name, op, values, current)

    async def go(sh: _Shell) -> None:
        if vdom:
            await sh.run("config vdom")
            await sh.run(f"edit {_quote(vdom)}")
        for line in lines:
            out = await sh.run(line)
            if out.strip() and FAIL_RX.search(out):
                with contextlib.suppress(Exception):
                    await sh.run("abort")
                if vdom:
                    with contextlib.suppress(Exception):
                        await sh.run("end")
                raise _explain(line, out)
        if vdom:
            await sh.run("end")
    session(t, go)


# ── status ───────────────────────────────────────────────────────────────────

def status(t: fos.Target) -> dict[str, Any]:
    """Firmware, hostname, serial, license and HA mode from ``get system status`` and the HA section."""
    async def go(sh: _Shell) -> str:
        return await sh.run("get system status")
    text = session(t, go)
    kv = {k.strip(): v.strip() for k, _, v in (ln.partition(":") for ln in text.splitlines()) if v}
    ver = re.search(r"(v\d+\.\d+\.\d+),build(\d+)", kv.get("Version", ""))
    out: dict[str, Any] = {"device": t.name, "fabric": t.fabric, "version": ver.group(1) if ver else None,
                           "build": int(ver.group(2)) if ver else None, "serial": kv.get("Serial-Number"),
                           "hostname": kv.get("Hostname"), "model": kv.get("Version", "").split(" v")[0] or None,
                           "license": {"licensed": kv.get("License Status") == "Valid",
                                       "status": kv.get("License Status")}}
    try:
        _, ha = read_objects(t, "system/ha")
        out["ha"] = {k: ha[0].get(k) for k in ("mode", "group-name", "priority") if ha and ha[0].get(k) is not None}
    except fos.DeviceError as e:
        out["ha"] = {"error": str(e)}
    return out
