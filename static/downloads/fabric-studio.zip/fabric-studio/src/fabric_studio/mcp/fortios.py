"""FortiOS REST access for the ``device`` tool.

Everything a FortiGate does differently by firmware or by transport lives here, so neither the tool nor the
agent ever sees it:

* **Auth is an API key, always.** ``POST /logincheck`` (the session login) is gone on 7.6: it answers 200 with
  the web UI's HTML and no cookies, which reads exactly like a wrong password. The key is minted over an SSH
  PTY, because FortiOS asks for the admin password twice during that CLI dialogue and an SSH exec channel
  cannot answer, after which FortiOS silently discards the whole object while reporting success. The dialogue
  is prompt-driven, never timed.
* **Two keys, two levels.** Reads use a read-only API user, minted on first use. A read-write user is minted
  only when a change is applied, so looking at a device never gives the tool the power to change it.
* **One login attempt.** A refused login is remembered and not retried for a while: repeated failures arm the
  FortiOS admin lockout, which then refuses even the right password.
* **A stale key is replaced once.** FortiOS shows a key once and has no read-back, so a key is re-minted only
  when the device rejects the one on file (a reinstall wipes it); minting a new one invalidates the old.
* **Writes are read back.** A change that FortiOS accepted but did not store is reported as unverified.
"""
from __future__ import annotations

import asyncio
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import quote

import requests

# FortiOS SSH servers need all three pinned for asyncssh, or the handshake dies with a bare "Connection lost"
# mid key exchange: the box offers only the @libssh.org spelling of curve25519, completes host-key negotiation
# only on ssh-ed25519, and drops the connection if any auth method is tried before password.
SSH_OPTS = {"kex_algs": ["curve25519-sha256@libssh.org"], "server_host_key_algs": ["ssh-ed25519"],
            "preferred_auth": ["password"]}

ANSI_RX = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b\][^\x07]*\x07")
# a prompt inside a config context is ``fgt (api-user) #``; the top-level one is ``fgt #``
CLI_PROMPT_RX = re.compile(r"[\w\-.]+\s*(?:\([^)\r\n]*\)\s*)?[#$]\s*\Z")
TOP_PROMPT_RX = re.compile(r"[\w\-.]+\s*[#$]\s*\Z")
PASSWORD_PROMPT_RX = re.compile(r"enter current administrator password", re.I)
NEW_KEY_RX = re.compile(r"New API key:\s*(\S+)")
MORE_RX = re.compile(r"--More--\s*\Z")
ERROR_RX = re.compile(r"command parse error|Command fail|return code -\d+", re.I)

# The key may be used from private space only. These are real subnets on purpose: ``0.0.0.0/0`` is stored as an
# EMPTY trusthost, which denies every request with a bare 401.
TRUSTHOSTS = (("10.0.0.0", "255.0.0.0"), ("172.16.0.0", "255.240.0.0"), ("192.168.0.0", "255.255.0.0"),
              ("198.51.100.0", "255.255.255.0"))
LEVELS = {"ro": ("fsmcp-ro", "super_admin_readonly"), "rw": ("fsmcp-rw", "super_admin")}

REFUSED_COOLDOWN_S = 120
HTTP_TIMEOUT_S = 20

# FortiOS error codes worth a sentence of their own (``error`` in a REST failure)
ERROR_HINTS = {-3: "that object does not exist", -5: "a value is not valid for this field",
               -15: "an object with that name already exists", -23: "the object is in use by another object, "
               "so it cannot be deleted; remove the reference first", -651: "the field name is not valid here"}


class DeviceError(Exception):
    """A failure whose message is safe and useful to show: it names the cause and the way out."""


class Unreachable(DeviceError):
    pass


class RestUnavailable(DeviceError):
    """The API is not a way in right now (an unlicensed VM refuses keys, HTTPS is closed or does not answer). The
    device tool answers from the CLI over SSH instead; this is not an error the person ever sees on its own."""

    @property
    def short(self) -> str:
        return str(self).split(". ")[0].rstrip(".")


class LoginRefused(DeviceError):
    pass


@dataclass
class Target:
    """One FortiGate, resolved from the pod. The password stays inside this object and never reaches a message."""
    host: str
    name: str
    fabric: str
    https_port: int
    ssh_port: int
    user: str = "admin"
    password: str = field(default="", repr=False)

    @property
    def ident(self) -> str:
        return f"{self.host}/{self.fabric}/{self.name}"


_KEYS: dict[tuple[str, str], str] = {}
_REFUSED: dict[str, tuple[float, str]] = {}
_LOCKS: dict[str, threading.Lock] = {}
_GUARD = threading.Lock()
_MKEYS: dict[tuple[str, str], str | None] = {}
_REST_OFF: dict[str, tuple[float, str]] = {}
REST_OFF_TTL_S = 300   # long enough to skip the minting dance on every call, short enough to notice a new license


def forget() -> None:
    """Drop every cached key, refusal and schema fact (tests, and a way to start clean)."""
    _KEYS.clear()
    _REFUSED.clear()
    _MKEYS.clear()
    _REST_OFF.clear()


def _lock_for(ident: str) -> threading.Lock:
    with _GUARD:
        return _LOCKS.setdefault(ident, threading.Lock())


def _account(t: Target, level: str) -> str:
    return f"fgt-key:{t.ident}:{level}"


def _load_key(t: Target, level: str) -> str | None:
    cached = _KEYS.get((t.ident, level))
    if cached:
        return cached
    try:
        from fabric_studio import keychain
        key = keychain.get_secret(_account(t, level))
    except Exception:
        return None
    if key:
        _KEYS[(t.ident, level)] = key
    return key


def _store_key(t: Target, level: str, key: str) -> None:
    _KEYS[(t.ident, level)] = key
    try:
        from fabric_studio import keychain
        keychain.set_secret(_account(t, level), key)
    except Exception:
        pass  # no keychain: the key lives for this server process, and a restart mints a fresh one


def _drop_key(t: Target, level: str) -> None:
    _KEYS.pop((t.ident, level), None)
    try:
        from fabric_studio import keychain
        keychain.delete_secret(_account(t, level))
    except Exception:
        pass


def has_key(t: Target, level: str) -> bool:
    return bool(_load_key(t, level))


# ── minting ──────────────────────────────────────────────────────────────────

class _MintError(DeviceError):
    def __init__(self, msg: str, transcript: str = ""):
        super().__init__(msg)
        self.transcript = transcript


async def _read_until(stdout: Any, patterns: list[re.Pattern], budget: float, state: dict) -> int | None:
    r"""Index of the first pattern to match the output since the last send, or None on timeout or EOF.
    Matching is scoped to ``state["cursor"]`` onwards: the prompt patterns are ``\Z``-anchored, so matching the
    whole transcript would re-match the PREVIOUS prompt before the box echoed a byte, and the dialogue would run
    ahead of the appliance."""
    loop = asyncio.get_running_loop()
    deadline = loop.time() + budget
    while True:
        remaining = deadline - loop.time()
        if remaining <= 0:
            return None
        try:
            chunk = await asyncio.wait_for(stdout.read(4096), timeout=remaining)
        except TimeoutError:
            return None
        if not chunk:
            return None
        state["transcript"] += chunk
        clean = ANSI_RX.sub("", state["transcript"][state["cursor"]:])
        for i, pat in enumerate(patterns):
            if pat.search(clean):
                return i


async def _mint_async(t: Target, api_user: str, profile: str, timeout_s: int) -> str:
    import asyncssh
    state = {"transcript": "", "cursor": 0}
    block = (f'config system api-user\nedit "{api_user}"\nset accprofile "{profile}"\nconfig trusthost\n'
             + "".join(f"edit {i}\nset ipv4-trusthost {net} {mask}\nnext\n" for i, (net, mask) in enumerate(TRUSTHOSTS, 1))
             + "end\nnext\nend\n")
    async with asyncssh.connect(t.host, port=t.ssh_port, username=t.user, password=t.password,
                                known_hosts=None, client_keys=[], **SSH_OPTS) as conn:
        proc = await conn.create_process(term_type="xterm")
        if await _read_until(proc.stdout, [CLI_PROMPT_RX], min(30, timeout_s), state) is None:
            raise _MintError("never reached the FortiOS CLI prompt", state["transcript"])

        async def send(text: str) -> None:
            state["cursor"] = len(state["transcript"])  # advance BEFORE writing: only this step's output may match
            proc.stdin.write(text.replace("\n", "\r"))
            await proc.stdin.drain()

        async def settle(what: str) -> None:
            """Answer password challenges until the top-level prompt returns. A loop, because how many times
            FortiOS challenges depends on the firmware (7.4 never, 7.6 on leaving a NEW api-user) and on whether
            the object already exists."""
            while True:
                hit = await _read_until(proc.stdout, [PASSWORD_PROMPT_RX, ERROR_RX, TOP_PROMPT_RX], timeout_s, state)
                if hit == 0:
                    await send(t.password + "\n")
                    continue
                if hit == 1:
                    raise _MintError(f"FortiOS rejected the {what}", state["transcript"])
                if hit is None:
                    raise _MintError(f"timed out waiting for the {what} to commit", state["transcript"])
                return

        await send(block)
        await settle("API user")
        await send(f"execute api-user generate-key {api_user}\n")
        while True:  # the challenge is 7.6-only: wait for EITHER it or the key
            hit = await _read_until(proc.stdout, [PASSWORD_PROMPT_RX, NEW_KEY_RX, ERROR_RX], timeout_s, state)
            if hit == 0:
                await send(t.password + "\n")
                continue
            if hit == 1:
                break
            raise _MintError("FortiOS did not produce an API key", state["transcript"])
        await send("exit\n")
    m = NEW_KEY_RX.search(ANSI_RX.sub("", state["transcript"]))
    if not m:
        raise _MintError("no API key in the FortiOS output", state["transcript"])
    return m.group(1)


async def _cli_async(t: Target, command: str, timeout_s: int) -> str:
    import asyncssh
    state = {"transcript": "", "cursor": 0}
    async with asyncssh.connect(t.host, port=t.ssh_port, username=t.user, password=t.password,
                                known_hosts=None, client_keys=[], **SSH_OPTS) as conn:
        proc = await conn.create_process(term_type="xterm")
        if await _read_until(proc.stdout, [CLI_PROMPT_RX], min(30, timeout_s), state) is None:
            raise _MintError("never reached the FortiOS CLI prompt", state["transcript"])
        state["cursor"] = len(state["transcript"])
        proc.stdin.write(command + "\r")
        await proc.stdin.drain()
        # long output arrives in pieces and a piece can end like a prompt: done is the prompt AND a quiet stream
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout_s
        while loop.time() < deadline:
            try:
                chunk = await asyncio.wait_for(proc.stdout.read(4096), timeout=0.6)
            except TimeoutError:
                seen = ANSI_RX.sub("", state["transcript"][state["cursor"]:])
                if MORE_RX.search(seen):  # the pager: advance it, never change the device's console setting
                    proc.stdin.write(" ")
                    await proc.stdin.drain()
                    state["transcript"] += "\n"  # a marker so the same --More-- is not answered twice
                elif TOP_PROMPT_RX.search(seen):
                    break
                continue
            if not chunk:
                break
            state["transcript"] += chunk
        proc.stdin.write("exit\r")
    return re.sub(r"--More--\s*", "", ANSI_RX.sub("", state["transcript"][state["cursor"]:]))


def cli_read(t: Target, command: str, timeout_s: int = 30) -> str:
    """Run one READ-ONLY CLI command and return its text. Only for working out why a device refuses the API: the
    caller never passes a command from the agent."""
    return _scrub(asyncio.run(_cli_async(t, command, timeout_s)), t)


def why_refused(t: Target) -> str:
    """Say why a device refuses a key that was just created. The evaluation (unlicensed) FortiGate VM does, with an
    ``internal_error`` in its own log and a bare 401 on the wire, and that reads exactly like a trusthost problem."""
    try:
        status = cli_read(t, "get system status")
    except Exception:
        status = ""
    if re.search(r"License Status:\s*(Invalid|Unlicensed|Expired)", status, re.I):
        return (f"{t.name} is an unlicensed (evaluation) FortiGate VM, and FortiOS does not accept API keys on one: "
                "every key is refused even though it was created. Configuring it needs a license (give the device "
                "one with set_vm_license, which reinstalls it); the CLI over SSH still works without.")
    return (f"{t.name} refused a freshly created API key. The key is accepted only from private addresses "
            "(10/8, 172.16/12, 192.168/16, 198.51.100/24); if this workstation reaches the pod through a public "
            "address, the device sees that one and answers 401.")


def _scrub(text: str, t: Target) -> str:
    return text.replace(t.password, "<hidden>") if t.password else text


def check_cooldown(t: Target) -> None:
    until, why = _REFUSED.get(t.ident, (0.0, ""))
    if time.time() < until:
        raise LoginRefused(why)


def login_refused(t: Target) -> LoginRefused:
    """Remember a refused login and say so. One attempt only: repeated failures arm the admin lockout."""
    why = (f"{t.name} refused the login for {t.user}. The tool made one attempt and will not retry for "
           f"{REFUSED_COOLDOWN_S // 60} minutes, because repeated failures lock the admin account for a while. "
           "Check the password Fabric Studio holds for this device (a fabric's password is set at install; a "
           "device that was changed by hand no longer matches it).")
    _REFUSED[t.ident] = (time.time() + REFUSED_COOLDOWN_S, why)
    return LoginRefused(why)


def mint(t: Target, level: str, timeout_s: int = 90) -> str:
    """Create the API user for ``level`` on the device and return a fresh key (which replaces any older one)."""
    import asyncssh
    check_cooldown(t)
    api_user, profile = LEVELS[level]
    try:
        key = asyncio.run(_mint_async(t, api_user, profile, timeout_s))
    except asyncssh.PermissionDenied:
        raise login_refused(t) from None
    except _MintError as e:
        raise DeviceError(f"could not create an API key on {t.name}: {e}") from None
    except (OSError, asyncssh.Error, TimeoutError) as e:
        raise Unreachable(f"cannot reach {t.name} over SSH at {t.host}:{t.ssh_port} ({type(e).__name__}). Its SSH "
                          "access must be PUBLIC, and the guest must have finished booting.") from None
    _store_key(t, level, key)
    return key


# ── REST ─────────────────────────────────────────────────────────────────────

def _send(t: Target, key: str, method: str, path: str, params: dict | None, body: dict | None) -> requests.Response:
    import urllib3
    urllib3.disable_warnings()
    url = f"https://{t.host}:{t.https_port}/api/v2/{path.lstrip('/')}"
    try:
        return requests.request(method, url, headers={"Authorization": f"Bearer {key}"}, params=params, json=body,
                                verify=False, timeout=HTTP_TIMEOUT_S)
    except requests.exceptions.RequestException as e:
        raise RestUnavailable(f"cannot reach {t.name} over HTTPS at {t.host}:{t.https_port} ({type(e).__name__}). "
                              "Its HTTPS access must be PUBLIC and the device must be up.") from None


def _unwrap(t: Target, r: requests.Response, level: str) -> dict[str, Any]:
    try:
        data = r.json()
    except ValueError:
        raise DeviceError(f"{t.name} answered {r.status_code} with something that is not FortiOS JSON; it is "
                          "probably still booting or not a FortiGate") from None
    if r.status_code == 403 or data.get("http_status") == 403:
        raise DeviceError(f"{t.name} refused: the {level} API user's profile does not allow that")
    if r.status_code >= 400 or data.get("status") == "error":
        code = data.get("error")
        results = data.get("results")
        cli = data.get("cli_error") or (results.get("error") if isinstance(results, dict) else None)
        detail = [d for d in (ERROR_HINTS.get(code) if isinstance(code, int) else None,
                              f"FortiOS said: {str(cli).strip()[:300]}" if cli else None) if d]
        err = DeviceError(f"FortiOS rejected the request (HTTP {r.status_code}"
                          + (f", error {code}" if code is not None else "") + ")"
                          + (": " + "; ".join(detail) if detail else ""))
        err.status = r.status_code  # type: ignore[attr-defined]
        err.code = code  # type: ignore[attr-defined]
        raise err
    return data


def call(t: Target, level: str, method: str, path: str, params: dict | None = None,
         body: dict | None = None, raw: bool = False) -> Any:
    """One REST call as ``level``. Mints the key on first use; replaces it once when the device rejects it.
    ``raw`` returns the response as it came, errors included, for the caller that wants to show it."""
    off_until, off_why = _REST_OFF.get(t.ident, (0.0, ""))
    if time.time() < off_until:
        raise RestUnavailable(off_why)
    with _lock_for(t.ident):
        key = _load_key(t, level)
        fresh = False
        if not key:
            key, fresh = mint(t, level), True
        r = _send(t, key, method, path, params, body)
        if r.status_code == 401 and not fresh:
            _drop_key(t, level)  # a reinstall or a manual change wiped it
            key, fresh = mint(t, level), True
            r = _send(t, key, method, path, params, body)
        if r.status_code == 401:
            why = why_refused(t)
            _REST_OFF[t.ident] = (time.time() + REST_OFF_TTL_S, why)
            raise RestUnavailable(why)
    return r if raw else _unwrap(t, r, level)


def get(t: Target, path: str, params: dict | None = None, level: str = "ro") -> Any:
    return call(t, level, "GET", path, params).get("results")


# ── configuration sections ───────────────────────────────────────────────────

ALIASES = {
    "interfaces": "system/interface", "routes": "router/static", "policies": "firewall/policy",
    "addresses": "firewall/address", "address_groups": "firewall/addrgrp", "services": "firewall/service/custom",
    "vips": "firewall/vip", "dns": "system/dns", "ntp": "system/ntp", "global": "system/global",
    "settings": "system/settings", "admins": "system/admin", "zones": "system/zone", "dhcp": "system/dhcp/server",
    "snmp": "system/snmp/community", "ha": "system/ha", "central_management": "system/central-management",
    "automation": "system/automation-stitch", "local_users": "user/local", "ippools": "firewall/ippool",
    "vpn_ipsec": "vpn.ipsec/phase1-interface", "sdwan": "system/sdwan",
}
# Changing these would cut off the very access the tool uses, or hand out new logins; the device's own GUI is the place.
PROTECTED = ("system/admin", "system/api-user", "system/accprofile")
# every segment starts with a letter or digit, so ``.`` and ``..`` can never be one: the HTTP layer would collapse
# them and ``system/./admin`` would reach the protected ``system/admin`` past a string comparison
SECTION_RX = re.compile(r"^[a-z0-9][a-z0-9_-]*(\.[a-z0-9_-]+)?(/[a-z0-9][a-z0-9_.-]*){1,2}$")
# no leading dot or slash: a name becomes a URL segment, and ``..`` would walk out of the section
NAME_RX = re.compile(r"^[A-Za-z0-9_@][A-Za-z0-9_.@:/ -]{0,78}$")
FIELD_RX = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")
SENSITIVE_RX = re.compile(r"passw|passwd|psk|secret|private-key|privatekey|(^|-)key$|token|community-name|auth-key|"
                          r"salt|ssh-public-key", re.I)
# fields whose REST value is one space-separated string, not a list of tables
SPACE_LISTS = {"allowaccess", "trust-ip-1"}
MKEY_GUESS = ("name", "id", "policyid", "seq-num", "ip")


def section_path(section: str) -> str:
    """An alias or a ``system/interface``-style cmdb path, validated: it becomes part of a URL."""
    path = ALIASES.get(section.strip().lower(), section.strip().strip("/"))
    if not SECTION_RX.fullmatch(path):
        raise DeviceError(f"{section!r} is not a configuration section. Use one of {', '.join(sorted(ALIASES))}, or "
                          "a path such as system/interface or firewall/policy.")
    return path


def mask(value: Any, key: str = "") -> Any:
    """Secrets out: a password, key or PSK never leaves the device through this tool."""
    if key and SENSITIVE_RX.search(key):
        return "<hidden>"
    if isinstance(value, dict):
        return {k: mask(v, k) for k, v in value.items()}
    if isinstance(value, list):
        return [mask(v, key) for v in value]
    if isinstance(value, str) and value.startswith("ENC "):
        return "<hidden>"
    return value


def mkey(t: Target, path: str) -> str | None:
    """The field that names an object in this section (``name``, ``policyid``…), or None for a single-object
    section such as ``system/global``."""
    k = (t.ident, path)
    if k not in _MKEYS:
        try:
            schema = get(t, f"cmdb/{path}", {"action": "schema"})
        except DeviceError:
            schema = None
        _MKEYS[k] = (schema or {}).get("mkey") if isinstance(schema, dict) else None
    return _MKEYS[k]


def read_objects(t: Target, path: str, vdom: str | None = None) -> tuple[str | None, list[dict[str, Any]]]:
    """``(key field, objects)``; a single-object section is ``(None, [obj])``."""
    res = get(t, f"cmdb/{path}", {"vdom": vdom} if vdom else None)
    if isinstance(res, dict):
        return None, [res]
    objs = list(res or [])
    key = mkey(t, path) or next((g for g in MKEY_GUESS if objs and g in objs[0]), None)
    return key, objs


def find(key: str | None, objs: list[dict[str, Any]], name: Any) -> dict[str, Any] | None:
    if key is None:
        return objs[0] if objs else None
    return next((o for o in objs if str(o.get(key)) == str(name)), None)


# ── comparing and sending values ─────────────────────────────────────────────

def _names(items: list) -> list[str]:
    out = []
    for i in items:
        if isinstance(i, dict):
            i = next((i[k] for k in ("name", "id", "q_origin_key") if k in i), i)
        out.append(str(i))
    return sorted(out)


def canon(field_name: str, value: Any) -> Any:
    """A value in the form FortiOS reads back, so a desired value and a stored one compare equal when they mean
    the same thing: bools are enable/disable, numbers are text, a table is its sorted member names."""
    if isinstance(value, bool):
        return "enable" if value else "disable"
    if isinstance(value, list):
        names = _names(value)
        return " ".join(names) if field_name in SPACE_LISTS else names
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, str) and field_name in SPACE_LISTS:
        return " ".join(sorted(value.split()))
    return value


def wire(field_name: str, value: Any, current: Any = None) -> Any:
    """The value as the REST API wants it: a list of names is a table, an option list is one string."""
    if isinstance(value, list):
        if field_name in SPACE_LISTS or isinstance(current, str):
            return " ".join(str(v) for v in value)
        return [v if isinstance(v, dict) else {"name": str(v)} for v in value]
    if isinstance(value, bool):
        return "enable" if value else "disable"
    return value


def same(field_name: str, have: Any, want: Any) -> bool:
    """Do these mean the same on the device? Beyond ``canon``: a table of one member reads back as plain text over
    the CLI, and an empty field is absent there, so ``None`` and ``""`` are the same."""
    a, b = canon(field_name, have), canon(field_name, want)
    if a == b:
        return True
    if a in (None, "", []) and b in (None, "", []):
        return True
    if isinstance(a, list) and len(a) == 1 and isinstance(b, str):
        return a[0] == b
    return isinstance(b, list) and len(b) == 1 and isinstance(a, str) and b[0] == a


def diff(current: dict[str, Any] | None, desired: dict[str, Any]) -> list[dict[str, Any]]:
    """What would change: ``[{field, from, to}]``. For a new object ``from`` is None throughout."""
    out = []
    for f, want in desired.items():
        have = (current or {}).get(f)
        if current is not None and same(f, have, want):
            continue
        out.append({"field": f, "from": mask(have, f) if current is not None else None, "to": mask(want, f)})
    return out


def mismatches(stored: dict[str, Any], desired: dict[str, Any]) -> list[dict[str, Any]]:
    """Fields FortiOS accepted but does not hold as asked (the silent-discard failure)."""
    return [{"field": f, "wanted": mask(w, f), "stored": mask(stored.get(f), f)}
            for f, w in desired.items() if not same(f, stored.get(f), w)]


def object_path(path: str, key: str | None, name: Any) -> str:
    return f"cmdb/{path}" if key is None else f"cmdb/{path}/{quote(str(name), safe='')}"
