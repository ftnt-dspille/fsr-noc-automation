"""The ``run`` tool: run a command over SSH, or make an API call, on any device whose access is public.

The ``device`` tool is the careful way to configure a FortiGate. This is the way that reaches everything else, and
reaches the FortiGate in ways ``device`` does not: any command, any API endpoint, any device type. It is built to
be easy: name the device, give a ``command`` or an ``api`` request, and read the answer.

* A command or request that only reads runs at once. A known read-only command (``get``, ``show``, ``ls``,
  ``ps``, ``df``...) or a GET needs no approval. Anything else is shown to the person first, exactly as it will be
  sent, and runs only after they approve; the agent cannot approve for them.
* Nothing is guessed to be safe: any shell syntax (``;``, ``&&``, ``$()``, redirects, backticks) makes a command
  need approval, and so does every unfamiliar command.
* The login is the one Fabric Studio holds for the device and never passes through the agent. The output has
  secrets hidden where FortiOS marks them (``set password ENC ...``); other output is returned as the device
  printed it, so ``cat`` of a secret file shows it.
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import re
import urllib.parse
from typing import Any

from mcp.server.mcpserver.exceptions import ToolError

from fabric_studio.mcp import device as dev
from fabric_studio.mcp import fortios as fos
from fabric_studio.mcp import fortios_cli as cli
from fabric_studio.mcp.server import _LONG_TOOL_DEADLINE_S, _refuse_if_locked, _tool

FORTIOS_LIKE = {"FGT", "FMG", "FAZ"}   # a FortiOS-style CLI: needs a terminal session and its SSH quirks
MAX_OUTPUT = 20000
MAX_TIMEOUT_S = 300

# shell syntax: any of these and the command is no longer something we can call read-only
SHELL_SYNTAX_RX = re.compile(r"[;&`$(){}<>\\\n\r]|\|\|")
CONTROL_RX = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

# Commands with no way to change anything, whatever their arguments. Everything else that is read-only has a rule
# of its own below, because the same command often has a mutating form (``ifconfig eth0 down``, ``date -s``).
LINUX_ALWAYS_READ = {"ls", "cat", "head", "tail", "grep", "egrep", "ps", "df", "du", "free", "uptime", "uname",
                     "whoami", "id", "pwd", "lsblk", "lscpu", "lsmod", "wc", "stat", "file", "which", "netstat",
                     "nslookup", "dig", "traceroute"}
FOLLOWING = {"-f", "--follow", "-F"}   # never ends: not a read
IP_READ = {"addr", "address", "a", "link", "l", "route", "r", "neigh", "n", "neighbor"}
IP_VERBS = {"show", "list", "ls", "get", "lst"}
SYSTEMCTL_READ = {"status", "is-active", "is-enabled", "list-units", "list-unit-files", "show"}
DOCKER_READ = {"ps", "images", "logs", "inspect", "version", "info"}
JOURNALCTL_WRITES = ("--vacuum", "--rotate", "--flush", "--sync", "--relinquish", "--setup-keys", "--update-catalog")
DMESG_OK = {"-T", "-H", "-x", "-k", "-u", "--ctime", "--human", "--kernel", "--userspace"}


def _linux_read_only(head: list[str]) -> bool:
    """Is this command, with these arguments, only a read? A name alone is never enough."""
    cmd, args = head[0], head[1:]
    if cmd in LINUX_ALWAYS_READ:
        return not (FOLLOWING & set(args))
    if cmd == "ip":
        words = [a for a in args if not a.startswith("-")]
        return bool(words) and words[0] in IP_READ and (len(words) == 1 or words[1] in IP_VERBS or words[1] == "dev")
    if cmd == "systemctl":
        return bool(args) and args[0] in SYSTEMCTL_READ
    if cmd == "docker":
        return bool(args) and args[0] in DOCKER_READ and not (FOLLOWING & set(args))
    if cmd == "journalctl":
        return not (FOLLOWING & set(args)) and not any(a.startswith(JOURNALCTL_WRITES) for a in args)
    if cmd == "ss":
        return not any(a in ("-K", "--kill") or (a.startswith("-") and not a.startswith("--") and "K" in a) for a in args)
    if cmd == "dmesg":
        return all(a in DMESG_OK for a in args)
    if cmd == "hostname":
        return all(a.startswith("-") for a in args)          # a name would SET the hostname
    if cmd == "date":
        return all(a == "-u" or a.startswith("+") or a in ("-R", "--utc", "--rfc-email") for a in args)
    if cmd == "ifconfig":
        return len(args) == 0 or (len(args) == 1 and args[0] not in ("up", "down"))
    return False


def _filter_ok(words: list[str]) -> bool:
    """A pipe target that can only transform what flows through it: never a file operand, never an output file."""
    cmd, args = words[0].lower(), words[1:]
    if cmd in ("grep", "egrep"):
        return True   # reads stdin and prints; no flag of grep writes a file
    if cmd in ("sort", "uniq"):
        return all(a.startswith("-") for a in args) and not any(a.startswith(("-o", "--output")) for a in args)
    if cmd in ("head", "tail", "wc", "cut"):
        return not (FOLLOWING & set(args))
    return False


FORTIOS_READ_FIRST = {"get", "show"}
FORTIOS_READ_EXECUTE = {"ping", "ping6", "traceroute", "traceroute6", "date", "time", "ping-options"}
FORTIOS_PROTECTED_API_RX = re.compile(r"/cmdb/system/(admin|api-user|accprofile)(/|\?|$)", re.I)
API_PATH_RX = re.compile(r"^/[A-Za-z0-9_./:@,=&?%+-]*$")
METHODS = ("GET", "POST", "PUT", "DELETE")


def _words(segment: str) -> list[str]:
    return segment.split()


def classify_command(command: str, vm_type: str) -> tuple[bool, str]:
    """``(read_only, why)``. Strict by design: a command is read-only only when it is plainly one of a short list
    of reads, with at most a pipe into a plain filter."""
    text = command.strip()
    if not text:
        return False, "empty"
    if CONTROL_RX.search(text):
        return False, "contains control characters"
    if "\n" in text or "\r" in text or SHELL_SYNTAX_RX.search(text):
        return False, ("is several lines, so it is a script and not a plain read" if "\n" in text or "\r" in text
                       else "contains shell syntax (; & | > $ and the like)")
    segments = [seg.strip() for seg in text.split("|")]
    head = _words(segments[0])
    if not head:
        return False, "empty"
    first = head[0].lower()
    fortios = vm_type in FORTIOS_LIKE
    if fortios:
        ok = first in FORTIOS_READ_FIRST or (first == "execute" and len(head) > 1 and head[1].lower() in FORTIOS_READ_EXECUTE)
    else:
        ok = _linux_read_only([first, *head[1:]])
    if not ok:
        return False, f"{head[0]} is not a known read-only command"
    for seg in segments[1:]:
        w = _words(seg)
        if not w or not (w[0].lower() == "grep" if fortios else _filter_ok(w)):
            return False, "pipes into something that is not a plain filter"
    return True, "a known read-only command"


def parse_api(api: str) -> tuple[str, str, dict[str, str]]:
    """``"GET /api/v2/monitor/system/status"`` (or just the path) to ``(method, path, query)``."""
    parts = api.strip().split(None, 1)
    method, target = ("GET", parts[0]) if parts and parts[0].startswith("/") else (parts[0].upper(), parts[1]) if len(parts) == 2 else ("", "")
    if method not in METHODS or not target:
        raise ToolError("api is a request such as 'GET /api/v2/monitor/system/status' (method, then path; "
                        f"the method is one of {', '.join(METHODS)} and defaults to GET)")
    path, _, query = target.partition("?")
    if (not API_PATH_RX.fullmatch(path + ("?" + query if query else "")) or ".." in path or "//" in path
            or "/./" in path or path.endswith("/.") or re.search(r"%(?!20)", path + query, re.I)):
        raise ToolError(f"{target!r} is not a usable API path: it starts with / and holds only letters, digits and "
                        "/ . _ - : @ , = & ? (a space is %20)")
    return method, path, dict(urllib.parse.parse_qsl(query, keep_blank_values=True))


def scrub_text(text: str, t: fos.Target) -> str:
    """Hide the secrets FortiOS marks: ``set password ENC ...`` lines, any ``ENC ...`` value, the login itself."""
    out = []
    for line in text.splitlines():
        m = re.match(r"(\s*set\s+)(\S+)(\s+)(.*)$", line)
        if m and fos.SENSITIVE_RX.search(m.group(2)):
            line = f"{m.group(1)}{m.group(2)}{m.group(3)}<hidden>"
        out.append(re.sub(r"\bENC\s+\S+", "<hidden>", line))
    return fos._scrub("\n".join(out) + ("\n" if text.endswith("\n") else ""), t)


def _clip(text: str) -> tuple[str, bool]:
    return (text[:MAX_OUTPUT], True) if len(text) > MAX_OUTPUT else (text, False)


# ── running ──────────────────────────────────────────────────────────────────

def _ssh_fortios(t: fos.Target, command: str, timeout_s: int) -> dict[str, Any]:
    lines = [ln for ln in command.replace("\r", "").split("\n") if ln.strip()]

    async def go(sh: cli._Shell) -> dict[str, Any]:
        out, failed = [], None
        for n, line in enumerate(lines):
            text = await sh.run(line, timeout_s=timeout_s)
            out.append(text if len(lines) == 1 else f"$ {line}\n{text}".rstrip())
            if len(lines) > 1 and n < len(lines) - 1 and text.strip() and cli.FAIL_RX.search(text):
                failed = line   # a script stops at its first refused line, as a person would stop
                with contextlib.suppress(Exception):
                    await sh.run("abort")
                break
        return {"output": "\n".join(out), **({"failed_line": failed} if failed else {})}
    return cli.session(t, go, timeout_s=timeout_s + 30)


def _ssh_linux(t: fos.Target, command: str, timeout_s: int) -> dict[str, Any]:
    import asyncssh
    fos.check_cooldown(t)

    async def go() -> dict[str, Any]:
        try:
            async with asyncssh.connect(t.host, port=t.ssh_port, username=t.user, password=t.password, known_hosts=None,
                                        client_keys=[], preferred_auth=["password", "keyboard-interactive"]) as conn:
                r = await conn.run(command, check=False, timeout=timeout_s)
        except asyncssh.PermissionDenied:
            raise fos.login_refused(t) from None
        except (OSError, asyncssh.Error, TimeoutError) as e:
            raise fos.Unreachable(f"cannot reach {t.name} over SSH at {t.host}:{t.ssh_port} ({type(e).__name__}). Its "
                                  "SSH access must be PUBLIC, and the guest must have finished booting.") from None
        return {"output": (r.stdout or "") + (("\n" + r.stderr) if r.stderr else ""), "exit_status": r.exit_status}
    return asyncio.run(go())


def _api(t: fos.Target, vm_type: str, method: str, path: str, query: dict[str, str], body: Any) -> dict[str, Any]:
    if vm_type == "FGT":
        if not re.match(r"^/api/v2/(cmdb|monitor|log)/", path):
            raise ToolError("a FortiGate API path starts with /api/v2/cmdb/, /api/v2/monitor/ or /api/v2/log/")
        try:
            r = fos.call(t, "ro" if method == "GET" else "rw", method, path[len("/api/v2/"):], query or None, body, raw=True)
        except fos.RestUnavailable as e:
            raise fos.DeviceError(f"the API is not available on {t.name}: {e.short}. Run a command over SSH instead "
                                  "(command=...).") from None
    else:
        import requests
        import urllib3
        urllib3.disable_warnings()
        try:
            r = requests.request(method, f"https://{t.host}:{t.https_port}{path}", params=query or None, json=body,
                                 auth=(t.user, t.password), verify=False, timeout=fos.HTTP_TIMEOUT_S)
        except requests.exceptions.RequestException as e:
            raise fos.Unreachable(f"cannot reach {t.name} over HTTPS at {t.host}:{t.https_port} ({type(e).__name__}). "
                                  "Its HTTPS access must be PUBLIC and the device must be up.") from None
    try:
        parsed: Any = fos.mask(r.json())
        text = json.dumps(parsed, indent=1, default=str)
    except ValueError:
        parsed, text = None, scrub_text(r.text, t)
    shown, cut = _clip(text)
    res: dict[str, Any] = {"status": r.status_code, "truncated": cut}
    if cut:
        res["body"] = shown
        res["note"] = "the answer is long; ask for a narrower path, or add filters to the query"
    else:
        res["body"] = parsed if parsed is not None else shown
    if r.status_code == 401 and vm_type != "FGT":
        res["hint"] = ("this device did not accept its Fabric Studio login over HTTP basic authentication; many "
                       "appliances need their own API token. Run a command over SSH instead.")
    return res


@_tool(deadline_s=_LONG_TOOL_DEADLINE_S, mutating=True)
def run(host: str, device: str, command: str | None = None, api: str | None = None, body: dict[str, Any] | None = None,
        fabric: str | None = None, timeout_s: int = 30, confirm: bool = False) -> dict[str, Any]:
    """MUTATING unless it only reads. Use this to read from or run something on ANY device of a fabric by name:
    FortiGate, FortiManager, FortiAnalyzer or a Linux guest. For example the firmware version of a FortiAnalyzer
    is ``command="get system status"``, and the free disk of a Linux guest is ``command="df -h"``. It runs a
    command over SSH, or makes an API call over HTTPS, using the device's public SSH or HTTPS access. Give EITHER
    ``command`` OR ``api``.

    ``command`` is what you would type at the device's prompt: ``get system status``, ``show system interface``,
    ``ls /var/log``, ``df -h``. ``api`` is a request: ``GET /api/v2/monitor/system/status`` (the method defaults
    to GET; POST, PUT and DELETE take a ``body``). A FortiGate, FortiManager and FortiAnalyzer get a FortiOS
    CLI; any other device gets a shell. Several lines in ``command`` run in order and stop at the first refusal.

    A command that only reads (get, show, ls, ps, df, a pipe into grep...) and every GET run at once. Anything
    else, including anything with shell syntax, returns a PLAN first: the exact command or request, as it will be
    sent. With ``confirm=true`` the person is asked to approve it, then it runs. Do not pass ``confirm`` for a
    read. For configuring a FortiGate prefer the ``device`` tool, which shows a real before and after.

    Returns the output (``output`` for a command, ``status`` and ``body`` for an API call), with FortiOS secrets
    hidden. The device must be powered on with SSH (and for ``api``, HTTPS) access PUBLIC; the tool says in plain
    words when something blocks it, and tries a login once only."""
    if bool(command) == bool(api):
        raise ToolError("give exactly one of command (to run over SSH, e.g. 'get system status') or api (e.g. "
                        "'GET /api/v2/monitor/system/status')")
    if not 1 <= timeout_s <= MAX_TIMEOUT_S:
        raise ToolError(f"timeout_s is 1 to {MAX_TIMEOUT_S}")
    via = "api" if api else "ssh"
    t, row = dev.resolve(host, device, fabric, need=("HTTPS",) if api else ("SSH",))
    vm_type = row["vm_type"] or ""
    try:
        if api:
            method, path, query = parse_api(api)
            if vm_type == "FGT" and method != "GET" and FORTIOS_PROTECTED_API_RX.search(path):
                raise ToolError("that path holds the accounts this tool signs in with; changing them here could lock "
                                "it out of the device. Use the device's own GUI for administrator accounts.")
            read_only, why = method == "GET", "a GET request"
            request = f"{method} {path}" + (f"?{urllib.parse.urlencode(query)}" if query else "")
            asked: dict[str, Any] = {"request": request, **({"body": fos.mask(body)} if body else {})}
        else:
            if CONTROL_RX.search(command or ""):
                raise ToolError("a command cannot contain control characters")
            read_only, why = classify_command(command or "", vm_type)
            asked = {"command": command}
        plan = {"device": t.name, "fabric": t.fabric, "type": vm_type, "via": via, "read_only": read_only, "why": why, **asked}
        if not read_only:
            if not confirm:
                return {"dry_run": True, **plan,
                        "warnings": [f"{'this request' if api else 'this command'} is not known to be read-only "
                                     f"({why}), so it needs the person's approval before it runs"],
                        "note": "re-run with confirm=true to run it; the person is asked first"}
            _refuse_if_locked(t.host)
        if api:
            result = _api(t, vm_type, method, path, query, body)
        else:
            result = (_ssh_fortios if vm_type in FORTIOS_LIKE else _ssh_linux)(t, command or "", timeout_s)
            result["output"] = scrub_text(result["output"], t)
            result["output"], cut = _clip(result["output"])
            if cut:
                result["truncated"] = True
                result["note"] = "the output is long; filter it (| grep ...) or ask for less"
        return {"executed": True, **plan, **result}
    except fos.DeviceError as e:
        raise ToolError(fos._scrub(str(e), t)) from None
