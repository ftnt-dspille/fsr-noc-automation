"""Worked examples for ``build action=examples``: how the topologies this server can see already do a thing.

Nothing is copied into this package. Each pattern is a matcher over the parsed intents (bundled and workspace),
so the examples are the user's own topologies and stay current with them. A snippet is the matching node or
link as YAML, with secret-looking values masked and long injected files cut short.
"""
from __future__ import annotations

import re
from collections.abc import Callable
from pathlib import Path
from typing import Any

from fabric_studio.mcp import fortios as fos

SECRET_KEY_RX = re.compile(r"(pass|secret|token|private|api_?key|psk|community)", re.I)
SECRET_LINE_RX = re.compile(r"(?i)(password|passwd|secret|token|psk|api_?key|community)\s*[=:]\s*\S+")
PRIVATE_KEY_RX = re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", re.S)
INJECT_LINES = 25
PER_PATTERN = 3

Node = dict[str, Any]
Doc = dict[str, Any]


def _nodes(doc: Doc, *types: str) -> list[Node]:
    return [n for n in doc.get("nodes") or [] if isinstance(n, dict) and (not types or n.get("type") in types)]


def _links(n: Node) -> list[dict[str, Any]]:
    return [lk for lk in n.get("links") or [] if isinstance(lk, dict)]


def _lan_switches(n: Node) -> set[str]:
    return {str(lk.get("switch")) for lk in _links(n) if not lk.get("mgmt")}


def _behind_gate(doc: Doc) -> list[Node]:
    gate_lans = set().union(*(_lan_switches(g) for g in _nodes(doc, "FGT"))) if _nodes(doc, "FGT") else set()
    return [n for n in _nodes(doc, "LXC", "BASIC", "WINDOWS")
            if len(_links(n)) > 1 and _lan_switches(n) & gate_lans]


def _key_access(doc: Doc) -> list[Node]:
    return [n for n in _nodes(doc, "LXC", "BASIC")
            if "authorized_key" in str((n.get("deviceconfig") or {}).get("inject") or {})]


def _licensed(*types: str) -> Callable[[Doc], list[Node]]:
    def match(doc: Doc) -> list[Node]:
        return [n for n in _nodes(doc, *types) if isinstance(n.get("license"), dict)]
    return match


def _managers(doc: Doc) -> list[Node]:
    return _nodes(doc, "FMG", "FAZ") if _nodes(doc, "FGT") else []


def _vlan(doc: Doc) -> list[Node]:
    return [n for n in _nodes(doc) if any("vlan" in lk or "trunk" in lk for lk in _links(n))]


def _of_type(*types: str) -> Callable[[Doc], list[Node]]:
    return lambda doc: _nodes(doc, *types)


def _deviceconfig(doc: Doc) -> list[Node]:
    return [n for n in _nodes(doc) if n.get("deviceconfig")]


PATTERNS: dict[str, tuple[str, Callable[[Doc], list[Node]]]] = {
    "client_behind_gate": ("A Linux or Windows client with a leg on a FortiGate's LAN switch (mgmt link for "
                           "access, a second link on the LAN)", _behind_gate),
    "lxc_key_access": ("A Linux guest you can log in to: the base LXC image accepts only SSH keys, so the "
                       "intent injects an authorized key through deviceconfig", _key_access),
    "licensed_fortigate": ("A FortiGate licensed with `license: {mode: auto}` (the pod's pool, or "
                           "`flex_config` for FortiFlex)", _licensed("FGT")),
    "licensed_manager": ("A FortiManager or FortiAnalyzer licensed with `license: {mode: auto}`",
                         _licensed("FMG", "FAZ")),
    "fortigate_with_manager": ("A FortiManager or FortiAnalyzer in a fabric with FortiGates (register them with "
                               "the `register` tool once built)", _managers),
    "vlan_switchport": ("A link with `vlan:` (access port) or `trunk:` (tagged ids) on a switch", _vlan),
    "router": ("A VyOS router node", _of_type("VYOS")),
    "windows": ("A Windows node", _of_type("WINDOWS")),
    "deviceconfig_payload": ("A node that runs setup steps from a deviceconfig payload", _deviceconfig),
}


def _mask(v: Any, key: str = "") -> Any:
    if isinstance(v, dict):
        return {k: _mask(x, str(k)) for k, x in v.items()}
    if isinstance(v, list):
        return [_mask(x, key) for x in v]
    if isinstance(v, str):
        if SECRET_KEY_RX.search(key) and not key.endswith(".pub") and "${" not in v:
            return "***"
        v = fos.mask_set_lines(v)
        v = SECRET_LINE_RX.sub(lambda m: m.group(1) + "=***", PRIVATE_KEY_RX.sub("<private key>", v))
        lines = v.splitlines()
        if len(lines) > INJECT_LINES:
            v = "\n".join([*lines[:INJECT_LINES], f"... ({len(lines) - INJECT_LINES} more lines)"])
    return v


def _snippet(n: Node) -> str:
    import yaml

    class Dumper(yaml.SafeDumper):
        pass

    def text(d: yaml.SafeDumper, v: str) -> yaml.Node:   # an injected file reads as a block, not one long line
        return d.represent_scalar("tag:yaml.org,2002:str", v, style="|" if "\n" in v else None)
    Dumper.add_representer(str, text)
    return yaml.dump(_mask(n), Dumper=Dumper, sort_keys=False, width=120)


def examples(intents: list[tuple[str, Path]], pattern: str | None = None) -> dict[str, Any]:
    """With no ``pattern``: every pattern and how many topologies show it. With one: up to three snippets."""
    import yaml
    if pattern is not None and pattern not in PATTERNS:
        return {"error": f"no pattern {pattern!r}", "patterns": sorted(PATTERNS)}
    docs = []
    for _, path in intents:
        try:
            doc = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        except (OSError, yaml.YAMLError):
            continue
        if isinstance(doc, dict):
            docs.append((path.parent.name, doc))
    if pattern is None:
        return {"patterns": [{"pattern": name, "what": what, "topologies": sorted(t for t, d in docs if match(d))}
                             for name, (what, match) in PATTERNS.items()],
                "next": "call build action=examples with a pattern to see the YAML"}
    what, match = PATTERNS[pattern]
    out = []
    for topo_name, doc in docs:
        for n in match(doc)[:1]:
            out.append({"topology": topo_name, "node": n.get("name"), "yaml": _snippet(n)})
        if len(out) >= PER_PATTERN:
            break
    return {"pattern": pattern, "what": what, "examples": out,
            "note": "copy the shape, not the addresses: use the target topology's own networks and names"}
