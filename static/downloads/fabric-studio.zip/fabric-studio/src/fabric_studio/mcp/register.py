"""Register a FortiGate with a FortiManager or FortiAnalyzer of the same fabric: the ``register`` tool.

Doing it by hand takes five steps on two devices, and each one fails silently when it is missed:

* the manager's admin needs ``rpc-permit`` before its JSON-RPC API answers at all;
* a FortiManager/FortiAnalyzer refuses a FortiGate **VM** until ``fgfm-allow-vm`` is enabled, and says nothing;
* the gate must point at the manager (central management, or FortiAnalyzer logging) at its in-fabric address;
* the gate then shows up on the manager as *unregistered*, under its serial, and has to be promoted;
* promoting needs the gate's admin login, which the agent must never handle.

This tool does them in order, reads what is already in place first (so a step that is done is skipped), and
passes the gate's login from Fabric Studio's own record straight to the manager: it never appears in a plan, a
result or an error. A change is a plan first; ``confirm=true`` asks the person, then runs it and reads back.
"""
from __future__ import annotations

import re
import time
from typing import Any

from mcp.server.mcpserver.exceptions import ToolError

from fabric_studio.mcp import device as dev
from fabric_studio.mcp import fortios as fos
from fabric_studio.mcp import rawexec as rx
from fabric_studio.mcp.server import _LONG_TOOL_DEADLINE_S, _client, _refuse_if_locked, _tool

MANAGERS = ("FMG", "FAZ")
ADOM_RX = re.compile(r"^[A-Za-z0-9_-]{1,35}$")
SERIAL_RX = re.compile(r"Serial-Number:\s*(\S+)")
APPEAR_S = 240      # a gate checks in within a minute once the manager allows VMs
TASK_S = 240


def _mgmt_ip(host: str, row: dict[str, Any]) -> str:
    return dev.mgmt_ip(_client(dev._pod_host(host)), row)


def _cli(t: fos.Target, script: str) -> str:
    res = rx._ssh_fortios(t, script, 60)
    if res.get("failed_line"):
        raise ToolError(f"{t.name} refused {res['failed_line']!r}: {res['output'].splitlines()[-1]}")
    return res["output"]


def _rpc(t: fos.Target, verb: str, url: str, body: dict[str, Any] | None = None) -> dict[str, Any]:
    return rx._jsonrpc(t, verb, url, body)


def _rows(m: fos.Target, adom: str) -> list[dict[str, Any]]:
    res = _rpc(m, "get", f"/dvmdb/adom/{adom}/device",
               {"fields": ["name", "sn", "ip", "mgmt_mode", "conn_status"], "loadsub": 0})
    if res["status"] != 0:
        raise ToolError(f"{m.name} would not list its devices (code {res['status']}: {res['message']})")
    return [d for d in res.get("data") or [] if isinstance(d, dict)]


def _state(g: fos.Target, m: fos.Target, kind: str, mgr_ip: str, adom: str) -> dict[str, Any]:
    """What is in place now, read only."""
    status = rx._ssh_fortios(g, "get system status", 60)["output"]
    sn = (SERIAL_RX.search(status) or [None, None])[1]
    if kind == "FMG":
        cfg = rx._ssh_fortios(g, "show system central-management", 60)["output"]
        pointed = "fortimanager" in cfg and mgr_ip in cfg
    else:
        cfg = rx._ssh_fortios(g, "show log fortianalyzer setting", 60)["output"]
        pointed = mgr_ip in cfg and "set status enable" in cfg
    glob = rx._ssh_fortios(m, "show system global", 60)["output"]
    allow_vm = "fgfm-allow-vm enable" in glob
    try:
        rows, rpc_ok = _rows(m, adom), True
    except fos.DeviceError:
        rows, rpc_ok = [], False
    row = next((d for d in rows if d.get("sn") == sn), None)
    return {"serial": sn, "pointed": pointed, "allow_vm": allow_vm, "rpc": rpc_ok, "row": row}


def _managed(row: dict[str, Any] | None) -> bool:
    return bool(row) and str(row.get("mgmt_mode") or "0") not in ("0", "unreg", "")


def _steps(st: dict[str, Any], kind: str, g: fos.Target, m: fos.Target, mgr_ip: str, adom: str) -> list[str]:
    if _managed(st["row"]):
        return []   # already managed: the prerequisites did their job, or were never needed
    out = []
    if not st["rpc"]:
        out.append(f"{m.name}: allow JSON-RPC for {m.user} (rpc-permit read-write)")
    if not st["allow_vm"]:
        out.append(f"{m.name}: accept FortiGate VMs (fgfm-allow-vm enable)")
    if not st["pointed"]:
        out.append(f"{g.name}: " + (f"central management = FortiManager {mgr_ip}" if kind == "FMG"
                                    else f"send logs to FortiAnalyzer {mgr_ip} in real time"))
    if not _managed(st["row"]):
        out.append(f"{m.name}: wait for {g.name} ({st['serial']}) to check in, then authorize it into ADOM {adom} "
                   f"with {g.name}'s admin login (passed from Fabric Studio, never shown)")
    return out


def _wait_row(m: fos.Target, adom: str, sn: str, until: float) -> dict[str, Any] | None:
    while time.monotonic() < until:
        row = next((d for d in _rows(m, adom) if d.get("sn") == sn), None)
        if row:
            return row
        time.sleep(10)
    return None


def _wait_task(m: fos.Target, task: Any) -> dict[str, Any]:
    until = time.monotonic() + TASK_S
    while time.monotonic() < until:
        d = _rpc(m, "get", f"/task/task/{task}").get("data") or {}
        if isinstance(d, dict) and d.get("state") in (4, "done"):
            return d
        time.sleep(5)
    return {"timeout": True}


@_tool(deadline_s=_LONG_TOOL_DEADLINE_S, mutating=True)
def register(host: str, gate: str, manager: str, fabric: str | None = None, adom: str = "root",
             confirm: bool = False) -> dict[str, Any]:
    """MUTATING. Register a FortiGate (``gate``) with a FortiManager or FortiAnalyzer (``manager``) of the same
    fabric, so it shows as managed there (FortiManager) or is authorized and its logs are stored (FortiAnalyzer).
    Use this instead of configuring both sides by hand with ``device`` and ``run``.

    It reads what is already in place and plans only the missing steps: allowing the manager's JSON-RPC API and
    FortiGate VMs, pointing the gate at the manager's in-fabric address, waiting for the gate to check in, and
    authorizing it into ``adom`` (default root) with the gate's admin login, which Fabric Studio holds and the
    tool passes straight to the manager. Without ``confirm=true`` it returns the plan; with it the person is asked
    to approve, then it runs and reads the manager's device list back (``verified``). Both devices need SSH and
    HTTPS access PUBLIC. Already registered: a no-op."""
    if not ADOM_RX.fullmatch(adom):
        raise ToolError("adom is an ADOM name such as root")
    g, grow = dev.resolve(host, gate, fabric, types=("FGT",), need=("SSH",))
    m, mrow = dev.resolve(host, manager, fabric or grow["fabric"], types=MANAGERS, need=("SSH", "HTTPS"))
    if mrow["fabric"] != grow["fabric"]:
        raise ToolError(f"{g.name} and {m.name} are in different fabrics; a gate registers with a manager in its own")
    kind = str(mrow["vm_type"])
    mgr_ip = _mgmt_ip(host, mrow)
    try:
        st = _state(g, m, kind, mgr_ip, adom)
        if not st["serial"]:
            raise ToolError(f"could not read {g.name}'s serial number from get system status")
        steps = _steps(st, kind, g, m, mgr_ip, adom)
        plan = {"gate": g.name, "manager": m.name, "type": kind, "fabric": g.fabric, "adom": adom,
                "manager_address": mgr_ip, "serial": st["serial"], "steps": steps, "noop": not steps}
        if not steps:
            return {"executed": False, **plan, "reason": f"{g.name} is already managed by {m.name}"}
        if not confirm:
            return {"dry_run": True, **plan, "note": "re-run with confirm=true to do it; the person is asked first"}
        _refuse_if_locked(g.host)
        done = []
        if not st["rpc"]:
            _cli(m, f"config system admin user\nedit {m.user}\nset rpc-permit read-write\nend")
            done.append("rpc-permit")
        if not st["allow_vm"]:
            _cli(m, "config system global\nset fgfm-allow-vm enable\nend")
            done.append("fgfm-allow-vm")
        if not st["pointed"]:
            if kind == "FMG":
                _cli(g, f'config system central-management\nset type fortimanager\nset fmg "{mgr_ip}"\nend')
            else:
                _cli(g, f'config log fortianalyzer setting\nset status enable\nset server "{mgr_ip}"\n'
                        "set upload-option realtime\nend")
            done.append("gate pointed at manager")
        row = st["row"] or _wait_row(m, adom, st["serial"], time.monotonic() + APPEAR_S)
        if row is None:
            return {"executed": True, "verified": False, **plan, "done": done,
                    "warning": f"{g.name} did not check in to {m.name} within {APPEAR_S // 60} minutes. Check that "
                               f"{g.name} reaches {mgr_ip} (run: execute ping {mgr_ip})."}
        if not _managed(row):
            res = _rpc(m, "exec", "/dvm/cmd/add/device",
                       {"data": {"adom": adom, "flags": ["create_task"],
                                 "device": {"name": row.get("name"), "device action": "promote_unreg",
                                            "adm_usr": g.user, "adm_pass": g.password}}})
            if res["status"] != 0:
                raise ToolError(f"{m.name} refused to authorize {g.name} (code {res['status']}: {res['message']})")
            task = (res.get("data") or {}).get("taskid") if isinstance(res.get("data"), dict) else None
            if task is not None:
                t = _wait_task(m, task)
                if t.get("timeout"):
                    return {"executed": True, "verified": False, **plan, "done": done,
                            "warning": f"{m.name}'s authorize task {task} did not finish in {TASK_S // 60} minutes"}
            done.append("authorized")
        after = next((d for d in _rows(m, adom) if d.get("sn") == st["serial"]), None)
        ok = _managed(after)
        return {"executed": True, "verified": ok, **plan, "done": done,
                "now": {k: (after or {}).get(k) for k in ("name", "sn", "mgmt_mode", "conn_status")},
                **({} if ok else {"warning": f"{m.name} does not list {g.name} as managed after authorizing"})}
    except fos.DeviceError as e:
        raise ToolError(fos._scrub(str(e), g)) from None

