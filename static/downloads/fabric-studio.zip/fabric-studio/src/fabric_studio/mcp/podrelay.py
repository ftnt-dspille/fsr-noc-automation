"""Reach a device through its pod when the device's own access is not PUBLIC.

``run`` normally talks to a device on the pod's public forwards. When those are closed it relays instead: SSH to
the pod (its own login, password then the configured pod key), and from the pod's shell to the device's address
inside the fabric. The device's login still comes from Fabric Studio and never reaches the agent: a command goes
through the jump channel's askpass helper, and an API call through ``curl`` with the login in a 0600 config file
that is removed when the call ends. The pod shell has ``curl`` but no Python, so the API side is plain shell.
"""
from __future__ import annotations

import base64
import json
import re
import shlex
from pathlib import Path
from typing import Any

from fabric_studio.channels import jump
from fabric_studio.mcp import fortios as fos
from fabric_studio.mcp import fortios_cli as cli
from fabric_studio.mcp import instances as inst

MARK = "FSHRELAYMK"
STATUS_MARK = "FSHRELAYST"
ACCESS_KEY = Path.home() / ".fsh" / "device_access_key"


def _pod_login(host: str) -> tuple[str, str]:
    creds = inst.creds_for(host)
    if not creds:
        raise fos.DeviceError(f"no login is held for the pod {host}, so nothing can be relayed through it")
    return creds


def _hop(host: str, payload: str, timeout_s: int) -> tuple[int, str]:
    """Run a bash payload in the pod's shell; returns (rc, output between the markers)."""
    import asyncio
    user, password = _pod_login(host)
    body = f"echo {MARK}; {payload}; _rc=$?; echo {MARK}:$_rc"
    try:
        rc, out, _ = asyncio.run(jump._jump_async(host, user, password, body, marker=MARK, timeout_s=timeout_s))
    except Exception as e:
        key = jump.configured_pod_key(host) if jump._is_pod_auth_failure(e) else None
        if not key:
            raise fos.Unreachable(f"cannot relay through the pod {host} over SSH ({type(e).__name__})") from None
        try:
            rc, out, _ = asyncio.run(jump._jump_async(host, user, password, body, marker=MARK, timeout_s=timeout_s,
                                                      pod_key=key))
        except Exception as e2:
            raise fos.Unreachable(f"cannot relay through the pod {host} over SSH ({type(e2).__name__})") from None
    return rc, out


def command(t: fos.Target, ip: str, cmd: str, timeout_s: int, linux: bool) -> dict[str, Any]:
    """A command on the device over SSH from the pod. A Linux guest is tried with the device-access key first
    (many images take keys only), then with the fabric's password."""
    user, password = _pod_login(t.host)
    attempts = []
    if linux and ACCESS_KEY.is_file():
        attempts.append({"type": "key", "user": t.user, "key_path": str(ACCESS_KEY)})
    attempts.append({"type": "password", "user": t.user, "password": t.password})
    rc, out, err = 1, "", ""
    for auth in attempts:
        rc, out, err = jump.jump_exec(t.host, user, password, ip, auth=auth, command=cmd, timeout_s=timeout_s + 30)
        if not (rc == 255 and "permission denied" in out.lower()):
            break
    if rc == 255 and "permission denied" in out.lower():
        raise fos.LoginRefused(f"{t.name} refused its Fabric Studio login over SSH from the pod")
    if not out and err.startswith("[jump-ssh connect failed"):
        raise fos.Unreachable(f"cannot reach {t.name} at {ip} from the pod: {err.split('] ', 1)[-1]}")
    res: dict[str, Any] = {"output": out, "exit_status": rc}
    if not linux:
        failed = next((ln for ln in out.splitlines() if cli.FAIL_RX.search(ln)), None)
        if failed:
            res["failed_line"] = failed.strip()
    return res


def _curl(ip: str, method: str, path: str, body: Any, *, auth_line: str | None = None,
          cookies: bool = False, headers: tuple[str, ...] = ()) -> str:
    """One curl call as shell. The body travels base64-encoded, so no quoting reaches the shell."""
    parts = ["curl -sk --max-time 170", f"-X {shlex.quote(method)}", "-o \"$_d/out\" -w '%{http_code}'"]
    if auth_line:
        parts.append('-K "$_d/auth"')
    if cookies:
        parts.append('-b "$_d/jar" -c "$_d/jar"')
    parts += [f"-H {shlex.quote(h)}" for h in headers]
    if body is not None:
        b64 = base64.b64encode(json.dumps(body).encode()).decode()
        parts.append(f"-H 'Content-Type: application/json' --data-binary @<(echo {b64} | base64 -d)")
    parts.append(shlex.quote(f"https://{ip}{path}"))
    return " ".join(parts)


def _session_dir(auth_line: str | None) -> str:
    """Make a private temp dir; an auth line (a curl config entry holding the login) goes into a 0600 file."""
    head = '_d=$(mktemp -d); chmod 700 "$_d"; trap \'rm -rf "$_d"\' EXIT'
    if auth_line:
        # base64, so no character of the login reaches the pod's CLI parser or the shell unencoded
        b64 = base64.b64encode((auth_line + "\n").encode()).decode()
        head += f"; umask 077; echo {b64} | base64 -d > \"$_d/auth\""
    return head


def _curl_value(s: str) -> str:
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


def api(t: fos.Target, ip: str, vm_type: str, method: str, path: str, query: dict[str, str],
        body: Any) -> tuple[int, str]:
    """An HTTPS call on the device from the pod. Returns (http status, response text)."""
    import urllib.parse
    full = path + (f"?{urllib.parse.urlencode(query)}" if query else "")
    if vm_type == "FGT":
        return _fgt_api(t, ip, method, full, body)
    return _call(t, ip, method, full, body, f"user = {_curl_value(t.user + ':' + t.password)}")


def _call(t: fos.Target, ip: str, method: str, full: str, body: Any, auth: str) -> tuple[int, str]:
    script = f"{_session_dir(auth)}; _s=$({_curl(ip, method, full, body, auth_line=auth)})"
    script += f"; echo {STATUS_MARK}:$_s; cat \"$_d/out\""
    _, out = _hop(t.host, script, 200)
    m = re.search(rf"{STATUS_MARK}:(\d+)\n?", out)
    if not m or m.group(1) == "000":
        raise fos.Unreachable(f"cannot reach {t.name} over HTTPS at {ip} from the pod; is it up?")
    return int(m.group(1)), out[m.end():]


def jsonrpc(t: fos.Target, ip: str, verb: str, url: str, body: Any) -> dict[str, Any]:
    """One FortiManager / FortiAnalyzer JSON-RPC request in its own session, run from the pod."""
    login = {"id": 1, "method": "exec", "params": [{"url": "/sys/login/user",
                                                    "data": {"user": t.user, "passwd": t.password}}]}
    req = {"id": 2, "method": verb.lower(), "params": [{**(body if isinstance(body, dict) else {}), "url": url}],
           "session": "@SESSION@"}
    out_ = {"id": 3, "method": "exec", "params": [{"url": "/sys/logout"}], "session": "@SESSION@"}

    def b64(d: dict[str, Any]) -> str:
        return base64.b64encode(json.dumps(d).encode()).decode()
    post = f"curl -sk --max-time 170 -H 'Content-Type: application/json' {shlex.quote(f'https://{ip}/jsonrpc')}"
    # the login body holds the password: it goes through a 0600 file, never the command line
    script = (f"{_session_dir(None)}; umask 077; printf '%s' {shlex.quote(b64(login))} | base64 -d > \"$_d/login\"; "
              f"_l=$({post} --data-binary @\"$_d/login\"); rm -f \"$_d/login\"; "
              "_sess=$(printf '%s' \"$_l\" | sed -n 's/.*\"session\" *: *\"\\([^\"]*\\)\".*/\\1/p'); "
              f"echo {STATUS_MARK}:login; printf '%s\\n' \"$_l\" | sed 's/\"session\" *: *\"[^\"]*\"/\"session\":\"\"/'; "
              f"[ -n \"$_sess\" ] || exit 0; "
              f"_q=$(printf '%s' {shlex.quote(b64(req))} | base64 -d | sed \"s/@SESSION@/$_sess/\"); "
              f"echo {STATUS_MARK}:result; {post} --data-binary \"$_q\"; echo; "
              f"printf '%s' {shlex.quote(b64(out_))} | base64 -d | sed \"s/@SESSION@/$_sess/\" | "
              f"{post} --data-binary @- >/dev/null")
    _, out = _hop(t.host, script, 200)
    parts = dict(re.findall(rf"{STATUS_MARK}:(\w+)\n(.*?)(?=\n{STATUS_MARK}:|\Z)", out, re.S))
    if "login" not in parts or not parts["login"].strip():
        raise fos.Unreachable(f"cannot reach {t.name} over HTTPS at {ip} from the pod; is it up?")
    try:
        login_res = json.loads(parts["login"])
    except ValueError:
        raise fos.DeviceError(f"{t.name} answered with something that is not JSON-RPC; it is probably still "
                              "booting") from None
    return {"login": login_res, "result": json.loads(parts["result"]) if parts.get("result", "").strip() else None}


def _fgt_api(t: fos.Target, ip: str, method: str, full: str, body: Any) -> tuple[int, str]:
    """FortiOS 7.6 has no session login, so the call carries the API key the device tool keeps for this gate
    (minted over SSH on first use, the same key a direct call uses). It goes in the private curl config."""
    level = "ro" if method == "GET" else "rw"
    key, fresh = fos._load_key(t, level), False
    if not key:
        key, fresh = _mint_or_say(t, level), True
    code, text = _call(t, ip, method, full, body, f"header = {_curl_value('Authorization: Bearer ' + key)}")
    if code == 401 and not fresh:   # a reinstall wiped it
        fos._drop_key(t, level)
        key = _mint_or_say(t, level)
        code, text = _call(t, ip, method, full, body, f"header = {_curl_value('Authorization: Bearer ' + key)}")
    return code, text


def _mint_or_say(t: fos.Target, level: str) -> str:
    try:
        return fos.mint(t, level)
    except fos.Unreachable:
        raise fos.DeviceError(f"{t.name}'s API needs a key, which is created over its SSH access, and neither its "
                              "SSH nor its HTTPS access is public. Use command=... instead: it runs on the CLI "
                              "through the pod.") from None
