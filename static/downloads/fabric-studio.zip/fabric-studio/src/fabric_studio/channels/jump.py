"""Unified jump-SSH transport: pod-shell bash → ssh onward to a fabric guest.

Both Project A (ssh-jump channel, ``core/channels/ssh.py``) and Project B
(fabric config phase, ``backend/fabric/config.py``) share this transport.
Before this module existed, two parallel implementations did the same
pod-hop with different auth (key vs password), different markers, and
different output parsing -- ~160 lines of duplicated logic. This module is
the one parameterized transport; the callers are thin wrappers.

The hop: asyncssh into ``pod_host:22`` (pod-shell admin), escape to bash
via ``fabric_studio.pod_shell._wrap``, run an inner ``ssh`` onward to ``dev_ip``
using either a base64-staged key (key auth) or ``SSH_ASKPASS`` (password
auth). Output is fenced by a metacharacter-free marker so the inner SSH's
stdout + exit code can be extracted from the pod-shell's own chatter.
"""
from __future__ import annotations

import asyncio
import base64
import os
import re
import shlex
import subprocess
import time
from typing import Any

from fabric_studio.pod_shell import _strip_fs_exit_trailer, _wrap

JUMP_MARKER = "FSHJUMPMK"

# Inner-ssh (pod → guest) failures that mean "the guest isn't ready yet", not
# "the command failed". ssh exits 255 on its own connection errors; a freshly
# installed VM's sshd isn't listening for the first ~20-60s of boot, so the
# first config command races it. These are retryable -- wait the guest out.
INNER_SSH_TRANSIENT = re.compile(
    r"Connection refused|Connection timed out|No route to host|"
    r"Connection reset|Connection closed|kex_exchange_identification|"
    r"Network is unreachable|Host is down|Name or service not known",
    re.IGNORECASE,
)


def _is_pod_auth_failure(exc: Exception) -> bool:
    """True when the POD hop was refused for credentials (not a network error).

    Matched on the message rather than ``asyncssh.PermissionDenied`` so this
    module keeps its lazy asyncssh import.
    """
    return "permission denied" in str(exc).lower()


# ── Pod-side identity ───────────────────────────────────────────────────────

def configured_pod_key(host: str) -> str | None:
    """The SSH private key configured for ``host``, or None.

    ``$FS_POD_SSH_KEY`` wins; otherwise the identity ``ssh -G <host>`` resolves.
    NB ``ssh -G`` reports the built-in defaults (``~/.ssh/id_rsa`` …) for a host
    with no ``Host`` block at all, so a returned path does NOT prove the key is
    the right one for this pod -- which is why the callers here use it only as a
    FALLBACK after password auth is refused, never as the first choice. Offering
    an unrelated default key first is what makes a password-auth pod fail with
    six ``Permission denied`` attempts that look like an sshd ban.
    """
    explicit = os.environ.get("FS_POD_SSH_KEY")
    if explicit:
        path = os.path.expanduser(explicit)
        return path if os.path.isfile(path) else None
    try:
        out = subprocess.check_output(
            ["ssh", "-G", host], text=True, stderr=subprocess.DEVNULL)
    except (OSError, subprocess.CalledProcessError):
        return None
    for line in out.splitlines():
        if line.startswith("identityfile "):
            path = os.path.expanduser(line.split(None, 1)[1])
            if os.path.isfile(path):
                return path
    return None


# ── Payload builders ────────────────────────────────────────────────────────

def build_key_payload(dev_ip: str, ssh_user: str, key_path: str, command: str,
                      *, marker: str = JUMP_MARKER) -> str:
    """Bash payload that stages the base64 key in a tmpfile and SSHes onward.

    Key auth: the private key is base64-encoded into the payload, written to
    a pod tmpfile (umask 077), used for ``ssh -i``, then scrubbed. The inner
    SSH uses ``2>&1`` so the caller gets combined stdout+stderr (needed because
    a freshly-booted guest's sshd prints diagnostic messages on stderr that
    the retry logic checks for transient errors)."""
    key_b64 = base64.b64encode(open(os.path.expanduser(key_path), "rb").read()).decode()  # noqa: SIM115
    keyfile = "/tmp/_fsh_jump_key"
    return (
        f"umask 077; echo {key_b64} | base64 -d > {keyfile}; echo {marker}; "
        f"ssh -i {keyfile} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "
        f"-o PasswordAuthentication=no -o BatchMode=yes -o LogLevel=ERROR "
        f"-o ConnectTimeout=10 {shlex.quote(ssh_user)}@{shlex.quote(dev_ip)} "
        f"{shlex.quote(command)} 2>&1; _rc=$?; echo {marker}:$_rc; rm -f {keyfile}; exit $_rc"
    )


def build_password_payload(dev_ip: str, dev_user: str, dev_pass: str,
                           command: str, *, marker: str = JUMP_MARKER,
                           sudo: bool = False) -> str:
    """Bash payload that uses SSH_ASKPASS to inject the password non-interactively.

    Password auth: ``SSH_ASKPASS`` + ``setsid -w`` detaches from the controlling
    tty so OpenSSH actually calls the askpass helper. ``PreferredAuthentications=
    password`` + ``PubkeyAuthentication=no`` avoids burning the target's
    MaxAuthTries with default pubkeys before the password is tried.

    ``sudo=True`` wraps the inner command with ``echo <pass> | sudo -S <cmd>``.
    """
    # A UNIQUE askpass path per invocation, not a fixed /tmp name. The pod runs
    # every guest hop, so concurrent provision items share its /tmp: with a fixed
    # path, session A's trailing `rm -f` deletes the helper session B is about to
    # exec, and B dies with
    #   ssh_askpass: exec(/tmp/_fsh_askpass.sh): No such file or directory
    #   Permission denied
    # which reads as a bad credential rather than a race. $$ (the hop shell's pid)
    # plus a nanosecond stamp is enough; the file is still removed at the end.
    askpass = "/tmp/_fsh_askpass.$$.$(date +%s%N).sh"
    inner = command if not sudo else f"echo {dev_pass!r} | sudo -S {command}"
    parts = [
        f"_askpass={askpass}",
        f"printf '#!/bin/sh\\necho %s\\n' {shlex.quote(dev_pass)} > \"$_askpass\"",
        'chmod 700 "$_askpass"',
        f"echo {shlex.quote(marker)}",
        (
            f"SSH_ASKPASS=\"$_askpass\" SSH_ASKPASS_REQUIRE=force setsid -w "
            f"ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "
            f"-o LogLevel=ERROR -o ConnectTimeout=10 "
            f"-o PreferredAuthentications=password -o PubkeyAuthentication=no "
            f"-o IdentitiesOnly=yes "
            f"{shlex.quote(dev_user)}@{shlex.quote(dev_ip)} "
            f"{shlex.quote(inner)}"
        ),
        "_rc=$?",
        f"echo {shlex.quote(marker)}:$_rc",
        'rm -f "$_askpass"',
        "exit $_rc",
    ]
    return "; ".join(parts)


# ── Marker parsing ──────────────────────────────────────────────────────────

def split_marked(raw: str, marker: str) -> tuple[str, int]:
    """Extract the inner SSH stdout + exit code from a marker-wrapped payload.

    Returns ``(inner_stdout, rc)``. If the marker is absent (inner SSH never
    ran), returns ``(raw, -1)`` -- rc -1 signals "no exit code captured"."""
    start = raw.find(marker)
    if start < 0:
        return raw, -1
    after = raw[start + len(marker):].lstrip("\n")
    end = after.find(marker + ":")
    if end < 0:
        return after, -1
    inner = after[:end].rstrip("\n")
    tail = after[end + len(marker) + 1:]
    try:
        rc = int(tail.strip().splitlines()[0])
    except (ValueError, IndexError):
        rc = -1
    return inner, rc


# ── Async runner ────────────────────────────────────────────────────────────

async def _jump_async(pod_host: str, pod_user: str, pod_pass: str,
                      payload: str, *, marker: str, timeout_s: int,
                      pod_key: str | None = None) -> tuple[int, str, str]:
    """One pod-hop: connect to ``pod_host:22``, run the wrapped payload, parse
    the marker. Returns ``(rc, inner_stdout, pod_stderr)``.

    ``pod_key`` selects POD-side key auth (``client_keys=[pod_key]``, no
    password) instead of pod-side password auth. The two pod-side modes are
    independent of the guest-side ``auth`` the payload was built with, so a
    key-only pod fronting password-auth appliances -- which pod-side password
    auth cannot reach at all -- is now expressible.

    The payload is wrapped with ``fabric_studio.pod_shell._wrap``: SSH to an FS pod lands
    in the restricted Fabric CLI, not a POSIX shell, so an unwrapped bash
    payload is simply not executed.
    """
    import asyncssh

    connect_kw: dict[str, Any] = {"known_hosts": None}
    if pod_key:
        connect_kw["client_keys"] = [pod_key]
    else:
        connect_kw["password"] = pod_pass
        connect_kw["client_keys"] = []

    async with asyncio.timeout(timeout_s):
        async with asyncssh.connect(pod_host, port=22, username=pod_user,
                                    **connect_kw) as conn:
            r = await conn.run(_wrap(payload))
    clean, _ = _strip_fs_exit_trailer(r.stdout or "")
    inner_out, inner_rc = split_marked(clean, marker)
    return inner_rc, inner_out, (r.stderr or "")


# ── Sync wrapper with retries ───────────────────────────────────────────────

def jump_exec(pod_host: str, pod_user: str, pod_pass: str, dev_ip: str, *,
              auth: dict[str, Any], command: str, timeout_s: int = 120,
              retries: int = 1, retry_sleep_s: int = 8,
              marker: str = JUMP_MARKER,
              pod_key: str | None = None,
              pod_key_fallback: bool = True) -> tuple[int, str, str]:
    """Run ``command`` on ``dev_ip`` by hopping through ``pod_host:22``.

    ``auth`` selects the guest-side auth method:

    * ``{"type": "key", "user": "<ssh_user>", "key_path": "<path>"}`` --
      base64-staged key (umask 077 tmpfile, ``ssh -i``). Inner SSH uses
      ``2>&1`` so the returned stdout includes inner stderr (needed for
      transient-error detection on freshly-booted guests).
    * ``{"type": "password", "user": "<dev_user>", "password": "<pass>"}`` --
      ``SSH_ASKPASS`` injection. Inner SSH keeps stderr separate.

    The POD side authenticates independently of the guest side. By default it
    uses ``pod_pass``; pass ``pod_key`` to use a private key instead. On a pod
    that refuses the password (an FS pod whose API password is NOT an SSH
    credential -- key-only sshd), ``pod_key_fallback`` re-tries once with the
    key ``configured_pod_key(pod_host)`` resolves. That combination -- pod key
    plus guest password -- previously had no implementation in either transport,
    so every health check and services-phase play against such a pod failed with
    an empty result that read as "the appliance is broken".

    Returns ``(rc, stdout, stderr)``. Retries the *connection* (not a non-zero
    command rc) on transient inner-SSH failures (rc 255 + "Connection refused"
    etc.) so a still-settling guest doesn't false-fail. A genuine non-zero rc
    returns immediately.
    """
    if auth["type"] == "key":
        payload = build_key_payload(dev_ip, auth["user"], auth["key_path"],
                                    command, marker=marker)
    elif auth["type"] == "password":
        sudo = bool(auth.get("sudo", False))
        payload = build_password_payload(dev_ip, auth["user"], auth["password"],
                                         command, marker=marker, sudo=sudo)
    else:
        raise ValueError(f"unknown auth type: {auth['type']!r}")

    last_err = ""
    key = pod_key
    tried_key_fallback = pod_key is not None
    # `attempts` is a budget, not a fixed range: the pod-key fallback below adds
    # one attempt rather than consuming a retry, so the default retries=1 caller
    # still gets a real chance to use the key.
    attempts = retries
    i = 0
    while i < attempts:
        i += 1
        try:
            rc, stdout, stderr = asyncio.run(
                _jump_async(pod_host, pod_user, pod_pass, payload,
                            marker=marker, timeout_s=timeout_s, pod_key=key))
        except Exception as e:
            last_err = f"{type(e).__name__}: {str(e)[:160]}"
            # Pod refused the password: it is key-only. Switch to the configured
            # identity and retry, without consuming a retry slot -- otherwise a
            # single-retry caller (the default) never gets to try the key at all.
            if (pod_key_fallback and not tried_key_fallback
                    and _is_pod_auth_failure(e)):
                tried_key_fallback = True
                key = configured_pod_key(pod_host)
                if key:
                    attempts += 1
                    continue
            if i < attempts:
                time.sleep(retry_sleep_s)
            continue
        # Inner SSH 255 = ssh's own connection error (not a remote command rc).
        # A freshly-installed VM's sshd isn't listening for the first ~20-60s,
        # so the first config command would false-fail ("Connection refused")
        # with no retry. Treat those as transient and wait the guest out.
        if rc == 255 and INNER_SSH_TRANSIENT.search(stdout):
            last_err = f"inner ssh to {dev_ip} not ready: {stdout[:160]}"
            if i < attempts:
                time.sleep(retry_sleep_s)
            continue
        return rc, stdout, stderr
    # All retries exhausted -- return a connection-failure sentinel.
    return 1, "", f"[jump-ssh connect failed after {i} attempts] {last_err}"
