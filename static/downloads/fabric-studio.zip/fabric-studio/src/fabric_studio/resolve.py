"""Resolve the pod login, a fabric, a VM and a SOAR guest's management IP.

Small selectors shared by the CLIs and the MCP server. They print a message and
``sys.exit`` on an unresolvable selector, which the CLIs rely on.
"""
from __future__ import annotations

import sys

from fabric_studio import admin as fs_admin
from fabric_studio.client.client import FabricStudioClient
from fabric_studio.pod.ports import get_vm_mgmt_ip


def pod_creds(host: str, user: str | None, pw: str | None) -> tuple[str, str]:
    """Pod login creds: explicit flags win, else macOS Keychain (account=host),
    else the backend DB's Pod row, else env. See ``fabric_studio.keychain``."""
    from fabric_studio.keychain import CredsError, get_secret, resolve_pod_login
    # The DB is optional for CLI use. Check the platform keyring first so a
    # healthy Keychain-backed setup does not probe an uninitialized local DB and
    # emit a misleading ``no such table: pod`` warning on every API call.
    stored = get_secret(host) if not pw else None
    if stored:
        return user or "admin", stored
    try:
        return resolve_pod_login(host, user, pw)
    except CredsError as e:
        sys.exit(str(e))


def soar_mgmt_ip(c: FabricStudioClient, fabric_id: int, vm: dict) -> str:
    """Resolve the SOAR VM's mgmt IP from the live VM ports."""
    full = c.get(
        f"api/v1/model/fabric/{fabric_id}/vm/{vm['id']}?related_fields=ports"
    ).json().get("object") or vm
    ip = get_vm_mgmt_ip(full)
    if not ip:
        ports = full.get("ports") or []
        by_id = {p.get("id"): p for p in ports}
        port = by_id.get(full.get("mgmt_port")) or (ports[0] if ports else {})
        ip = port.get("ipv4addr")
    if not ip:
        sys.exit("Could not determine SOAR mgmt IP from VM ports.")
    return ip


def resolve_fabric_id(c: FabricStudioClient, fabric: str | None) -> int:
    """--fabric may be an id, a name, or omitted (use the running fabric)."""
    if fabric and str(fabric).isdigit():
        return int(fabric)
    if fabric:
        f = fs_admin.get_fabric_by_name(c, fabric)
        if not f:
            sys.exit(f"No fabric named {fabric!r} on this pod.")
        return f["id"]
    running = c.get("api/v1/runtime/fabric").json().get("object") or {}
    if not running.get("id"):
        sys.exit("No running fabric and no --fabric given.")
    return running["id"]


def resolve_vm(c: FabricStudioClient, fabric_id: int, vm: str, vm_type: str | None) -> dict:
    """--vm may be an id, a name, or omitted (single VM of --vm-type)."""
    vms = fs_admin.list_fabric_vms(c, fabric_id)
    if vm and str(vm).isdigit():
        match = [v for v in vms if str(v.get("id")) == str(vm)]
    elif vm:
        match = [v for v in vms if v.get("name") == vm]
    elif vm_type:
        match = [v for v in vms if v.get("vm_type") == vm_type]
    else:
        match = [v for v in vms if v.get("vm_type") == "SOAR"]
    if not match:
        names = ", ".join(f"{v['id']}:{v['name']}({v['vm_type']})" for v in vms)
        sys.exit(f"VM {vm or vm_type or 'SOAR'!r} not found. Available: {names}")
    if len(match) > 1:
        names = ", ".join(f"{v['id']}:{v['name']}" for v in match)
        sys.exit(f"Ambiguous VM selector; pass --vm <id>. Candidates: {names}")
    return match[0]
