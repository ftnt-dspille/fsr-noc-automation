"""Declarative Fabric Studio topology reconciler (plan → apply).

PROJECT B -- topology/builder engine. NOT in the health-check (Project A) runtime:
nothing under ``backend/api`` / ``main.py`` / ``orchestrator.py`` imports this. It
lives under ``backend/engine/`` for shared-core proximity only; callers are the
``tools/fs_topology*`` CLIs. See CLAUDE.md "Code map: three surfaces".


Terraform-style convergence for an FS fabric: you describe the intended end
state in an intent YAML (fabric + networks + switches + nodes + links); this
module reads the live model graph via ``fs_admin.read_fabric_state``, diffs
desired-vs-actual *by name*, and applies the **minimal** action that realizes
each change -- relying on ``fs_admin``'s ``ensure_*`` primitives, which are
idempotent by construction, so ``apply`` is safe to re-run.

Layering (see docs/reference/FS_TOPOLOGY_FRAMEWORK.md):

    intent (YAML)  →  reconciler (this file)  →  provider (fs_admin)  →  FS REST

Two entry points:
  * ``plan(c, intent)``  → a ``Plan`` of changes (printable diff; no mutation).
  * ``apply(c, intent, prune=...)`` → converge, then re-read and assert.

Ordering (FS dependency order): fabric → networks → switches → VMs →
cabling → port addressing → bring-up (install_fabric or synchronize) →
wait booted → re-read + assert. Destructive ops (deleting resources the
intent no longer declares) only run when ``prune=True``.

The intent's ``config:`` / ``healthchecks:`` / ``images:`` sections are
*handoff* phases, not reconciled here -- config is Ansible/SSH against booted
node endpoints (or ``tests/verification/provision.py:push``), health runs the
catalog checks against the booted devices (``health.py``). The
reconciler's job ends at "booted + reachable".
"""
from __future__ import annotations

import dataclasses
import ipaddress
import os
import re
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from fabric_studio import admin as fa
from fabric_studio import (
    topology_graph as topology,  # network-graph reachability (Topology / reachable / BFS)
)
from fabric_studio.client.client import FabricStudioClient
from fabric_studio.topology import lock as _lock
from fabric_studio.topology import payload as _payload

# ── Intent model ─────────────────────────────────────────────────────────────

# Pod-seeded shared infrastructure that is referenced by name (not owned by any
# one tenant's intent). A ``--prune`` must NEVER delete these -- doing so tears
# down every other tenant's egress/mgmt too. Matched case-insensitively against
# the live resource name. Extend an intent-owned resource's protection via
# ``protected: true`` on its network/switch spec.
SEEDED_SHARED_NAMES = {
    "internet", "internet access", "isp", "oob mgmt", "oob mgmt switch",
    "management", "mgmt",
}

# The flat set above conflates two different namespaces, and that conflation was
# load-bearing in the fortiaigate_lab incident. FS seeds NETWORKS called
# `Internet` / `ISP` / `OOB Mgmt` / `Management`, fronted by SWITCHES called
# `Internet Access` / `OOB Mgmt` (the pairing is spelled out in
# tools/fs_lxc_matrix.py SEEDED_SWITCH: network "Internet" -> switch
# "Internet Access"). `internet access` is therefore a seeded SWITCH name and
# NOT a seeded network name -- but the flat set protected it as both.
#
# Consequence: an intent that minted its own NETWORK named `Internet Access`
# (which the `internet-egress` preset used to do) got a duplicate of the seeded
# `Internet` subnet that was permanently immune to `--prune`, because its name
# matched a seeded *switch*. The duplicate could never be cleaned up, and no
# check could tell it apart from real shared infra.
#
# Splitting per kind makes the leftover duplicate prunable while keeping the
# genuinely-shared switch protected. `SEEDED_SHARED_NAMES` stays as the union
# for callers that don't know the resource kind (e.g. node names).
# Asymmetric on purpose. The SWITCH set stays permissive (it keeps every name
# the flat set had): over-protecting a switch merely means `--prune` won't delete
# it, while under-protecting one tears down another tenant's egress. The NETWORK
# set is the one that had to be tightened -- dropping `internet access` from it
# is what makes a tenant-minted duplicate of the seeded `Internet` subnet
# cleanable instead of permanently immune.
SEEDED_SHARED_NETWORK_NAMES = {"internet", "isp", "oob mgmt", "management", "mgmt"}
SEEDED_SHARED_SWITCH_NAMES = set(SEEDED_SHARED_NAMES)

# A node `access:` type -> the pod-wide security-preference flag that must be "yes"
# for FS to allocate that type's external port-forward. `apply` flips exactly the
# needed flags up front (step 0c). Console types (SERIAL/VNC/SPICE) are PRIVATE
# in-browser consoles with no external forward, so they need no flag.
_ACCESS_SECURITY_FLAG = {
    "SSH": "ssh_public_allowed",
    "HTTP": "http_public_allowed",
    "HTTPS": "https_public_allowed",
    "HTTPS2HTTP": "https_public_allowed",
    "RDP": "rdp_public_allowed",
}


def _mgmt_link(nd: NodeSpec) -> LinkSpec | None:
    """Which of a node's links must be its FS **management port**, or None.

    FS aims a node's external access port-forwards at the port flagged
    ``model.vmport.mgmt``. A node that declares a forwarding ``access:`` type but
    has no mgmt port gets a forward that listens on the pod and never reaches the
    guest (TCP connects, session hangs, no banner) -- the failure looks like a
    firewall/perimeter block, so it costs hours to diagnose. Live-confirmed on
    pod B, 07-16: flipping ``vmport.mgmt`` + the carrying switch's ``mgmt`` and
    reinstalling the fabric turned a dead SSH forward into a working one.

    Console-only access types (SERIAL/VNC/SPICE) ride the in-browser console and
    need no forward, so they don't make a node management-bearing --
    ``_ACCESS_SECURITY_FLAG`` is exactly the set that does.

    An explicit ``mgmt: true`` on a link wins; otherwise the first declared link
    is chosen (it is the node's primary segment by convention). An explicit
    ``mgmt: false`` on every link opts out entirely and is honored."""
    if not any(t in _ACCESS_SECURITY_FLAG for t in nd.access):
        return None
    explicit = [lk for lk in nd.links if lk.mgmt is True]
    if explicit:
        return explicit[0]
    if any(lk.mgmt is False for lk in nd.links) and all(
            lk.mgmt is not None for lk in nd.links):
        return None                      # every link explicitly opted out
    return next((lk for lk in nd.links if lk.mgmt is not False), None)


def _is_protected_name(name: str | None, extra: set[str],
                       seeded: set[str] | None = None) -> bool:
    # Collapse internal whitespace too (not just strip) so 'OOB  Mgmt' can't slip
    # past the 'oob mgmt' allowlist and get pruned -- deleting seeded shared infra
    # is catastrophic on a multi-tenant pod, so normalize defensively.
    n = re.sub(r"\s+", " ", (name or "").strip().lower())
    return n in (SEEDED_SHARED_NAMES if seeded is None else seeded) or n in extra


# VLAN ids OVS/802.1Q actually accept. 0 means "untagged" in the FS model and
# 4095 is reserved, so a usable tag is 1..4094. FS stores whatever you send it,
# which is why this is enforced here and not left to the API.
VLAN_MIN, VLAN_MAX = 1, 4094


def parse_vlan_id(raw: Any, where: str) -> int:
    """A single VLAN tag, validated. Raises ValueError with ``where`` in the
    message -- the intent layer is the ONLY place this is checked (``PATCH
    model/switch/port/{id}`` accepts 4096 and -1 and stores them, and the fault
    surfaces later as traffic that vanishes)."""
    try:
        vlan = int(raw)
    except (TypeError, ValueError):
        raise ValueError(f"{where}: vlan {raw!r} is not an integer") from None
    if not (VLAN_MIN <= vlan <= VLAN_MAX):
        raise ValueError(f"{where}: vlan {vlan} out of range "
                         f"({VLAN_MIN}-{VLAN_MAX}; 0 is untagged, 4095 reserved)")
    return vlan


def parse_trunk_list(raw: Any, where: str) -> tuple[int, ...]:
    """A trunk allow-list -- ``[100, 200]``, ``"100,200"`` or ``"100-104,200"``
    -- validated and normalized to a sorted tuple. Every element goes through
    :func:`parse_vlan_id`, so a typo'd or out-of-range member is an error rather
    than a string FS will happily store."""
    if isinstance(raw, (str, bytes)):
        items: list[Any] = [x.strip() for x in str(raw).split(",") if x.strip()]
    elif isinstance(raw, (list, tuple)):
        items = list(raw)
    else:
        items = [raw]
    if not items:
        raise ValueError(f"{where}: trunk list is empty")
    out: set[int] = set()
    for it in items:
        txt = str(it).strip()
        if "-" in txt and not txt.startswith("-"):
            lo_s, hi_s = txt.split("-", 1)
            lo = parse_vlan_id(lo_s, where)
            hi = parse_vlan_id(hi_s, where)
            if hi < lo:
                raise ValueError(f"{where}: trunk range {txt!r} is inverted")
            out.update(range(lo, hi + 1))
        else:
            out.add(parse_vlan_id(it, where))
    return tuple(sorted(out))


def format_trunk(vlans: Iterable[int]) -> str:
    """The FS ``model.switchport.trunk`` wire format for a set of VLANs."""
    return ",".join(str(v) for v in sorted(set(vlans)))


@dataclass
class NetworkSpec:
    name: str
    cidr: str                       # e.g. "10.254.254.0/24"
    gateway: str | None = None
    dns1: str | None = None
    dns2: str | None = None
    # Terraform ``lifecycle { prevent_destroy }``: a prune must refuse to delete
    # this resource even when it's no longer declared. Pod-seeded shared nets are
    # protected by name automatically (see SEEDED_SHARED_NAMES).
    protected: bool = False

    @property
    def ipv4network(self) -> str:
        return str(ipaddress.IPv4Network(self.cidr, strict=False).network_address)

    @property
    def ipv4netmask(self) -> str:
        return str(ipaddress.IPv4Network(self.cidr, strict=False).netmask)


@dataclass
class RouterSpec:
    """An FS-native in-fabric router the intent knowingly keeps.

    FS seeds routers into some fabric templates (e.g. an "ISP Router" fronting a
    seeded Internet/ISP pair). They own real port IPs and answer ARP, but were
    never modelled here -- so `plan` could not see one, and `--prune` could not
    remove one, no matter how badly it broke the fabric.

    This spec is deliberately thin: FS routerports have no ``vlan`` field (an
    FS-native router cannot trunk), so there is no cabling grammar worth
    inventing. Declaring a router by name means "I know this is here, keep it";
    a router NOT declared is undeclared infrastructure in our fabric and
    ``--prune`` removes it. ``protected`` additionally shields it from a prune,
    matching SwitchSpec/NetworkSpec semantics."""
    name: str
    protected: bool = False


@dataclass
class SwitchSpec:
    name: str
    auto_address: str | None = None   # name of a NetworkSpec, or None
    mgmt: bool = True
    # ``role`` is sugar over the FS ``mgmt`` flag. The flag decides which port FS
    # aims a node's access port-forwards at -- it does NOT decide egress: a
    # host-uplinked switch injects its network's gateway either way, and the one
    # segment that never injects is the seeded OOB switch (refuted the older
    # "mgmt = no default route" reading; see ``_switch_gives_egress`` and
    # docs/reference/LXC_MATRIX_RUNBOOK.md conclusion 2). FS
    # seeds two host-uplinked switches embodying these roles: "OOB Mgmt" (mgmt)
    # and "Internet Access" (egress); referencing them by name reuses the
    # pod-provided uplink rather than creating a floating segment.
    role: str | None = None
    # Force the switch host-uplinked: assign a System Host int port the network's
    # gateway IP and cable it to this switch, so the segment routes outbound via
    # the host's NAT. Needed for a user-declared management/egress net the pod
    # didn't seed (a plain declared net is a floating segment otherwise).
    host_uplink: bool = False
    # Terraform ``lifecycle { prevent_destroy }`` -- prune refuses to delete it.
    protected: bool = False
    # EVERY network this switch carries. FS itself only knows one
    # (``auto_address``), because it auto-addresses a single subnet -- but a
    # VLAN switch legitimately carries one subnet per VLAN, and declaring them
    # here is what lets the port/switch address check say "the IP must be in ONE
    # OF the switch's networks" instead of demanding --allow-addr-mismatch for a
    # topology that is correct. ``auto_address`` is the primary (first) one.
    networks: list[str] = field(default_factory=list)

    def carries(self, net_name: str | None) -> bool:
        return bool(net_name) and net_name in (self.networks or [self.auto_address])


@dataclass
class LinkSpec:
    port: str                       # VM port name, e.g. "port1" / "eth0"
    switch: str                     # SwitchSpec name
    ip: str | None = None        # optional static ipv4 for the port
    netmask: str | None = None
    # Native-device name (e.g. "System Host") that should DHCP-serve this port.
    # FS does *static DHCP*: the port keeps its FS-assigned ipv4addr/netmask but
    # FS leases it to the guest. Required for qcow guests, which can't take an
    # FS-injected static address. Mutually exclusive in practice with ``ip``.
    dhcp: str | None = None
    # Is this the guest's MANAGEMENT port (``model.vmport.mgmt``)? FS points a
    # node's external access port-forwards (SSH 11000+idx, …) at the mgmt port, so
    # a node with `access:` whose ports are all mgmt=false gets a forward that
    # LISTENS but never reaches the guest -- the pod accepts the TCP connection and
    # the session then hangs with no banner (proven live 07-16: fitng on pod B).
    # Leave None to let the reconciler decide (the first link of a node that
    # declares a forwarding `access:` type becomes mgmt); set explicitly to pin a
    # different port, or False to keep a port out of the running.
    mgmt: bool | None = None
    # ── VLAN (OVS vlan_mode on the SWITCHPORT this link lands on) ────────────
    # ``vlan:``  -- untagged access port; frames land on this VLAN.
    # ``trunk:`` -- 802.1Q trunk carrying exactly these VLANs; the guest is
    #               expected to terminate them on subinterfaces.
    # Mutually exclusive (parse_intent enforces it), and both are validated at
    # parse: the FS API accepts 4096, -1 and "not,a,vlan" without complaint and
    # stores them, so the intent layer is the only place a bad tag is caught.
    # Leaving both unset means "don't touch the switchport" -- an untouched port
    # is VLAN-unaware, which is correct for a single-VLAN segment.
    vlan: int | None = None
    trunk: tuple[int, ...] = ()

    @property
    def switchport_mode(self) -> str | None:
        """OVS ``vlan_mode`` this link wants on its switchport, or None for
        'leave it alone'. Derived, never authored -- an explicit ``mode:`` is
        how east and west diverged (a VLAN-unaware port with a tag works by OVS
        inference; setting the mode by hand breaks it)."""
        if self.trunk:
            return "trunk"
        return "access" if self.vlan else None


@dataclass
class RedeemSpec:
    """In-guest FortiFlex token redemption config for ``FLEX-GUEST`` mode.
    Symmetric with :class:`ReadySpec` -- typed, not an untyped ``dict[str, Any]``.

      * ``api``        -- the redemption adapter (e.g. ``soar``). Required.
      * ``ssh_user`` / ``ssh_password`` / ``ssh_key`` -- guest SSH login for the
        redeem POST. Default admin/fortinet; override for non-default-cred guests.
      * ``timeout_s``  -- the redeem-poll budget (depl_status polling). Default 900s.
      * ``regen_attempts`` -- max mint→redeem regen cycles on failure. Default 3.
      * ``regen_loop_timeout_s`` -- total wall-clock budget for the regen loop. Default 1800s.
      * ``regen_delay_s`` -- delay between regen attempts. Default 20s.
      * ``mint_timeout_s`` -- FortiFlex token-mint budget (PENDING→ACTIVE wait).
        Separate from ``timeout_s`` (mint vs redeem poll). Default 1800s.
    """
    api: str = "soar"
    ssh_user: str | None = None
    ssh_password: str | None = None
    ssh_key: str | None = None
    timeout_s: int = 900
    regen_attempts: int = 3
    regen_loop_timeout_s: int = 1800
    regen_delay_s: int = 20
    mint_timeout_s: int = 1800


@dataclass
class LicenseSpec:
    """How FS should license a node. The reconciler sets the VM's license *mode*
    before install (FS assigns at install time), optionally seeding the FS license
    pool first.

      * ``mode``        -- ``AUTO`` (FS pulls a matching license from its pool /
        FortiFlex at install), ``NONE`` (install unlicensed; license it yourself
        post-boot), or ``FLEX-GUEST`` (install unlicensed, then mint + redeem a
        FortiFlex token inside the guest post-boot). Default AUTO.
      * ``file``        -- a local ``.lic`` imported into the FS pool *before*
        install so an ``AUTO`` assignment can pick it (idempotent: tolerated if the
        serial is already pooled). Use on a pod with no pre-uploaded license.
      * ``flex_config`` -- a FortiFlex config id mapped to this node's ``vm_type``
        (``system/license/flex/pool``) so FS auto-provisions a Flex license. The
        pod's FortiCloud account must be registered (pod-wide; out of intent scope).
        **Required for ``FLEX-GUEST`` mode.**
      * ``redeem``      -- in-guest redemption config for ``FLEX-GUEST`` mode:
        a :class:`RedeemSpec` (``{api, ssh_user?, ssh_password?, ssh_key?,
        timeout_s?}``) where ``api`` selects the adapter (e.g. ``soar``).
        Ignored for other modes.
      * ``install_order`` -- WHEN FS installs the license relative to restoring
        the node's ``deviceconfig:``. FS calls this "Order of installation" and
        stores it as ``model.vmparameters.install_license``:

          ``default``        → ``FIRMWARE`` (FS default: license before config)
          ``before_config``  → ``FIRST``
          ``after_config``   → ``LAST``

        Use ``after_config`` when the license activation needs something the
        config carries. Proven live on FMG: the appliance's ``system dns`` is
        NOT re-pushed by FS on install (only addresses + the default route are),
        so a node relying on a restored config for its resolver must license
        AFTER that config lands, or FortiCare/FortiGuard is unresolvable at
        activation time and the guest boots eval/limited. Left unset the field
        is not written, so FS's own default stands.
    """
    mode: str = "AUTO"
    file: str | None = None
    flex_config: str | None = None
    redeem: RedeemSpec | None = None
    install_order: str | None = None

    # intent spelling → FS ``model.vmparameters.install_license`` value
    _ORDER_MAP = {"default": "FIRMWARE",
                  "before_config": "FIRST",
                  "after_config": "LAST"}

    def fs_install_license(self) -> str | None:
        """The FS ``install_license`` value, or None when unset (leave FS alone)."""
        if self.install_order is None:
            return None
        return self._ORDER_MAP[str(self.install_order).strip().lower()]

    def is_guest_redeem(self) -> bool:
        """True if this node needs in-guest FortiFlex token redemption."""
        return self.mode.upper() == "FLEX-GUEST"

    def fs_mode(self) -> str:
        """The FS-facing license mode: ``FLEX-GUEST`` → ``NONE`` (FS never
        pool-licenses guest-redeem nodes; they do their own licensing post-boot),
        else the node's ``mode``."""
        return "NONE" if self.is_guest_redeem() else self.mode


def _parse_license(val: Any) -> LicenseSpec | None:
    """Parse a node's ``license:`` -- a string (``auto``/``none``/``flex-guest``)
    or a dict (``{mode, file, flex_config, redeem}``). ``None``/absent → no
    licensing (today's behavior; FS default). YAML ``license: none`` parses to
    Python ``None`` -- write ``license: "none"`` or ``license: {mode: none}`` to
    force unlicensed.

    Validates that ``FLEX-GUEST`` mode has a ``flex_config`` and a known
    ``redeem.api`` (raises ValueError if not)."""
    if val is None:
        return None
    if isinstance(val, str):
        return LicenseSpec(mode=val.strip().upper())
    if isinstance(val, dict):
        mode = str(val.get("mode", "AUTO")).upper()
        redeem_raw = val.get("redeem")
        redeem: RedeemSpec | None = None
        if isinstance(redeem_raw, dict):
            redeem = RedeemSpec(
                api=str(redeem_raw.get("api", "soar")),
                ssh_user=redeem_raw.get("ssh_user"),
                ssh_password=redeem_raw.get("ssh_password"),
                # ssh/asyncssh get the path verbatim (no shell), so expand ~ here.
                ssh_key=(os.path.expanduser(redeem_raw["ssh_key"])
                         if redeem_raw.get("ssh_key") else None),
                timeout_s=int(redeem_raw.get("timeout_s", 900)),
                regen_attempts=int(redeem_raw.get("regen_attempts", 3)),
                regen_loop_timeout_s=int(redeem_raw.get("regen_loop_timeout_s", 1800)),
                regen_delay_s=int(redeem_raw.get("regen_delay_s", 20)),
                mint_timeout_s=int(redeem_raw.get("mint_timeout_s", 1800)),
            )
        order_raw = val.get("install_order")
        if order_raw is not None:
            order = str(order_raw).strip().lower()
            if order not in LicenseSpec._ORDER_MAP:
                raise ValueError(
                    f"license: unknown install_order {order_raw!r} -- expected one of "
                    f"{', '.join(sorted(LicenseSpec._ORDER_MAP))}")
            order_raw = order
        lic = LicenseSpec(mode=mode, file=val.get("file"),
                          flex_config=val.get("flex_config"),
                          redeem=redeem, install_order=order_raw)
        # Validate FLEX-GUEST constraints.
        if lic.is_guest_redeem():
            if not lic.flex_config:
                raise ValueError(
                    "license: mode FLEX-GUEST requires flex_config (id or name)")
            if lic.redeem is None:
                raise ValueError(
                    "license: mode FLEX-GUEST requires redeem: {api, ...}")
            api = lic.redeem.api
            if not api:
                raise ValueError("license: redeem requires api (e.g. 'soar')")
            # Known adapters: soar, fmg, faz, fgt. Extend as more products add
            # in-guest redemption (see backend/fabric/guest.py REDEEM_ADAPTERS).
            if api not in ("soar", "fmg", "faz", "fgt"):
                raise ValueError(f"license: unknown redeem.api {api!r} "
                                 f"(known: soar, fmg, faz, fgt)")
        return lic
    raise ValueError(f"license: must be a string or a map, got {type(val).__name__}")


@dataclass
class ReadySpec:
    """A post-boot readiness / health gate for a node. Declares that the node is
    considered "done" when it passes a set of probes (HTTPS up, services running,
    license usable). Executed by the guest phase post-provisioning.

      * ``product`` -- readiness adapter to run (e.g. ``soar``). Defaults to
        ``node.type.lower()``.
      * ``https``   -- HTTPS endpoint to probe (expect 200/302). Defaults per product.
      * ``services`` -- service-health probe (e.g. ``csadm`` for SOAR). Defaults per product.
      * ``license`` -- assert a usable license (e.g. has ``Serial no:``). Defaults per product.
      * ``timeout_s`` -- probe budget (default 600s). Total timeout across all probes.
      * ``ssh_user`` / ``ssh_password`` / ``ssh_key`` -- guest login for the probe
        SSH. Default admin/fortinet; override for guests with non-default creds
        (e.g. an FS-installed FortiGate). A FLEX-GUEST node's ``license.redeem``
        creds still take precedence when both are present.
    """
    product: str | None = None
    https: str | None = None
    services: str | None = None
    license: str | None = None
    timeout_s: int = 600
    ssh_user: str | None = None
    ssh_password: str | None = None
    ssh_key: str | None = None


def _parse_ready(val: Any, node_type: str) -> ReadySpec | None:
    """Parse a node's ``ready:`` -- a dict (``{product, https, services, license,
    timeout_s, ssh_user, ssh_password, ssh_key}``) or ``None``/absent (no
    readiness gate). ``product`` defaults to ``node_type.lower()`` when omitted.
    Pure -- testable offline."""
    if val is None:
        return None
    if isinstance(val, dict):
        return ReadySpec(
            product=val.get("product") or node_type.lower(),
            https=val.get("https"),
            services=val.get("services"),
            license=val.get("license"),
            timeout_s=int(val.get("timeout_s", 600)),
            ssh_user=val.get("ssh_user"),
            ssh_password=val.get("ssh_password"),
            ssh_key=val.get("ssh_key"),
        )
    raise ValueError(f"ready: must be a dict or absent, got {type(val).__name__}")


@dataclass
class NodeSpec:
    name: str
    type: str                       # FGT / SOAR / LXC / BASIC / ...
    firmware: int | str | None = None  # home-repo firmware id, or a name/version
                                       # string (e.g. "9.7", "7.6.6") resolved → id
    image: str | None = None     # home-repo firmware *name* (resolved → id)
    links: list[LinkSpec] = field(default_factory=list)
    # Per-VM hypervisor overrides (model.vmparameters) -- override the firmware
    # .meta. Apply on (re)install. Used for build hosts that need more than the
    # firmware's default sizing (e.g. nested-virt builders).
    cpu: int | None = None          # vCPU count
    memory: int | None = None       # RAM in MiB
    # Back this guest's RAM with pod hugepages (model.vmparameters.hugepages).
    # None = leave FS's default, which is TRUE -- and that default is a trap on a
    # busy pod: hugepages are a fixed preallocated pool (`hugepages:available`),
    # NOT ordinary RAM, so a guest declaring more than the pool has free fails at
    # power-on with "unable to map backing store for guest RAM" while the pod
    # still has tens of GiB of normal memory idle. Set false for guests that
    # don't need the performance (a lab DC, a workstation) so they map from
    # ordinary RAM and leave the pool for the appliances it was sized for.
    hugepages: bool | None = None
    # Pin the VM's SMBIOS UUID (model.vm.uuid → qemu -uuid → guest DMI
    # product_uuid → k8s node systemUUID). Set at CREATE time only -- FS bakes it
    # into the qemu launch, so it can't be changed on a live VM without a
    # destroy→recreate. Use to make a guest's hardware identity deterministic/
    # stable across pods -- e.g. so a UUID-locked appliance license (FortiAIGate)
    # stays valid on redeploy, or so one license covers a fleet that shares the
    # UUID. Accepts canonical 8-4-4-4-12 hex; None = let FS assign one.
    uuid: str | None = None
    # Extra data disks (model.vmdisk, extra=True), each an int capacity in MiB,
    # in declared order. The firmware's base disk is always present and not
    # counted here. Idempotent: only disks beyond those already attached are added.
    disks: list[int] = field(default_factory=list)
    # Access types to expose PUBLIC (external port-forward), e.g. ["SSH","HTTPS"].
    access: list[str] = field(default_factory=list)
    # Console (VNC/SPICE) password -- model.vm.console_password. REQUIRED for a
    # console access type to actually be exposed: FS accepts a PUBLIC VNC access
    # without one, then declines to allocate its forward at install ("No valid
    # password for VNC, public access not allowed"), so the model advertises VNC
    # while nothing listens. `validate` rejects that combination up front rather
    # than letting it surface as a mystery dead port after a full deploy.
    console_password: str | None = None
    # Device admin password -- model.vm.password. FS logs in with it for post-boot
    # prepare and hands it to the guest at install, so it must match what the
    # image expects (e.g. a FortiSIEM collector baked on another pod). Absent =
    # FS's per-type default. Model-only -- applies on (re)install. Use a ${var}.
    password: str | None = None
    # Custom guest ports to expose externally (System Host custom port redirection,
    # e.g. an app on 8080). Each entry: {port: int, type?: HTTP|HTTPS} -- a PUBLIC
    # vmaccess of that type with dport=port. Requires the pod-wide
    # custom_rules_allowed gate, which apply flips on automatically.
    expose: list[dict] = field(default_factory=list)
    # Provision-time device config: a local file FS uploads as a model.deviceconfig
    # (method RESTORE, matching this node's vm_type) and **restores to the device
    # during install** -- the FS-native config-injection path (distinct from the
    # post-boot config: jump-SSH phase). FortiOS-centric (RESTORE = full config).
    # Phase 2: a string is a literal path; a dict ``{device: <name>}`` is a
    # *derived* form -- built from ``devices/<name>/payload/`` into
    # ``.fabric/confs/<fabric>/`` by ``build_deviceconfigs`` before plan/apply.
    # ``base`` overrides which ``devices/_base/`` files to include; ``inject`` adds
    # synthetic files (e.g. per-node env). See ``payload.build_deviceconfig``.
    provision_config: str | None = None
    # Derived deviceconfig spec (set by parse_intent when ``deviceconfig:`` is a
    # dict). ``build_deviceconfigs`` reads this, builds the .conf, and replaces
    # ``provision_config`` with the built path. None for literal-path nodes.
    device: dict[str, Any] | None = None
    # How FS licenses this node (set before install). None = leave FS default.
    license: LicenseSpec | None = None
    # Post-boot readiness gate (HTTPS up, services running, license usable).
    # Executed after config phase. None = no gate.
    ready: ReadySpec | None = None
    # count: create N copies of this node; the node name and field references
    # can use ${count.index} (0-based integer) to distinguish copies.
    count: int | None = None
    # for_each: create one copy per key in a dict; node name and field references
    # can use ${each.key} (the dict key) and ${each.value} (the dict value).
    for_each: dict[str, Any] | None = None
    # Arbitrary ``model.vmparameters`` overrides (e.g. ``expert``, ``hugepages``,
    # ``cpu_model``, ``boot_menu_time``). Patched on the VM model -- takes effect on
    # the NEXT install (destroy → install). Merged with cpu/memory in the reconciler.
    # In intent YAML: ``params: {expert: "[login-hooks]\npre-sleep=25\n", hugepages: 2}``.
    params: dict[str, Any] = field(default_factory=dict)
    # Terraform ignore_changes: field names in this list are skipped during drift
    # detection (plan/apply won't emit Change objects for them). Empty list = detect
    # all (backward compat). Unknown field names are tolerated. E.g. ["cpu", "memory"]
    # to prevent cpu/memory changes from appearing in the plan.
    ignore_changes: list[str] = field(default_factory=list)
    # Terraform ``lifecycle { prevent_destroy }`` -- a prune refuses to delete
    # this VM even when it's no longer declared. Use for a shared-pod VM that
    # must survive another tenant's ``--prune``. (Seeded shared infra is
    # protected by name automatically via ``SEEDED_SHARED_NAMES``.)
    protected: bool = False
    # Phase 5: explicit dependencies on other nodes. A node listed here must be
    # booted+reachable before this node's provision items run. Empty = no
    # explicit deps (list order still ties independent items, as before).
    depends_on: list[str] = field(default_factory=list)
    # FS-native model.installafter (GUI: VM Advanced -> "Install after"). Nodes
    # listed here must be INSTALLED (not just reachable) before FS will install
    # this one -- enforced by FS itself at the platform level, so it holds even
    # for a raw install_fabric bulk install, unlike depends_on above which only
    # gates our own provision-phase items. Use for a guest whose first-boot
    # work assumes another guest is already up (e.g. an in-fabric onboarder
    # that SSHes appliances the moment it boots) instead of relying on
    # reachability polling/retries to paper over the install race.
    install_after: list[str] = field(default_factory=list)
    # Phase 6: the device module this node uses (e.g. ``fleet``). When set,
    # defaults from ``devices/<module>/device.yaml`` are applied -- image, type,
    # cpu, memory, access, and an implicit ``deviceconfig: {device: <module>}``
    # if the node has no explicit ``deviceconfig:``. Node fields override
    # device defaults. None = no module (behavior unchanged).
    module: str | None = None
    # Which declared network's gateway/DNS FS auto-injects into this guest
    # (``model.vm.auto_params_network``). None = leave whatever FS already has
    # (often its own default of "whichever network is on port1"). That default is
    # a trap for a node whose port1 carries a non-routable segment (e.g. FMG/FAZ's
    # License net, gw=None): the guest gets no gateway/DNS and never reaches
    # FortiCare/DNS, no matter what egress port2/port3 carry. Live-confirmed on
    # fmg/faz -- pointing this at "OOB Mgmt" (routable, host-uplinked) fixed
    # egress where the license-segment default silently starved it. The model
    # changes at once, but a RUNNING guest keeps its old gateway/DNS. Live on
    # 2.2.35: FS marks the change "synchronize", and a sync completes, clears the
    # pending diff and leaves the guest untouched (LXC: same route, resolv.conf
    # and interfaces.d). Only an install of the device writes them. A DHCP-served
    # port is the exception: the change also raises a System Host dhcp_table
    # "install", which apply already performs, and the guest renews the lease.
    auto_params_network: str | None = None


@dataclass
class ConfigSpec:
    """A post-boot configuration handoff for one node (or a local pre-flight).
    The reconciler does NOT execute these -- the *config phase*
    (``backend/engine/config.py``) does, after ``apply`` reports
    booted+reachable. Exactly one action key is set per item:

      * ``local``    -- run a shell command on the **local machine** (the laptop
        running ``fabric config``). No node or SSH needed. Use for pre-flight
        steps that must happen before the remote phase: cert regeneration,
        local file generation, preflight checks. ``{command, label?}``.
        ``node`` is omitted for local items. **Fails fast**: a non-zero rc
        aborts the entire config phase (unlike other action types which
        record + continue), because subsequent remote steps typically depend
        on the pre-flight's output. Set ``ignore_errors: true`` to make a
        local: item fail-soft like the others.
      * ``commands`` -- shell commands run in order over (jump-)SSH into the node.
      * ``script``   -- a local script file uploaded and executed on the node.
      * ``upload``   -- stage a local file/dir onto the node: ``{src, dest}``
        places ``src`` (preserving its basename) under the remote ``dest``
        directory -- the ``cp -r src dest/`` intuition. The transport tars +
        base64s the tree through the jump hop (keep it small -- build inputs,
        not artifacts). Enables staging build assets onto a data disk.
      * ``detached`` -- a long-running command launched ``setsid``-detached, then
        polled to completion via a sentinel rc-file: ``{command|script, sentinel,
        log, timeout_s, poll_s, stall_s}``. Survives the SSH channel being severed
        mid-run (each poll is a fresh, reconnect-tolerant jump-SSH), which the
        SOAR ``.bin`` install needs (its firewall reset kills the live channel).
      * ``playbook`` -- a local Ansible playbook run against this node. The config
        phase ensures the node's SSH access is PUBLIC, resolves its external
        port-forward (``11000 + port_idx``), writes a one-host inventory, and runs
        ``ansible-playbook -i <inv> <playbook> --limit <node>`` (modules execute
        on the guest -- use ``uri`` to hit its localhost API, ``command`` for
        ``docker exec``, etc.). With ``--no-run-ansible`` it instead emits the
        inventory + playbook path and reports the item as ``deferred`` (handoff).
        Auth is the node's guest SSH: ``ssh_password`` (sshpass) or ``ssh_key``.
      * ``ingest``   -- pull a large artifact *off* the node into the pod's home
        repo as a bootable firmware: ``{remote_qcow, dest_name,
        template_firmware}`` (+ optional ``compact``/``compress``/``port``/
        ``timeout``). The inverse of ``upload``: uses the HTTP-pull path
        (``tools/fs_builder_ingest``) since a >2 GB qcow can't ride the
        inline-base64 jump transport. Idempotent -- skips if the firmware row
        already exists, or cleanly if the node hasn't produced the artifact yet
        (e.g. a preceding ``detached`` build that didn't finish). Closes the
        build→firmware loop so ``apply`` yields a deployable image.

    ``ssh_user``/``ssh_key``/``ssh_password`` default from the intent-level
    ``config_defaults``; ``become`` wraps each command in ``sudo sh -c``.

    ``ssh_via`` names the *port* whose IP the jump-SSH targets. The jump runs
    from the FS **pod appliance's** shell, which sits on the pod-management
    network (OOB Mgmt) -- a node addressed only on an isolated fabric segment is
    host-uplinked *within the fabric* yet unreachable from the pod, so the hop
    gets "No route to host". Point ``ssh_via`` at the node's OOB-Mgmt-cabled
    port. Default (None) = the node's first addressed port.

    ``ansible_via`` names another NODE in the same fabric to run a ``playbook``
    FROM, instead of running it on the workstation over the pod port-forward.
    That forward costs ~724 ms per TCP connect (workstation → VPN → pod →
    forward) against ~2.8 ms from a node sharing the target's L2 segment.
    Ansible-over-SSH is round-trip heavy and Windows guests support no
    pipelining -- a PowerShell module is pushed per task -- so the difference is
    minutes per play, not milliseconds. The named node must be a Linux node on
    the target's segment; the config phase stages the playbook and key onto it,
    installs ansible-core if missing, and runs there against the target's
    *fabric-internal* address."""
    node: str | None = None   # None only for local: items
    commands: list[str] = field(default_factory=list)
    script: str | None = None
    upload: dict[str, str] | None = None
    detached: dict[str, Any] | None = None
    playbook: str | None = None
    ingest: dict[str, Any] | None = None
    # ``device_access: {ssh: true, api: true}`` -- install the controller's SSH key and cache a
    # REST API key (tools/device_access). Added automatically for every FGT node at provision
    # time; an explicit item replaces the default ({ssh: false, api: false} turns it off).
    device_access: dict[str, Any] | None = None
    local: dict[str, Any] | None = None
    # Phase 3: per-item extra vars for ``playbook:`` items, passed to
    # ansible-playbook as ``--extra-vars @file`` (temp JSON, not inline -- keeps
    # secrets off the process table). Rejected on non-playbook actions at parse.
    vars: dict[str, Any] | None = None
    ssh_user: str | None = None
    ssh_key: str | None = None
    ssh_password: str | None = None
    ssh_via: str | None = None
    become: bool = False
    ignore_errors: bool = False
    # Phase 3: when False, this item does NOT inherit ``provision_defaults``
    # (scoped credentials -- stops a Linux ssh_password leaking onto a Windows
    # node). Default True = current behavior (inherit everything).
    inherit_defaults: bool = True
    ansible_via: str | None = None
    # Phase 5: a short label so a provision item is addressable by something
    # other than its list position. Used in `depends_on:` references.
    label: str | None = None
    # Phase 5: explicit dependencies on other provision items (by label) or
    # nodes (by name). An item listed here must complete before this one runs.
    # Empty = no explicit deps (list order ties independent items, as before).
    depends_on: list[str] = field(default_factory=list)
    # Nodes whose CURRENT IDENTITY this item's work depends on, beyond its own
    # ``node``. The run journal binds an entry to the identity of the node the
    # item targets, so a rebuilt guest invalidates its own entries -- but an item
    # that targets node A while configuring node B is not invalidated when B is
    # rebuilt, and is silently skipped against a B that no longer exists.
    #
    # Concretely: a FortiManager onboarding item targets the FMG and registers
    # the GATES. Reinstall a gate and the FMG's identity is unchanged, so the
    # onboard is skipped as "already in journal" -- leaving the rebuilt gate
    # unregistered, and failing several items later somewhere else. Listing the
    # gates here folds their identities into the entry, so rebuilding any of them
    # re-runs the onboarding that concerns them.
    #
    # Names that do not resolve to a device in live state are ignored rather than
    # fatal: an item may legitimately name a node that is not deployed yet.
    identity_nodes: list[str] = field(default_factory=list)


@dataclass
class HealthSpec:
    """A post-boot health-check handoff for one node (or device-type). The
    reconciler does NOT run these -- the *health phase*
    (``backend/fabric/health.py``) does, after ``apply`` reports
    booted+reachable, as the final lifecycle stage (plan → apply → **verify**).

    Targets a live device by ``node`` (matched to a discovered Device by name)
    or by ``device_type`` (the first device of that vm_type); names the catalog
    ``checks`` (slugs) to run against it; ``params`` substitutes ``${var}`` in
    each check (e.g. a ping target). Each check runs through the production
    orchestrator path and reports its real status (ok / fail / warn / skip)."""
    node: str | None = None
    device_type: str | None = None
    checks: list[str] = field(default_factory=list)
    params: dict[str, Any] = field(default_factory=dict)


@dataclass
class ImageSpec:
    """A firmware/image the fabric depends on, ensured in the pod's home repo
    *before* nodes are created. Nodes reference it by logical ``name`` via
    ``image:``. The reconciler does not reconcile images; the **images phase**
    (``backend/engine/images.py``) does, as an apply pre-step.

      * ``path``  -- a prebuilt local artifact to upload (idempotent: skipped if
        the home repo already carries an artifact of the same uploaded
        filename). LXC ``.zip`` (FS keys recognition on the ``LXC_`` filename
        prefix) → ``vm_type=LXC``; ``.qcow2`` → ``vm_type=BASIC``.
      * ``build`` -- build inputs. **LXC** builds run inline via lxc-builder
        (``images.build_lxc_image``). **qcow** builds (``via: fs-builder``)
        run detached on a builder VM and ingest back via ``fabric_builds`` -- see
        :class:`QcowBuildSpec`. ``build`` with no ``path`` produces the artifact.
      * ``home_repo`` -- a **resolve-only** reference to a firmware filename already
        in the pod home repo: no upload, no build, just look it up by filename and
        bind it to ``name``. The consumer side of the factory/consumer split -- a
        topology deploys an image a *builder* topology produced earlier. Absent →
        the node referencing it fails to resolve a firmware (honest).

    ``kind`` (``lxc``/``qcow``) is inferred from the path suffix when omitted;
    ``dest_name`` overrides the uploaded filename (qcow -- keep the ``LXC_``
    prefix for LXC). Exactly one of ``path`` / ``build`` / ``home_repo`` is set."""
    name: str
    path: str | None = None
    kind: str | None = None
    dest_name: str | None = None
    build: dict[str, Any] | None = None
    home_repo: str | None = None
    # How a guest off this image gets its address. Some goldens self-apply the
    # static address Fabric Studio puts on the port (the Win10 HOL image does);
    # others carry only a DHCP client and will sit with NO address at all if the
    # port is static -- the guest boots, the link is up, and nothing answers,
    # which reads as a dead VM rather than an addressing mismatch. Declaring it
    # once here lets `plan`/`apply` reject the combination instead of shipping it.
    # "dhcp" = links to this image MUST use `dhcp:`; None = no constraint.
    addressing: str | None = None


@dataclass
class AdomSpec:
    """An ADOM to ensure on an FMG/FAZ. ``os_ver`` (e.g. "7.4") pins the ADOM's
    device-OS version; None lets the controller default it."""
    name: str
    os_ver: str | None = None


@dataclass
class RegisterSpec:
    """A FortiGate to register + authorize on an FMG/FAZ. ``device`` is a node
    name (vm_type FGT); ``adom`` is the target ADOM name (defaults to the
    service's first declared ADOM, else "root")."""
    device: str
    adom: str | None = None


@dataclass
class FmgServiceSpec:
    """FortiManager post-setup: create ``adoms`` and register/authorize the
    FortiGates in ``register`` (which also points each FGT's central-management
    at this FMG)."""
    node: str                       # node name, vm_type FMG
    adoms: list[AdomSpec] = field(default_factory=list)
    register: list[RegisterSpec] = field(default_factory=list)


@dataclass
class FazServiceSpec:
    """FortiAnalyzer post-setup: create ``adoms`` and register/authorize the
    FortiGates in ``register`` (which also enables each FGT's log forwarding to
    this FAZ)."""
    node: str                       # node name, vm_type FAZ
    adoms: list[AdomSpec] = field(default_factory=list)
    register: list[RegisterSpec] = field(default_factory=list)


@dataclass
class ServicesSpec:
    """Post-boot **fabric services** -- the declarative onboarding of FortiGates
    into FortiManager and FortiAnalyzer (ADOMs + device authorization). Compiled
    by ``backend/engine/ansible.py`` into Fortinet-collection Ansible
    playbooks + an httpapi inventory, then applied (``apply --services``). Empty
    sub-specs (no fortimanager / no fortianalyzer) are simply skipped."""
    fortimanager: FmgServiceSpec | None = None
    fortianalyzer: FazServiceSpec | None = None


@dataclass
class Intent:
    fabric: str
    images: list[ImageSpec] = field(default_factory=list)
    networks: list[NetworkSpec] = field(default_factory=list)
    switches: list[SwitchSpec] = field(default_factory=list)
    # FS-native in-fabric routers this intent knowingly keeps. Empty means "this
    # fabric should contain no routers" -- and a prune will say so.
    routers: list[RouterSpec] = field(default_factory=list)
    nodes: list[NodeSpec] = field(default_factory=list)
    config: list[ConfigSpec] = field(default_factory=list)
    config_defaults: dict[str, Any] = field(default_factory=dict)
    healthchecks: list[HealthSpec] = field(default_factory=list)
    services: ServicesSpec | None = None
    service_defaults: dict[str, Any] = field(default_factory=dict)
    description: str = ""
    # Schema-v2 deprecation warnings collected during parse (old spellings that
    # were silently accepted + normalized to canonical keys). Empty for an
    # all-canonical intent. Surfaced by `fabric validate` / `fabric plan`.
    deprecations: list[str] = field(default_factory=list)


# Reusable seeded-infra presets (the `use:` key). Each expands to the standard
# net + switch blocks that otherwise get copy-pasted into every intent. Both are
# FS-seeded shared infra, so the injected resources are auto-``protected`` (a
# prune can't delete them -- see SEEDED_SHARED_NAMES). An explicit declaration of
# the same name in the intent always wins (the preset only fills what's absent).
PRESETS: dict[str, dict[str, Any]] = {
    "oob-mgmt": {
        "networks": [{"name": "OOB Mgmt", "cidr": "10.254.254.0/24",
                      "gateway": "10.254.254.254", "protected": True}],
        "switches": [{"name": "OOB Mgmt", "auto_address": "OOB Mgmt",
                      "role": "mgmt", "protected": True}],
    },
    "internet-egress": {
        # dns1 is required, not cosmetic: a FortiFlex guest on this egress net
        # must resolve FortiCare to activate its entitlement -- without it the
        # node boots eval/limited (see the flex-activation gate in apply).
        #
        # NAME: the NETWORK is "Internet" and the SWITCH is "Internet Access".
        # That asymmetry is FS's, not ours: FS seeds a network called `Internet`
        # fronted by a host-uplinked switch called `Internet Access` (the pairing
        # is spelled out in tools/fs_lxc_matrix.py SEEDED_SWITCH). This preset
        # used to mint its OWN network named "Internet Access" on the same
        # 203.0.113.0/24 -- a duplicate of the seeded `Internet` net, carrying a
        # seeded-shared NAME, which made it auto-`protected` and therefore
        # indistinguishable from the real seed and immune to prune.
        #
        # That duplicate is what broke fortiaigate_lab on 2026-08-25: the preset
        # claimed gateway 203.0.113.254 and host_uplink put System Host int2 on
        # it, while the FS-seeded "ISP Router" already held the same address on
        # the same segment with an uncabled upstream. The router won the ARP and
        # the whole egress segment black-holed -- FortiAIGate licensing returned
        # `Server Error`, the FGT's FortiGuard DB sat at 0.00000 for weeks, FMG
        # flex activation failed with an empty reason, and `plan` reported the
        # fabric clean the entire time. `_lint_topology` now refuses both faults.
        "networks": [{"name": "Internet", "cidr": "203.0.113.0/24",
                      "gateway": "203.0.113.254", "dns1": "8.8.8.8",
                      "protected": True}],
        "switches": [{"name": "Internet Access", "auto_address": "Internet",
                      "role": "egress", "host_uplink": True, "protected": True}],
    },
}


def _expand_presets(doc: dict[str, Any]) -> dict[str, Any]:
    """Pre-pass for ``presets: [oob-mgmt, ...]`` (deprecated ``use:``): inject
    each preset's net/switch blocks that aren't already declared by name.
    Returns a shallow-copied doc so the caller's mapping isn't mutated; explicit
    declarations win over presets. The alias pass has already normalized
    ``use:`` → ``presets:`` before this runs."""
    use = doc.get("presets")
    if not use:
        return doc
    if isinstance(use, str):
        use = [use]
    doc = dict(doc)
    nets = list(doc.get("networks") or [])
    sws = list(doc.get("switches") or [])
    have_net = {n.get("name") for n in nets}
    have_sw = {s.get("name") for s in sws}
    for name in use:
        preset = PRESETS.get(name)
        if preset is None:
            raise ValueError(f"unknown preset {name!r} in presets: "
                             f"(have: {', '.join(sorted(PRESETS))})")
        for n in preset["networks"]:
            if n["name"] not in have_net:
                nets.append(dict(n)); have_net.add(n["name"])
        for s in preset["switches"]:
            if s["name"] not in have_sw:
                sws.append(dict(s)); have_sw.add(s["name"])
    doc["networks"], doc["switches"] = nets, sws
    return doc


def _resolve_intent_path(p: str | None, base_dir: str | None) -> str | None:
    """Resolve a local-file path referenced from an intent (``script``,
    ``playbook``, ``ssh_key``, ``upload.src``, ``detached.script``,
    ``provision_config``). ``~`` is expanded and absolute paths pass through
    unchanged. Ordinary repository paths are rooted at the repository (so an
    intent can say ``build_images/foo`` from anywhere). Paths beginning with
    ``../`` retain the legacy intent-relative behavior, and ``intent://foo``
    explicitly addresses a file next to the intent. Other relative paths fall
    back to the intent directory for compatibility with existing topologies.
    When ``base_dir`` is None, relative paths retain their previous behavior."""
    if not p:
        return p
    p = os.path.expanduser(p)
    if base_dir and not os.path.isabs(p):
        if p.startswith("intent://"):
            return os.path.normpath(os.path.join(base_dir, p[len("intent://"):]))
        if p.startswith("../") or p == "..":
            return os.path.normpath(os.path.join(base_dir, p))

        # The CLI is normally launched from the repository root. Deriving the
        # root from cwd (and falling back to base_dir) also keeps library users
        # that parse an intent from another checkout working as expected.
        roots = [os.getcwd(), base_dir]
        for start in roots:
            try:
                current = _payload.repo_root(start)
            except FileNotFoundError:
                continue
            candidate = os.path.normpath(os.path.join(current, p))
            # Generated files may not exist when parsing happens. Use the
            # repository root for a known top-level path anyway.
            first = re.split(r"[\\/]", p, maxsplit=1)[0]   # intents are written with "/" on every OS
            if os.path.exists(candidate) or first in {
                "ansible", "backend", "build_images", "docs", "devices",
                "site", "tests", "tools", "topologies",
            }:
                return candidate
        return os.path.normpath(os.path.join(base_dir, p))
    return p


_VAR_RE = re.compile(r"\$\{var\.([A-Za-z_][A-Za-z0-9_]*)\}")
# Canonical UUID (8-4-4-4-12 hex) -- validates a node's pinned SMBIOS `uuid`.
_UUID_RE = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
                      r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")


def _coerce_var(raw: Any, vtype: str | None, name: str) -> Any:
    """Coerce a variable value to its declared ``type`` (string/number/bool).
    An untyped variable passes through unchanged."""
    if vtype is None or raw is None:
        return raw
    try:
        if vtype == "string":
            return str(raw)
        if vtype == "number":
            return int(raw) if float(raw).is_integer() else float(raw)
        if vtype == "bool":
            if isinstance(raw, bool):
                return raw
            return str(raw).strip().lower() in ("1", "true", "yes", "on")
    except (TypeError, ValueError):
        raise ValueError(f"variable {name!r}: {raw!r} is not a valid {vtype}")
    raise ValueError(f"variable {name!r}: unknown type {vtype!r} (string/number/bool)")


def _when_defaults(doc: dict[str, Any]) -> dict[str, Any]:
    """``variables:`` name → declared default, for resolving a ``when:`` that is
    still an unsubstituted ``${var.x}``.

    The normal path substitutes variables into the whole doc before
    ``parse_intent`` ever sees it, so this only matters when a raw doc is parsed
    directly -- which the golden-snapshot test does deliberately, to pin the
    intent *as written*. Falling back to the declared default is not a guess: it
    is precisely what a pod with no ``.fabricvars`` overlay resolves to.
    """
    out: dict[str, Any] = {}
    declared = doc.get("variables")
    if not isinstance(declared, dict):
        return out
    for name, spec in declared.items():
        if isinstance(spec, dict):
            if "default" in spec:
                out[name] = _coerce_var(spec["default"], spec.get("type"), name)
        else:
            out[name] = spec
    return out


def _when_enabled(entry: dict[str, Any], what: str,
                  defaults: dict[str, Any] | None = None) -> bool:
    """Is this ``networks:`` / ``switches:`` / ``links:`` entry present on this pod?

    An optional ``when:`` key makes a single declaration pod-conditional, so ONE
    intent can describe pods whose physical shape genuinely differs -- rather than
    forking the intent or leaving a pod permanently drifted. The canonical case is
    a pooled-license segment: the FNDN pods bind the FMG/FAZ license to a
    management IP on its own L2, and a pod with no such license wants neither the
    segment nor the extra egress NIC that goes with it (a dead floating switch and
    a reinstall to cable it). ``when: "${var.<flag>}"`` + a ``bool`` variable puts
    that choice in the per-pod ``.fabricvars`` overlay.

    ``unless:`` is the negation of ``when:`` -- so one ``type: bool`` variable can
    drive both halves of an either/or (port1 on the license segment WHEN a pod
    serves a pooled license, on egress UNLESS it does) without an inverse variable
    the two spellings could drift apart on. Setting both keys is an error.

    Absent both means unconditional -- every existing intent is unaffected.
    Truthiness is YAML's, with the usual string spellings accepted so a ``-var``
    (always a string) behaves like a typed ``bool`` variable.

    NOTE for ``links:``: dropped links do NOT renumber the ones that remain --
    ``port:`` auto-numbering keys off the DECLARATION index, so a conditional link
    can't silently shift a later port onto the wrong NIC.
    """
    if "when" in entry and "unless" in entry:
        raise ValueError(f"{what}: set either `when:` or `unless:`, not both")
    key = "when" if "when" in entry else ("unless" if "unless" in entry else None)
    if key is None:
        return True
    val = entry[key]
    negate = key == "unless"

    def _out(b: bool) -> bool:
        return (not b) if negate else b

    if isinstance(val, str):
        m = _VAR_RE.fullmatch(val.strip())
        if m:
            # Unsubstituted reference (raw-doc parse) -- use the declared default.
            # An undeclared variable, or one with no default, still falls through
            # to the error below rather than being quietly treated as present.
            if (defaults or {}).get(m.group(1)) is not None:
                return _out(bool(defaults[m.group(1)]))
        tok = val.strip().lower()
        if tok in ("", "false", "no", "off", "0", "null", "none"):
            return _out(False)
        if tok in ("true", "yes", "on", "1"):
            return _out(True)
        raise ValueError(
            f"{what}: {key}={val!r} is not a boolean "
            f"(use a ${{var.<name>}} declared as `type: bool`)")
    return _out(bool(val))


def _parse_var_assignment(s: str) -> tuple[str, str]:
    """``NAME=VALUE`` (from a ``-var`` flag) → (name, value)."""
    if "=" not in s:
        raise ValueError(f"-var must be NAME=VALUE, got {s!r}")
    name, _, value = s.partition("=")
    name = name.strip()
    if not name:
        raise ValueError(f"-var must be NAME=VALUE, got {s!r}")
    return name, value


def load_varfile(path: str) -> dict[str, Any]:
    """Load a ``*.fabricvars`` overlay -- a flat YAML mapping of name → value."""
    import yaml
    with open(path, encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    if not isinstance(data, dict):
        raise ValueError(f"varfile {path!r} must be a mapping of name → value")
    return data


def resolve_variables(doc: dict[str, Any], *, base_dir: str | None = None,
                      pod_host: str | None = None,
                      var_files: tuple[str, ...] = (),
                      var_overrides: tuple[str, ...] = ()) -> dict[str, Any]:
    """Resolve the intent's ``variables:`` block into concrete values.

    Each ``variables:`` entry is either a bare scalar (its default) or a map
    ``{default?, type?, required?, description?}``. Precedence, low→high:
    declared ``default`` < ``<base_dir>/defaults.fabricvars`` <
    ``<base_dir>/<pod_host>.fabricvars`` < each ``--var-file`` (in order) <
    each ``--var NAME=VALUE``. Overriding an undeclared variable, or leaving a
    ``required`` one unset, is an error. Returns name → coerced value."""
    declared = doc.get("variables")
    if not declared:
        if var_files or var_overrides:
            raise ValueError("no variables: block declared, but -var/-var-file were given")
        return {}
    if not isinstance(declared, dict):
        raise ValueError("intent.variables must be a mapping of name → spec")

    specs: dict[str, dict[str, Any]] = {}
    values: dict[str, Any] = {}
    for name, spec in declared.items():
        if isinstance(spec, dict):
            specs[name] = spec
            if "default" in spec:
                values[name] = spec["default"]
        else:
            specs[name] = {"default": spec}
            values[name] = spec

    def _overlay(src: dict[str, Any], origin: str) -> None:
        for k, v in src.items():
            if k not in specs:
                raise ValueError(f"{origin}: variable {k!r} is not declared in variables:")
            values[k] = v

    auto: list[str] = []
    if base_dir:
        auto.append(os.path.join(base_dir, "defaults.fabricvars"))
        if pod_host:
            auto.append(os.path.join(base_dir, f"{pod_host}.fabricvars"))
    for f in auto:
        if os.path.exists(f):
            _overlay(load_varfile(f), os.path.basename(f))
    for f in var_files:
        _overlay(load_varfile(f), os.path.basename(f))
    for assignment in var_overrides:
        name, value = _parse_var_assignment(assignment)
        if name not in specs:
            raise ValueError(f"-var: variable {name!r} is not declared in variables:")
        values[name] = value

    # A var with no value is required unless explicitly `required: false`
    # (an optional-and-unset var just can't be referenced).
    missing = [n for n, s in specs.items()
               if n not in values and s.get("required", True) is not False]
    if missing:
        raise ValueError(
            f"variables with no value (set a default, an overlay, or -var): "
            f"{', '.join(sorted(missing))}")

    return {n: _coerce_var(values[n], specs[n].get("type"), n) for n in values}


def substitute_variables(obj: Any, values: dict[str, Any]) -> Any:
    """Recursively replace ``${var.NAME}`` in every string in ``obj``. A string
    that is *exactly* one reference yields the raw value (so a number/bool var
    keeps its type for ``cpu``/``memory``/flags); embedded references stringify.
    References to an unknown variable raise."""
    if isinstance(obj, str):
        m = _VAR_RE.fullmatch(obj)
        if m:
            name = m.group(1)
            if name not in values:
                raise ValueError(f"${{var.{name}}} references an undeclared/unset variable")
            return values[name]

        def _sub(mo: re.Match) -> str:
            name = mo.group(1)
            if name not in values:
                raise ValueError(f"${{var.{name}}} references an undeclared/unset variable")
            return str(values[name])
        return _VAR_RE.sub(_sub, obj)
    if isinstance(obj, dict):
        return {k: (v if k == "variables" else substitute_variables(v, values))
                for k, v in obj.items()}
    if isinstance(obj, list):
        return [substitute_variables(v, values) for v in obj]
    return obj


# Fortinet appliance families name their NICs ``port1, port2, …``; everything
# else we deploy (LXC, BASIC, qcow Linux such as SOAR/FAIG) uses ``eth0, eth1``.
# Used only to pick a default when a link omits ``port:``.
_PORT_STYLE_TYPES = frozenset({
    "FGT", "FMG", "FAZ", "FML", "FAC", "FAD", "FSW", "FWB", "FPX", "FDD", "FTS",
})


def _default_port_name(node_type: str, index: int) -> str:
    """Default NIC name for the ``index``-th link when ``port:`` is omitted."""
    if str(node_type).upper() in _PORT_STYLE_TYPES:
        return f"port{index + 1}"
    return f"eth{index}"


# ── Schema v2 alias table ────────────────────────────────────────────────────
# Old spellings silently accepted + normalized to canonical (v2) keys before
# the parser proper runs. Every old key is deprecated (accepted, never emitted,
# never documented). The canonical key always wins when both are present.
# See docs/plans/SCHEMA_V2_AND_GRAPH_PLAN.md Phase 1.
_TOPLEVEL_ALIASES: dict[str, str] = {
    "use": "presets",                 # → presets:
    "config": "provision",            # → provision: (post-boot handoff list)
    "config_defaults": "provision_defaults",  # → provision_defaults:
    "fabric_services": "services",    # → services: (FMG/FAZ onboarding)
}
# Node-level aliases (applied per entry in the nodes list).
_NODE_ALIASES: dict[str, str] = {
    "provision_config": "deviceconfig",   # → deviceconfig: (FS-native RESTORE)
    "ready": "wait_for",                  # → wait_for: (readiness gate)
    # `firmware:` is unified INTO `image:` (Phase 1 unification). Kept as a
    # separate alias so the deprecation warning names it; `image:` wins on conflict
    # because the unification makes them the same field.
    "firmware": "image",
}


def _apply_schema_aliases(doc: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
    """Normalize schema-v1 (deprecated) keys to their v2 canonical spellings.

    Returns ``(doc, deprecations)``. The doc is shallow-copied at each level so
    the caller's mapping isn't mutated. A key present in BOTH old and new forms
    keeps the new (canonical) value and warns about the discarded old one.
    Aliasing runs *before* preset expansion and *before* variable substitution,
    so canonical keys are what those passes see. Top-level and per-node only --
    nested blocks (links, images, config items) have no deprecated aliases."""
    deprecations: list[str] = []
    out = dict(doc)
    for old, new in _TOPLEVEL_ALIASES.items():
        if old in out:
            if new in out:
                deprecations.append(
                    f"both '{new}:' and deprecated '{old}:' present -- keeping "
                    f"'{new}:', ignoring '{old}:'")
            else:
                out[new] = out.pop(old)
                deprecations.append(f"'{old}:' is deprecated; use '{new}:'")
    nodes = out.get("nodes")
    if isinstance(nodes, list):
        new_nodes = []
        for nd in nodes:
            if not isinstance(nd, dict):
                new_nodes.append(nd)
                continue
            nd2 = dict(nd)
            for old, new in _NODE_ALIASES.items():
                if old in nd2:
                    if new in nd2:
                        deprecations.append(
                            f"node {nd2.get('name', '?')!r}: both '{new}' and "
                            f"deprecated '{old}' present -- keeping '{new}'")
                    else:
                        nd2[new] = nd2.pop(old)
                        deprecations.append(
                            f"node {nd2.get('name', '?')!r}: '{old}' is "
                            f"deprecated; use '{new}'")
            new_nodes.append(nd2)
        out["nodes"] = new_nodes
    return out, deprecations


# Known top-level intent keys (schema v2 canonical + their v1 aliases, which the
# alias pass has already normalized). Anything else is a typo that would
# otherwise be silently ignored. `fabric` is checked separately (required).
_KNOWN_TOPLEVEL_KEYS: frozenset[str] = frozenset({
    "fabric", "description", "variables",
    "presets",                     # v2 (v1 alias: use)
    "images", "networks", "switches", "nodes",
    "routers",                     # FS-native in-fabric L3 hops (see RouterSpec)
    "provision",                   # v2 (v1 alias: config)
    "provision_defaults",          # v2 (v1 alias: config_defaults)
    "healthchecks",
    "services",                    # v2 (v1 alias: fabric_services)
    "service_defaults",
    # v1 aliases -- still present in the doc if the alias pass ran; accepted here
    # so a doc that hasn't been aliased (e.g. direct parse_intent call with v1
    # keys) doesn't false-positive. The alias pass already warned.
    "use", "config", "config_defaults", "fabric_services",
})


def _reject_unknown_toplevel_keys(doc: dict[str, Any]) -> None:
    """Error on any top-level key the schema doesn't recognize. Catches typos
    (``node:`` instead of ``nodes:``, ``switch:`` instead of ``switches:``) that
    would otherwise be silently ignored -- the intent would parse as if the
    section wasn't declared."""
    unknown = sorted(k for k in doc if k not in _KNOWN_TOPLEVEL_KEYS)
    if unknown:
        raise ValueError(
            f"unknown top-level key(s): {', '.join(repr(k) for k in unknown)}. "
            f"Known: {', '.join(sorted(_KNOWN_TOPLEVEL_KEYS - {'fabric'}))}")


def load_device_module(name: str, base_dir: str | None = None) -> dict[str, Any]:
    """Load ``devices/<name>/device.yaml`` and return it. Raises FileNotFoundError
    if the file doesn't exist (a ``module:`` reference must resolve). Used by
    ``parse_intent`` to apply device defaults to a node (Phase 6).

    The returned dict has keys: ``defaults`` (image, type, cpu, memory, access),
    ``outputs`` (list of output keys the playbook emits), ``playbook`` (relative
    path). All optional -- a device with no device.yaml is fine for devices that
    haven't been migrated yet."""
    import yaml
    root = _payload.repo_root(base_dir or os.getcwd())
    path = os.path.join(root, "devices", name, "device.yaml")
    if not os.path.isfile(path):
        raise FileNotFoundError(
            f"module {name!r}: no device.yaml at devices/{name}/device.yaml")
    with open(path, encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def _apply_module_defaults(nd: dict, base_dir: str | None) -> tuple[dict, dict | None]:
    """Apply device module defaults to a node dict (Phase 6). Returns
    ``(nd_with_defaults, module_manifest)``. The module manifest is None when
    no ``module:`` is set or the device has no device.yaml.

    Merge order: device defaults < node fields (explicit overrides win).
    Also sets ``deviceconfig: {device: <module>}`` if the node has no explicit
    ``deviceconfig:`` and the device has a ``payload/`` directory."""
    module_name = nd.get("module")
    if not module_name:
        return nd, None

    try:
        manifest = load_device_module(module_name, base_dir)
    except FileNotFoundError:
        return nd, None

    defaults = manifest.get("defaults") or {}
    # Apply defaults only for keys the node doesn't explicitly set.
    for key, val in defaults.items():
        if key not in nd:
            nd[key] = val

    # Implicit deviceconfig: if the node has no explicit deviceconfig and the
    # device has a payload/ directory, set deviceconfig: {device: <module>}.
    if "deviceconfig" not in nd:
        root = _payload.repo_root(base_dir or os.getcwd())
        payload_dir = os.path.join(root, "devices", module_name, "payload")
        if os.path.isdir(payload_dir):
            nd["deviceconfig"] = {"device": module_name}

    return nd, manifest


def parse_intent(doc: dict[str, Any], base_dir: str | None = None) -> Intent:
    """Build an ``Intent`` from a parsed YAML/JSON mapping matching the
    FS_TOPOLOGY_FRAMEWORK "Intent spec" shape. Raises ``ValueError`` on a
    malformed document (missing fabric, link to an undeclared switch, etc.).

    ``base_dir`` anchors relative local-file paths (``script``/``playbook``/
    ``ssh_key``/``upload.src``/``detached.script``) -- pass the intent file's
    directory (``load_intent`` does this) so they resolve portably.

    A ``presets:`` (or deprecated ``use:``) list expands built-in seeded-infra
    presets (``oob-mgmt``, ``internet-egress``) into their net/switch blocks
    first (explicit declarations win). Schema-v1 keys are silently accepted as
    aliases of their v2 canonical spellings (see ``_apply_schema_aliases``)."""
    if not isinstance(doc, dict):
        raise ValueError("intent must be a mapping")
    fabric = doc.get("fabric")
    if not fabric:
        raise ValueError("intent.fabric is required")
    doc, _deprecations = _apply_schema_aliases(doc)
    _reject_unknown_toplevel_keys(doc)
    doc = _expand_presets(doc)

    images = []
    for im in (doc.get("images") or []):
        if "name" not in im:
            raise ValueError("image item requires a 'name'")
        if not im.get("path") and not im.get("build") and not im.get("home_repo"):
            raise ValueError(
                f"image {im['name']!r} requires a 'path', a 'build', or a 'home_repo'")
        build = im.get("build")
        if isinstance(build, dict):
            # Resolve build hook paths with the same repository-native rules as
            # script/upload/playbook paths; legacy intent-relative paths remain
            # supported by _resolve_intent_path.
            build = dict(build)
            for k in ("provision_script", "fabric_payload", "ssh_key"):
                if build.get(k):
                    build[k] = _resolve_intent_path(build[k], base_dir)
            # qcow build (via: fs-builder): the detached build script is a sibling
            # file too -- anchor it like config.detached.script.
            det = build.get("detached")
            if isinstance(det, dict) and det.get("script"):
                det = dict(det)
                det["script"] = _resolve_intent_path(det["script"], base_dir)
                build["detached"] = det
            # qcow build self-staging: stage[].src is a local tree to upload --
            # anchor it like config.upload.src.
            stage = build.get("stage")
            if isinstance(stage, list):
                build["stage"] = [
                    ({**s, "src": _resolve_intent_path(s["src"], base_dir)}
                     if isinstance(s, dict) and s.get("src") else s)
                    for s in stage
                ]
            # build.cache[].key: the local recipe tree hashed into the entry's name.
            cache = build.get("cache")
            if isinstance(cache, list):
                build["cache"] = [
                    ({**it, "key": _resolve_intent_path(it["key"], base_dir)}
                     if isinstance(it, dict) and isinstance(it.get("key"), str) else it)
                    for it in cache
                ]
        images.append(ImageSpec(
            name=im["name"], path=im.get("path"), kind=im.get("kind"),
            dest_name=im.get("dest_name"), build=build,
            home_repo=im.get("home_repo"), addressing=im.get("addressing")))

    # Falls back to the declared defaults for a `when:` that is still an
    # unsubstituted ${var.x} (raw-doc parse) -- see _when_defaults.
    _when_vars = _when_defaults(doc)

    networks = [
        NetworkSpec(name=n["name"], cidr=n["cidr"], gateway=n.get("gateway"),
                    dns1=n.get("dns1"), dns2=n.get("dns2"),
                    protected=bool(n.get("protected", False)))
        for n in (doc.get("networks") or [])
        if _when_enabled(n, f"network {n.get('name')!r}", _when_vars)
    ]
    net_names = {n.name for n in networks}

    routers = []
    for r in (doc.get("routers") or []):
        if isinstance(r, str):
            r = {"name": r}
        if not isinstance(r, dict) or not r.get("name"):
            raise ValueError("routers entry must be a name or a mapping with 'name'")
        if not _when_enabled(r, f"router {r.get('name')!r}", _when_vars):
            continue
        routers.append(RouterSpec(name=r["name"], protected=bool(r.get("protected", False))))

    switches = []
    for s in (doc.get("switches") or []):
        if not _when_enabled(s, f"switch {s.get('name')!r}", _when_vars):
            continue
        # ``networks:`` is the general form -- every subnet the switch carries,
        # one per VLAN on a VLAN switch. ``auto_address:`` is the single-net
        # spelling and stays supported; when both are given, auto_address must
        # be one of the networks.
        nets = s.get("networks")
        if nets is not None and not isinstance(nets, list):
            raise ValueError(f"switch {s['name']!r} networks must be a list of network names")
        nets = list(nets or [])
        for nm in nets:
            if nm not in net_names:
                raise ValueError(f"switch {s['name']!r} networks entry {nm!r} is not a declared network")
        aa = s.get("auto_address")
        if aa and aa not in net_names:
            raise ValueError(f"switch {s['name']!r} auto_address {aa!r} is not a declared network")
        if aa and nets and aa not in nets:
            raise ValueError(f"switch {s['name']!r} auto_address {aa!r} is not in its "
                             f"networks list {nets!r}")
        if not aa and nets:
            # FS auto-addresses exactly one subnet; the first declared one is it.
            aa = nets[0]
        if aa and not nets:
            nets = [aa]
        role = s.get("role")
        if role is not None and role not in ("mgmt", "egress"):
            raise ValueError(f"switch {s['name']!r} role {role!r} must be 'mgmt' or 'egress'")
        # role wins over an explicit mgmt flag; default (neither set) is mgmt=True.
        if role is not None:
            mgmt = (role == "mgmt")
            if "mgmt" in s and bool(s["mgmt"]) != mgmt:
                raise ValueError(
                    f"switch {s['name']!r}: role {role!r} and mgmt={s['mgmt']!r} contradict each other")
        else:
            mgmt = bool(s.get("mgmt", True))
        switches.append(SwitchSpec(name=s["name"], auto_address=aa, mgmt=mgmt, role=role,
                                   host_uplink=bool(s.get("host_uplink", False)),
                                   protected=bool(s.get("protected", False)),
                                   networks=nets))
    sw_names = {s.name for s in switches}

    nodes = []
    for nd in (doc.get("nodes") or []):
        # Phase 6: apply device module defaults (image, cpu, memory, access,
        # implicit deviceconfig) when ``module:`` is set on the node. Node
        # fields override device defaults; --var overrides both later.
        nd, _module_manifest = _apply_module_defaults(nd, base_dir)
        node_type = nd.get("type", "")
        # Shorthand: ``switch: <name>`` on a node is sugar for a single link on
        # the node's default first port. Mutually exclusive with ``links:``.
        raw_links = nd.get("links")
        if nd.get("switch") is not None:
            if raw_links:
                raise ValueError(
                    f"node {nd['name']!r}: use either the `switch:` shorthand or "
                    f"an explicit `links:` block, not both")
            raw_links = [nd["switch"]]
        links = []
        for i, lk in enumerate(raw_links or []):
            # A bare string is sugar for a link to that switch on the default port.
            if isinstance(lk, str):
                lk = {"switch": lk}
            if "switch" not in lk:
                raise ValueError(f"node {nd['name']!r} link missing 'switch': {lk!r}")
            # Pod-conditional link. Checked BEFORE the declared-switch check so a
            # link disabled alongside its (also-disabled) switch doesn't trip it.
            if not _when_enabled(lk, f"node {nd['name']!r} link {lk.get('port') or f'#{i}'}",
                                 _when_vars):
                continue
            if lk["switch"] not in sw_names:
                raise ValueError(f"node {nd['name']!r} link to undeclared switch {lk['switch']!r}")
            # ``port:`` may be omitted -- auto-number by declaration order, using
            # the port naming the device family actually uses (Fortinet
            # appliances are ``port1..``; Linux/LXC/qcow guests are ``eth0..``).
            port = lk.get("port") or _default_port_name(node_type, i)
            where = f"node {nd['name']!r} link {port}"
            if lk.get("vlan") is not None and lk.get("trunk") is not None:
                raise ValueError(f"{where}: vlan: and trunk: are mutually exclusive "
                                 f"-- a switchport is access OR trunk, never both")
            if lk.get("mode") is not None:
                # There is no `mode:` key on purpose. It is derived from
                # vlan:/trunk:, so the wrong states (trunk on an endpoint port, a
                # native vlan next to mode: trunk) are unrepresentable.
                raise ValueError(f"{where}: `mode:` is not an intent key -- the "
                                 f"switchport mode is derived from vlan: (access) "
                                 f"or trunk: (trunk)")
            vlan = parse_vlan_id(lk["vlan"], where) if lk.get("vlan") is not None else None
            trunk = parse_trunk_list(lk["trunk"], where) if lk.get("trunk") is not None else ()
            links.append(LinkSpec(port=port, switch=lk["switch"],
                                  ip=lk.get("ip"), netmask=lk.get("netmask"),
                                  dhcp=lk.get("dhcp"),
                                  mgmt=lk.get("mgmt"),
                                  vlan=vlan, trunk=trunk))
        disks = [int(d) for d in (nd.get("disks") or [])]
        access = list(nd.get("access") or [])
        # expose: custom guest ports → System Host port redirects. Accept a bare
        # int or {port, from_port?, proto?, name?}. Normalize to
        # {from_port, to_port, socktype, name}: from_port (external listener)
        # defaults to the guest port; proto TCP unless UDP.
        expose = []
        for ex in (nd.get("expose") or []):
            entry = {"port": int(ex)} if isinstance(ex, int) else dict(ex)
            if "port" not in entry:
                raise ValueError(f"node {nd['name']!r} expose entry missing 'port': {ex!r}")
            to_port = int(entry["port"])
            from_port = int(entry.get("from_port", to_port))
            proto = str(entry.get("proto", "TCP")).upper()
            if proto not in ("TCP", "UDP"):
                raise ValueError(f"node {nd['name']!r} expose proto must be TCP/UDP, got {proto!r}")
            expose.append({"from_port": from_port, "to_port": to_port,
                           "socktype": proto, "name": entry.get("name")})
        count = nd.get("count")
        if count is not None:
            try:
                count = int(count)
            except (TypeError, ValueError):
                raise ValueError(f"node {nd['name']!r}: count must be an integer, got {count!r}")
        for_each = nd.get("for_each")
        if for_each is not None and not isinstance(for_each, dict):
            raise ValueError(f"node {nd['name']!r}: for_each must be a dict, got {type(for_each).__name__}")
        ignore_changes = list(nd.get("ignore_changes") or [])
        if ignore_changes and not all(isinstance(f, str) for f in ignore_changes):
            raise ValueError(f"node {nd['name']!r}: ignore_changes must be a list of strings")
        uuid_val = nd.get("uuid")
        if uuid_val is not None:
            uuid_val = str(uuid_val).strip()
            if not _UUID_RE.match(uuid_val):
                raise ValueError(
                    f"node {nd['name']!r}: uuid must be canonical 8-4-4-4-12 hex "
                    f"(e.g. 464f5254-4950-44f4-833f-56070da0a5fa), got {uuid_val!r}")
        raw_params = nd.get("params")
        if raw_params is not None and not isinstance(raw_params, dict):
            raise ValueError(f"node {nd['name']!r}: params must be a mapping, got {type(raw_params).__name__}")
        auto_params_network = nd.get("auto_params_network")
        if auto_params_network is not None and auto_params_network not in net_names:
            raise ValueError(
                f"node {nd['name']!r}: auto_params_network {auto_params_network!r} "
                f"is not a declared network")
        # deviceconfig: a literal path (string) or a derived form (dict
        # {device: <name>, base?: [...], inject?: {...}}). The derived form is
        # built by build_deviceconfigs before plan/apply; here we just store it.
        dc = nd.get("deviceconfig")
        if isinstance(dc, dict):
            if "device" not in dc or not dc["device"]:
                raise ValueError(f"node {nd['name']!r}: deviceconfig dict requires a 'device' key")
            device_spec = dict(dc)
            provision_config: str | None = None
        elif isinstance(dc, str) and dc:
            device_spec = None
            provision_config = _resolve_intent_path(dc, base_dir)
        else:
            device_spec = None
            provision_config = None
        nodes.append(NodeSpec(
            name=nd["name"], type=node_type, uuid=uuid_val,
            image=nd.get("image"), links=links,
            cpu=nd.get("cpu"), memory=nd.get("memory"),
            hugepages=nd.get("hugepages"), disks=disks, access=access,
            expose=expose, console_password=nd.get("console_password"),
            password=nd.get("password"),
            provision_config=provision_config,
            device=device_spec,
            params=dict(raw_params or {}),
            license=_parse_license(nd.get("license")),
            ready=_parse_ready(nd.get("wait_for"), node_type),
            count=count, for_each=for_each, ignore_changes=ignore_changes,
            auto_params_network=auto_params_network,
            protected=bool(nd.get("protected", False)),
            depends_on=list(nd.get("depends_on") or []),
            install_after=list(nd.get("install_after") or []),
            module=nd.get("module")))

    node_names = {nd.name for nd in nodes}
    for nd in nodes:
        unknown = [n for n in nd.install_after if n not in node_names]
        if unknown:
            raise ValueError(
                f"node {nd.name!r}: install_after references unknown node(s) "
                f"{unknown!r}")
        if nd.name in nd.install_after:
            raise ValueError(f"node {nd.name!r}: install_after cannot reference itself")
    _install_after_map = {nd.name: nd.install_after for nd in nodes}
    for start in _install_after_map:
        path, seen = [start], {start}
        stack = [(start, iter(_install_after_map[start]))]
        while stack:
            _cur, it = stack[-1]
            nxt = next(it, None)
            if nxt is None:
                stack.pop()
                path.pop()
                seen.discard(_cur)
                continue
            if nxt == start:
                raise ValueError(
                    f"install_after cycle: {' → '.join(path + [nxt])}")
            if nxt in seen:
                continue
            path.append(nxt)
            seen.add(nxt)
            stack.append((nxt, iter(_install_after_map.get(nxt, []))))
    cfg_defaults = dict(doc.get("provision_defaults") or {})
    if cfg_defaults.get("ssh_key"):
        cfg_defaults["ssh_key"] = _resolve_intent_path(cfg_defaults["ssh_key"], base_dir)
    config = []
    for ci in (doc.get("provision") or []):
        local = ci.get("local")
        if local is not None:
            # local: items run on the laptop -- no node or SSH needed.
            if not (isinstance(local, dict) and local.get("command")):
                raise ValueError("provision local: item requires a 'command'")
            # label and depends_on are parsed HERE too. They used to be read
            # only in the node path below, so a `local:` item silently lost
            # both -- and both losses are quiet in the worst way.
            #
            # No label means the item is journaled by POSITION ("item:3"), so
            # `--forget <label>` cannot reach it and a resume skips it forever;
            # worse, inserting any item above it renumbers it, and it inherits
            # a different item's history.
            #
            # No depends_on means its declared ordering is silently void. For
            # patch-pipeline's `soar-creds` that is the whole correctness
            # argument: the intent says it must run AFTER fleet and miniflux
            # re-seed, because both mint fresh credentials and this copies them
            # into FortiSOAR. Dropped, it ran in the FIRST wave alongside them
            # and copied the very credentials it existed to replace -- a sync
            # that "succeeded" while leaving the appliance authenticating with
            # the previous lab's secrets.
            config.append(ConfigSpec(local=local,
                                     label=ci.get("label"),
                                     depends_on=list(ci.get("depends_on") or []),
                                     ignore_errors=bool(ci.get("ignore_errors", False))))
            continue
        if "node" not in ci:
            raise ValueError("provision item requires a 'node' (or use 'local:' for laptop-side steps)")
        if ci["node"] not in node_names:
            raise ValueError(f"provision item targets undeclared node {ci['node']!r}")
        cmds = ci.get("commands") or []
        if isinstance(cmds, str):
            cmds = [cmds]
        actions = [k for k in ("commands", "script", "upload", "detached", "playbook", "ingest")
                   if (ci.get(k) if k != "commands" else cmds)]
        if "device_access" in ci:
            actions.append("device_access")
        if len(actions) != 1:
            raise ValueError(
                f"provision item for {ci['node']!r} must set exactly one of "
                f"commands/script/upload/detached/playbook/ingest/device_access (got {actions or 'none'})")
        device_access = ci.get("device_access")
        if "device_access" in ci:
            device_access = {} if device_access is None else device_access
            if not isinstance(device_access, dict) or set(device_access) - {"ssh", "api"}:
                raise ValueError(f"provision item for {ci['node']!r}: device_access takes only "
                                 f"'ssh' and 'api' (booleans)")
        via = ci.get("ansible_via")
        if via is not None:
            # Catch the typo at parse time. Getting this wrong otherwise
            # surfaces as an unreachable controller mid-provision, after apply has
            # already built the fabric.
            if via not in node_names:
                raise ValueError(
                    f"provision item for {ci['node']!r}: ansible_via names undeclared "
                    f"node {via!r}")
            if via == ci["node"]:
                raise ValueError(
                    f"provision item for {ci['node']!r}: ansible_via cannot be the "
                    f"target node itself")
            if not ci.get("playbook"):
                raise ValueError(
                    f"provision item for {ci['node']!r}: ansible_via only applies to a "
                    f"'playbook' item")
        upload = ci.get("upload")
        if upload is not None:
            if not (isinstance(upload, dict) and upload.get("src") and upload.get("dest")):
                raise ValueError(
                    f"provision item for {ci['node']!r}: upload requires 'src' and 'dest'")
            upload = dict(upload)
            upload["src"] = _resolve_intent_path(upload["src"], base_dir)
        detached = ci.get("detached")
        if detached is not None:
            if not isinstance(detached, dict) or bool(detached.get("command")) == bool(detached.get("script")):
                raise ValueError(
                    f"provision item for {ci['node']!r}: detached requires exactly one "
                    f"of 'command' or 'script'")
            if detached.get("script"):
                detached = dict(detached)
                detached["script"] = _resolve_intent_path(detached["script"], base_dir)
        ingest = ci.get("ingest")
        if ingest is not None:
            missing = [k for k in ("remote_qcow", "dest_name", "template_firmware")
                       if not (isinstance(ingest, dict) and ingest.get(k))]
            if missing:
                raise ValueError(
                    f"provision item for {ci['node']!r}: ingest requires "
                    f"{', '.join(missing)}")
        # Phase 3: vars: is only valid on playbook: items (it's Ansible extra-vars).
        item_vars = ci.get("vars")
        if item_vars is not None:
            if not ci.get("playbook"):
                raise ValueError(
                    f"provision item for {ci['node']!r}: vars: is only valid on a "
                    f"'playbook' item (it becomes ansible --extra-vars)")
            if not isinstance(item_vars, dict):
                raise ValueError(
                    f"provision item for {ci['node']!r}: vars: must be a mapping")
        config.append(ConfigSpec(
            node=ci["node"], commands=list(cmds),
            script=_resolve_intent_path(ci.get("script"), base_dir),
            upload=upload, detached=detached,
            playbook=_resolve_intent_path(ci.get("playbook"), base_dir),
            ingest=ingest, device_access=device_access,
            vars=dict(item_vars) if item_vars else None,
            ssh_user=ci.get("ssh_user"),
            ssh_key=_resolve_intent_path(ci.get("ssh_key"), base_dir),
            ssh_password=ci.get("ssh_password"),
            ssh_via=ci.get("ssh_via"),
            become=bool(ci.get("become", False)),
            ignore_errors=bool(ci.get("ignore_errors", False)),
            inherit_defaults=bool(ci.get("inherit_defaults", True)),
            ansible_via=ci.get("ansible_via"),
            label=ci.get("label"),
            depends_on=list(ci.get("depends_on") or []),
            identity_nodes=list(ci.get("identity_nodes") or [])))

    healthchecks = []
    for hi in (doc.get("healthchecks") or []):
        node = hi.get("node")
        dtype = hi.get("device_type")
        if not node and not dtype:
            raise ValueError("healthcheck item requires a 'node' or a 'device_type'")
        if node and node not in node_names:
            raise ValueError(f"healthcheck item targets undeclared node {node!r}")
        checks = hi.get("checks") or []
        if isinstance(checks, str):
            checks = [checks]
        if hi.get("check"):
            checks = [hi["check"], *checks]
        if not checks:
            raise ValueError(
                f"healthcheck item for {node or dtype!r} requires 'check' or 'checks'")
        healthchecks.append(HealthSpec(
            node=node, device_type=dtype, checks=list(checks),
            params=dict(hi.get("params") or {})))

    # Expand nodes with count/for_each before validating node references.
    nodes = _expand_nodes(nodes)
    # Update node_names to reflect expanded nodes for service validation.
    expanded_node_names = {nd.name for nd in nodes}

    node_type = {nd.name: nd.type for nd in nodes}
    services = _parse_services(doc.get("services") or {}, expanded_node_names, node_type)

    intent = Intent(fabric=fabric, images=images, networks=networks, switches=switches,
                    routers=routers,
                    nodes=nodes, config=config, config_defaults=cfg_defaults,
                    healthchecks=healthchecks, services=services,
                    service_defaults=doc.get("service_defaults") or {},
                    description=doc.get("description", ""),
                    deprecations=_deprecations)

    # Phase 5: cycle detection at parse time -- a depends_on cycle is a fatal
    # error, caught here (in validate) rather than mid-apply.
    from fabric_studio.topology.depgraph import DependencyGraph
    graph = DependencyGraph(intent)
    cycle = graph.detect_cycles()
    if cycle:
        raise ValueError(
            f"dependency cycle: {' → '.join(cycle)} → {cycle[0]}")

    return intent


_COUNT_INDEX_RE = re.compile(r"\$\{count\.index\}")
_EACH_KEY_RE = re.compile(r"\$\{each\.key\}")
_EACH_VALUE_RE = re.compile(r"\$\{each\.value\}")


def _substitute_expansion_vars(obj: Any, count_index: int | None = None,
                               each_key: str | None = None, each_value: Any = None) -> Any:
    """Recursively substitute ${count.index}, ${each.key}, ${each.value} in strings."""
    if isinstance(obj, str):
        if count_index is not None:
            obj = _COUNT_INDEX_RE.sub(str(count_index), obj)
        if each_key is not None:
            obj = _EACH_KEY_RE.sub(each_key, obj)
        if each_value is not None:
            obj = _EACH_VALUE_RE.sub(str(each_value), obj)
        return obj
    if isinstance(obj, dict):
        return {k: _substitute_expansion_vars(v, count_index, each_key, each_value)
                for k, v in obj.items()}
    if isinstance(obj, list):
        return [_substitute_expansion_vars(item, count_index, each_key, each_value)
                for item in obj]
    return obj


def _expand_nodes(nodes: list[NodeSpec]) -> list[NodeSpec]:
    """Fan out nodes with ``count`` or ``for_each`` into multiple concrete nodes.

    A node with ``count: N`` expands to N copies with indices 0..N-1 substituted
    into ``${count.index}`` in the node name and all field references. A node with
    ``for_each: {key: value, ...}`` expands to one copy per dict entry with
    ``${each.key}`` and ``${each.value}`` substituted. Both are mutually exclusive.
    Nodes without count/for_each pass through unchanged. Node names and fields are
    copied (not mutated in-place) so the original spec is unmodified."""
    result = []
    for node in nodes:
        if node.count is not None and node.for_each is not None:
            raise ValueError(f"node {node.name!r}: count and for_each are mutually exclusive")
        if node.count is not None:
            # count: expand to node.count copies with 0-based indices.
            if not isinstance(node.count, int) or node.count < 1:
                raise ValueError(f"node {node.name!r}: count must be a positive integer")
            for idx in range(node.count):
                expanded = _expand_single_node(node, count_index=idx)
                result.append(expanded)
        elif node.for_each is not None:
            # for_each: expand to one copy per dict entry.
            if not isinstance(node.for_each, dict):
                raise ValueError(f"node {node.name!r}: for_each must be a dict")
            for key, value in node.for_each.items():
                expanded = _expand_single_node(node, each_key=str(key), each_value=value)
                result.append(expanded)
        else:
            # No expansion -- pass through unchanged.
            result.append(node)
    return result


def _expand_single_node(node: NodeSpec, count_index: int | None = None,
                        each_key: str | None = None, each_value: Any = None) -> NodeSpec:
    """Expand a single node with count_index and/or each_key/value substitution."""
    # Substitute the node name first.
    name = _substitute_expansion_vars(node.name, count_index, each_key, each_value)
    # Substitute into all fields that might contain variable references.
    links = [LinkSpec(
        port=_substitute_expansion_vars(lk.port, count_index, each_key, each_value),
        switch=_substitute_expansion_vars(lk.switch, count_index, each_key, each_value),
        ip=_substitute_expansion_vars(lk.ip, count_index, each_key, each_value),
        netmask=_substitute_expansion_vars(lk.netmask, count_index, each_key, each_value),
        dhcp=_substitute_expansion_vars(lk.dhcp, count_index, each_key, each_value),
        mgmt=lk.mgmt,                       # bool | None -- nothing to substitute
        vlan=lk.vlan, trunk=lk.trunk,       # already parsed + validated ints
    ) for lk in node.links]
    access = [_substitute_expansion_vars(a, count_index, each_key, each_value)
              for a in node.access]
    expose = [_substitute_expansion_vars(ex, count_index, each_key, each_value)
              for ex in node.expose]
    provision_config = _substitute_expansion_vars(
        node.provision_config, count_index, each_key, each_value)
    params = _substitute_expansion_vars(node.params, count_index, each_key, each_value)
    # Return a new node with substituted fields and count/for_each cleared.
    return NodeSpec(
        name=name,
        type=node.type,
        firmware=node.firmware,
        image=node.image,
        links=links,
        cpu=node.cpu,
        memory=node.memory,
        disks=list(node.disks),
        access=access,
        expose=expose,
        provision_config=provision_config,
        params=params,
        license=node.license,
        auto_params_network=node.auto_params_network,
        count=None,
        for_each=None,
    )


def _parse_adoms(raw: Any) -> list[AdomSpec]:
    """An ``adoms:`` list -- each item a bare name string or ``{name, os_ver}``."""
    out = []
    for a in (raw or []):
        if isinstance(a, str):
            out.append(AdomSpec(name=a))
        elif isinstance(a, dict) and a.get("name"):
            out.append(AdomSpec(name=a["name"], os_ver=a.get("os_ver")))
        else:
            raise ValueError(f"adom item must be a name or {{name, os_ver}}, got {a!r}")
    return out


def _parse_register(raw: Any, node_names: set[str], default_adom: str | None) -> list[RegisterSpec]:
    """A ``register:`` list -- each item a bare node-name string or
    ``{device, adom}``. Validates the device is a declared node."""
    out = []
    for r in (raw or []):
        if isinstance(r, str):
            device, adom = r, default_adom
        elif isinstance(r, dict) and r.get("device"):
            device, adom = r["device"], (r.get("adom") or default_adom)
        else:
            raise ValueError(f"register item must be a node name or {{device, adom}}, got {r!r}")
        if device not in node_names:
            raise ValueError(f"register targets undeclared node {device!r}")
        out.append(RegisterSpec(device=device, adom=adom))
    return out


def _parse_service(raw: dict[str, Any], want_type: str, node_names: set[str],
                   node_type: dict[str, str]):
    """Parse one fortimanager/fortianalyzer sub-spec; returns (node, adoms,
    register) after validating the controller node exists and has ``want_type``."""
    node = raw.get("node")
    if not node:
        raise ValueError(f"fabric_services.{want_type.lower()} requires a 'node'")
    if node not in node_names:
        raise ValueError(f"fabric_services.{want_type.lower()} node {node!r} is not a declared node")
    if node_type.get(node) not in (want_type, ""):       # "" = type omitted; trust the user
        raise ValueError(
            f"fabric_services.{want_type.lower()} node {node!r} is type "
            f"{node_type.get(node)!r}, expected {want_type}")
    adoms = _parse_adoms(raw.get("adoms"))
    default_adom = adoms[0].name if adoms else None
    register = _parse_register(raw.get("register"), node_names, default_adom)
    return node, adoms, register


def _parse_services(raw: dict[str, Any], node_names: set[str],
                    node_type: dict[str, str]) -> ServicesSpec | None:
    """Parse the ``fabric_services:`` block into a ``ServicesSpec`` (or None)."""
    if not raw:
        return None
    fmg = faz = None
    if raw.get("fortimanager"):
        node, adoms, register = _parse_service(
            raw["fortimanager"], "FMG", node_names, node_type)
        fmg = FmgServiceSpec(node=node, adoms=adoms, register=register)
    if raw.get("fortianalyzer"):
        node, adoms, register = _parse_service(
            raw["fortianalyzer"], "FAZ", node_names, node_type)
        faz = FazServiceSpec(node=node, adoms=adoms, register=register)
    if fmg is None and faz is None:
        return None
    return ServicesSpec(fortimanager=fmg, fortianalyzer=faz)


def load_intent(path: str, *, pod_host: str | None = None,
                var_files: tuple[str, ...] = (),
                var_overrides: tuple[str, ...] = ()) -> Intent:
    import yaml
    with open(path, encoding="utf-8") as fh:
        doc = yaml.safe_load(fh)
    base_dir = os.path.dirname(os.path.abspath(path))
    values = resolve_variables(doc, base_dir=base_dir, pod_host=pod_host,
                               var_files=tuple(var_files),
                               var_overrides=tuple(var_overrides))
    if values:
        doc = substitute_variables(doc, values)
    return parse_intent(doc, base_dir=base_dir)


# ── Plan ─────────────────────────────────────────────────────────────────────

@dataclass
class Change:
    op: str          # "create" | "update" | "delete" | "noop" | "replace"
    kind: str        # "fabric" | "network" | "switch" | "node" | "link" | "boot"
    name: str
    detail: str = ""
    # True when applying this change destroys and reinstalls ``name``'s VM.
    # Several FS model fields (cpu/memory/disks/params/firmware/license mode/
    # provision_config content/cabling) are only read at install time, so apply
    # converges them with destroy_vm → install_vm. That wipes guest state -- an
    # appliance loses whatever it was configured with since its last install --
    # and the plan gave no hint it was about to happen: a one-line "cpu 2→4"
    # read like an in-place edit. Marking it is the whole point of a plan.
    reinstall: bool = False

    def __str__(self) -> str:
        sign = {"create": "+", "update": "~", "delete": "-", "noop": "=",
                "replace": "-/+"}.get(self.op, "?")
        d = f"  ({self.detail})" if self.detail else ""
        r = "  [REINSTALL]" if self.reinstall else ""
        return f"  {sign} {self.kind} {self.name}{d}{r}"

    def to_dict(self) -> dict[str, Any]:
        """Serialize to JSON-serializable dict."""
        return {
            "op": self.op,
            "kind": self.kind,
            "name": self.name,
            "detail": self.detail,
            "reinstall": self.reinstall,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Change:
        """Deserialize from dict (inverse of to_dict()).

        Phase 4: tolerates unknown ``op`` values (renders as ``?`` in __str__)
        so a saved plan file outlives a schema change that adds a new op --
        loading an old plan with a new op, or vice versa, doesn't crash."""
        return cls(
            op=d["op"],
            kind=d["kind"],
            name=d["name"],
            detail=d.get("detail", ""),
            # Absent in plans saved before the field existed -- default False.
            reinstall=bool(d.get("reinstall", False)),
        )


@dataclass
class Plan:
    changes: list[Change] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    # BLOCKING topology faults (``_lint_topology``). A warning says "this may not
    # be what you meant"; an error says "applying this deploys a broken network".
    # ``apply`` refuses while this is non-empty unless explicitly overridden.
    errors: list[str] = field(default_factory=list)
    # Timestamp and fabric name for validation when loading a saved plan.
    timestamp: str | None = None  # ISO 8601 datetime string
    fabric: str | None = None     # intent fabric name

    def __post_init__(self) -> None:
        """Auto-populate timestamp if not set."""
        if self.timestamp is None:
            self.timestamp = datetime.now(UTC).isoformat().replace("+00:00", "Z")

    @property
    def mutating(self) -> list[Change]:
        return [c for c in self.changes if c.op != "noop"]

    @property
    def reinstall_nodes(self) -> list[str]:
        """Nodes this plan will destroy→install (guest state lost). Summarized in
        ``render`` so the destructive half of an apply is visible before it runs."""
        # ``kind: node`` names the node directly; link/disk changes name a
        # sub-resource (``fgt.port1→sw``, ``fgt/data``, ``fgt[0]``), so take the
        # node prefix -- the reinstall is always of the owning VM.
        out = set()
        for c in self.changes:
            if not c.reinstall or c.op == "noop":
                continue
            out.add(re.split(r"[.\[/]", c.name, maxsplit=1)[0])
        return sorted(out)

    def render(self) -> str:
        body: list[str]
        if not self.mutating:
            body = ["Plan: no changes -- fabric already matches intent."]
        else:
            creates = sum(c.op == "create" for c in self.changes)
            updates = sum(c.op == "update" for c in self.changes)
            deletes = sum(c.op == "delete" for c in self.changes)
            replaces = sum(c.op == "replace" for c in self.changes)
            summary = (f"Plan: {creates} to create, {updates} to update, "
                       f"{deletes} to delete"
                       + (f", {replaces} to replace" if replaces else "")
                       + " (prune)")
            body = [summary]
            if self.reinstall_nodes:
                body.append(
                    f"  {len(self.reinstall_nodes)} node(s) will be REINSTALLED "
                    f"(destroy \u2192 install; guest state is lost): "
                    + ", ".join(self.reinstall_nodes))
            body += [str(c) for c in self.changes if c.op != "noop"]
        for w in self.warnings:
            body.append(f"  ! {w}")
        for e in self.errors:
            body.append(f"  \u2717 ERROR {e}")
        if self.errors:
            body.append(f"\nBLOCKED: {len(self.errors)} topology error(s) -- apply "
                        "will refuse. Fix the intent, or re-run with --force-lint "
                        "if you are certain the check is wrong.")
        return "\n".join(body)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to JSON-serializable dict (round-trippable with from_dict())."""
        return {
            "timestamp": self.timestamp,
            "fabric": self.fabric,
            "changes": [c.to_dict() for c in self.changes],
            "warnings": self.warnings,
            "errors": self.errors,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Plan:
        """Deserialize from dict (inverse of to_dict())."""
        changes = [Change.from_dict(c) for c in d.get("changes", [])]
        plan = cls(
            changes=changes,
            warnings=d.get("warnings", []),
            errors=d.get("errors", []),
            timestamp=d.get("timestamp"),
            fabric=d.get("fabric"),
        )
        # from_dict bypasses __post_init__, so only set timestamp if not in dict
        # (this ensures the loaded timestamp is preserved).
        return plan


def _enable_dhcp_service(c: FabricStudioClient, fid: int | str, intent: Intent,
                         state: dict[str, Any], say) -> list[str]:
    """Switch ``dhcp_service`` ON for the System Host port(s) uplinking every
    switch that carries a ``dhcp:`` link and isn't serving leases yet.

    Returns the host-port names changed. Idempotent, and silent about segments
    that already serve. See the call site for why this is a fix rather than an
    error."""
    switches = state.get("switches") or []
    sw_name_by_port = {p.get("id"): s.get("name")
                       for s in switches for p in (s.get("ports") or [])}
    host_ports_by_switch: dict[str, list[dict[str, Any]]] = {}
    for hp in (state.get("host") or {}).get("ports") or []:
        nm = sw_name_by_port.get(hp.get("peer"))
        if nm is not None:
            host_ports_by_switch.setdefault(nm, []).append(hp)
    want = {lk.switch for nd in intent.nodes for lk in nd.links if lk.dhcp}
    changed: list[str] = []
    for sw_name in sorted(want):
        hps = host_ports_by_switch.get(sw_name) or []
        if not hps or any(hp.get("dhcp_service") for hp in hps):
            continue                      # floating, or already serving
        hp = hps[0]
        try:
            fa.set_host_port_dhcp_service(c, hp["id"], True)
        except AttributeError:
            # fs_admin is a separate package and may predate the helper --
            # fall back to the model PATCH it would make.
            fa._patch(c, f"api/v1/model/host/port/{hp['id']}",
                      {"object": {"dhcp_service": True}}, "set_dhcp_service")
        except Exception as e:
            say(f"could not enable DHCP service on {hp.get('name')}: {e}")
            continue
        changed.append(str(hp.get("name")))
        say(f"switch {sw_name!r}: enabled DHCP service on System Host "
            f"{hp.get('name')} (serves the reservation this apply writes)")
    return changed


def _lint_topology(intent: Intent, state: dict[str, Any] | None,
                   prune: bool = False) -> list[str]:
    """BLOCKING checks for topologies that would deploy broken L3.

    These are errors, not warnings, because every one of them produces a segment
    that assigns addresses and then silently drops traffic -- the most expensive
    failure mode this framework has, since `plan` reports clean and the fault
    only shows up as an application-layer symptom hours later.

    All four checks below are generalisations of one live incident (fortiaigate_lab,
    2026-08-25): the FS-seeded "ISP Router" held 203.0.113.254 -- the gateway of
    the `Internet Access` net -- with its own upstream port uncabled and no
    default route, while the System Host port configured with the SAME address
    sat on the SAME segment. The router won the ARP, so every guest on the
    segment black-holed. FortiAIGate's licence could not reach FortiCare and
    reported `Server Error`; the FortiGate's FortiGuard DB had been stuck at
    0.00000 for weeks; FMG flex activation failed with an empty reason. `plan`
    said the fabric matched intent throughout, because routers were invisible to
    `read_fabric_state` and nothing checked gateway ownership for exclusivity.

    Passing ``state=None`` (fabric does not exist yet) still runs the
    intent-only checks -- a duplicate subnet is wrong before anything is built.
    """
    errors: list[str] = []
    _norm = lambda nm: re.sub(r"\s+", " ", (nm or "").strip().lower())

    # -- 1. Two declared networks on the same subnet -------------------------
    # FS lets you create both. Nothing downstream can then say which net a port
    # "means", and a host_uplink on one silently contends with the other.
    by_cidr: dict[str, list[str]] = {}
    for n in intent.networks:
        by_cidr.setdefault(_norm_intent_cidr(n.cidr), []).append(n.name)
    for cidr, names in sorted(by_cidr.items()):
        if len(names) > 1:
            errors.append(
                f"networks {', '.join(repr(x) for x in sorted(names))} all declare "
                f"subnet {cidr} -- two networks on one subnet cannot both own the "
                f"gateway; give them distinct subnets or declare one network")

    # -- 2. A declared network shadows FS-seeded shared infra -----------------
    # SEEDED_SHARED_NAMES exists so `--prune` cannot delete another tenant's
    # egress. The side effect: an intent that MINTS a net with a seeded name gets
    # it auto-protected and indistinguishable from the real seed. If the values
    # then differ from what the pod actually seeded, the intent is describing a
    # network that does not exist while claiming a name that does.
    live_nets = {(_norm(n.get("name"))): n for n in ((state or {}).get("networks") or [])}
    for n in intent.networks:
        if not _is_protected_name(n.name, set(), SEEDED_SHARED_NETWORK_NAMES):
            continue
        cur = live_nets.get(_norm(n.name))
        if not cur:
            continue
        drift = []
        if _cidr_of(cur) != _norm_intent_cidr(n.cidr):
            drift.append(f"cidr {_cidr_of(cur)}\u2192{_norm_intent_cidr(n.cidr)}")
        if n.gateway and cur.get("ipv4gateway") and cur["ipv4gateway"] != n.gateway:
            drift.append(f"gateway {cur['ipv4gateway']}\u2192{n.gateway}")
        if drift:
            errors.append(
                f"network {n.name!r} uses an FS-seeded shared name but redefines it "
                f"({'; '.join(drift)}) -- the intent would mutate infrastructure "
                f"other fabrics reference; rename it or match the seeded values")

    if not state:
        return errors

    # -- 2b. A declared network duplicates a DIFFERENT live network's subnet --
    # The common real-world shape, and the one that bit fortiaigate_lab: the
    # intent hand-declares `Internet Access` on 203.0.113.0/24 while the pod has
    # already seeded `Internet` on the same subnet. Both exist, both name the
    # same gateway, and nothing downstream can say which one a port belongs to.
    declared_net_names = {_norm(x.name) for x in intent.networks}
    protected_net_names = {_norm(x.name) for x in intent.networks if x.protected}

    def _survives(live: dict[str, Any]) -> bool:
        """Will this live network still exist after the run? A --prune removes
        undeclared, unprotected nets -- and flagging a duplicate that the same
        run is about to delete would block the very apply that cleans it up."""
        if not prune:
            return True
        if _norm(live.get("name")) in declared_net_names:
            return True
        return _is_protected_name(live.get("name"), protected_net_names,
                                  SEEDED_SHARED_NETWORK_NAMES)

    for n in intent.networks:
        want = _norm_intent_cidr(n.cidr)
        clash = [
            live.get("name") for live in (state.get("networks") or [])
            if _cidr_of(live) == want and _norm(live.get("name")) != _norm(n.name)
            and _survives(live)
        ]
        if clash:
            errors.append(
                f"network {n.name!r} ({want}) duplicates the subnet of existing "
                f"network(s) {', '.join(repr(x) for x in sorted(clash))} on this pod "
                f"-- reference the existing network by name instead of declaring a "
                f"second one on the same subnet")

    # -- 2c. Routers this run's --prune will delete ---------------------------
    # The same self-unblocking rule as `_survives` (nets, check 2b) and the
    # `doomed` VM ports (check 3): an undeclared, unprotected router is quoted
    # as a gateway claimant (check 3) and as a black hole (check 4) from LIVE
    # state -- and left live, both errors are true. But under `prune=True` the
    # same run deletes the router, so keeping the error blocks the ONLY run
    # that cleans it up and strands the fabric behind --force-lint. Without
    # prune the router survives and keeps erroring, which is the correct
    # loud path. Protected/declared routers always count.
    doomed_routers: set[str] = set()
    if prune:
        declared_routers = {_norm(r.name) for r in intent.routers}
        protected_routers = {_norm(r.name) for r in intent.routers if r.protected}
        doomed_routers = {
            _norm(r.get("name") or "") for r in (state.get("routers") or [])
            if _norm(r.get("name") or "") not in declared_routers
            and not _is_protected_name(r.get("name"), protected_routers)
        }

    # -- 3. Gateway address owned by more than one device --------------------
    # The incident. Build IP -> owners across System Host ports, router ports and
    # static VM ports, then flag any gateway with more than one claimant.
    owners: dict[str, list[str]] = {}
    for hp in ((state.get("host") or {}).get("ports") or []):
        if isinstance(hp, dict) and hp.get("ipv4addr"):
            owners.setdefault(hp["ipv4addr"], []).append(
                f"System Host.{hp.get('name')}")
    for r in (state.get("routers") or []):
        if _norm(r.get("name") or "") in doomed_routers:
            continue          # this run's --prune deletes it (check 2c)
        for rp in (r.get("ports") or []):
            if rp.get("ipv4addr"):
                owners.setdefault(rp["ipv4addr"], []).append(
                    f"router {r.get('name')}.{rp.get('name')}")
    nd_by_name = {nd.name: nd for nd in intent.nodes}
    for v in (state.get("vms") or []):
        # Ports apply is about to clear do not count as claimants -- they are the
        # leftovers of a port renumber, and counting them makes this lint BLOCK
        # the very apply that repairs them (the intent declares one owner; the
        # model still lists two until apply runs).
        nd = nd_by_name.get(v.get("name"))
        doomed = set()
        if nd is not None:
            vports = {p.get("name"): p for p in (v.get("ports") or [])}
            doomed = {n for n, _ in _stale_overlapping_ports(nd, vports)}
        for vp in (v.get("ports") or []):
            if vp.get("name") in doomed:
                continue
            if vp.get("ipv4addr") and vp.get("addrmode", "STA") == "STA":
                owners.setdefault(vp["ipv4addr"], []).append(
                    f"{v.get('name')}.{vp.get('name')}")
    gateways = {n.get("ipv4gateway") for n in (state.get("networks") or [])
                if n.get("ipv4gateway")}
    for n in intent.networks:
        if n.gateway:
            gateways.add(n.gateway)
    for gw in sorted(g for g in gateways if g):
        who = owners.get(gw) or []
        if len(who) > 1:
            errors.append(
                f"gateway {gw} is claimed by {len(who)} devices ({', '.join(sorted(who))}) "
                f"-- they contend for ARP on the same segment and traffic follows "
                f"whichever answers; exactly one device may own a gateway address")

    # -- 4. A router that is a black hole ------------------------------------
    # Cabled on one leg, carrying an address, but with no other cabled port and
    # no default route: anything that ARPs it disappears.
    for r in (state.get("routers") or []):
        if _norm(r.get("name") or "") in doomed_routers:
            continue          # this run's --prune deletes it (check 2c)
        ports = r.get("ports") or []
        cabled = [p for p in ports if p.get("cable")]
        addressed = [p for p in cabled if p.get("ipv4addr")]
        if addressed and len(cabled) < 2 and not r.get("ipv4gateway"):
            legs = ", ".join(f"{p.get('name')}={p.get('ipv4addr')}" for p in addressed)
            errors.append(
                f"router {r.get('name')!r} is a black hole: {legs} is cabled but the "
                f"router has no second cabled port and no default route, so traffic "
                f"routed to it is dropped -- cable its upstream, give it a gateway, "
                f"or remove it from the segment")

    return errors


def _floating_switch_warnings(intent: Intent,
                              live_switches: list[dict[str, Any]]) -> list[str]:
    """Warn about switches that carry nodes but are NOT host-uplinked.

    A switch is routable only if a System Host port is cabled to it (FS seeds
    "OOB Mgmt" and "Internet Access" that way). The framework can't mint new
    uplinks -- the host has a fixed port set -- so a switch the intent *creates*,
    or an existing non-uplinked switch, is a *floating segment*: VMs get an IP
    but no route off it. That's the matrix bug; surfacing it keeps a topology
    from looking converged while being unreachable. ``live_switches`` is the
    ``read_fabric_state`` switch list (each carrying derived ``host_uplinked``);
    pass ``[]`` when the fabric doesn't exist yet. A switch the intent declares
    with ``host_uplink: true`` counts as uplinked: apply cables it
    (``_ensure_host_uplink``) and fails loudly if the host has no free port."""
    uplinked = {s["name"] for s in live_switches if s.get("host_uplinked")}
    uplinked |= {s.name for s in intent.switches if s.host_uplink}
    carrying = {lk.switch for nd in intent.nodes for lk in nd.links}
    # Name the switches that ARE host-uplinked on this fabric so the hint points
    # at a real fix rather than a hardcoded name (a seeded switch like "Internet
    # Access" can itself be floating -- see fs_internet_access_switch_floating).
    uplinked_list = sorted(uplinked)
    if uplinked_list:
        hint = "cable to a host-uplinked switch (" + ", ".join(repr(n) for n in uplinked_list) + ")"
    else:
        hint = ("no switch on this fabric is host-uplinked -- run "
                "`fs_topology state` and check `host_uplinked`")
    warnings: list[str] = []
    for name in sorted(carrying):
        if name in uplinked:
            continue
        warnings.append(
            f"switch {name!r} carries nodes but is not host-uplinked "
            f"(floating segment -- IPs assigned but no route off it); {hint}")
    return warnings


def _dhcp_switches_without_service(intent: Intent,
                                   state: dict[str, Any]) -> list[str]:
    """Switches carrying a ``dhcp:`` link whose System Host port does NOT have
    the DHCP server switched on (``dhcp_service`` false).

    A ``dhcp:`` link is modelled in two halves, and only one of them is ours: the
    reconciler writes the reservation (``dhcp_server`` + an in-subnet address on
    the guest's port), but the server that answers the DISCOVER is a *host port*
    property FS seeds per fabric. Live-read across a pod's fabrics,
    ``dhcp_service`` is true only on the FS-seeded OOB Mgmt uplink -- so a
    reservation on any other segment is written perfectly, installs cleanly, and
    is never served. The guest boots, DISCOVERs into silence, and comes up with
    no address at all, which presents as a dead VM rather than as a missing
    DHCP server. Nothing else in the model contradicts it, so neither `plan` nor
    the fabric diff can see the problem.

    Returns one message per affected switch. Switches with no System Host port at
    all are skipped -- those are floating segments and
    ``_floating_switch_warnings`` already names them, with a better fix."""
    switches = state.get("switches") or []
    # switch port id → switch name, to resolve which switch a host port cables to
    sw_name_by_port: dict[Any, str] = {}
    for s in switches:
        for p in s.get("ports") or []:
            sw_name_by_port[p.get("id")] = s.get("name")
    # switch name → the System Host ports cabled onto it
    host_ports_by_switch: dict[str, list[dict[str, Any]]] = {}
    for hp in (state.get("host") or {}).get("ports") or []:
        nm = sw_name_by_port.get(hp.get("peer"))
        if nm is not None:
            host_ports_by_switch.setdefault(nm, []).append(hp)

    # switch → a node.port that asked for DHCP there, for a concrete message
    wants: dict[str, str] = {}
    for nd in intent.nodes:
        for lk in nd.links:
            if lk.dhcp:
                wants.setdefault(lk.switch, f"{nd.name}.{lk.port}")

    out: list[str] = []
    for sw_name in sorted(wants):
        hps = host_ports_by_switch.get(sw_name)
        if not hps:
            continue  # floating segment -- covered by _floating_switch_warnings
        if any(hp.get("dhcp_service") for hp in hps):
            continue
        names = ", ".join(str(hp.get("name")) for hp in hps)
        out.append(
            f"switch {sw_name!r} carries a dhcp: link ({wants[sw_name]}) but the "
            f"System Host port(s) cabled to it ({names}) have dhcp_service=false "
            f"-- the reservation is written but nothing answers the DISCOVER, so "
            f"the guest boots with NO address (looks like a dead VM, not a missing "
            f"lease). Enable the DHCP server on that host port, or move the link "
            f"to a switch whose host port already serves DHCP")
    return out


def _image_addressing_violations(intent: Intent) -> list[str]:
    """Nodes whose links contradict their image's declared ``addressing``.

    An image that says ``addressing: dhcp`` carries only a DHCP client -- it does
    NOT self-apply the address Fabric Studio writes onto the port. Give such a
    guest a static link and it boots fine, brings its NIC up, and never gets an
    address: no ARP, no services, no port forward. Every symptom points at the
    network, and the model looks perfect, so this is expensive to diagnose from
    the outside (measured: a Server 2022 golden on a static port, against a Win10
    golden on the same switch that self-configured happily).

    Purely declarative -- an image with no ``addressing`` constrains nothing."""
    by_image = {im.name: im for im in intent.images}
    out: list[str] = []
    for nd in intent.nodes:
        im = by_image.get(nd.image or "")
        if im is None or (im.addressing or "").lower() != "dhcp":
            continue
        for lk in nd.links:
            if lk.dhcp:
                continue
            how = f"a static ip: ({lk.ip})" if lk.ip else "no dhcp: and no ip:"
            out.append(
                f"node {nd.name!r} uses image {im.name!r}, which declares "
                f"addressing: dhcp, but link {nd.name}.{lk.port} has {how}. That "
                f"image does not self-apply a Fabric Studio static address, so the "
                f"guest would boot with NO address at all -- link up, nothing "
                f"answering, which looks like a dead VM. Use "
                f"`dhcp: System Host` on this link")
    return out


def _hugepage_shortfall(c: FabricStudioClient, intent: Intent,
                        node_names: Iterable[str],
                        vm_id: dict[str, Any]) -> str | None:
    """Message describing a hugepage shortfall for the nodes about to be installed,
    or None when they fit.

    Hugepages are a FIXED preallocated pool, not ordinary RAM, and FS defaults
    ``model.vmparameters.hugepages`` to true. A guest that wants more pages than
    the pool has free does not fail in the model, in the plan, or in the fabric
    diff -- it installs cleanly and then dies at power-on with ``unable to map
    backing store for guest RAM: Cannot allocate memory``, leaving a VM that
    ``runtime device status`` still calls "Running". Nothing downstream of that
    reads as a memory problem, which is what makes it expensive: the symptom is a
    guest with no address, and every obvious explanation is a network one.

    Counts only the guests THIS apply is about to (re)install -- pages already
    held by running VMs are excluded from ``free`` by the pod itself, so adding
    them would double-count."""
    try:
        free = fa.hugepages_free(c)
    except Exception:
        return None  # older pod without the endpoint -- don't block the apply
    by_name = {nd.name: nd for nd in intent.nodes}
    want: list[tuple[str, int, int]] = []
    total = 0
    for name in node_names:
        nd = by_name.get(name)
        if nd is None or str(vm_id.get(name) or "") == "":
            continue
        # Only nodes whose backing is hugepages: declared true, or left to FS's
        # default (true) -- an explicit false maps from ordinary RAM and is free.
        if nd.hugepages is False:
            continue
        try:
            par = fa.get_vm_parameters(c, vm_id[name])
        except Exception:
            continue
        if nd.hugepages is None and not par.get("hugepages"):
            continue
        mem = int(par.get("memory") or 0)
        if mem <= 0:
            continue
        pages = -(-mem // fa.HUGEPAGE_SIZE_MIB)  # ceil
        want.append((name, mem, pages))
        total += pages
    if not want or total <= free:
        return None
    detail = ", ".join(f"{n} ({m} MiB → {p} pages)" for n, m, p in want)
    return (f"hugepage pool exhausted: {detail} need {total} page(s) of "
            f"{fa.HUGEPAGE_SIZE_MIB} MiB but only {free} are free "
            f"(pod total {fa.hugepages_available(c)}). These guests would install "
            f"cleanly and then FAIL AT POWER-ON with 'unable to map backing store "
            f"for guest RAM', while `runtime device status` still reports Running. "
            f"Set `hugepages: false` on the node(s) that don't need pool-backed RAM "
            f"-- the pod's ordinary memory is unaffected -- or reduce `memory:`")


def _norm_cidr(network: str, netmask: str) -> str:
    """Normalize (network, netmask-in-either-notation) to prefix form
    ``a.b.c.0/24`` so a live row's quad-dotted mask compares equal to an
    intent's ``/24``."""
    try:
        return str(ipaddress.IPv4Network(f"{network}/{netmask}", strict=False))
    except (ipaddress.AddressValueError, ipaddress.NetmaskValueError, ValueError):
        return f"{network}/{netmask}"


def _cidr_of(net_row: dict[str, Any]) -> str:
    return _norm_cidr(net_row.get("ipv4network", ""), net_row.get("ipv4netmask", ""))


def _norm_intent_cidr(cidr: str) -> str:
    try:
        return str(ipaddress.IPv4Network(cidr, strict=False))
    except (ipaddress.AddressValueError, ipaddress.NetmaskValueError, ValueError):
        return cidr


def plan(c: FabricStudioClient, intent: Intent, prune: bool = False) -> Plan:
    """Diff the intent against live state -- pure read, no mutation. Mirrors the
    apply ordering so the printed plan reads top-to-bottom in dependency order."""
    p = Plan(fabric=intent.fabric)
    from fabric_studio.topology import images  # lazy: avoids a circular import at module load
    p.changes.extend(images.plan_images(c, intent))
    declared_images = {im.name for im in intent.images}
    fab = fa.get_fabric_by_name(c, intent.fabric)
    if not fab:
        p.changes.append(Change("create", "fabric", intent.fabric))
        # Nothing exists yet -- everything below is a create.
        for n in intent.networks:
            p.changes.append(Change("create", "network", n.name, n.cidr))
        for s in intent.switches:
            p.changes.append(Change("create", "switch", s.name,
                                    f"auto_address={s.auto_address}"))
        for nd in intent.nodes:
            p.changes.append(Change("create", "node", nd.name, nd.type))
            for lk in nd.links:
                p.changes.append(Change("create", "link", f"{nd.name}.{lk.port}→{lk.switch}"))
        p.changes.append(Change("create", "boot", intent.fabric, "install_fabric + wait booted"))
        p.warnings = _floating_switch_warnings(intent, [])
        p.warnings.extend(_image_addressing_violations(intent))
        p.errors.extend(_lint_topology(intent, None))
        return p

    p.changes.append(Change("noop", "fabric", intent.fabric))
    st = fa.read_fabric_state(c, fab["id"])
    nets_by_name = {n["name"]: n for n in st["networks"]}
    sws_by_name = {s["name"]: s for s in st["switches"]}
    vms_by_name = {v["name"]: v for v in st["vms"]}

    # Networks
    desired_net_names = set()
    for n in intent.networks:
        desired_net_names.add(n.name)
        cur = nets_by_name.get(n.name)
        if not cur:
            p.changes.append(Change("create", "network", n.name, n.cidr))
        elif (_cidr_of(cur) != _norm_intent_cidr(n.cidr)
              or (n.gateway and cur.get("ipv4gateway") != n.gateway)
              or (n.dns1 is not None and (cur.get("ipv4dns1") or "") != (n.dns1 or ""))
              or (n.dns2 is not None and (cur.get("ipv4dns2") or "") != (n.dns2 or ""))):
            p.changes.append(Change("update", "network", n.name,
                                    f"{_cidr_of(cur)}→{_norm_intent_cidr(n.cidr)}"))
        else:
            p.changes.append(Change("noop", "network", n.name))
    if prune:
        _pn = {re.sub(r"\s+", " ", x.name.strip().lower())
               for x in intent.networks if x.protected}
        for name in nets_by_name:
            # Mirror _prune's protection filter, or the plan promises deletions
            # apply will refuse -- which reads as "prune is broken" and, worse,
            # as "this run will remove shared infra" when it won't.
            if name not in desired_net_names and not _is_protected_name(
                    name, _pn, SEEDED_SHARED_NETWORK_NAMES):
                p.changes.append(Change("delete", "network", name))

    # Switches
    desired_sw_names = set()
    for s in intent.switches:
        desired_sw_names.add(s.name)
        cur = sws_by_name.get(s.name)
        want_aa = nets_by_name.get(s.auto_address, {}).get("id") if s.auto_address else None
        if not cur:
            p.changes.append(Change("create", "switch", s.name, f"auto_address={s.auto_address}"))
        elif str(cur.get("auto_address_network")) != str(want_aa) or bool(cur.get("mgmt")) != s.mgmt:
            p.changes.append(Change("update", "switch", s.name,
                                    f"rewire auto_address→{s.auto_address}"))
        else:
            p.changes.append(Change("noop", "switch", s.name))
    if prune:
        _ps = {re.sub(r"\s+", " ", x.name.strip().lower())
               for x in intent.switches if x.protected}
        for name in sws_by_name:
            # Same protection filter _prune applies -- see the network preview.
            if name not in desired_sw_names and not _is_protected_name(
                    name, _ps, SEEDED_SHARED_SWITCH_NAMES):
                p.changes.append(Change("delete", "switch", name))

    # Switchport VLANs. Drift here is invisible to every other check -- the
    # runtime row and the GUI both render whatever is stored -- so without this
    # a narrowed trunk or a retagged access port reports "no changes" and apply
    # short-circuits before it can repair anything.
    p.changes.extend(_plan_switchport_vlans(intent, st))

    # Nodes (VMs) + links
    desired_node_names = set()
    # Resolve current links per (vm_name, port_name) → switch_id for diffing.
    cur_link_switch: dict[tuple[Any, str], Any] = {}
    for lk in st["links"]:
        cur_link_switch[(lk["vm_id"], lk["vm_port_name"])] = lk["switch_id"]
    # Resolve already-present declared images by uploaded filename so a node's
    # image: maps to a firmware id (uploaded LXC rows have empty names) and
    # firmware drift after a re-upload is detected -- read-only, no build/upload.
    present_image_ids = images.resolve_image_ids(c, intent)
    for nd in intent.nodes:
        desired_node_names.add(nd.name)
        cur = vms_by_name.get(nd.name)
        want_fw = _resolve_firmware_id(c, nd, image_ids=present_image_ids,
                                       declared_images=declared_images)
        if not cur:
            p.changes.append(Change("create", "node", nd.name, nd.type))
        elif want_fw is not None and str(cur.get("firmware")) != str(want_fw):
            p.changes.append(Change("update", "node", nd.name, f"firmware→{want_fw}",
                                    reinstall=True))
        else:
            p.changes.append(Change("noop", "node", nd.name))
        # Resource drift (cpu/memory/disks/access/params) on an existing VM. Only query
        # FS for these when the intent declares them -- keeps plan cheap otherwise.
        if cur and (nd.cpu is not None or nd.memory is not None or nd.disks
                    or nd.access or nd.provision_config or nd.params or nd.license):
            _plan_node_resources(c, p, nd, cur, fab["id"])
        for lk in nd.links:
            want_sw_id = sws_by_name.get(lk.switch, {}).get("id")
            cur_sw = cur_link_switch.get((cur.get("id") if cur else None, lk.port))
            if cur_sw is None or str(cur_sw) != str(want_sw_id):
                # Recabling an EXISTING vm is model-only until it reinstalls;
                # a brand-new node installs once anyway, so don't cry reinstall.
                p.changes.append(Change("create", "link",
                                        f"{nd.name}.{lk.port}→{lk.switch}",
                                        reinstall=cur is not None))
            else:
                p.changes.append(Change("noop", "link", f"{nd.name}.{lk.port}→{lk.switch}"))
        # Apply clears an undeclared port whose address overlaps a declared one
        # -- left alone it fails the install inside the guest. Report it so a
        # renumber's blast radius is visible. Same predicate apply uses, so the
        # two cannot drift; read off the state snapshot, no extra FS calls.
        if cur:
            cur_ports = {p2.get("name"): p2 for p2 in (cur.get("ports") or [])}
            for pname, vp in _stale_overlapping_ports(nd, cur_ports):
                p.changes.append(Change("update", "link", f"{nd.name}.{pname}",
                                        f"clear {vp['ipv4addr']} (undeclared port "
                                        f"overlapping a declared subnet)",
                                        reinstall=True))
    if prune:
        for name in vms_by_name:
            if name not in desired_node_names:
                p.changes.append(Change("delete", "node", name))

    # A changed static-DHCP reservation reinstalls its guest at bring-up. Predict
    # it here with the same predicate apply uses, so a plan can never under-report
    # a destroy.
    _plan_dhcp_reservations(c, p, intent, fab["id"], nets_by_name, vms_by_name)

    # Bring-up: install if no runtime, recover nodes whose runtime is gone, else
    # synchronize touched VMs. plan() must be runtime-aware here: a node with a
    # model row but NO runtime row (a crashed / out-of-band-destroyed / half-
    # installed VM) is invisible to the model-graph diff above. Without surfacing
    # it as a change, the CLI short-circuits on "no changes" and never re-installs
    # it, so a plain `apply` can't self-heal runtime drift -- you'd need `--force`
    # (proven live, Pod B gate-recovery 2026-06-12). Emitting a per-node "boot"
    # change makes the plan mutating, so apply's per-VM bring-up
    # (the ``str(vid) not in rt_ids`` install_vm branch) runs and recovers it.
    runtime = fa.runtime_vms(c, fab["id"])
    rt_ids = {str(v.get("id")) for v in runtime}
    recover = [nd.name for nd in intent.nodes
               if (cur := vms_by_name.get(nd.name)) is not None
               and str(cur.get("id")) not in rt_ids]
    infra_touched = any(
        ch.op in ("create", "update")
        and ch.kind in ("node", "link", "switch", "network")
        for ch in p.changes)
    # The System Host (native DHCP server) can carry a STANDING model→runtime diff
    # with no node change -- e.g. an orphan reservation left after a VM is deleted
    # out-of-band. FS surfaces it as "sync wanted" on the host; left alone it
    # invites a GUI sync that tears down every VM's port forward. Surface it as a
    # boot change so `apply` heals it (System Host first, then rebuild forwards)
    # instead of short-circuiting on "no changes".
    host_dhcp_pending = bool(runtime) and bool(fa.devices_needing_dhcp_install(c, fab["id"]))
    if not runtime:
        p.changes.append(Change("create", "boot", intent.fabric, "install_fabric + wait booted"))
    else:
        for name in recover:
            p.changes.append(Change("create", "boot", name, "install_vm (no runtime -- recover)"))
        if infra_touched:
            p.changes.append(Change("update", "boot", intent.fabric, "synchronize devices"))
        elif not recover and not host_dhcp_pending:
            p.changes.append(Change("noop", "boot", intent.fabric))
        # NOT an elif on infra_touched. It was, and that is exactly how a
        # fabric-wide consequence went unannounced: adding one node with
        # `dhcp: System Host` sets BOTH flags, `infra_touched` won the chain,
        # and the plan said nothing louder than "synchronize devices" while
        # apply went on to install the System Host and rebuild every forward.
        # The operator approved an additive-looking plan and got a host install.
        #
        # A plan that under-reports destruction is worse than one that
        # over-reports it: `_prune`'s preview already carries the mirror-image
        # rule ("or the plan promises deletions apply will refuse"). Same bug
        # class, and this is the dangerous direction.
        if host_dhcp_pending:
            p.changes.append(Change("update", "boot", intent.fabric,
                                    "install System Host (DHCP table diff) -- this DROPS "
                                    "every VM's external port forward; they are rebuilt by "
                                    "synchronizing the host (guests NOT reinstalled, unless "
                                    "--full-redeploy is passed)"))

    # Routers -- undeclared ones are drift the intent cannot reproduce.
    declared_rt = {re.sub(r"\s+", " ", r.name.strip().lower()) for r in intent.routers}
    for r in (st.get("routers") or []):
        nm = r.get("name") or ""
        if re.sub(r"\s+", " ", nm.strip().lower()) in declared_rt:
            p.changes.append(Change("noop", "router", nm))
        elif prune:
            p.changes.append(Change("delete", "router", nm, "not declared in intent"))
        else:
            p.warnings.append(
                f"router {nm!r} exists in this fabric but is not declared in the "
                f"intent -- it is invisible to apply and can hold a gateway "
                f"address; declare it under `routers:` or re-run with --prune")

    # extend, not assign: the router drift block above already appended.
    p.warnings.extend(_floating_switch_warnings(intent, st["switches"]))
    p.warnings.extend(_dhcp_switches_without_service(intent, st))
    p.warnings.extend(_image_addressing_violations(intent))
    p.errors.extend(_lint_topology(intent, st, prune=prune))
    return p


def _dhcp_field(v: Any) -> str | None:
    """Normalise one vmport field for comparison.

    FS returns ``dhcp_server``/``network`` as plain ints on a vmport but they are
    written as ints OR strings depending on the caller, and a related_fields read
    can hand back an embedded object instead of an id. Comparing raw would report
    ``223 != "223"`` as a change, which is the failure mode this whole predicate
    exists to prevent -- so everything is flattened to a string first."""
    if v is None:
        return None
    if isinstance(v, dict):
        v = v.get("id", v)
    return str(v).strip()


def dhcp_reservation_differs(vp: dict[str, Any], *, addr: str | None,
                             mask: str | None, srv: int | None,
                             net: int | None) -> bool:
    """Does this port ALREADY hold exactly the static-DHCP reservation we want?

    THE BUG THIS EXISTS TO KILL. Adding one node to a fabric gives it a new DHCP
    reservation, which leaves the System Host with a model→runtime diff, which
    makes ``devices_needing_dhcp_install`` fire. The bring-up loop then reinstalled
    **every guest that DHCPs off that host** -- on the theory that a guest which
    booted before its lease existed never acquired an address. True for the NEW
    node; false for every node whose reservation did not move, and those are
    destroyed and rebuilt from their golden image for nothing.

    On a topology where every guest DHCPs off the System Host that means adding a
    single node wipes the entire fabric: a promoted domain controller loses AD DS,
    the forest and its seeded users; Fleet loses its enroll secret and every
    enrolled agent with it. The identical mistake was already made once through
    the port-redirect path (see the comment on ``redirect_host_dev`` in
    ``apply``), and this is the same lesson arriving through the DHCP door.

    ``plan`` and ``apply`` both call this, so they cannot disagree about who gets
    reinstalled -- which was the second half of the defect: ``plan`` reported zero
    reinstalls while ``apply`` rebuilt five guests.

    A field we are not setting (``None``) cannot be a change, so it is skipped
    rather than compared against the port's current value."""
    want: dict[str, Any] = {"addrmode": "DHCP", "ipv4addr": addr,
                            "ipv4netmask": mask, "dhcp_server": srv,
                            "network": net}
    return any(_dhcp_field(vp.get(k)) != _dhcp_field(v)
               for k, v in want.items() if v is not None)


def _plan_dhcp_reservations(c: FabricStudioClient, p: Plan, intent: Intent,
                            fid: Any, nets_by_name: dict[str, Any],
                            vms_by_name: dict[str, Any]) -> None:
    """Predict the guest reinstalls that a CHANGED static-DHCP reservation causes.

    apply writes a DHCP port only when its reservation moves, and a port whose
    reservation moved is reinstalled so the guest boots into the new lease. This
    is the plan half of that, calling the SAME predicate
    (:func:`dhcp_reservation_differs`) so the two cannot drift -- the divergence
    that made this necessary was plan reporting zero reinstalls while apply
    rebuilt five guests.

    Plan does not need to know WHICH address a reallocation would pick, only THAT
    one is coming, so the allocator is not duplicated here:

    * ``lk.ip`` set        -- apply uses it verbatim; compare it directly.
    * ``lk.ip`` unset      -- apply KEEPS the port's current address when it is
      already a usable host in the link's subnet, so an in-subnet port is not a
      change. An out-of-subnet one (the FS default OOB address on a fresh port)
      always gets reallocated, so it always is.

    Ports are read per node, and only for nodes that both exist and declare a
    DHCP link -- a plan on a fabric with no DHCP makes no extra calls at all."""
    dhcp_nodes = [nd for nd in intent.nodes
                  if vms_by_name.get(nd.name) and any(lk.dhcp for lk in nd.links)]
    if not dhcp_nodes:
        return
    try:
        srv = fa.get_system_host(c, fid)["id"]
    except Exception:
        return  # no System Host to lease from; apply will raise with a better message
    sw_aa = {sw.name: sw.auto_address for sw in intent.switches}
    net_by_name = {n.name: n for n in intent.networks}

    for nd in dhcp_nodes:
        cur = vms_by_name[nd.name]
        try:
            ports = {pt.get("name"): pt for pt in fa.get_vm_ports(c, fid, cur["id"])}
        except Exception:
            continue
        for lk in nd.links:
            if not lk.dhcp:
                continue
            vp = ports.get(lk.port)
            if vp is None:
                continue          # the port itself is missing; the link diff owns that
            net = nets_by_name.get(sw_aa.get(lk.switch), {}).get("id")
            addr = lk.ip
            if addr is None:
                # No declared address: apply keeps whatever is there IF it is a
                # usable host in the subnet. Anything else is a reallocation.
                ns = net_by_name.get(sw_aa.get(lk.switch))
                curaddr = vp.get("ipv4addr")
                keeps = False
                if ns and curaddr:
                    try:
                        keeps = (ipaddress.IPv4Address(str(curaddr))
                                 in ipaddress.IPv4Network(ns.cidr, strict=False))
                    except ValueError:
                        keeps = False
                if keeps:
                    addr = curaddr          # compares equal -- not a change
                else:
                    p.changes.append(Change(
                        "update", "node", nd.name,
                        f"{lk.port} dhcp reservation (address {curaddr or 'unset'} "
                        f"is not a host in {ns.cidr if ns else 'the link subnet'})",
                        reinstall=True))
                    continue
            if dhcp_reservation_differs(vp, addr=addr, mask=lk.netmask,
                                        srv=srv, net=net):
                p.changes.append(Change(
                    "update", "node", nd.name,
                    f"{lk.port} dhcp reservation\u2192{addr}", reinstall=True))


def _resolve_firmware_id(c: FabricStudioClient, nd: NodeSpec,
                         image_ids: dict[str, int] | None = None,
                         declared_images: set[str] | None = None) -> int | None:
    """A node's target firmware id. Schema v2 unifies ``firmware:`` and
    ``image:`` into a single ``image:`` field that resolves in order:

    1. **logical ``images[]`` name** -- via the images-phase map (``image_ids``)
    2. **home-repo id** -- a literal numeric id (int or all-digit string)
    3. **home-repo name / filename / version string** -- e.g. ``"9.7"`` → latest
       9.7.x, scoped to the node's vm_type

    Returns None when nothing is declared, or when ``image`` names a *declared*
    image not yet uploaded (plan-time -- the images phase will create it on
    apply). Raises only for an ``image:`` that is neither declared nor present,
    or for a pinned firmware that resolves to a 0-byte stub (install would fail
    with rc 254).

    ``nd.firmware`` (deprecated v1 field) is honored if set -- tests construct
    NodeSpec directly -- but ``parse_intent`` no longer populates it."""
    # v1 compat: an explicit firmware field still wins (tests / direct construction).
    if nd.firmware is not None:
        if isinstance(nd.firmware, int) or (
                isinstance(nd.firmware, str) and nd.firmware.strip().isdigit()):
            return int(nd.firmware)
        return _resolve_firmware_ref(c, nd, str(nd.firmware))
    if nd.image:
        # 1. logical images[] name → images-phase map
        if image_ids and nd.image in image_ids:
            return int(image_ids[nd.image])
        # 2. literal numeric id (home-repo firmware id as a string/int)
        if isinstance(nd.image, int) or (
                isinstance(nd.image, str) and nd.image.strip().isdigit()):
            fid = int(nd.image)
            _warn_if_stub(c, fid, nd.name, str(nd.image))
            return fid
        # 3. home-repo name / filename / version string (then the pod's other repos)
        import os as _os
        for tier in (lambda: fa.list_home_firmwares(c), lambda: _remote_firmwares(c, nd.type)):
            for f in tier():
                if f.get("name") == nd.image or _os.path.basename(f.get("path") or "") == nd.image:
                    fid = int(f["id"])
                    _warn_if_stub(c, fid, nd.name, str(nd.image))
                    return fid
        # version-string form ("9.7", "7.6.6") → resolve scoped to vm_type
        want = _parse_version_ref(str(nd.image))
        if want is not None:
            try:
                fid = _resolve_firmware_ref(c, nd, str(nd.image))
                _warn_if_stub(c, fid, nd.name, str(nd.image))
                return fid
            except fa.FabricStudioAdminError:
                pass  # fall through to declared-images check
        if declared_images and nd.image in declared_images:
            return None    # declared but not uploaded yet -- resolved on apply
        have = ", ".join(sorted({_firmware_ref_display(f) for f in
                                 list(fa.list_home_firmwares(c, nd.type or None)) + _remote_firmwares(c, nd.type)})) or "none"
        raise fa.FabricStudioAdminError(
            f"node {nd.name!r}: image {nd.image!r} not found in home repository or the pod's other repos "
            f"for {nd.type or 'any'} (have: {have})")
    # No image declared → auto-select the latest usable image for the node's
    # vm_type: prefer one already in the home repo, else the latest the pod
    # can deploy (a ``ready`` repo image, else a ``remote`` one FS downloads at
    # install). Skips 0-byte stubs.
    return _auto_select_firmware(c, nd.type)


def _warn_if_stub(c: FabricStudioClient, fid: int, node_name: str,
                  image_ref: str) -> None:
    """Raise if a resolved firmware id points at a 0-byte stub. A stub fails at
    install with rc 254 (\"firmware image is invalid\"); catching it at plan time
    names the problem rather than letting it surface three layers deep in an
    install task."""
    for f in fa.list_home_firmwares(c):
        if int(f.get("id") or 0) == fid:
            if int(f.get("size") or 0) == 0:
                raise fa.FabricStudioAdminError(
                    f"node {node_name!r}: image {image_ref!r} (id={fid}) is a "
                    f"0-byte stub -- install would fail with rc 254. The firmware "
                    f"was never uploaded or the upload was interrupted. Re-upload "
                    f"or pin a different image.")
            return


import re as _re

# Parse a Fortinet firmware filename's version + build for "latest" ordering,
# e.g. ``FGT_VM64_KVM-v7.6.6.M-build3652-FORTINET.out.kvm.zip`` → (7, 6, 6, 3652).
_FW_VER_RE = _re.compile(r"v(\d+)\.(\d+)\.(\d+).*?build(\d+)", _re.IGNORECASE)


def _firmware_sort_key(fw: dict[str, Any]) -> tuple:
    """Sort key for "latest" firmware: GA over Beta, then version, then build.
    Version comes from :func:`_fw_version_tuple` (robust to FS's bogus ``patch``
    field on SOAR rows, which would otherwise tie every SOAR image at zero and
    make ``max`` pick an arbitrary one). A row with no parseable version sorts
    lowest; a Beta-named image sorts below any GA."""
    ver = _fw_version_tuple(fw) or (0, 0, 0, 0)
    name = str(fw.get("version_s") or fw.get("name") or fw.get("path") or "")
    is_ga = "beta" not in name.lower()
    return (is_ga, *ver)


def _auto_select_firmware(c: FabricStudioClient, vm_type: str) -> int | None:
    """Latest usable firmware id for ``vm_type``, or None if the pod has none.
    Per the rule "use what's in the home repo, else the latest available remote"
    (FS auto-downloads a ``remote`` image at install): prefer the latest usable
    **home**-repo image, else the latest across **all** repos. Skips 0-byte stubs;
    GA beats Beta, then highest version+build.

    Raises if two firmwares tie at the same sort key (e.g. two LXC images with
    no parseable version both sort to ``(True, 0, 0, 0, 0)``) -- ``max`` would pick
    an arbitrary one. Demand an explicit ``image:`` pin instead."""
    if not vm_type:
        return None
    fws = [f for f in fa.list_all_firmwares(c, vm_type) if not f.get("is_diff")]

    def _repo(f) -> str:
        r = f.get("repository")
        return (r.get("name") if isinstance(r, dict) else r) or ""

    usable = [f for f in fws if int(f.get("size") or 0) > 0]      # drop 0-byte stubs
    home = [f for f in usable if _repo(f) == "home"]
    for tier in (home, usable):                                   # home wins; else latest remote
        if tier:
            best_key = _firmware_sort_key(max(tier, key=_firmware_sort_key))
            tied = [f for f in tier if _firmware_sort_key(f) == best_key]
            if len(tied) > 1:
                import os as _os
                filenames = [_os.path.basename(f.get("path") or "")
                             or f.get("name", "?") for f in tied]
                raise fa.FabricStudioAdminError(
                    f"cannot auto-select firmware for {vm_type!r}: {len(tied)} "
                    f"images tie at the same version ({', '.join(repr(n) for n in filenames)}). "
                    f"Pin one explicitly with `image:` on the node using its "
                    f"filename (e.g. image: {filenames[0]!r}) or a logical name "
                    f"from `images:`; avoid numeric IDs -- they change on pod rebuild.")
            return int(tied[0]["id"])
    return None


# A firmware *reference* version string: "9.7", "v9.7.2", "7.6.6-build3652".
# Trailing components are optional and act as a prefix match (any "9.7.*").
_FW_REF_RE = _re.compile(
    r"^v?(\d+)\.(\d+)(?:\.(\d+))?(?:[.\-]?(?:M\d*)?)?(?:.*?build(\d+))?$",
    _re.IGNORECASE)


def _parse_version_ref(ref: str) -> tuple[int, int, int | None, int | None] | None:
    m = _FW_REF_RE.match(ref.strip())
    if not m:
        return None
    major, minor, patch, build = m.groups()
    return (int(major), int(minor),
            int(patch) if patch is not None else None,
            int(build) if build is not None else None)


# Loose version scan inside a firmware name/version_s/path: matches ``7.6.6``,
# ``7-6-5`` (SOAR), and ``v9.7.2`` (FGT) alike. Used to recover the *real* patch
# when FS's ``patch`` field is unreliable -- see ``_fw_version_tuple``.
_FW_NAME_VER_RE = _re.compile(r"(\d+)[.\-](\d+)(?:[.\-](\d+))?")


def _fw_version_tuple(f: dict[str, Any]) -> tuple[int, int, int, int] | None:
    """A firmware row's (major, minor, patch, build).

    FS's home-repo rows carry ``major``/``minor``/``patch``/``build`` fields, but
    ``patch`` is unreliable: SOAR rows report ``patch: 1`` uniformly regardless of
    the real version (a 7.6.5 and a 7.6.6 image both report patch=1); the true
    version lives in ``version_s`` / the filename. So parse the version from the
    name string first (falling back to the fields only when the name has no
    parseable version), and take ``build`` from its own field (parsing it from the
    path only when the field is absent)."""
    name = str(f.get("version_s") or f.get("name") or f.get("path") or "")
    m = _FW_NAME_VER_RE.search(name)
    if m:
        patch = int(m.group(3)) if m.group(3) is not None else 0
        build = int(f.get("build") or 0)
        if not build:                                   # parse from path if no field
            bm = _FW_VER_RE.search(str(f.get("path") or ""))
            build = int(bm.group(4)) if bm else 0
        return (int(m.group(1)), int(m.group(2)), patch, build)
    if f.get("major") is not None:                      # fields-only fallback
        return (int(f["major"]), int(f.get("minor") or 0),
                int(f.get("patch") or 0), int(f.get("build") or 0))
    m = _FW_VER_RE.search(str(f.get("path") or ""))
    return tuple(int(g) for g in m.groups()) if m else None


def _version_matches(fw_ver: tuple | None,
                     want: tuple[int, int, int | None, int | None]) -> bool:
    """True when ``fw_ver`` matches the ``want`` prefix: major+minor always, plus
    patch and build only when the reference pinned them."""
    if fw_ver is None:
        return False
    wmaj, wmin, wpatch, wbuild = want
    if fw_ver[0] != wmaj or fw_ver[1] != wmin:
        return False
    if wpatch is not None and fw_ver[2] != wpatch:
        return False
    if wbuild is not None and fw_ver[3] != wbuild:
        return False
    return True


def _firmware_ref_display(f: dict[str, Any]) -> str:
    import os as _os
    return f.get("name") or _os.path.basename(str(f.get("path") or "")) or str(f.get("id"))


def _resolve_firmware_ref(c: FabricStudioClient, nd: NodeSpec, ref: str) -> int:
    """Resolve a name / filename / version-string firmware reference to a home-repo
    firmware id, scoped to the node's vm_type. Exact name/filename wins; else a
    version prefix ("9.7" → latest 9.7.x) picks the newest match by GA/version/build."""
    import os as _os
    home = fa.list_home_firmwares(c, nd.type or None)
    # The home repository wins; an image the pod would download on install (a usable remote one) is the fallback,
    # looked up only when the home repository has no match.
    for tier in (lambda: home, lambda: _remote_firmwares(c, nd.type)):
        fws = tier()
        for f in fws:                                             # exact name / filename
            if f.get("name") == ref or _os.path.basename(str(f.get("path") or "")) == ref:
                return int(f["id"])
        want = _parse_version_ref(ref)                            # version prefix
        if want is not None:
            matches = [f for f in fws if _version_matches(_fw_version_tuple(f), want)]
            if matches:
                # Newest by the robust version tuple (not ``_firmware_sort_key``,
                # which can't parse SOAR filenames and would tie them all at zero).
                return int(max(matches, key=lambda fw: _fw_version_tuple(fw) or (0, 0, 0, 0))["id"])
    have = ", ".join(sorted({_firmware_ref_display(f) for f in list(home) + _remote_firmwares(c, nd.type)})) or "none"
    raise fa.FabricStudioAdminError(
        f"node {nd.name!r}: firmware {ref!r} not found in home repo or the pod's other repos for "
        f"{nd.type or 'any'} (have: {have})")


def _remote_firmwares(c: FabricStudioClient, vm_type: str | None) -> list[dict[str, Any]]:
    """Usable firmware outside the home repository, which the pod downloads on first install."""
    if not vm_type:
        return []
    try:
        home_ids = {f.get("id") for f in fa.list_home_firmwares(c, vm_type)}
        return [f for f in fa.list_all_firmwares(c, vm_type)
                if f.get("id") not in home_ids and not f.get("is_diff") and int(f.get("size") or 0) > 0]
    except Exception:  # noqa: BLE001 - the fallback is best effort; the caller reports what the home repository has
        return []


# Per-vm-type known-good resource minimums. FS firmware ``.meta`` defaults are
# often BELOW what the appliance needs to actually run (e.g. FMG/FAZ ship with
# 1-2 vCPU / 2-4 GiB but won't come up healthy under that) -- a silent footgun: a
# minimally-declared node boots into a broken state. The reconciler FLOORS each
# node's cpu/memory to these so "use the working defaults if not mentioned"
# holds. An explicit intent value still wins, but is itself floored (you can size
# UP, never below a known-broken level). Disks are handled separately (firmware
# data disks are auto-extended to their declared size). Verified live 2026-06-11:
# FMG/FAZ need 4 vCPU / 8192 MiB.
VM_TYPE_MIN_RESOURCES: dict[str, dict[str, int]] = {
    "FMG": {"cpu": 4, "memory": 8192},
    "FAZ": {"cpu": 4, "memory": 8192},
    # Windows Setup itself is the floor here, not the running OS: the installer
    # unpacks into a RAM disk and a 2 GB guest either bluescreens or crawls
    # through an unattended install. 4 GB / 2 vCPU is the practical minimum for
    # both Server 2022 and Win11 (Win11 Setup also hard-requires >= 2 cores).
    "WINDOWS": {"cpu": 2, "memory": 4096},
}


def _effective_resource(spec_val: int | None, minimum: int | None, current: int) -> int | None:
    """Target value for a floored resource, or None to leave the firmware default.
    An explicit ``spec_val`` wins but is floored to ``minimum``; with no spec we
    only bump UP to ``minimum`` (never downsize below the firmware default)."""
    floor = minimum or 0
    if spec_val is not None:
        target = max(int(spec_val), floor)
        return target if target != current else None
    if floor and current < floor:
        return floor
    return None


def _gz_content_eq(a: bytes, b: bytes) -> bool:
    """Compare two byte strings for equal CONTENT, ignoring gzip mtime.

    .conf files are uploaded as gzip archives. The gzip header (RFC 1952)
    embeds an mtime in bytes 4-7 that changes whenever the file is touched,
    so a naive byte-equal fails even if the compressed payload is identical.
    Zero out the mtime field in both buffers before comparing."""
    if a == b:
        return True
    # Gzip magic: \x1f\x8b, CM=\x08, flags byte, then 4-byte mtime at offset 4.
    if (len(a) >= 10 and len(b) >= 10
            and a[:3] == b"\x1f\x8b\x08" and b[:3] == b"\x1f\x8b\x08"):
        a = a[:4] + b"\x00\x00\x00\x00" + a[8:]
        b = b[:4] + b"\x00\x00\x00\x00" + b[8:]
        return a == b
    return False


def _plan_node_resources(c: FabricStudioClient, p: Plan, nd: NodeSpec,
                         cur: dict[str, Any], fid: int | str) -> None:
    """Append cpu/memory/disk/access drift Changes for an existing VM. Mirrors
    what ``_apply_node_resources`` will do, so plan and apply agree.

    Fields in nd.ignore_changes are skipped -- no Change objects emitted for them."""
    vid = cur["id"]
    ignored = set(nd.ignore_changes or [])
    mins = VM_TYPE_MIN_RESOURCES.get(nd.type.upper(), {})
    if (nd.cpu is not None or nd.memory is not None or mins) and not ("cpu" in ignored and "memory" in ignored):
        par = fa.get_vm_parameters(c, vid)
        cur_cpu, cur_mem = int(par.get("cpu_count") or 0), int(par.get("memory") or 0)
        tgt_cpu = _effective_resource(nd.cpu, mins.get("cpu"), cur_cpu)
        tgt_mem = _effective_resource(nd.memory, mins.get("memory"), cur_mem)
        if tgt_cpu is not None and "cpu" not in ignored:
            p.changes.append(Change("update", "node", nd.name, f"cpu {cur_cpu}→{tgt_cpu}",
                                    reinstall=True))
        if tgt_mem is not None and "memory" not in ignored:
            p.changes.append(Change("update", "node", nd.name,
                                    f"memory {cur_mem}→{tgt_mem} MiB", reinstall=True))
    if "disk" not in ignored:
        for d in fa.list_vm_disks(c, vid):
            declared, capacity = int(d.get("declared") or 0), int(d.get("capacity") or 0)
            if declared > 0 and capacity < declared:
                p.changes.append(Change("update", "disk", f"{nd.name}/{d.get('name') or d['id']}",
                                        f"capacity {capacity}→{declared} MiB",
                                        reinstall=True))
    if nd.disks and "disk" not in ignored:
        have = [d for d in fa.list_vm_disks(c, vid) if d.get("extra")]
        for i, cap in enumerate(nd.disks):
            if i >= len(have):
                p.changes.append(Change("create", "disk", f"{nd.name}[{i}]", f"{cap} MiB",
                                        reinstall=True))
    if nd.access and "access" not in ignored:
        cur_acc = {a.get("type"): a for a in fa.list_vm_accesses(c, fid, vid)}
        for t in nd.access:
            a = cur_acc.get(t)
            if not a or a.get("mode") != "PUBLIC":
                p.changes.append(Change("update", "access", f"{nd.name}.{t}", "→PUBLIC"))
    if nd.expose and "expose" not in ignored:
        cur_red = fa.list_port_redirects(c, fid)
        for ex in nd.expose:
            match = next((r for r in cur_red
                          if int(r.get("from_port") or 0) == ex["from_port"]
                          and (r.get("socktype") or "TCP") == ex["socktype"]), None)
            if not match:
                p.changes.append(Change("create", "redirect",
                                        f"{nd.name}:{ex['from_port']}/{ex['socktype']}",
                                        f"→ :{ex['to_port']}"))
    if nd.provision_config and "provision_config" not in ignored:
        # Reinstall is needed only when the config CONTENT changed (missing or
        # stale bytes). FS may clear vm["config"] after a successful RESTORE, so
        # the vm→config link being broken does NOT mean the guest config is wrong
        # -- it just means we need to re-link before the next install. Treat a
        # broken link as a cheap re-link, not a full VM reinstall.
        import os as _o
        path = _o.path.expanduser(nd.provision_config)
        name = _o.path.basename(path)
        if not _o.path.isfile(path):
            p.changes.append(Change("update", "node", nd.name,
                                    f"provision_config {name} (file missing)",
                                    reinstall=True))
        else:
            desired = open(path, "rb").read()
            vm_type = nd.type or "FGT"
            content_ok = False
            matched_id = None
            for r in fa.list_device_configs(c, fid):
                if r.get("name") == name and str(r.get("vm_type")) == str(vm_type):
                    try:
                        remote = fa.export_device_config(c, r["id"])
                        if _gz_content_eq(remote, desired):
                            content_ok = True
                            matched_id = r["id"]
                    except Exception:
                        pass  # can't export -- treat as stale
                    break
            if not content_ok:
                p.changes.append(Change("update", "node", nd.name,
                                        f"provision_config {name} (content changed)",
                                        reinstall=True))
            elif str(cur.get("config")) != str(matched_id):
                # Content correct but vm→config link cleared by FS post-install.
                # Apply will re-link without reinstalling.
                p.changes.append(Change("update", "config_link", nd.name,
                                        f"provision_config {name} (re-link only)"))
    if nd.license and "license" not in ignored:
        # License mode drift → reinstall (the new mode is applied at install). The
        # pool/flex seeding in _ensure_license is idempotent and not surfaced here.
        # Compare against fs_mode() so FLEX-GUEST (FS-mode NONE) doesn't phantom-drift.
        cur_mode = str((fa.get_vm_license_mode(c, fid, vid) or {}).get("mode") or "").upper()
        desired_mode = nd.license.fs_mode().upper()
        if cur_mode != desired_mode:
            p.changes.append(Change("update", "node", nd.name,
                                    f"license {cur_mode or '∅'}→{nd.license.fs_mode()}",
                                    reinstall=True))
        # License-vs-config install order (model.vmparameters.install_license).
        # Also read at install time, so a change here means a reinstall.
        want_order = nd.license.fs_install_license()
        if want_order is not None:
            cur_order = str((fa.get_vm_parameters(c, vid) or {}).get("install_license") or "")
            if cur_order != want_order:
                p.changes.append(Change("update", "node", nd.name,
                                        f"license install order {cur_order or '∅'}→{want_order} "
                                        f"({nd.license.install_order})",
                                        reinstall=True))
    if nd.params and "params" not in ignored:
        _reserved = {"cpu_count", "cpu", "memory", "memory_mb", "install_license"}
        extra = {k: v for k, v in nd.params.items() if k not in _reserved}
        if extra:
            cur = fa.get_vm_parameters(c, vid)
            diff_keys = [k for k in extra if str(extra[k]) != str(cur.get(k))]
            if diff_keys:
                p.changes.append(Change("update", "node", nd.name,
                                        f"params {', '.join(sorted(diff_keys))}",
                                        reinstall=True))


def _infra_needing_install(c: FabricStudioClient, fid: int | str,
                           intent: Intent) -> tuple[list[str], list[str]]:
    """``(host_ports, switches)`` that exist in the MODEL but have no runtime
    device, i.e. infra that is declared, looks converged, and carries no traffic.

    Adding infra to an already-running fabric leaves it half-built, and nothing
    downstream notices: a created System Host port comes back ``runtime: None``,
    and a switch created after the fabric was installed gets no runtime device at
    all (its pre-sync fails with "No 'model.device' matching <id>"). A guest on
    such a segment boots, takes its injected address and gateway, and sits there
    with the NIC link down -- while apply prints ``converged ✓``. Probed live:
    that is exactly the state a new switch + new uplink port produced, and it
    persisted across a clean guest reinstall.

    The two halves have very different fixes, so they are reported separately:
    a host port goes live from ``install_device(System Host)`` (cheap, guests
    untouched), a switch needs a full ``install_fabric``, which REDEPLOYS every
    guest in the fabric."""
    ports = [str(p.get("name")) for p in (fa.get_system_host(c, fid).get("ports") or [])
             if not p.get("runtime")]
    declared = {sw.name for sw in intent.switches}
    switches = [str(s.get("name")) for s in fa.read_fabric_state(c, fid)["switches"]
                if str(s.get("name")) in declared and not s.get("runtime")]
    return ports, switches


def _create_host_port(c: FabricStudioClient, host: dict[str, Any], say) -> dict[str, Any]:
    """Mint a new forwarding System Host ``int`` port.

    FS exposes this only on the NESTED route -- ``POST model/host/{device}/port``.
    The flat collection (``POST model/host/port``) answers 405, which is what made
    the two-port ceiling look like a hard limit. The new port comes back with
    ``runtime: None``; it carries traffic only after the System Host is installed.
    """
    used = {str(p.get("name")) for p in host.get("ports") or []}
    idx = max([int(p.get("index") or 0) for p in host.get("ports") or []] or [0]) + 1
    n = 1
    while f"int{n}" in used:
        n += 1
    name = f"int{n}"
    resp = c.post(f"api/v1/model/host/{host['id']}/port", json_data={"object": {
        "device": host["id"], "name": name, "type": "int",
        "index": idx, "forwarding": True}})
    obj = (resp.json() or {}).get("object") if resp.status_code == 200 else None
    if not obj:
        raise fa.FabricStudioAdminError(
            f"host_uplink: could not create a System Host port ({name}): "
            f"HTTP {resp.status_code} {str(resp.text)[:200]}")
    say(f"host uplink: created System Host port {name} (id {obj['id']}) "
        f"-- needs a System Host install to carry traffic")
    return obj


def _ensure_host_uplink(c: FabricStudioClient, fid: int | str, switch_id: int | str,
                        net: NetworkSpec, say, *,
                        declared_switch_ids: set | None = None) -> None:
    """Make ``switch_id`` host-uplinked for ``net``: ensure a forwarding System
    Host port owns ``net.gateway`` and is cabled to the switch. Idempotent.

    If no host port owns the gateway, this needs a forwarding ``int`` port (not
    the external ``mgmt1`` WAN port) pointed at it -- that port becomes the net's
    router, NAT'd out through ``mgmt1``. Each host-uplinked net needs its OWN int
    port (one cable per port).

    **Ports are created, not stolen.** The System Host ships with two int ports,
    which used to be treated as a hard ceiling: a third uplink repointed a
    sibling's port and silently collapsed that switch to floating. Host ports are
    creatable (``POST model/host/{device}/port``) and a guest on a created port
    routes normally -- probed live, a fresh net on a freshly created ``int4``
    got its gateway injected and reached the internet. So we mint a new port when
    no free one exists, and only reuse a port that is genuinely free (uncabled,
    or cabled to a switch this intent doesn't declare -- a stale/phantom switch
    whose address the repoint overwrites). A port cabled to a declared sibling is
    never touched.

    A created port has ``runtime: None`` until the System Host is installed, and
    a guest on it stays link-down until then -- see ``_infra_needing_install``,
    which makes apply refuse to report convergence over that state."""
    host = fa.get_system_host(c, fid)
    ports = host.get("ports") or []
    gw, mask = net.gateway, net.ipv4netmask
    owner = next((hp for hp in ports
                  if hp.get("forwarding") and hp.get("ipv4addr") == gw), None)
    if owner is None:
        int_ports = [hp for hp in ports
                     if hp.get("forwarding") and hp.get("name") != "mgmt1"]
        declared = declared_switch_ids or set()

        def _free_for_reuse(hp):
            cab = hp.get("cable")
            if not cab:
                return True  # uncabled -- stale addr is overwritten by the repoint
            # Cabled: free only if it lands on a switch this intent doesn't declare.
            for sid in declared:
                if str(sid) == str(switch_id):
                    continue
                if any(sp.get("cable") == cab for sp in fa.list_switch_ports(c, fid, sid)):
                    return False  # cabled to a declared sibling -- don't steal
            return True

        # Prefer a genuinely free int port; otherwise CREATE one rather than
        # stealing a declared sibling's uplink.
        cand = next((hp for hp in int_ports if _free_for_reuse(hp)), None)
        if cand is None:
            cand = _create_host_port(c, host, say)
        fa.set_host_port_ipv4(c, cand["id"], gw, mask)
        owner = {**cand, "ipv4addr": gw}
        say(f"host uplink: System Host {cand.get('name')} → {gw} (router for {net.name})")
    # Cable the owning host port onto this switch (idempotent: skip if its current
    # cable already lands on a port of this switch).
    sw_ports = fa.list_switch_ports(c, fid, switch_id)
    sw_port_ids = {sp.get("id") for sp in sw_ports}
    cur_cable = owner.get("cable")
    if cur_cable and any(sp.get("cable") == cur_cable for sp in sw_ports):
        return  # already cabled to this switch
    if cur_cable:
        fa.delete_cable(c, fid, cur_cable)
    sp = fa.free_switch_port(c, fid, switch_id)
    if not sp:
        raise fa.FabricStudioAdminError(f"host_uplink: switch {switch_id} has no free port")
    fa.create_cable(c, fid, host["id"], owner["id"], sp["device"], sp["id"])
    say(f"host uplink: cabled System Host {owner.get('name')} → switch {switch_id}")


def _apply_node_resources(c: FabricStudioClient, fid: int | str, nd: NodeSpec,
                          vid: int | str, say, net_id: dict[str, Any] | None = None) -> bool:
    """Idempotently converge a VM's cpu/memory/disks/access to the NodeSpec.
    Returns True if a cpu/memory/disk change was made -- those are model-only and
    only take effect on a full reinstall (destroy_vm → install_vm), so the caller
    must reinstall the VM. Access (PUBLIC) does not require a reinstall.

    Fields in nd.ignore_changes are skipped -- no mutations made to them."""
    reinstall = False
    ignored = set(nd.ignore_changes or [])
    # auto_params_network: which network's gateway/DNS FS auto-injects. Model-only:
    # a running guest only picks it up on an install -- see NodeSpec.auto_params_network.
    if nd.auto_params_network and "auto_params_network" not in ignored and net_id:
        want_net = net_id.get(nd.auto_params_network)
        if want_net is not None:
            cur = fa.get_vm_by_name(c, fid, nd.name) or {}
            if str(cur.get("auto_params_network") or "") != str(want_net):
                fa._patch(c, f"api/v1/model/vm/{vid}",
                         {"object": {"auto_params_network": want_net}},
                         "set_auto_params_network")
                say(f"node {nd.name}: auto_params_network → {nd.auto_params_network} "
                    f"(id {want_net})")
                if cur.get("runtime"):
                    say(f"node {nd.name}: already installed -- a sync clears this change "
                        f"without applying it; the guest keeps its old gateway/DNS until "
                        f"the device is reinstalled (a DHCP-served port gets it from the "
                        f"System Host install instead)")
    # ``install_license`` (FS "Order of installation": license before/after the
    # deviceconfig restore) rides along on EVERY set_vm_parameters patch, because
    # fs_admin.set_vm_parameters always puts it in the body and defaults it to
    # "FIRMWARE". So resolve it ONCE and pass it explicitly on every call below:
    # the intent wins when it declares an order, otherwise we echo back whatever
    # is already on the VM. Without this, an unrelated cpu/memory edit silently
    # resets a deliberately-chosen order to FS's default -- which for a node whose
    # resolver comes from its restored config means the next install licenses
    # before DNS exists and the guest comes up eval/limited.
    want_order = nd.license.fs_install_license() if nd.license else None

    def _order_of(par: dict[str, Any]) -> str:
        return want_order or str(par.get("install_license") or "FIRMWARE")

    mins = VM_TYPE_MIN_RESOURCES.get(nd.type.upper(), {})
    if (nd.cpu is not None or nd.memory is not None or mins) and not ("cpu" in ignored and "memory" in ignored):
        par = fa.get_vm_parameters(c, vid)
        cur_cpu, cur_mem = int(par.get("cpu_count") or 0), int(par.get("memory") or 0)
        tgt_cpu = _effective_resource(nd.cpu, mins.get("cpu"), cur_cpu)
        tgt_mem = _effective_resource(nd.memory, mins.get("memory"), cur_mem)
        if tgt_cpu is not None or tgt_mem is not None:
            cpu = tgt_cpu if (tgt_cpu is not None and "cpu" not in ignored) else cur_cpu
            mem = tgt_mem if (tgt_mem is not None and "memory" not in ignored) else cur_mem
            if cpu != cur_cpu or mem != cur_mem:
                fa.set_vm_parameters(c, vid, cpu_count=cpu, memory=mem,
                                     install_license=_order_of(par))
                say(f"node {nd.name}: parameters cpu={cpu} memory={mem} MiB"
                    + ("" if (nd.cpu is not None or nd.memory is not None) else " (vm-type minimum)"))
                reinstall = True
    # License install order, when the intent declares one and FS disagrees. Model
    # -only, like cpu/memory: it is read at install time, so converging it has to
    # reinstall for the new order to actually be exercised.
    if want_order is not None and "license" not in ignored:
        par = fa.get_vm_parameters(c, vid)
        cur_order = str(par.get("install_license") or "")
        if cur_order != want_order:
            fa.set_vm_parameters(c, vid, install_license=want_order)
            say(f"node {nd.name}: license install order "
                f"{cur_order or '∅'}→{want_order} ({nd.license.install_order})")
            reinstall = True
    # Hugepage backing. Declared-only: leaving it unset keeps whatever FS chose,
    # so this never silently moves an appliance off the pool it was sized for.
    if nd.hugepages is not None and "hugepages" not in ignored:
        par = fa.get_vm_parameters(c, vid)
        if bool(par.get("hugepages")) != bool(nd.hugepages):
            fa.set_vm_parameters(c, vid, extra={"hugepages": bool(nd.hugepages)},
                                 install_license=_order_of(par))
            say(f"node {nd.name}: hugepages {bool(par.get('hugepages'))}→{bool(nd.hugepages)}"
                + ("" if nd.hugepages else " (maps from ordinary RAM)"))
            reinstall = True
    # Firmware data disks ship declared>0 but capacity 0 -- FS provisions them
    # 0-byte until extended, so e.g. FMG/FAZ never get a usable data partition.
    # Honor the declared size (capacity := declared) so the disk is real on boot.
    if "disk" not in ignored:
        for d in fa.list_vm_disks(c, vid):
            declared, capacity = int(d.get("declared") or 0), int(d.get("capacity") or 0)
            if declared > 0 and capacity < declared:
                fa.set_vm_disk_capacity(c, d["id"], declared)
                say(f"node {nd.name}: disk {d.get('name') or d['id']} capacity {capacity}→{declared} MiB")
                reinstall = True
    if nd.disks and "disk" not in ignored:
        have = [d for d in fa.list_vm_disks(c, vid) if d.get("extra")]
        for i, cap in enumerate(nd.disks):
            if i < len(have):
                continue  # already attached (idempotent on disk count/order)
            fa.add_vm_disk(c, vid, cap)
            say(f"node {nd.name}: +disk[{i}] {cap} MiB")
            reinstall = True
    # BEFORE the accesses: FS decides whether to allocate a console forward at
    # install time by looking at console_password, so it has to be on the model
    # first. Setting it afterwards leaves this install's VNC unexposed and only
    # takes effect on the next one.
    if nd.console_password and "console_password" not in ignored:
        cur = fa.get_vm_by_name(c, fid, nd.name) or {}
        if cur.get("console_password") != nd.console_password:
            fa.set_vm_console_password(c, fid, vid, nd.console_password)
            say(f"node {nd.name}: console password set (VNC/SPICE exposure)")
            reinstall = True
    if nd.password and "password" not in ignored:
        cur = fa.get_vm_by_name(c, fid, nd.name) or {}
        if cur.get("password") != nd.password:
            fa.set_vm_password(c, fid, vid, nd.password)
            say(f"node {nd.name}: device password set")
            reinstall = True
    if nd.access and "access" not in ignored:
        changed = fa.ensure_public_access(c, fid, vid, types=tuple(nd.access))
        if changed:
            say(f"node {nd.name}: access PUBLIC {changed}")
    # Extra vmparameters (expert hooks, hugepages, …)
    if nd.params and "params" not in ignored:
        # The common cpu/memory/install_license fields are managed by the explicit
        # node.cpu/memory and set_vm_parameters calls above -- filter them out so we
        # don't double-patch or clobber those values.
        _reserved = {"cpu_count", "cpu", "memory", "memory_mb", "install_license"}
        extra = {k: v for k, v in nd.params.items() if k not in _reserved}
        if extra:
            desired = dict(extra)
            cur = fa.get_vm_parameters(c, vid)
            if {k: str(v) for k, v in desired.items()} != {k: str(cur.get(k)) for k in desired}:
                fa.patch_vm_params(c, vid, desired)
                say(f"node {nd.name}: parameters {', '.join(sorted(desired))}")
                reinstall = True
    return reinstall


import os as _os


def _ensure_provision_config(c: FabricStudioClient, fid: int | str, nd: NodeSpec,
                             vid: int | str, say) -> bool:
    """Upload ``nd.provision_config`` as a ``model.deviceconfig`` (RESTORE,
    vm_type = node type) and point the VM at it, so FS restores it at install.
    Idempotent: reuse an existing same-name config whose bytes already match the
    local file; otherwise (re)upload. Returns True if the VM's config link
    changed -- the restore only happens on (re)install, so the caller reinstalls.

    Skipped if 'provision_config' is in nd.ignore_changes."""
    if not nd.provision_config or "provision_config" in (nd.ignore_changes or []):
        return False
    path = _os.path.expanduser(nd.provision_config)
    if not _os.path.isfile(path):
        raise fa.FabricStudioAdminError(
            f"node {nd.name!r}: provision_config not found at {path!r}")
    name = _os.path.basename(path)
    vm_type = nd.type or "FGT"
    want = _os.path.basename(path)
    desired = open(path, "rb").read()

    # Reuse a same-name config in this fabric if its content already matches.
    # If it's stale, try to delete it -- but FS refuses to delete a deviceconfig
    # that a running fabric still references (rcode 246). That's fine: import a
    # fresh copy under the same name and relink; the stale one is orphaned and
    # freed on the next reinstall (it's only consumed at install-time RESTORE).
    cid = None
    for r in fa.list_device_configs(c, fid):
        if r.get("name") == name and str(r.get("vm_type")) == str(vm_type):
            try:
                if _gz_content_eq(fa.export_device_config(c, r["id"]), desired):
                    cid = r["id"]
                    break
            except Exception:
                pass  # can't read it -- treat as stale, replace below
            try:
                fa.delete_device_config(c, r["id"])  # stale -- replace
            except fa.FabricStudioAdminError as e:
                say(f"node {nd.name}: stale provision_config in use, leaving orphaned ({e})")
            break
    if cid is None:
        # Bytes differ or no config exists -- upload fresh and reinstall.
        row = fa.import_device_config(c, path, name=name, fabric_id=fid, vm_type=vm_type)
        cid = row["id"]
        say(f"node {nd.name}: uploaded provision_config {want} = deviceconfig {cid}")
        cur = fa.get_vm_by_name(c, fid, nd.name) or {}
        if str(cur.get("config")) != str(cid):
            fa.set_vm_config(c, fid, vid, cid)
            say(f"node {nd.name}: provision_config linked → deviceconfig {cid} (restores on install)")
        return True  # content changed -- reinstall required

    # Content already correct. Re-link if FS cleared vm["config"] post-install,
    # but don't reinstall -- the guest already has the right config.
    cur = fa.get_vm_by_name(c, fid, nd.name) or {}
    if str(cur.get("config")) != str(cid):
        fa.set_vm_config(c, fid, vid, cid)
        say(f"node {nd.name}: provision_config re-linked → deviceconfig {cid} (no reinstall)")
    return False


def _flex_config_ref(nd: NodeSpec) -> int | str | None:
    """The FortiFlex config reference (id or name) for a node: the node's
    ``license.flex_config`` if set, else the ``FLEX_<TYPE>_CONFIG`` env (which
    ``fs_topology._resolve_provider`` populates from the ``[flex_configs]``
    fabric.toml table -- the recommended place -- over any pre-existing env value).
    None when the node isn't flex-licensed."""
    if nd.license and nd.license.flex_config is not None:
        return nd.license.flex_config
    if nd.license and nd.license.mode.upper() == "AUTO":
        from fabric_studio.topology import flex
        return flex.env_config_for_type(nd.type)
    return None


def _ensure_forticloud_for_flex(c: FabricStudioClient, intent: Intent, say) -> None:
    """Pod-wide pre-step: if any node is FortiFlex-licensed (a resolved
    ``flex_config``), ensure the pod's FortiCloud account is registered so FS can
    auto-assign at install. Idempotent -- skips when already registered. Creds from
    FORTIFLEX_USER/PASS or Keychain (see flex.resolve_flex_creds)."""
    # An AUTO node counts even when no config resolves: it is FortiFlex-licensed
    # by definition, and _ensure_license auto-derives its pool config later. The
    # old predicate keyed on _flex_config_ref alone, so an AUTO node with no
    # [flex_configs] entry left the account unregistered too.
    def _is_flex(nd) -> bool:
        return (_flex_config_ref(nd) is not None
                or bool(nd.license and nd.license.mode.upper() == "AUTO"))
    if not any(_is_flex(nd) for nd in intent.nodes):
        return
    if fa.forticloud_registered(c):
        say("forticloud: account already registered")
        return
    from fabric_studio.topology import flex
    api_id, password = flex.resolve_flex_creds()
    say("forticloud: registering FortiFlex account (so FS can auto-license)")
    fa.register_forticloud_account(c, api_id, password)
    say("forticloud: registered ✓")


def _ensure_license(c: FabricStudioClient, fid: int | str, nd: NodeSpec,
                    vid: int | str, say) -> bool:
    """Apply ``nd.license`` to the VM so FS licenses it at install. Optionally
    seeds the FS pool (``file``) / FortiFlex pool (``flex_config``) first, then
    sets the VM license *mode* (the only knob FS honors -- it rejects a direct
    ``served`` PATCH). Returns True if the mode changed (caller reinstalls so the
    new mode takes effect). No-op when the node declares no ``license`` or when
    'license' is in nd.ignore_changes.

    For ``FLEX-GUEST`` nodes, sets FS mode to NONE (FS does not pool-license them;
    the guest redeems in-guest post-boot) and skips FS pool seeding entirely."""
    if not nd.license or "license" in (nd.ignore_changes or []):
        return False
    lic = nd.license
    # 1. Seed the FS pool with a local .lic (idempotent: skip if the serial is
    #    already pooled; FS import is keyed on the embedded serial).
    if lic.file:
        path = _os.path.expanduser(lic.file)
        if not _os.path.isfile(path):
            raise fa.FabricStudioAdminError(
                f"node {nd.name!r}: license file not found at {path!r}")
        before = {str(r.get("name")) for r in fa.list_fs_licenses(c)}
        try:
            row = fa.import_fs_license(c, path)
            if str(row.get("name")) in before:
                say(f"node {nd.name}: license {row.get('name')} already in FS pool")
            else:
                say(f"node {nd.name}: imported license {row.get('name')} into FS pool")
        except fa.FabricStudioAdminError as e:
            say(f"node {nd.name}: license import tolerated ({e}) -- assuming already pooled")
    # 2. FortiFlex pool mapping for this vm_type (pod-wide; account registered by
    #    the apply pre-step). The config is the node's flex_config or the env
    #    default FLEX_<TYPE>_CONFIG; a name is resolved to its numeric id.
    #    Skip for FLEX-GUEST nodes (they redeem in-guest, not through the FS pool).
    if not lic.is_guest_redeem():
        flex_ref = _flex_config_ref(nd)
        if flex_ref is None and lic.mode.upper() == "AUTO":
            # AUTO means "FS picks the license from its FortiFlex pool" -- but a
            # pool only exists once set_flex_pool has mapped this vm_type to a
            # config. With no flex_config and no [flex_configs] entry we used to
            # skip silently, set the VM to AUTO anyway, and leave FS with nothing
            # to draw from ("no licenses available" at install, on a pod that
            # looks configured). Derive it when the account leaves no doubt.
            # A pod that already maps this type (set by an earlier build) keeps its
            # mapping; only an unmapped pod asks the account to pick one.
            from fabric_studio.topology import flex
            flex_ref = flex.pooled_config_for_vm_type(fa.list_flex_pool(c), nd.type)
            if flex_ref is not None:
                say(f"node {nd.name}: no flex_config set; using the pod's existing "
                    f"{nd.type} FortiFlex pool config {flex_ref}")
            else:
                flex_ref = flex.autodetect_config_for_vm_type(nd.type)
                say(f"node {nd.name}: no flex_config set; using the account's only "
                    f"ACTIVE {nd.type} config {flex_ref}")
        if flex_ref is not None:
            from fabric_studio.topology import flex
            cid = flex.resolve_config_id(flex_ref)
            # Catch a wrong-product-type config (e.g. a FortiSOAR config wired to an
            # FGT node) here, with an actionable message, instead of FS returning an
            # opaque HTTP 500 from set_flex_pool.
            flex.assert_config_matches_vm_type(cid, nd.type)
            fa.set_flex_pool(c, nd.type, cid)
            say(f"node {nd.name}: FortiFlex pool {nd.type}→config {cid}"
                + (f" (from {flex_ref!r})" if str(flex_ref) != str(cid) else ""))
    # 3. Set the VM license mode (effective on the next install).
    #    Use fs_mode() which converts FLEX-GUEST to NONE.
    cur_mode = str((fa.get_vm_license_mode(c, fid, vid) or {}).get("mode") or "").upper()
    desired_mode = lic.fs_mode().upper()
    if cur_mode != desired_mode:
        fa.set_vm_license_mode(c, fid, vid, mode=lic.fs_mode())
        say(f"node {nd.name}: license mode {cur_mode or '∅'}→{lic.fs_mode()} (assigns on install)")
        return True
    return False


# ── Apply ────────────────────────────────────────────────────────────────────

def _nodes_awaiting_build(intent: Intent, image_ids: dict[str, int]) -> set[str]:
    """Nodes whose ``image`` is a declared ``build:`` image (no ``path``) that the
    images phase did not resolve -- i.e. its build has not run yet."""
    pending = {im.name for im in intent.images or ()
               if im.build and not im.path and im.name not in image_ids}
    return {nd.name for nd in intent.nodes if nd.image in pending}


def _without_nodes(intent: Intent, drop: set[str]) -> Intent:
    """A copy of ``intent`` without the ``drop`` nodes and the config /
    healthcheck items that target them (the same scoping ``--target`` does)."""
    return dataclasses.replace(
        intent,
        nodes=[n for n in intent.nodes if n.name not in drop],
        config=[x for x in intent.config if getattr(x, "node", None) not in drop],
        healthchecks=[h for h in intent.healthchecks if getattr(h, "node", None) not in drop])


def apply(c: FabricStudioClient, intent: Intent, *, prune: bool = False,
          boot: bool = True, boot_timeout_s: int = 900,
          force_reinstall: set[str] | None = None,
          allow_no_egress: bool = False,
          allow_addr_mismatch: bool = False,
          allow_floating_mgmt: bool = False,
          allow_dhcp_service_off: bool = False,
          allow_hugepage_overcommit: bool = False,
          allow_full_redeploy: bool = False,
          force_lint: bool = False,
          discard_guard: Callable[[str], str | None] | None = None,
          publish_redirects: bool = False,
          progress=None) -> dict[str, Any]:
    """Converge the live fabric to ``intent`` via idempotent ``fs_admin.ensure_*``
    calls in dependency order, then (if ``boot``) install/synchronize and wait
    for every VM to reach powered + post_boot_prepared, then re-read and assert
    convergence. Returns a summary dict. ``prune=True`` deletes resources the
    intent no longer declares (links, then nodes, switches, networks).

    ``force_reinstall`` is a set of node names to destroy→install even with no
    resource diff -- the way to re-apply a license/flex-config change (which FS
    only honors at install) to an already-running guest, e.g. an FGT stuck in
    eval/limited mode after its flex pool was corrected."""
    def _say(m: str) -> None:
        if progress:
            progress(m)

    # Kill-switch: checked before anything else, including the lint below --
    # when engaged for this (pod, fabric) pair, apply() refuses to run.
    # getattr: test doubles for ``c`` don't carry a real ``.server``.
    _lock.check_lockout(getattr(c, "server", "") or "", intent.fabric)

    # Guard: refuse to deploy a topology that is already known-broken at L3.
    # These are the faults that assign addresses and then drop traffic -- see
    # ``_lint_topology``. Checked BEFORE wait_pod_idle so a bad intent fails
    # instantly rather than after queueing behind another install.
    # State is best-effort: if the fabric can't be read (pod unreachable, or a
    # caller passing a client that doesn't serve reads), fall back to the
    # intent-only checks rather than blocking on a read that apply's own
    # ensure_fabric/wait_pod_idle below will fail on loudly anyway. Never let a
    # read failure here masquerade as "topology is fine".
    _lint_state = None
    try:
        _lint_fab = fa.get_fabric_by_name(c, intent.fabric)
        if _lint_fab:
            _lint_state = fa.read_fabric_state(c, _lint_fab["id"])
    except Exception as _exc:
        _say(f"lint: could not read live state ({type(_exc).__name__}); "
             "running intent-only checks")
    _lint_errs = _lint_topology(intent, _lint_state, prune=prune)
    if _lint_errs:
        if force_lint:
            for e in _lint_errs:
                _say(f"LINT OVERRIDDEN (--force-lint): {e}")
        else:
            raise ValueError(
                "refusing to apply -- this topology would deploy broken networking:\n"
                + "\n".join(f"  \u2717 {e}" for e in _lint_errs)
                + "\n\nFix the intent, or pass force_lint=True / --force-lint if the "
                  "check is wrong.")

    # Guard: never step on a busy pod (FS allows one install at a time).
    fa.wait_pod_idle(c)

    # 0a. Images -- ensure firmwares the nodes reference exist in the home repo
    #     (pod-global, independent of the fabric) before any node is created.
    from fabric_studio.topology import images  # lazy: avoids a circular import at module load
    image_ids = images.ensure_images(c, intent, _say)

    # 0a'. Nodes whose image is a build this apply has not produced yet (its
    #     builder is down, so the images phase deferred it) can't be created.
    #     Converge everything else first -- that boots the builder and runs the
    #     deferred build (step 9) -- then re-apply the whole intent, which now
    #     resolves the built image and creates those nodes. One apply instead of
    #     a `--target <builder>` apply followed by a full one.
    awaiting = _nodes_awaiting_build(intent, image_ids)
    if awaiting:
        names = ", ".join(sorted(awaiting))
        _say(f"node(s) {names}: image not built yet -- converging the rest first "
             f"(builder up + build), then these")
        kwargs = dict(boot=boot, boot_timeout_s=boot_timeout_s,
                      force_reinstall=force_reinstall, allow_no_egress=allow_no_egress,
                      allow_addr_mismatch=allow_addr_mismatch,
                      allow_floating_mgmt=allow_floating_mgmt,
                      allow_dhcp_service_off=allow_dhcp_service_off,
                      allow_hugepage_overcommit=allow_hugepage_overcommit,
                      allow_full_redeploy=allow_full_redeploy, force_lint=force_lint,
                      discard_guard=discard_guard, publish_redirects=publish_redirects,
                      progress=progress)
        first = apply(c, _without_nodes(intent, awaiting), prune=False, **kwargs)
        built = set((first.get("built_images") or {}).keys())
        missing = {nd.image for nd in intent.nodes if nd.name in awaiting} - built
        if missing:
            raise fa.FabricStudioAdminError(
                f"node(s) {names}: image(s) {', '.join(sorted(missing))} were not built "
                f"this run (is the builder booted and converged?) -- the rest of the "
                f"fabric is converged")
        _say(f"image(s) built -- converging deferred node(s) {names}")
        summary = apply(c, intent, prune=prune, **kwargs)
        summary["built_images"] = {**first.get("built_images", {}),
                                   **summary.get("built_images", {})}
        summary["deferred_nodes"] = sorted(awaiting)
        return summary

    # 0b. FortiFlex -- register the pod's FortiCloud account up front if any node
    #     is flex-licensed, so the per-node set_flex_pool + install can assign.
    _ensure_forticloud_for_flex(c, intent, _say)

    # 0c. Security preferences -- a PUBLIC vmaccess only gets an external forward
    #     when the pod-wide per-protocol gate is "yes". Flip on exactly the flags
    #     the nodes' `access:` lists need, up front (before step 3 creates the
    #     accesses), so e.g. `access: [RDP]` actually yields a 17000+idx forward
    #     instead of a stub. Console types (SERIAL/VNC/SPICE) are PRIVATE and need
    #     no flag. Mirrors the custom_rules_allowed flip for `expose:` (step 5b).
    access_flags = sorted({
        _ACCESS_SECURITY_FLAG[t] for nd in intent.nodes for t in nd.access
        if t in _ACCESS_SECURITY_FLAG
    })
    if access_flags:
        flipped = fa.ensure_public_forwards_allowed(c, tuple(access_flags))
        if flipped:
            _say(f"pod security: enabled {flipped} (node access requires it)")

    # 0. Fabric
    fab = fa.ensure_fabric(c, intent.fabric, intent.description)
    fid = fab["id"]
    _say(f"fabric {intent.fabric!r} = id {fid}")

    # 1. Networks
    net_id: dict[str, Any] = {}
    for n in intent.networks:
        row = fa.ensure_network(c, fid, n.name, n.ipv4network, n.ipv4netmask, n.gateway)
        # ensure_* returns the existing row as-is; reconcile drift via update.
        # Include dns1/dns2 in the drift check: a FortiFlex guest on an egress net
        # needs a resolver to reach FortiCare, so a net created without dns1 (then
        # the intent adds one) must be updated, not left as-is (proven live: the
        # dns1 never landed and flex activation timed out).
        if (_cidr_of(row) != _norm_intent_cidr(n.cidr)
                or (n.gateway and row.get("ipv4gateway") != n.gateway)
                or (n.dns1 is not None and (row.get("ipv4dns1") or "") != (n.dns1 or ""))
                or (n.dns2 is not None and (row.get("ipv4dns2") or "") != (n.dns2 or ""))):
            row = fa.update_network(c, fid, row["id"], ipv4network=n.ipv4network,
                                    ipv4netmask=n.ipv4netmask, ipv4gateway=n.gateway,
                                    ipv4dns1=n.dns1, ipv4dns2=n.dns2)
        net_id[n.name] = row["id"]
        _say(f"network {n.name} = id {row['id']} ({n.cidr})")

    # 2. Switches (auto_address resolved to the network id)
    #
    # A switch that carries some node's management port must itself be a
    # management switch, or FS builds no working forward for that node (live-
    # confirmed 07-16: mgmt on BOTH the vmport and its switch, plus a full fabric
    # install, is what makes an SSH forward answer). This can force `mgmt: true`
    # on a switch the intent declared `role: egress` (→ mgmt=False). That is
    # harmless, and it is worth being precise about why, because a wrong guess
    # here already cost a lab. Probed live (see `_switch_gives_egress`): flipping a
    # host-uplinked egress switch to mgmt=True and reinstalling BOTH the node that
    # owns the mgmt port and a bystander left the injected gateway, the default
    # route, and internet egress intact for both, and every SSH forward still
    # answered. `switch.mgmt` drives port-forwarding, not routing -- the segment
    # that gets no default route is the seeded OOB one, whatever its flags say.
    mgmt_switches = {lk.switch for nd in intent.nodes
                     if (lk := _mgmt_link(nd)) is not None}
    sw_id: dict[str, Any] = {}
    for s in intent.switches:
        aa = net_id.get(s.auto_address) if s.auto_address else None
        want_mgmt = s.mgmt or s.name in mgmt_switches
        row = fa.ensure_switch(c, fid, s.name, aa, want_mgmt)
        if str(row.get("auto_address_network")) != str(aa) or bool(row.get("mgmt")) != want_mgmt:
            row = fa.update_switch(c, fid, row["id"], auto_address_network=aa, mgmt=want_mgmt)
        sw_id[s.name] = row["id"]
        extra = "" if want_mgmt == s.mgmt else " [mgmt forced on: carries a management port]"
        _say(f"switch {s.name} = id {row['id']} (auto_address={s.auto_address}){extra}")

    # 2b. Host-uplink the switches that ask for it: give the System Host a
    #     forwarding port owning the net's gateway and cable it to the switch, so
    #     the segment routes outbound via the host NAT (not a floating segment).
    #     Pass the full declared switch-id set so a second uplink picks its OWN
    #     int port instead of stealing the first's (see _ensure_host_uplink).
    declared_sw_ids = set(sw_id.values())
    for s in intent.switches:
        if not s.host_uplink:
            continue
        net = next((n for n in intent.networks if n.name == s.auto_address), None)
        if not net or not net.gateway:
            raise fa.FabricStudioAdminError(
                f"switch {s.name!r}: host_uplink needs an auto_address network with a gateway")
        _ensure_host_uplink(c, fid, sw_id[s.name], net, _say,
                            declared_switch_ids=declared_sw_ids)

    # 3. Nodes (VMs) -- create on firmware, repoint firmware on drift, then
    #    converge per-VM resources (cpu/memory/disks/access). Resource edits that
    #    need a reinstall are tracked in ``reinstall_nodes`` for the bring-up step.
    vm_id: dict[str, Any] = {}
    reinstall_nodes: set[str] = set(force_reinstall or ())
    for nd in intent.nodes:
        existing = fa.get_vm_by_name(c, fid, nd.name)
        fw = _resolve_firmware_id(c, nd, image_ids=image_ids)
        if not existing:
            if fw is None:
                raise fa.FabricStudioAdminError(
                    f"node {nd.name!r}: firmware/image required to create the VM")
            existing = fa.create_vm(c, fid, nd.name, fw, uuid=nd.uuid)
            _say(f"node {nd.name} created = id {existing['id']} on fw {fw}"
                 + (f" (uuid {nd.uuid})" if nd.uuid else ""))
        else:
            if fw is not None and str(existing.get("firmware")) != str(fw):
                fa.set_vm_firmware(c, fid, existing["id"], fw)
                _say(f"node {nd.name}: firmware repointed → {fw}")
                reinstall_nodes.add(nd.name)
            # uuid is baked into the qemu launch: changing it (fa.set_vm_uuid)
            # only lands on a reinstall, which loses guest state -- so surface
            # drift from a pinned value rather than silently reinstalling.
            if nd.uuid and str(existing.get("uuid", "")).lower() != nd.uuid.lower():
                _say(f"node {nd.name}: WARNING pinned uuid {nd.uuid} != live "
                     f"{existing.get('uuid') or '<none>'} -- set it and reinstall "
                     f"the node (guest state is lost) to adopt it")
        vm_id[nd.name] = existing["id"]
        if _apply_node_resources(c, fid, nd, existing["id"], _say, net_id=net_id):
            reinstall_nodes.add(nd.name)
        if _ensure_provision_config(c, fid, nd, existing["id"], _say):
            reinstall_nodes.add(nd.name)
        if _ensure_license(c, fid, nd, existing["id"], _say):
            reinstall_nodes.add(nd.name)

    # 3b. FS-native install ordering (model.installafter, GUI "Install after").
    #     All node ids are known now (every node in intent.nodes has an entry in
    #     vm_id from the loop above). This is enforced by FS at install time --
    #     distinct from depends_on, which only gates our own provision-phase
    #     items. No reinstall is needed for a change here: FS reads it at the
    #     next install, not baked into a running guest.
    for nd in intent.nodes:
        want_after = sorted(vm_id[dep] for dep in nd.install_after)
        cur_after = sorted(fa.get_vm_install_after(c, vm_id[nd.name]))
        if cur_after != want_after:
            fa.set_vm_install_after(c, vm_id[nd.name], want_after)
            _say(f"node {nd.name}: install_after → "
                 f"{sorted(nd.install_after) or '∅'}")

    # 4. Cabling -- only (re)cable a port not already on the desired switch.
    st = fa.read_fabric_state(c, fid)
    cur_link_switch = {(lk["vm_id"], lk["vm_port_name"]): lk["switch_id"] for lk in st["links"]}
    for nd in intent.nodes:
        vid = vm_id[nd.name]
        for lk in nd.links:
            want_sw = sw_id[lk.switch]
            if str(cur_link_switch.get((vid, lk.port))) == str(want_sw):
                continue  # already cabled correctly
            fa.cable_vm_to_switch(c, fid, vid, want_sw, lk.port)
            _say(f"cabled {nd.name}.{lk.port} → switch {lk.switch}")

    # 4b. Prune stray cables: a managed node port cabled to a MANAGED switch but
    #     not declared in the intent's links is drift (e.g. a leftover eth1→egress
    #     cable from an earlier topology revision). Two NICs on one L2 segment give
    #     the guest a duplicate interface and leave FS firewall (nft) chains
    #     inconsistent -- which made the LXC install fail rc 254 at teardown. Only
    #     touch managed switches: an FS-auto OOB-mgmt cable (unmanaged switch) is
    #     left alone. Marks the node for reinstall (cable change is model-only).
    for nm in _prune_undeclared_cables(c, fid, intent, vm_id, sw_id, _say):
        reinstall_nodes.add(nm)

    # 4c. Switchport VLANs. Every link that declares vlan:/trunk: programs the
    #     SWITCHPORT it is cabled to. A switch whose ports changed is reinstalled
    #     (POST runtime/switch/{id}) at bring-up -- a synchronize updates the
    #     runtime row and leaves OVS on the old config, so the row would read
    #     correct while traffic disagreed.
    reinstall_switches: set[Any] = set()
    for sname, changed in _apply_switchport_vlans(c, fid, intent, vm_id, sw_id, _say).items():
        if changed:
            reinstall_switches.add(sw_id[sname])

    # 5. Port addressing (explicit static IPs; auto_address handles the rest).
    _sys_host_id: int | None = None  # resolved lazily, once, if any link wants DHCP
    dhcp_native_ids: set[int] = set()  # native devices whose DHCP config we changed
    dhcp_nodes_by_native: dict[int, set[str]] = {}  # native id → nodes that DHCP off it

    def _native_device_id(name: str) -> int:
        nonlocal _sys_host_id
        if name == "System Host":
            if _sys_host_id is None:
                _sys_host_id = fa.get_system_host(c, fid)["id"]
            return _sys_host_id
        raise ValueError(f"unknown native dhcp device {name!r} (only 'System Host' supported)")

    # A DHCP port must carry the model.network its switch auto-addresses, or the
    # native DHCP serves no lease (proven live). Map switch name → network id.
    sw_aa = {s.name: s.auto_address for s in intent.switches}
    net_by_name = {n.name: n for n in intent.networks}
    # Per-network set of already-claimed host addresses (seeded with the gateway),
    # so static-DHCP allocation across nodes/ports doesn't hand out duplicates.
    _claimed: dict[str, set[str]] = {}

    def _valid_dhcp_addr(net_name: str | None, cur: str | None) -> tuple[str | None, str | None]:
        """Return (ipv4addr, ipv4netmask) for a static-DHCP port: keep ``cur`` if
        it's already a usable host in the link's subnet, else allocate the next
        free one. A freshly-created FS LXC/qcow port defaults to the System Host
        OOB address (e.g. 10.254.254.1), which is OUTSIDE the link's subnet -- the
        native DHCP serves only the net's own scope, so leasing an out-of-subnet
        address yields no reservation and the guest never gets an IP (proven live
        on Pod B: eth0 stuck at 10.254.254.1 on a 203.0.113.0/24 net → no lease,
        SSH/redirect unreachable). Allocate a real in-subnet host instead."""
        ns = net_by_name.get(net_name)
        if not ns:
            return cur, None  # unknown subnet -- best-effort, leave as-is
        subnet = ipaddress.IPv4Network(ns.cidr, strict=False)
        gw = ns.gateway
        claimed = _claimed.setdefault(net_name, {gw} if gw else set())

        def _ok(a: str | None) -> bool:
            try:
                ip = ipaddress.IPv4Address(a)
            except Exception:
                return False
            return (ip in subnet and a != gw and a not in claimed
                    and ip != subnet.network_address and ip != subnet.broadcast_address)

        if _ok(cur):
            claimed.add(cur)
            return cur, str(subnet.netmask)
        for host in subnet.hosts():
            a = str(host)
            if a == gw or a in claimed:
                continue
            claimed.add(a)
            return a, str(subnet.netmask)
        return cur, str(subnet.netmask)  # subnet exhausted -- fall back

    for nd in intent.nodes:
        vid = vm_id[nd.name]
        ports = {p.get("name"): p for p in fa.get_vm_ports(c, fid, vid)}
        # Management port: FS aims this node's access port-forwards at it. Set it
        # before install -- the flag is only honored by a full fabric install.
        want_mgmt_port = _mgmt_link(nd)
        for lk in nd.links:
            vp = ports.get(lk.port)
            if vp is not None:
                want = (lk is want_mgmt_port) if want_mgmt_port is not None \
                    else bool(lk.mgmt)
                if bool(vp.get("mgmt")) != want:
                    fa.set_port_mgmt(c, fid, vid, vp["id"], want)
                    reinstall_nodes.add(nd.name)
                    _say(f"set {nd.name}.{lk.port} mgmt={want} "
                         f"({'management port for ' + ','.join(nd.access) if want else 'not a management port'})")
            if lk.dhcp:
                if vp:
                    # Static DHCP: give the port a fixed FS-owned address in the
                    # link's subnet and let the System Host lease it. Set
                    # ``network`` to the switch's auto_address net so the native
                    # DHCP actually serves the lease (gateway/DNS scope).
                    srv = _native_device_id(lk.dhcp)
                    net = net_id.get(sw_aa.get(lk.switch)) or vp.get("network")
                    addr, sub_mask = (lk.ip, lk.netmask) if lk.ip else \
                        _valid_dhcp_addr(sw_aa.get(lk.switch), vp.get("ipv4addr"))
                    mask = lk.netmask or sub_mask or vp.get("ipv4netmask")
                    # Only a port whose reservation actually MOVES is worth
                    # writing, and only such a port earns a reinstall. See
                    # dhcp_reservation_differs -- fanning the reinstall out to
                    # every client of the DHCP device is how adding one node
                    # rebuilt an entire fabric.
                    if dhcp_reservation_differs(vp, addr=addr, mask=mask,
                                                srv=srv, net=net):
                        fa.set_port_ipv4(c, fid, vid, vp["id"], addr, mask,
                                         dhcp_server=srv, network=net)
                        dhcp_native_ids.add(srv)
                        dhcp_nodes_by_native.setdefault(srv, set()).add(nd.name)
                        _say(f"set {nd.name}.{lk.port} = DHCP via {lk.dhcp} "
                             f"({addr}, network={net})")
            elif lk.ip:
                if vp:
                    fa.set_port_ipv4(c, fid, vid, vp["id"], lk.ip, lk.netmask, "STA")
                    _say(f"set {nd.name}.{lk.port} = {lk.ip}")
            else:
                # auto_address link (no dhcp, no explicit ip): FS only auto-fills
                # the IP at VM CREATE, from whatever switch the port was first
                # cabled to -- and it will NOT auto-fill a static (STA) port that is
                # empty or carries a stale out-of-subnet IP (proven live: a cleared
                # STA port stays null through install → guest boots with no mgmt IP).
                # So WE must assign a valid in-subnet static when the port's IP
                # doesn't belong to its switch's auto_address net (missing, or left
                # over from a previous switch). Pick a free host from LIVE state so
                # it can't collide with other VMs even under --target.
                if vp and lk.trunk:
                    # A TRUNK port terminates no VLAN, so it must carry no
                    # untagged address -- assigning one here is how two trunk
                    # ports in the VLAN lab ended up with 10.100.0.2/.3 that the
                    # uplink drops. Step 4c already cleared them and turned FS
                    # address management off; don't undo it.
                    pass
                elif vp:
                    net_name = sw_aa.get(lk.switch)
                    ns = net_by_name.get(net_name)
                    cur = vp.get("ipv4addr")
                    if ns and (not cur or not _ip_in_cidr(cur, ns.cidr)):
                        addr = _alloc_static_ip(c, fid, ns)
                        if addr:
                            mask = str(ipaddress.IPv4Network(ns.cidr, strict=False).netmask)
                            fa.set_port_ipv4(c, fid, vid, vp["id"], addr, mask, "STA",
                                             network=net_id.get(net_name))
                            reinstall_nodes.add(nd.name)
                            _say(f"assigned static {addr} to {nd.name}.{lk.port} "
                                 f"(auto_address {net_name}; was {cur or 'empty'} -- FS "
                                 f"won't auto-fill a static port)")

        # A port the intent stopped declaring keeps its last address, and FS
        # still pushes that into the guest at install. Usually harmless -- but
        # NOT when it overlaps a subnet a declared port now holds, which is
        # exactly what a port renumber produces: move a link from port3 to port2
        # and both carry the old address, so FortiOS refuses the second one --
        # `Subnets overlap between 'port3' with primary IP of 'port2'`,
        # `Command fail. Return code -54`. The install then dies AFTER the guest
        # has booted and licensed, naming a port the intent never mentions.
        #
        # Only the overlap is cleared. An undeclared port on an unrelated subnet
        # is left alone: FS auto-addresses ports at VM create, so a node can
        # legitimately carry addresses the intent never spelled out, and wiping
        # those would strip working management IPs.
        for pname, vp in _stale_overlapping_ports(nd, ports):
            fa.clear_port_ipv4(c, fid, vid, vp["id"])
            reinstall_nodes.add(nd.name)
            _say(f"cleared {nd.name}.{pname} = {vp['ipv4addr']} (undeclared port "
                 f"overlapping a declared port's subnet)")

    # 5b. Custom port exposure (System Host port redirects). A node's `expose:`
    # publishes guest ports on the System Host's external IP. Gated pod-wide by
    # custom_rules_allowed, flipped once here. to_addr = the node's reachable
    # fabric IP (its VM port's ipv4addr); the host routes/NATs to it.
    #
    # A redirect is NOT like a VM's SSH/HTTPS access. Those are model vmaccess
    # rows that the guest's own install materialises into forwards. A redirect
    # is a rule on the SYSTEM HOST, and writing it to the model changes nothing
    # on the wire: `output` reports the endpoint, `plan` goes clean, and the
    # port answers nothing until the System Host itself is installed. So the
    # host is marked for install here and the bring-up below does it -- the same
    # path native DHCP changes already take, including the install_fabric that
    # rebuilds the VM forwards a host install tears down. Both halves have to be
    # automatic: an `expose:` that needs a remembered follow-up command is an
    # `expose:` that silently does not work.
    redirect_host_dev = None
    if any(nd.expose for nd in intent.nodes):
        flipped = fa.ensure_public_forwards_allowed(c, ("custom_rules_allowed",))
        _say(f"pod security: enabled {flipped} (custom port redirects)" if flipped
             else "pod security: custom_rules_allowed already on")
        host_dev = _native_device_id("System Host")
        redirects_changed = False
        for nd in intent.nodes:
            if not nd.expose:
                continue
            vid = vm_id[nd.name]
            ports = {p.get("name"): p for p in fa.get_vm_ports(c, fid, vid)}
            # to_addr: prefer the first declared link's port IP, else any port IP.
            addr = next((ports[lk.port].get("ipv4addr") for lk in nd.links
                         if ports.get(lk.port) and ports[lk.port].get("ipv4addr")), None)
            if not addr:
                addr = next((p.get("ipv4addr") for p in ports.values()
                             if p.get("ipv4addr")), None)
            if not addr:
                _say(f"node {nd.name}: expose skipped -- no resolved port IP yet")
                continue
            for ex in nd.expose:
                name = ex.get("name") or f"{nd.name}-{ex['socktype'].lower()}-{ex['from_port']}"
                changed = fa.ensure_port_redirect(
                    c, fid, device=host_dev, name=name,
                    from_port=ex["from_port"], to_addr=addr, to_port=ex["to_port"],
                    socktype=ex["socktype"])
                if changed:
                    redirects_changed = True
                    _say(f"node {nd.name}: redirect :{ex['from_port']}/{ex['socktype']} "
                         f"→ {addr}:{ex['to_port']}")

        # Measured: a device `synchronize` on the System Host does NOT publish a
        # redirect -- the rule stayed in the model through two applies and the
        # port never answered. The host has to be INSTALLED, which is what the
        # bring-up does with this.
        if redirects_changed or publish_redirects:
            redirect_host_dev = host_dev

    # 6. Prune (destructive -- opt-in).
    if prune:
        _prune(c, fid, intent, vm_id, sw_id, net_id, _say)

    # 7. Bring-up.
    summary: dict[str, Any] = {"fabric_id": fid, "booted": False}
    if boot:
        # Pre-flight: a node port's IP must belong to the network of the switch
        # it's cabled to. A stale out-of-subnet IP (e.g. 10.254.254.1 left over
        # after moving a port from OOB Mgmt onto a 203.0.113.0/24 switch) leaves
        # the guest unreachable on its segment → the System Host can't manage it
        # (FGT: 'no valid management interface' → limited mode). FS only
        # auto-addresses a port with NO IP, so it won't self-correct this. Fail
        # before install; override with allow_addr_mismatch.
        _boot_state = fa.read_fabric_state(c, fid)
        addr_bad = _port_switch_net_mismatches(intent, _boot_state)
        ip_bad = [m for m in addr_bad if m["reason"] == "ip"]
        net_bad = [m for m in addr_bad if m["reason"] == "network"]
        # network-field mismatch: loud WARNING (mostly GUI labeling; auto_address
        # ports get it corrected at addressing). Don't fail the install on it.
        for m in net_bad:
            _say(f"WARNING: {m['node']}.{m['port']} network field = {m['port_network']!r} "
                 f"but it's cabled to switch {m['switch']!r} ({m['expected_cidr']}) -- "
                 f"stale network association")
        # IP mismatch: FATAL -- the port is unreachable on its segment, so FS can't
        # manage the guest. (Override with allow_addr_mismatch.)
        if ip_bad and not allow_addr_mismatch:
            lines = "; ".join(f"{m['node']}.{m['port']}={m['ip']} cabled to "
                              f"{m['switch']!r} (network {m['expected_cidr']})"
                              for m in ip_bad)
            raise fa.FabricStudioAdminError(
                f"port/switch network mismatch -- {lines}. The port's IP is not in "
                f"its switch's network, so the guest is unreachable on that segment "
                f"(FS can't manage it). Fix the link/IP (a moved port keeps its old "
                f"IP -- set the right ip:, use dhcp:, or clear it so FS re-addresses), "
                f"or pass --allow-addr-mismatch.")
        if ip_bad:
            _say(f"WARNING: port/switch IP mismatch on {', '.join(m['node'] for m in ip_bad)} "
                 f"-- installing anyway (--allow-addr-mismatch)")

        # Pre-flight: FS manages every guest THROUGH the System Host, so a node
        # whose ports are all on floating segments (no host-uplinked switch) is
        # unreachable and never reaches post_boot_prepared (FGT: GatewayMethod SSH
        # never connects). The switch `mgmt` flag does NOT make a floating segment
        # reachable (proven by the Run-2 matrix). A node passes if ANY port is on a
        # host-uplinked switch -- a data port on a floating switch is fine. Fail
        # before install; override with allow_floating_mgmt.
        unmanageable = _unmanageable_nodes(intent, _boot_state)
        if unmanageable and not allow_floating_mgmt:
            raise fa.FabricStudioAdminError(
                f"node(s) {', '.join(unmanageable)} have no host-uplinked port -- "
                f"every declared link lands on a FLOATING switch (no System Host "
                f"port owns its gateway). FS manages guests through the System "
                f"Host, so these would never reach post_boot_prepared (FGT: the "
                f"GatewayMethod SSH never connects). Cable the management port to a "
                f"host-uplinked switch (check `fabric state` host_uplinked; a "
                f"host-uplinked *mgmt* net is fine -- egress not required for "
                f"management), or pass --allow-floating-mgmt.")
        if unmanageable:
            _say(f"WARNING: node(s) {', '.join(unmanageable)} have no host-uplinked "
                 f"port -- installing anyway (--allow-floating-mgmt); expect them to "
                 f"stay un-managed (no post_boot_prepared)")

        # Pre-flight: a FortiFlex-licensed node activates its license by reaching
        # FortiCare OUTBOUND. If it sits on a floating/mgmt-only segment with no
        # egress, the entitlement stays PENDING and the guest boots UNLICENSED
        # (eval → limited mode, no mgmt port, no forwards). Fail before installing
        # rather than producing a silently-broken VM. Override with allow_no_egress
        # (e.g. a fixed .lic that needs no phone-home, or egress the model can't see).
        flex_bad = _flex_nodes_without_egress(intent, _boot_state)
        if flex_bad and not allow_no_egress:
            raise fa.FabricStudioAdminError(
                f"FortiFlex node(s) {', '.join(flex_bad)} have no internet egress -- "
                f"every declared link lands on a floating switch, on the seeded "
                f"'Internet Access' switch (inert for every node type), or -- for a "
                f"non-appliance guest -- on the seeded OOB segment, which only "
                f"appliances get a default route from (see _switch_gives_egress). "
                f"FortiFlex activates the license by contacting FortiCare outbound, so "
                f"these would boot UNLICENSED (eval/limited mode). Cable them to a "
                f"switch YOU declare with host_uplink: true (check `fabric state` "
                f"host_uplinked / `fabric reach` egress), or pass --allow-no-egress "
                f"to install anyway.")
        if flex_bad:
            _say(f"WARNING: FortiFlex node(s) {', '.join(flex_bad)} have no egress -- "
                 f"installing anyway (--allow-no-egress); expect eval/limited mode")

        # Pre-flight (advisory): a FortiFlex node WITH egress still won't activate
        # if its egress net carries no DNS -- FortiCare is resolved by hostname, so
        # a default route alone leaves the entitlement PENDING → eval/limited mode
        # (the soc-demo FGT failure: gateway but no dns1 → 'License invalid').
        # Never fatal (DNS may come from a per-VM Custom resolver), but loud.
        dns_bad = _flex_nodes_without_dns(intent, _boot_state)
        if dns_bad:
            _say(f"WARNING: FortiFlex node(s) {', '.join(dns_bad)} have egress but "
                 f"their egress network has no DNS (dns1) -- FortiCare won't resolve, "
                 f"so the flex entitlement may never activate (eval/limited mode). "
                 f"Add `dns1:` to the egress network (or set a per-VM Custom DNS).")

        # Pre-flight: hugepage capacity for everything about to be (re)installed.
        # Cheap to check, and the failure it prevents costs hours (see
        # _hugepage_shortfall). Advisory-by-override, like the guards below.
        _rt_ids = {str(v.get("id")) for v in fa.runtime_vms(c, fid)}
        _hp_nodes = sorted(set(reinstall_nodes) | {nd.name for nd in intent.nodes
                                                   if str(vm_id.get(nd.name)) not in _rt_ids})
        hp_msg = _hugepage_shortfall(c, intent, _hp_nodes, vm_id)
        if hp_msg and not allow_hugepage_overcommit:
            raise fa.FabricStudioAdminError(
                hp_msg + " -- or pass --allow-hugepage-overcommit to try anyway.")
        if hp_msg:
            _say(f"WARNING: {hp_msg} -- installing anyway "
                 f"(--allow-hugepage-overcommit); expect power-on to fail")

        # Pre-flight: an image that only does DHCP must not be given a static link.
        # Declarative and pod-independent, so it is a hard failure with no override
        # -- the combination cannot work, it can only look like it did.
        img_bad = _image_addressing_violations(intent)
        if img_bad:
            raise fa.FabricStudioAdminError("; ".join(img_bad))

        # A `dhcp:` link needs a DHCP SERVER on the segment, not just the
        # reservation this reconciler writes. `dhcp_service` lives on the System
        # Host port and FS seeds it only on the OOB Mgmt uplink, so a reservation
        # elsewhere installs cleanly, is never served, and the guest comes up
        # with no address at all -- which reads as a dead VM.
        #
        # This used to be a hard failure telling the operator to move the link.
        # It doesn't have to be: `dhcp_service` is a writable field on the host
        # port, and turning it on is the same class of edit as repointing a port
        # for a host uplink, which apply already does. Probed live: with it
        # enabled on the segment's uplink, an LXC guest got its lease, a default
        # route, and internet egress. So switch it on and heal the segment.
        # allow_dhcp_service_off keeps the old behaviour (warn, change nothing).
        dhcp_bad = _dhcp_switches_without_service(intent, _boot_state)
        if dhcp_bad and allow_dhcp_service_off:
            for m in dhcp_bad:
                _say(f"WARNING: {m} -- leaving it off (--allow-dhcp-service-off); "
                     f"expect the guest to come up with no address")
        elif dhcp_bad:
            fixed = _enable_dhcp_service(c, fid, intent, _boot_state, _say)
            if not fixed:
                raise fa.FabricStudioAdminError(
                    "; ".join(dhcp_bad) + " -- and the DHCP server could not be "
                    "enabled on the segment's System Host port. Move the link to a "
                    "switch whose host port serves DHCP, or pass "
                    "--allow-dhcp-service-off to install anyway.")
            # dhcp_table/DHCP-service edits only reach dnsmasq via a System Host
            # install, which the DHCP-diff step below performs.

        # Switch sync: a switch that got a new port/cable (e.g. a node cabled to a
        # fresh switchport) needs its runtime synced or the new port + cable aren't
        # LIVE -- the cabled VM then has no L2 link to the segment (FGT → System
        # Host unreachable → 'no valid management interface'). A targeted node
        # apply installs only the node VM, so we must sync any switch that still
        # has a model→runtime diff before bringing the node up.
        diff_devs = (fa.fabric_diff(c, fid).get("detail") or {}).get("devices") or {}
        for s in _boot_state["switches"]:
            if str(s["id"]) in diff_devs:
                _say(f"synchronize switch {s['name']!r} (model→runtime diff: new port/cable)")
                # Best-effort: a FLOATING switch (no host uplink → no System Host
                # port) has no runtime.device to sync, so FS rejects the call with
                # HTTP 400 "No 'model.device' matching <id>" (rcode 246). That must
                # NOT abort the whole apply -- the new cable is still brought live by
                # the install_fabric / install_vm below. Only host-uplinked switches
                # have a runtime device that actually needs this pre-sync.
                try:
                    tk = fa.synchronize_device(c, s["id"])
                    if tk.get("id"):
                        fa.wait_device_task(c, tk["id"], timeout_s=300, raise_on_error=False)
                except Exception as e:
                    _say(f"  switch {s['name']!r} has no runtime device to sync "
                         f"(floating segment?) -- skipping, install will cable it: {e}")

        # VLAN reprogram: a switchport whose vlan/mode/trunk changed needs the
        # SWITCH reinstalled, not synchronized. `synchronize` updates the runtime
        # row -- GET runtime/switch/{id}/port reports the new tag -- while the OVS
        # bridge keeps the old config, so the row reads correct and traffic
        # follows the previous VLANs. Verified both ways on a live pod: narrowing
        # a trunk did not block the removed VLAN and widening it back did not
        # restore it, until this install ran. Skipped on a fabric with no runtime
        # at all: the install_fabric below creates the bridge from the model.
        if reinstall_switches and fa.runtime_vms(c, fid):
            for _swid in sorted(reinstall_switches, key=str):
                _nm = next((x["name"] for x in _boot_state["switches"]
                            if str(x["id"]) == str(_swid)), _swid)
                _say(f"reinstall switch {_nm!r} (VLAN change -- synchronize does "
                     f"NOT reprogram OVS)")
                try:
                    _t = fa.install_switch(c, _swid)
                    if _t.get("id"):
                        fa.wait_device_task(c, _t["id"], timeout_s=300,
                                            raise_on_error=False)
                except Exception as e:
                    _say(f"  switch {_nm!r} VLAN reinstall failed: {e}")

        # Infra that exists in the model but has no runtime device carries no
        # traffic, and every other check in this function will still say the
        # fabric converged. Heal what is cheap to heal; refuse to pretend about
        # the rest. (See _infra_needing_install for the live evidence.)
        _dead_ports, _dead_switches = _infra_needing_install(c, fid, intent)
        if _dead_ports and fa.runtime_vms(c, fid):
            # A created uplink port goes live from a System Host install --
            # guests are untouched by it, so just do it.
            _say(f"System Host port(s) {', '.join(_dead_ports)} have no runtime "
                 f"(newly created) -- installing the System Host to bring them up")
            _t = fa.install_device(c, fa.get_system_host(c, fid)["id"])
            if _t.get("id"):
                fa.wait_device_task(c, _t["id"], timeout_s=boot_timeout_s)
        # Nodes whose guest came up from its image during THIS apply (first
        # install, full redeploy, newly added VM, or destroy→install). Only these
        # get license redemption in the guest phase -- see summary["fresh"].
        fresh: set[str] = set()
        if _dead_switches and fa.runtime_vms(c, fid):
            # A switch minted after the fabric was installed has no runtime
            # device, and only install_fabric creates one -- which redeploys
            # every guest. That is not a decision this function gets to make
            # silently, so it is opt-in.
            msg = (f"switch(es) {', '.join(_dead_switches)} exist in the model but have "
                   f"no runtime device -- FS only creates one during a full "
                   f"install_fabric, so guests cabled to them come up with the NIC "
                   f"link DOWN (address and gateway injected, nothing reachable). "
                   f"A full install REDEPLOYS every guest in this fabric "
                   f"(destroy → install; guest state is lost).")
            if not allow_full_redeploy:
                raise fa.FabricStudioAdminError(
                    msg + " Re-run with --full-redeploy to do it, or add the switch "
                          "before the fabric is first installed.")
            _say(f"WARNING: {msg} -- redeploying (--full-redeploy)")
            _t = fa.install_fabric(c, fid, allow_running=True)
            if _t.get("id"):
                fa.wait_task(c, _t, timeout_s=boot_timeout_s, label="install_fabric (new switch)")
            fa.wait_running(c, fid, timeout_s=boot_timeout_s)
            fresh.update(n.name for n in intent.nodes)

        runtime = fa.runtime_vms(c, fid)
        rebuilt: set[str] = set()
        if not runtime:
            _say("no runtime -- install_fabric + wait booted ...")
            task = fa.install_fabric(c, fid)
            if task.get("id"):
                fa.wait_task(c, task, timeout_s=boot_timeout_s, label="install_fabric")
            fa.wait_running(c, fid, timeout_s=boot_timeout_s)
            fresh.update(n.name for n in intent.nodes)
        else:
            # Native DHCP devices first: a `dhcp:` port changed the System Host's
            # DHCP config (it serves the lease), so it has a pending model→runtime
            # diff. The fabric diff's verb for a dhcp_table change is **install**,
            # NOT synchronize -- a sync does not push dhcp_table into the running
            # dnsmasq (proven live: after a sync the diff still showed
            # devices.64.dhcp_table.938 = "install" and the guest got no lease).
            # Install it BEFORE the guest boots so the reservation is ready when the
            # guest does DHCP. Diff-driven, so it's idempotent (no diff → no install).
            # FS always syncs the System Host FIRST, one device at a time, so we
            # install any native DHCP device with a pending dhcp_table diff before
            # the guests. We heal EVERY pending native diff -- both reservations this
            # apply changed (dhcp_native_ids) AND standing orphan diffs with no intent
            # change (e.g. a reservation left after a VM was deleted out-of-band) -- so
            # the fabric never sits in a "host wants sync" state that a stray GUI sync
            # would resolve destructively.
            host_installed = False
            # WHICH host devices we installed, not merely THAT we installed one.
            # The forward rebuild below synchronizes exactly these rather than
            # reaching for a fabric-wide install; without the ids it had nothing
            # to aim at and took the sledgehammer.
            installed_host_devs: set[Any] = set()
            dhcp_host_installs = set(fa.devices_needing_dhcp_install(c, fid))
            for did in sorted(dhcp_host_installs):
                _say(f"install native DHCP device {did} (System Host) -- dhcp_table diff")
                t = fa.install_device(c, did)
                if t.get("id"):
                    fa.wait_device_task(c, t["id"], timeout_s=boot_timeout_s)
                host_installed = True
                installed_host_devs.add(did)
                # A guest that DHCPs off this device booted before the lease
                # existed → it never acquired an address. Reinstall it so it
                # boots into the now-served reservation (fresh DHCP at boot).
                for n in dhcp_nodes_by_native.get(did, set()):
                    reinstall_nodes.add(n)

            # Port redirects also need the System Host installed, but NOTHING
            # about a redirect invalidates a guest's DHCP lease -- so this must
            # NOT reuse the loop above.
            #
            # It did, once, and the cost was the whole point of writing this
            # down: folding the redirect into `devices_needing_dhcp_install`
            # inherited the reinstall-every-DHCP-client behaviour, and in a
            # topology where every guest DHCPs off the System Host that means
            # every guest is destroyed and rebuilt from its golden image.
            # Publishing one LDAP port wiped a promoted domain controller --
            # AD DS gone, the forest gone, the seeded users gone, and the
            # domain-joined workstation left looking for a DC that no longer
            # existed. A guest reinstall is the most destructive thing this
            # function can do and it must never be a side effect of a
            # networking change.
            if redirect_host_dev is not None and redirect_host_dev not in dhcp_host_installs:
                _say(f"install System Host device {redirect_host_dev} "
                     "(publish port redirects; guests untouched)")
                t = fa.install_device(c, redirect_host_dev)
                if t.get("id"):
                    fa.wait_device_task(c, t["id"], timeout_s=boot_timeout_s)
                host_installed = True
                installed_host_devs.add(redirect_host_dev)

            # Model-only edits → synchronize each VM (cheap, no reboot); freshly
            # created VMs with no runtime row get an install_vm.
            rt_ids = {str(v.get("id")) for v in runtime}
            install_task: dict[str, Any] = {}   # node → install task id (for log forensics)
            # A new VM installed into a RUNNING fabric knocks out the existing
            # guests' external port forwards; see the System Host install below.
            new_vm_installed = False
            # Nodes this apply actually DESTROYED and rebuilt -- not the nodes it
            # planned to. The provision phase needs the truth: a guest that came
            # back factory-fresh must not be skipped as "already provisioned".
            # See summary["rebuilt"].
            for nd in intent.nodes:
                vid = vm_id[nd.name]
                if str(vid) not in rt_ids:
                    _say(f"install_vm {nd.name} (new in running fabric)")
                    t = fa.install_vm(c, vid)
                    install_task[nd.name] = (t or {}).get("id")
                    fa.wait_vm_ready(c, vid, timeout_s=boot_timeout_s,
                                     task_id=(t or {}).get("id"))
                    fresh.add(nd.name)
                    new_vm_installed = True
                elif nd.name in reinstall_nodes:
                    # Discard guard: refuse to destroy a builder node that has a
                    # completed-but-unconsumed detached build on its disk (the
                    # sentinel is ground truth; see config.build_discard_guard).
                    # Leave the VM installed and let the rest of the apply proceed.
                    if discard_guard:
                        reason = discard_guard(nd.name)
                        if reason:
                            _say(f"refusing reinstall of {nd.name}: {reason}")
                            install_task[nd.name] = "BLOCKED:" + reason[:120]
                            continue
                    # cpu/memory/disk/cable/config edits only take effect on a
                    # full rebuild.
                    _say(f"reinstall {nd.name} (resource change: destroy → install)")
                    rebuilt.add(nd.name)
                    fa.destroy_vm(c, vid)
                    fa.wait_vm_gone(c, vid, timeout_s=boot_timeout_s)
                    t = fa.install_vm(c, vid)
                    install_task[nd.name] = (t or {}).get("id")
                    fa.wait_vm_ready(c, vid, timeout_s=boot_timeout_s,
                                     task_id=(t or {}).get("id"))
                else:
                    t = fa.synchronize_device(c, vid)
                    if t.get("id"):
                        fa.wait_device_task(c, t["id"], timeout_s=300)
            # Installing the System Host tears down EVERY VM's external port forward
            # (SSH 11000+idx / HTTPS 13000+idx). Reinstalled guests above rebuilt
            # their own forwards, but a host-only install (no guest reinstall) leaves
            # them all down, so something has to put them back.
            #
            # THIS USED TO CALL install_fabric(allow_running=True), justified by a
            # comment calling it an "idempotent no-op for already-installed VMs".
            # That is false, and fs_admin.install_fabric's own docstring says so in
            # as many words: an empty-body install "redeploys every VM in the fabric
            # -- it powers off and reinstalls running guests". So the cheap-sounding
            # tail of an ADDITIVE apply quietly redeployed the whole fabric. It cost
            # a live patch-pipeline run: adding one node with `dhcp: System Host`
            # produced a dhcp_table diff → host install → this rebuild → every guest
            # redeployed, none of which appeared anywhere in `plan`.
            #
            # That is precisely the hazard the redirect branch above already refuses
            # to commit ("a guest reinstall ... must never be a side effect of a
            # networking change"), and which the new-switch branch treats as opt-in
            # ("not a decision this function gets to make silently"). Rebuilding port
            # forwards is a networking change; it gets the same rule.
            #
            # So the rebuild is aimed at the System Host only, never the fabric.
            #
            # It must be an INSTALL of the host, run AFTER the new guests are
            # installed -- a synchronize is not enough. Measured on a running
            # FortiSOAR fabric adding one LXC: host install (dhcp_table) →
            # install_vm <new> → synchronize host left EVERY external SSH forward
            # (11000, 11001) timing out, while the guests stayed healthy and
            # reachable through the pod jump. A manual install of the System Host
            # brought every forward back with no guest reboot (the SOAR's uptime
            # was unchanged). And installing a new VM breaks the existing forwards
            # even when nothing else touched the host, so this runs whenever a
            # new VM went in, not only after a DHCP/redirect host install.
            # A host install never reinstalls a guest (the DHCP branch above
            # reinstalls its own reservation holders explicitly, not FS).
            if host_installed or new_vm_installed:
                _host_devs = sorted(installed_host_devs, key=str)
                if not _host_devs:
                    try:
                        _host_devs = [_native_device_id("System Host")]
                    except Exception as e:
                        _say(f"warning: could not resolve the System Host to rebuild "
                             f"port forwards ({e}); install it manually if a forward is down")
                for _hd in _host_devs:
                    _why = "new guest installed" if new_vm_installed else "host changed"
                    _say(f"rebuild port forwards: install System Host device {_hd} "
                         f"({_why}; no guest reinstall)")
                    _st = fa.install_device(c, _hd)
                    if _st.get("id"):
                        fa.wait_device_task(c, _st["id"], timeout_s=boot_timeout_s)
                # IF A FORWARD IS STILL DOWN, INSTALL THAT VM -- NOT THE FABRIC.
                #
                # install_fabric is the wrong tool at every scale here. A VM's
                # port forward is rebuilt by installing THAT VM (which is why the
                # per-VM bring-up above notes that "reinstalled guests rebuilt
                # their own forwards"), so the remedy for N broken forwards is N
                # install_vm calls, not one fabric-wide redeploy of everything
                # including the N guests that were fine.
                #
                # The difference is not merely efficiency. install_fabric powers
                # off and reinstalls every running guest, so using it to repair
                # one forward destroys unrelated state -- that is precisely how a
                # live patch-pipeline lost Fleet's database while adding an
                # unrelated node. Per-VM keeps the blast radius equal to the
                # problem.
                #
                # Still opt-in, because installing a VM IS destructive to that
                # guest. But it is now a scalpel with a named list, so the
                # operator can see exactly which guests pay for the repair.
                if allow_full_redeploy:
                    _targets = [(nd.name, vm_id[nd.name]) for nd in intent.nodes
                                if nd.name in vm_id]
                    _say(f"--full-redeploy: reinstalling {len(_targets)} guest(s) "
                         f"INDIVIDUALLY to force forwards back up "
                         f"({', '.join(n for n, _ in _targets)})")
                    for _nm, _vid in _targets:
                        _say(f"  install_vm {_nm} (forward rebuild)")
                        _t = fa.install_vm(c, _vid)
                        fa.wait_vm_ready(c, _vid, timeout_s=boot_timeout_s,
                                         task_id=(_t or {}).get("id"))
                        rebuilt.add(_nm)
                else:
                    # Said out loud rather than silently repaired. The
                    # access-check below reports which forwards actually answer,
                    # so the operator can reinstall just those nodes.
                    _say("note: port forwards were rebuilt by installing the "
                         "System Host, with no guest reinstall. If a forward is "
                         "still down, install the System Host again (pod UI) "
                         "before anything else -- reinstalling a node wipes that "
                         "guest, and a fabric-wide install is never the right "
                         "repair for a port forward.")
            fa.wait_running(c, fid, timeout_s=boot_timeout_s)
            # License assignment is async and lands after powered+post_boot_prepared
            # (esp. FortiFlex). Wait for each FS-licensed node's status.licensed to flip;
            # skip FLEX-GUEST (they license post-boot in the guest phase).
            # Warn (don't fail) on timeout -- licensing can be slow/intermittent.
            lic_status: dict[str, bool] = {}
            for nd in intent.nodes:
                if nd.license and nd.license.fs_mode().upper() != "NONE":
                    st = fa.wait_vm_licensed(c, vm_id[nd.name], timeout_s=min(300, boot_timeout_s),
                                             progress=_say)
                    ok = bool(st.get("licensed"))
                    lic_status[nd.name] = ok
                    if ok:
                        _say(f"node {nd.name}: licensed=True")
                    else:
                        # Surface WHY: the install task's console log carries the
                        # real reason (e.g. "License invalid due to exceeding
                        # allowed N CPUs" → flex didn't activate, guest on eval).
                        reason = _license_failure_reason(c, install_task.get(nd.name))
                        _say(f"node {nd.name}: licensed=False (check FS pool/FortiFlex)"
                             + (f"\n    install log: {reason}" if reason else ""))
            if lic_status:
                summary["licensed"] = lic_status

            # Live-probe each node's PUBLIC accesses (SSH/HTTPS/…) at their
            # external port-forwards. A node can be powered yet have no working
            # forward -- e.g. an unlicensed FGT in limited mode never gets a mgmt
            # port, so FS skips the reverse-proxy. Warn (don't fail): licensing is
            # best-effort and a handoff may finish setup later. Use `fabric verify`
            # for a standalone re-check.
            access_check = _validate_node_accesses(c, fid, intent, vm_id, _say)
            if access_check:
                summary["access_check"] = access_check
        summary["booted"] = True
        # Hand the provision phase the nodes whose guest state was just thrown
        # away. It cannot work this out for itself: a reinstall reuses the same
        # model VM row AND the same firmware, so the journal's device-identity
        # token (`vm:<id>/fw:<fw>`) is byte-identical before and after, every
        # entry still validates, and every item on a factory-fresh guest is
        # skipped as already done. That is how a fabric comes back looking
        # converged with the domain controller holding no forest.
        if rebuilt:
            summary["rebuilt"] = sorted(rebuilt)
        # Every node whose guest is factory-fresh after this apply. The guest
        # phase redeems licenses only on these, so adding one node never
        # re-licenses (or re-runs first-boot setup on) the ones already running.
        summary["fresh"] = sorted(fresh | rebuilt)

    # 8. Re-read + assert convergence. Once booted, hold the topology to the
    #    "booted + reachable" bar (every declared port has a reachable IP);
    #    a model-only (--no-boot) converge checks resources/links only.
    summary["convergence"] = assert_converged(c, fid, intent,
                                              require_reachable=summary["booted"])

    # 9. Builds the images phase (0a) deferred because the builder was down --
    #    it runs before boot. Now that this apply has booted the fabric, run them.
    if summary["booted"] and summary["convergence"].get("ok"):
        built = images.run_deferred_builds(c, intent, image_ids, _say)
        if built:
            summary["built_images"] = built
    return summary


def _license_failure_reason(c, task_id) -> str:
    """Best-effort one-liner explaining why a node didn't license: scan the
    install task's console log for the most telling line (license / management
    port). Returns '' if there's no task id or nothing useful in the log."""
    if not task_id:
        return ""
    try:
        log = fa.get_task_log(c, task_id)
    except Exception:
        return ""
    if not log:
        return ""
    needles = ("license invalid", "no license", "exceeding allowed",
               "no valid static management port", "no management port",
               "access to the vm is limited")
    hits = [ln.strip() for ln in log.splitlines()
            if any(nl in ln.lower() for nl in needles)]
    return " | ".join(dict.fromkeys(hits))[:300] if hits else ""


def _validate_node_accesses(c, fid, intent: Intent, vm_id, _say) -> dict[str, Any]:
    """Live-probe every managed node's PUBLIC accesses at their external
    port-forwards (SSH banner / TLS handshake / TCP connect). Emits a warning per
    unreachable forward and returns ``{node: [{type, port, ok, detail}, …]}``.
    Pure reporting -- never raises, never fails the apply."""
    from urllib.parse import urlparse
    host = urlparse(getattr(c, "server", "") or "").hostname or getattr(c, "server", "")
    report: dict[str, Any] = {}
    for nd in intent.nodes:
        vid = vm_id.get(nd.name)
        if vid is None:
            continue
        try:
            probes = fa.probe_vm_accesses(c, fid, vid, host)
        except Exception as e:
            _say(f"access-check {nd.name}: skipped ({type(e).__name__})")
            continue
        if not probes:
            continue
        report[nd.name] = probes
        bad = [p for p in probes if not p["ok"]]
        if bad:
            for p in bad:
                _say(f"access-check {nd.name}: {p['type']} UNREACHABLE "
                     f"({host}:{p['port']} -- {p['detail']})")
        else:
            kinds = ", ".join(p["type"] for p in probes)
            _say(f"access-check {nd.name}: ok ({kinds})")
        # A plain-HTTP backend behind access:[HTTPS] (TLS→TLS proxy) returns 502
        # because the proxy expects TLS on :443 but the guest serves plain HTTP.
        # The TLS handshake to the external port succeeds (the proxy terminates
        # TLS), so the probe above shows ok -- but the app is unreachable. Probe
        # the guest's backend port directly to detect the mismatch and suggest
        # HTTPS2HTTP (FS terminates TLS, proxies to plain-HTTP :80).
        for p in probes:
            if p["type"] == "HTTPS" and p["ok"]:
                detail = _probe_https_backend(c, fid, nd, vm_id, host, p["port"])
                if detail:
                    _say(f"access-check {nd.name}: WARNING -- HTTPS access "
                         f"reaches a plain-HTTP backend ({detail}). Use "
                         f"`access: [HTTPS2HTTP]` instead of HTTPS to let FS "
                         f"terminate TLS and proxy to the guest's :80.")
    return report


def _probe_https_backend(c, fid, nd, vm_id, host, ext_port):
    """Probe whether a guest behind an HTTPS access serves plain HTTP on :443.
    Connects to the guest's internal IP:443 and checks if the response looks like
    plain HTTP (not a TLS ServerHello). Returns a short diagnostic string when the
    backend is plain HTTP, or '' when it's correctly TLS or unreachable."""
    import socket
    import ssl
    ports = {}
    try:
        ports = {p.get("name"): p for p in fa.get_vm_ports(c, fid, vm_id.get(nd.name, 0))}
    except Exception:
        return ""
    addr = next((p.get("ipv4addr") for p in ports.values() if p.get("ipv4addr")), None)
    if not addr:
        return ""
    try:
        # Try a TLS handshake to the guest's :443 directly (bypass the proxy).
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((addr, 443), timeout=3) as raw:
            with ctx.wrap_socket(raw, server_hostname=nd.name) as tls:
                return ""  # TLS handshake succeeded -- backend is genuinely TLS
    except ssl.SSLError:
        return f"{addr}:443 did not accept TLS"
    except Exception:
        pass
    # The guest:443 is not TLS. Check if it's plain HTTP by sending a GET.
    try:
        with socket.create_connection((addr, 443), timeout=3) as raw:
            raw.sendall(b"GET / HTTP/1.0\r\nHost: x\r\n\r\n")
            resp = raw.recv(128)
            if resp[:4] in (b"HTTP", b"http"):
                return f"{addr}:443 serves plain HTTP"
    except Exception:
        pass
    return ""


def _prune_undeclared_cables(c, fid, intent: Intent, vm_id, sw_id, _say) -> set[str]:
    """Delete cables on managed-node ports that land on a MANAGED switch but
    aren't in the node's declared ``links:``. Returns the set of node names whose
    cabling changed (caller reinstalls them -- a cable edit is model-only and only
    takes effect on a rebuild). Leaves cables to unmanaged switches (e.g. the
    FS-auto OOB-mgmt segment) untouched."""
    managed_switch_ids = {str(s) for s in sw_id.values()}
    declared_ports = {nd.name: {lk.port for lk in nd.links} for nd in intent.nodes}
    vid_to_name = {vm_id[nd.name]: nd.name for nd in intent.nodes}
    changed: set[str] = set()
    st = fa.read_fabric_state(c, fid)
    for lk in st["links"]:
        name = vid_to_name.get(lk["vm_id"])
        if name is None:                                   # not a managed node
            continue
        if str(lk["switch_id"]) not in managed_switch_ids:  # unmanaged switch (OOB) -- leave
            continue
        if lk["vm_port_name"] in declared_ports.get(name, set()):  # declared -- keep
            continue
        cable_id = lk.get("cable_id")
        if cable_id is None:
            continue
        fa.delete_cable(c, fid, cable_id)
        _say(f"pruned stray cable {name}.{lk['vm_port_name']} → switch {lk['switch_id']} "
             f"(not in intent links)")
        changed.add(name)
    return changed


def _prune(c, fid, intent: Intent, vm_id, sw_id, net_id, _say) -> None:
    """Delete live resources the intent no longer declares. Order matters:
    nodes (+ their runtime) → switches → networks, so FK references clear first.

    Pod-seeded shared infra (``SEEDED_SHARED_NAMES``) and any resource flagged
    ``protected: true`` are NEVER deleted -- Terraform ``prevent_destroy``. This
    is the guard behind the "never --prune on a shared pod" footgun: the seeded
    Internet/ISP/OOB Mgmt nets+switches are referenced by name, so they're absent
    from ``net_id``/``sw_id`` and would otherwise be pruned out from under every
    other tenant.

    VM prune is **best-effort per VM** (aligned with ``_destroy_locked``): one
    stuck VM logs and continues rather than aborting before switches/networks."""
    # Names the intent itself marks protected, plus the built-in seeded set.
    _norm = lambda nm: re.sub(r"\s+", " ", nm.strip().lower())
    protected_nets = {_norm(s.name) for s in intent.networks if s.protected}
    protected_sws = {_norm(s.name) for s in intent.switches if s.protected}
    protected_vms = {_norm(n.name) for n in intent.nodes if n.protected}
    st = fa.read_fabric_state(c, fid)
    keep_vms = set(vm_id.values())
    for v in st["vms"]:
        if v["id"] not in keep_vms:
            if _is_protected_name(v.get("name"), protected_vms):
                _say(f"prune: KEEPING protected node {v.get('name')!r} (id {v['id']})")
                continue
            _say(f"prune node {v['name']} (id {v['id']})")
            try:
                if fa.get_vm_runtime_state(c, v["id"])["exists"]:
                    fa.destroy_vm(c, v["id"]); fa.wait_vm_gone(c, v["id"])
                fa.delete_vm(c, fid, v["id"])
            except Exception as exc:
                _say(f"  (node {v.get('name')} not pruned: {exc})")
    # Routers the intent does not declare. An FS-seeded router left cabled into
    # our segments is undeclared infrastructure that can hold a gateway address
    # and black-hole the fabric (see _lint_topology). Uncable first, then delete:
    # a router with no cables is inert even if the delete is refused.
    declared_routers = {_norm(r.name) for r in intent.routers}
    protected_routers = {_norm(r.name) for r in intent.routers if r.protected}
    for r in (st.get("routers") or []):
        if _norm(r.get("name") or "") in declared_routers:
            continue
        if _is_protected_name(r.get("name"), protected_routers):
            _say(f"prune: KEEPING protected router {r.get('name')!r} (id {r['id']})")
            continue
        _say(f"prune router {r.get('name')} (id {r['id']}) -- not declared in intent")
        for rp in (r.get("ports") or []):
            if rp.get("cable"):
                try:
                    fa.delete_cable(c, fid, rp["cable"])
                    _say(f"  uncabled {r.get('name')}.{rp.get('name')}")
                except Exception as exc:
                    _say(f"  (uncable {rp.get('name')} failed: {exc})")
        try:
            fa.delete_router(c, fid, r["id"])
        except Exception as exc:
            _say(f"  (router {r.get('name')} left uncabled, delete failed: {exc})")

    keep_sw = set(sw_id.values())
    for s in st["switches"]:
        if s["id"] not in keep_sw and (s.get("vm_type") == "SW"):
            if _is_protected_name(s.get("name"), protected_sws,
                                  SEEDED_SHARED_SWITCH_NAMES):
                _say(f"prune: KEEPING protected switch {s['name']!r} (id {s['id']})")
                continue
            _say(f"prune switch {s['name']} (id {s['id']})")
            fa.delete_switch(c, fid, s["id"])
    keep_net = set(net_id.values())
    for n in st["networks"]:
        if n["id"] not in keep_net:
            if _is_protected_name(n.get("name"), protected_nets,
                                  SEEDED_SHARED_NETWORK_NAMES):
                _say(f"prune: KEEPING protected network {n['name']!r} (id {n['id']})")
                continue
            _say(f"prune network {n['name']} (id {n['id']})")
            fa.delete_network(c, fid, n["id"])


# ── Reachability ─────────────────────────────────────────────────────────────
# "Booted + model-converged" isn't the whole story -- the doc's bar is "every
# node port has a reachable IP". Reachability is computed from the live graph
# (no SSH): we reuse the repo's `topology.py` (Network/Port graph + BFS
# `reachable()`) so the logic stays in one tested place. Empirical ping (jump-SSH
# into the guest) is the heavier `tools/fs_lxc_matrix.py` path; this is the
# cheap, deterministic, offline-testable prediction that gates convergence.

@dataclass
class ReachRow:
    """One node-port's reachability verdict -- readable matrix row."""
    node: str
    port: str
    ip: str | None
    network: str | None
    switch: str | None
    routable: bool          # the switch is host-uplinked (a gateway sits on it)
    egress: bool            # routable AND not the OOB segment (FS injects a route)
    ok: bool                # has an IP on a known fabric network
    # The switchport's VLAN: an access tag, or "trunk 100,200". None = untagged.
    # An address on the right subnet and the wrong VLAN is unreachable, so the
    # row is incomplete without it.
    vlan: str | None = None

    def __str__(self) -> str:
        flag = "ok  " if self.ok else "MISS"
        if self.ok and self.vlan and self.vlan.startswith("trunk") and not self.ip:
            flag = "trnk"          # no address, by design
        tag = "egress" if self.egress else ("routable" if self.routable else "isolated")
        vlan = f" vlan={self.vlan}" if self.vlan else ""
        return (f"  [{flag}] {self.node}.{self.port:<6} {self.ip or '-':<15} "
                f"net={self.network or '-'} sw={self.switch or '-'}{vlan} ({tag})")


def _plan_switchport_vlans(intent: Intent, state: dict[str, Any]) -> list[Change]:
    """VLAN drift between the intent's ``vlan:``/``trunk:`` and the live
    switchports, as plan Changes. Pure -- diffs a state snapshot, no pod calls.

    Also flags an untagged address sitting on a trunk port: FS auto-addresses any
    cabled port with no IP at install, so one appears on its own and is then
    dropped at the uplink while the guest looks configured."""
    out: list[Change] = []
    vm_by_name = {v["name"]: v for v in state["vms"]}
    port_row = {}
    for sw in state["switches"]:
        for sp in sw.get("ports") or []:
            port_row[sp["id"]] = sp
    sp_for = {(lk["vm_id"], lk["vm_port_name"]): lk["switch_port"] for lk in state["links"]}
    for nd in intent.nodes:
        vm = vm_by_name.get(nd.name)
        if not vm:
            continue                      # a node still to be created
        vp_by_name = {vp["name"]: vp for vp in vm.get("ports", [])}
        for lk in nd.links:
            mode = lk.switchport_mode
            if mode is None:
                continue
            sp = port_row.get(sp_for.get((vm["id"], lk.port)))
            if sp is None:
                continue                  # not cabled yet -- the cabling change covers it
            want = ("trunk", 0, format_trunk(lk.trunk)) if mode == "trunk" \
                else ("access", int(lk.vlan or 0), "")
            cur = (str(sp.get("mode") or ""), int(sp.get("vlan") or 0),
                   str(sp.get("trunk") or ""))
            if cur != want:
                out.append(Change("update", "switchport", f"{nd.name}.{lk.port}",
                                  f"mode={cur[0] or '-'}/vlan={cur[1]}/trunk={cur[2] or '-'} → "
                                  f"mode={want[0]}/vlan={want[1]}/trunk={want[2] or '-'} "
                                  f"(switch reinstall)"))
            vp = vp_by_name.get(lk.port) or {}
            if mode == "trunk" and (vp.get("ipv4addr") or vp.get("auto_config") is not False):
                out.append(Change("update", "switchport", f"{nd.name}.{lk.port}",
                                  f"clear untagged address {vp.get('ipv4addr') or '-'} on a "
                                  f"trunk port + stop FS auto-addressing it"))
    return out


def _apply_switchport_vlans(c: FabricStudioClient, fid: int | str, intent: Intent,
                            vm_id: dict[str, Any], sw_id: dict[str, Any],
                            _say) -> dict[str, bool]:
    """Program every declared ``vlan:``/``trunk:`` onto the switchport its link
    is cabled to. Returns ``{switch_name: changed?}`` -- a changed switch must be
    REINSTALLED (see ``fa.install_switch``), not synchronized.

    Only ports a link actually declares are touched. A link with neither field
    is left alone: an untouched switchport is VLAN-unaware, which is the right
    state for a single-VLAN segment and the state an explicit ``mode:`` would
    have broken."""
    wanted: dict[Any, dict[str, Any]] = {}      # switchport id → fields
    for nd in intent.nodes:
        vid = vm_id.get(nd.name)
        if vid is None:
            continue
        ports = {p["name"]: p for p in fa.get_vm_ports(c, fid, vid)}
        for lk in nd.links:
            mode = lk.switchport_mode
            if mode is None:
                continue
            vp = ports.get(lk.port)
            peer = (vp or {}).get("peer")
            if not peer:
                _say(f"WARNING: {nd.name}.{lk.port} declares a VLAN but is not "
                     f"cabled to a switchport -- nothing to tag")
                continue
            if mode == "trunk":
                # vlan=0 on purpose: a NATIVE vlan set alongside mode=trunk is
                # silently ignored by OVS while the GUI shows it, which reads as
                # a working native VLAN and is not one.
                wanted[peer] = {"mode": "trunk", "vlan": 0,
                                "trunk": format_trunk(lk.trunk), "_sw": lk.switch}
                # A trunk port must carry NO untagged address -- the guest's
                # 802.1Q subinterfaces hold the addresses. FS auto-addresses any
                # cabled port with no IP from its switch's network at install, so
                # clearing is not enough; turn FS address management off. Left
                # on, the port comes up with an untagged IP that the uplink drops
                # while the guest looks configured. (Observed live: an intent
                # declaring no `ip:` on two trunk ports still had 10.100.0.2 and
                # 10.100.0.3 injected onto them.)
                if vp.get("auto_config") is not False or vp.get("ipv4addr"):
                    fa.set_port_auto_config(c, fid, vid, vp["id"], False)
                    if vp.get("ipv4addr"):
                        fa.clear_port_ipv4(c, fid, vid, vp["id"])
                    _say(f"{nd.name}.{lk.port}: trunk port -- cleared the untagged "
                         f"address and turned off FS auto-addressing")
            else:
                wanted[peer] = {"mode": "access", "vlan": lk.vlan, "trunk": "",
                                "_sw": lk.switch}
    changed: dict[str, bool] = {}
    for sname, sid in sw_id.items():
        if not any(w["_sw"] == sname for w in wanted.values()):
            continue
        changed.setdefault(sname, False)
        for p in fa.list_switch_ports(c, fid, sid):
            want = wanted.get(p["id"])
            if not want:
                continue
            cur = (str(p.get("mode") or ""), int(p.get("vlan") or 0),
                   str(p.get("trunk") or ""))
            new = (want["mode"], int(want["vlan"] or 0), want["trunk"])
            if cur == new:
                continue
            fa.set_switchport_vlan(c, p["id"], mode=want["mode"],
                                   vlan=want["vlan"], trunk=want["trunk"])
            _say(f"switchport {sname}/{p.get('name')}: mode={new[0]} vlan={new[1]} "
                 f"trunk={new[2]!r}")
            changed[sname] = True
    return changed


def _topology_from_state(state: dict[str, Any]) -> topology.Topology:
    """Build a `topology.Topology` from a `read_fabric_state` snapshot -- same
    graph assembly as `topology.build`, but from the already-fetched dict (no
    extra API calls), so reachability is a pure function over state."""
    t = topology.Topology()
    for n in state["networks"]:
        t.networks[n["id"]] = topology.Network(
            id=n["id"], name=n["name"],
            cidr=_norm_cidr(n.get("ipv4network", ""), n.get("ipv4netmask", "")),
            gateway=n.get("ipv4gateway"))
    # Switchport tags, so an L2 segment is (network, VLAN) and not just the
    # network. Two ports on ONE switch in different VLANs share a subnet and are
    # NOT the same broadcast domain -- without this the graph rubber-stamps them
    # as "same L2" and a VLAN fault reads as green.
    sw_by_id = {sw["id"]: sw for sw in state["switches"]}
    sp_vlan: dict[Any, int | None] = {}
    sp_trunk: dict[Any, tuple[int, ...]] = {}
    sp_switch: dict[Any, Any] = {}
    for sw in state["switches"]:
        for sp in sw.get("ports") or []:
            sp_vlan[sp["id"]] = topology.access_vlan(sp)
            sp_trunk[sp["id"]] = topology.trunk_vlans(sp)
            sp_switch[sp["id"]] = sw["id"]
    # (switch, vlan) → network, learned from the ACCESS ports. A VLAN is tied to
    # a subnet by the switch it lives on: a trunk carrying 100 and 200 where each
    # VLAN has its OWN subnet reaches two different networks, so pairing every
    # carried VLAN with the trunk port's own network gets the graph wrong.
    def _net_of(prt):
        nid = prt.get("network")
        if nid is None and prt.get("ipv4addr"):
            nid = t.network_for_ip(prt["ipv4addr"])
        return nid

    vlan_net = topology.vlan_network_map(
        [(sp_switch.get(prt.get("peer")), sp_vlan.get(prt.get("peer")), _net_of(prt))
         for v in state["vms"] for prt in v.get("ports", [])])
    for v in state["vms"]:
        for prt in v.get("ports", []):
            ip, nid = prt.get("ipv4addr"), prt.get("network")
            if nid is None and ip:
                nid = t.network_for_ip(ip)
            peer = prt.get("peer")
            trunk = sp_trunk.get(peer) or ()
            if nid is None and trunk:
                # A trunk port carries no address of its own, so there is no IP
                # to infer a network from -- take the network of the switch it
                # is cabled to, which is what its subinterfaces sit on.
                nid = (sw_by_id.get(sp_switch.get(peer)) or {}).get("auto_address_network")
            port = topology.Port(vm_id=v["id"], vm_name=v["name"],
                                 vm_type=v.get("vm_type") or "", name=prt.get("name", "?"),
                                 ipv4=ip, network_id=nid,
                                 vlan=sp_vlan.get(peer), trunk=trunk,
                                 trunk_segs=topology.trunk_segments(
                                     trunk, sp_switch.get(peer), vlan_net, nid))
            t.ports.append(port)
            t.by_vm[v["name"]].append(port)
    t.index()
    t.cables = [(c["conn1"], c["conn2"]) for c in state.get("cables", [])]
    return t


def _stale_overlapping_ports(nd: NodeSpec,
                             ports: dict[str, Any]) -> list[tuple[str, dict[str, Any]]]:
    """``(port_name, port_row)`` for every port the intent does NOT declare whose
    address shares a subnet with one the intent DOES declare on this node.

    This is the wreckage a port renumber leaves: the link moves from port3 to
    port2, apply addresses port2, and port3 keeps the same address because no
    link mentions it any more. FortiOS then refuses the second interface
    (``Subnets overlap ... Command fail. Return code -54``) and the install dies
    inside a guest that booted fine, blaming a port the intent never names.

    Narrow on ONE axis only: the overlap. FS auto-addresses ports at VM create,
    so an undeclared port on an unrelated subnet is normal and is left alone.

    Every node type is in scope, not just FortiOS. Two addresses in one subnet on
    one host is wrong everywhere -- it just fails loudly on an appliance and
    quietly on Linux, where it buys ARP ambiguity and asymmetric return paths
    instead of an error. The intent is the source of truth for addressing, so a
    port it no longer declares does not get to keep a foot in a declared subnet.

    ``ports`` is ``{name: row}`` as returned by ``fa.get_vm_ports`` / state."""
    declared = {lk.port for lk in nd.links}
    # What the declared ports will hold after this apply: the intent's `ip:` when
    # it sets one, else whatever the port already carries.
    keep: list[str] = []
    for lk in nd.links:
        addr = lk.ip or (ports.get(lk.port) or {}).get("ipv4addr")
        if addr:
            keep.append(addr)
    out: list[tuple[str, dict[str, Any]]] = []
    for pname, vp in ports.items():
        addr = vp.get("ipv4addr")
        if pname in declared or not addr:
            continue
        mask = vp.get("ipv4netmask") or "255.255.255.0"
        try:
            net = ipaddress.IPv4Network(f"{addr}/{mask}", strict=False)
        except Exception:
            continue                      # unparseable -- can't judge, leave it
        if any(_ip_in_cidr(k, str(net)) for k in keep):
            out.append((pname, vp))
    return out


def _ip_in_cidr(ip: str | None, cidr: str | None) -> bool:
    """True if ``ip`` is a host inside ``cidr``. False on any parse failure or
    None (caller treats unparseable as 'can't judge')."""
    if not ip or not cidr:
        return False
    try:
        return ipaddress.IPv4Address(ip) in ipaddress.IPv4Network(cidr, strict=False)
    except Exception:
        return False


def _port_switch_net_mismatches(intent: Intent,
                                state: dict[str, Any]) -> list[dict[str, Any]]:
    """Node ports whose assigned IP does NOT belong to the network of the switch
    they're cabled to -- e.g. a port left at 10.254.254.1 (OOB Mgmt) after being
    moved onto a 203.0.113.0/24 (Internet Access) switch. Such a port is
    unreachable on its own segment, so the System Host can't manage the guest
    (FGT → 'no valid management interface' → limited mode). Pure/offline.

    Catches BOTH inconsistencies between a port and the switch it's cabled to:
      * ``reason='ip'``    -- the port's IP isn't in the switch's network subnet.
      * ``reason='network'`` -- the port's ``network`` field points at a DIFFERENT
        net than the switch auto-addresses (the FS GUI keys a port's net off this
        field, so a wrong/stale one mislabels the port even if the IP looks right).

    Each entry: ``{node, port, ip, switch, expected_cidr, reason, ...}``. Ports
    with no IP yet are skipped for the IP check (FS will address them), and
    switches with no auto_address network are skipped (nothing to validate)."""
    sw_by_id = {s["id"]: s for s in state["switches"]}
    net_by_id = {n["id"]: n for n in state["networks"]}
    port_switch = {(lk["vm_id"], lk["vm_port_name"]): lk["switch_id"] for lk in state["links"]}
    vm_by_name = {v["name"]: v for v in state["vms"]}
    # A switch may legitimately carry MORE than the one subnet FS auto-addresses
    # -- one per VLAN. The intent's ``networks:`` list is the authority on which
    # ones are allowed; without it the rule stays the old single-net one. This is
    # what retires --allow-addr-mismatch for a correct multi-VLAN switch: the
    # check becomes "the IP is in one of the switch's networks", which is the
    # rule that was actually meant all along.
    net_by_name = {n["name"]: n for n in state["networks"]}
    sw_spec = {sw.name: sw for sw in intent.switches}
    out: list[dict[str, Any]] = []
    for nd in intent.nodes:
        vm = vm_by_name.get(nd.name)
        if not vm:
            continue
        pmap = {p["name"]: p for p in vm.get("ports", [])}
        for lk in nd.links:
            vp = pmap.get(lk.port)
            if not vp:
                continue
            sw = sw_by_id.get(port_switch.get((vm["id"], lk.port))) or {}
            sw_net_id = sw.get("auto_address_network")
            net = net_by_id.get(sw_net_id)
            if not net:
                continue
            spec = sw_spec.get(sw.get("name") or "")
            allowed = [net_by_name[nm] for nm in (spec.networks if spec else [])
                       if nm in net_by_name] or [net]
            cidrs = [f"{n.get('ipv4network')}/{n.get('ipv4netmask')}" for n in allowed]
            cidr = " | ".join(cidrs)
            ip = vp.get("ipv4addr")
            if ip and not any(_ip_in_cidr(ip, cd) for cd in cidrs):
                out.append({"node": nd.name, "port": lk.port, "ip": ip,
                            "switch": sw.get("name"), "expected_cidr": cidr,
                            "reason": "ip"})
            # network-field check: a set-but-wrong network field (the FS GUI labels
            # a port by this). None is fine -- FS infers the net from the switch.
            allowed_ids = {str(n.get("id")) for n in allowed}
            port_net = vp.get("network")
            if port_net is not None and str(port_net) not in allowed_ids:
                out.append({"node": nd.name, "port": lk.port, "ip": ip,
                            "switch": sw.get("name"), "expected_cidr": cidr,
                            "reason": "network",
                            "port_network": net_by_id.get(port_net, {}).get("name", port_net)})
    return out


def _alloc_static_ip(c: FabricStudioClient, fid: int | str,
                     ns: NetworkSpec) -> str | None:
    """Pick a free host IP in ``ns``'s subnet, avoiding every address currently in
    use on the LIVE fabric (all VM ports + System Host ports + the gateway). Reads
    live state so it stays collision-safe even on a targeted apply that doesn't see
    the other nodes' intent. Returns None if the subnet is exhausted."""
    used: set[str] = set()
    st = fa.read_fabric_state(c, fid)
    for v in st["vms"]:
        for p in v.get("ports", []):
            if p.get("ipv4addr"):
                used.add(p["ipv4addr"])
    try:
        for p in fa.get_system_host(c, fid).get("ports", []):
            if p.get("ipv4addr"):
                used.add(p["ipv4addr"])
    except Exception:
        pass
    if ns.gateway:
        used.add(ns.gateway)
    for host in ipaddress.IPv4Network(ns.cidr, strict=False).hosts():
        if str(host) not in used:
            return str(host)
    return None


def _flex_nodes_without_egress(intent: Intent, state: dict[str, Any]) -> list[str]:
    """Names of FortiFlex-licensed nodes whose declared links provide NO internet
    egress (no host-uplinked, non-mgmt switch). Such a node can't reach FortiCare
    to activate its entitlement, so it boots unlicensed (eval/limited). A node
    with a fixed ``license.file`` (.lic) is excluded -- that needs no phone-home.
    Pure/offline (testable)."""
    rows_by_node: dict[str, list[ReachRow]] = {}
    for r in reachability_report(state, intent)["rows"]:
        rows_by_node.setdefault(r.node, []).append(r)
    bad: list[str] = []
    for nd in intent.nodes:
        if not nd.license or nd.license.file:           # unlicensed or fixed .lic
            continue
        if _flex_config_ref(nd) is None:                # not FortiFlex
            continue
        if not any(r.egress for r in rows_by_node.get(nd.name, [])):
            bad.append(nd.name)
    return bad


def _flex_nodes_without_dns(intent: Intent, state: dict[str, Any]) -> list[str]:
    """Names of FortiFlex nodes that HAVE egress but whose egress network carries
    **no DNS** (`ipv4dns1`). FortiFlex activation resolves FortiCare by hostname,
    so a default route alone isn't enough -- without a resolver the entitlement
    never activates and the guest stays eval/limited (proven live by the soc-demo
    FGT: `Internet Access` net had a gateway but no dns1 → `License invalid`; and
    by Run-3 cell r6, where Predefined off a DNS-less net gave a route but
    `DNS: 0.0.0.0`). The intent-level fix is `dns1:` on the egress network (or a
    per-VM Custom DNS, which isn't intent-expressible). Pure/offline; advisory
    (warn) -- DNS may be supplied out-of-band, so this never blocks the install."""
    net_by_name = {n["name"]: n for n in state["networks"]}
    rows_by_node: dict[str, list[ReachRow]] = {}
    for r in reachability_report(state, intent)["rows"]:
        rows_by_node.setdefault(r.node, []).append(r)
    bad: list[str] = []
    for nd in intent.nodes:
        if not nd.license or nd.license.file:
            continue
        if _flex_config_ref(nd) is None:
            continue
        egress = [r for r in rows_by_node.get(nd.name, []) if r.egress]
        if not egress:                                  # no-egress gate owns this
            continue
        if not any((net_by_name.get(r.network) or {}).get("ipv4dns1") for r in egress):
            bad.append(nd.name)
    return bad


def _unmanageable_nodes(intent: Intent, state: dict[str, Any]) -> list[str]:
    """Names of nodes FS cannot MANAGE because **no** declared port lands on a
    host-uplinked switch. FS configures every guest *through* the System Host, so
    a node whose only links are on floating segments is unreachable → it never
    reaches ``post_boot_prepared`` (FGT: the GatewayMethod SSH never connects).

    Proven by the Run-2 manageability matrix (docs/plans/
    FS_TOPOLOGY_VALIDATION_PROBE_PLAN.md): every node with a host-uplinked port
    reached post_boot_prepared; both floating-only nodes did not -- and the
    switch ``mgmt`` flag was irrelevant (a host-uplinked *mgmt* net manages fine,
    a floating *mgmt* net does not). So the rule is host-uplink of ANY port, not
    the mgmt flag and not egress (a mgmt-only net with no internet route is fine
    for management -- that's why this is distinct from
    ``_flex_nodes_without_egress``, which additionally needs a non-mgmt switch).

    A node passes if ANY port is routable -- so a data port on a floating switch
    doesn't disqualify a node whose mgmt port is on a good switch (matrix cell G).
    Nodes with no links are skipped (nothing to judge). Pure/offline (testable)."""
    rows_by_node: dict[str, list[ReachRow]] = {}
    for r in reachability_report(state, intent)["rows"]:
        rows_by_node.setdefault(r.node, []).append(r)
    bad: list[str] = []
    for nd in intent.nodes:
        rows = rows_by_node.get(nd.name)
        if not rows:                                    # no declared links → skip
            continue
        if not any(r.routable for r in rows):
            bad.append(nd.name)
    return bad


# Which segment gives a guest a default route is decided by the SEEDED switch it
# is on and by the guest's type -- never by ``switch.mgmt``. See
# ``_switch_gives_egress`` for the live evidence behind each branch.


def _switch_gives_egress(sw: dict[str, Any], vm_type: str | None) -> bool:
    """Does a guest of ``vm_type`` on this switch get a working default route?

    Node type matters, which is the part that took two live labs to see. FS
    addresses a Linux guest by writing ifupdown files and an appliance through
    its own config, and the two disagree about exactly one segment -- the seeded
    OOB one:

    * **Linux (LXC/qcow/BASIC)** -- no default gateway on the seeded ``OOB Mgmt``
      switch (that is what makes out-of-band out-of-band), gateway everywhere
      else host-uplinked.
    * **FortiOS appliances** (``_PORT_STYLE_TYPES``) -- FS points their default
      route AT the OOB gateway. Read live off a working lab: the FGT's routing
      table is ``S* 0.0.0.0/0 [10/0] via 10.254.254.254, port2`` (port2 = OOB)
      and ``execute ping 8.8.8.8`` is 0% loss; FMG and FAZ ping out the same way.
      So for an appliance the OOB segment IS its egress, and scoring it otherwise
      fails the FortiFlex pre-flight on a lab that works.

    The seeded ``Internet Access`` (``intsw``) switch gives egress to NEITHER --
    an LXC guest on it gets an address and no gateway, and on the appliance side
    it is worse: the FGT's port1 and FMG's port3 sit on it and have **no address
    at all** in-guest (``diagnose ip address list`` / ``get system interface``),
    while the FS model happily reports one. Declare your own switch instead.

    ``vm_type`` None (a state-only read that can't resolve the type) is treated
    as Linux -- the stricter of the two, so an unknown guest is never promised
    egress it may not have."""
    if not sw.get("host_uplinked"):
        return False                                  # floating: no route at all
    if _is_seeded_internet_switch(sw):
        return False                                  # inert for every node type
    if _is_seeded_oob_switch(sw):
        return str(vm_type or "").upper() in _PORT_STYLE_TYPES
    return True


def _is_seeded_internet_switch(sw: dict[str, Any]) -> bool:
    """The seeded 'Internet Access' switch -- see ``_switch_gives_egress``."""
    if str(sw.get("nameid") or "").lower() == "intsw":
        return True
    return _norm_sw_name(sw) == "internet access"


def _norm_sw_name(sw: dict[str, Any]) -> str:
    return re.sub(r"\s+", " ", str(sw.get("name") or "").strip().lower())


def _is_seeded_oob_switch(sw: dict[str, Any]) -> bool:
    """Is this the FS-seeded out-of-band management segment?

    **This is the empirical rule, and it is NOT the ``mgmt`` flag.** Probed live
    on a dev pod (FS 2.0.8, fabric `mgmt-egress-probe`, ``tools/probe_mgmt_egress
    .py``, intent ``topologies/scratch/mgmt_egress_probe``) with everything else
    held constant -- same network, same host uplink, same firmware, guests
    reinstalled between phases:

    * a user switch on the seeded ISP net, ``mgmt=False`` → gateway injected,
      ``ping 8.8.8.8`` 0% loss, ``curl`` 301;
    * the SAME switch flipped to ``mgmt=True`` → gateway still injected, egress
      still fine, for the node that owns the mgmt port AND for a bystander;
    * a guest single-homed on that ``mgmt=True`` switch → gateway injected,
      full egress;
    * a guest single-homed on the seeded ``OOB Mgmt`` switch (also ``mgmt=True``,
      also host-uplinked, gateway set on its network) → **no** gateway, no egress;
    * a guest on the seeded ``Internet Access`` switch, host-uplinked by a created
      port owning the net's gateway → **no** gateway either, across two clean
      reinstalls -- then the same net on a switch WE created → gateway injected,
      ping 0% loss, curl 301.

    Ruled out as the discriminator by that run: ``switch.mgmt`` (both switches
    were mgmt=True with opposite outcomes); the host port's ``dhcp_service``; and
    the host port's flags generally (the failing ``int3`` and the working ``int4``
    were byte-identical -- forwarding on, egress NAT off, DHCP off, both live).
    What is left is the seeded switch's identity, so that is what we match --
    ``nameid`` first (FS's own stable handle), falling back to the seeded name.

    **Scope: LXC guests.** Every cell above used an LXC image, which FS addresses
    by writing ``/etc/network/interfaces.d/*``. Appliances are addressed through
    a different path and were not testable on the probe pod (FS refuses to
    install FortiOS without an entitlement), so this rule is unverified for
    FGT/FMG/FAZ.

    The older ``egress = routable and not switch.mgmt`` rule read the mgmt flag
    as "management-only, no internet". It cost a lab: pinning a node's mgmt port
    onto the egress switch force-flips that switch to ``mgmt=True`` (FS wants the
    vmport and its switch to agree), which made every node on the segment score
    non-egress and failed the FortiFlex pre-flight on a topology that worked."""
    if str(sw.get("nameid") or "").lower() == "oobsw":
        return True
    return _norm_sw_name(sw) in {"oob mgmt", "oob mgmt switch"}


def reachability_report(state: dict[str, Any],
                        intent: Intent | None = None) -> dict[str, Any]:
    """Reachability verdict over a `read_fabric_state` snapshot (pure -- testable
    offline). Returns ``{rows, pairs}``:

    * ``rows`` -- one `ReachRow` per node-port (the intent's declared links when
      ``intent`` is given, else every cabled VM port): does it have an IP on a
      fabric network, on which switch, and is that switch routable/egress.
    * ``pairs`` -- predicted node→node reachability via `topology.reachable`
      (same-L2 or routed through an FGT), each with a human ``why``.
    """
    t = _topology_from_state(state)
    sw_by_id = {s["id"]: s for s in state["switches"]}
    switchport_by_id = {sp["id"]: sp for s in state["switches"] for sp in (s.get("ports") or [])}
    port_switch = {(lk["vm_id"], lk["vm_port_name"]): lk["switch_id"] for lk in state["links"]}
    vms = {v["name"]: v for v in state["vms"]}
    # Egress depends on the guest's type (appliances route off the OOB segment,
    # Linux guests do not), so resolve it -- the intent is authoritative, the
    # live VM row is the fallback for a state-only read.
    type_by_node = {v.get("name"): v.get("vm_type") for v in state["vms"]}
    if intent is not None:
        type_by_node.update({nd.name: nd.type for nd in intent.nodes})

    def row_for(node: str, port_name: str, prt: dict[str, Any] | None) -> ReachRow:
        ip = (prt or {}).get("ipv4addr")
        nid = (prt or {}).get("network")
        if nid is None and ip:
            nid = t.network_for_ip(ip)
        net = t.networks[nid].name if nid in t.networks else None
        swid = port_switch.get((vms[node]["id"], port_name)) if node in vms else None
        sw = sw_by_id.get(swid) or {}
        routable = bool(sw.get("host_uplinked"))
        sp = switchport_by_id.get((prt or {}).get("peer")) or {}
        trunk = topology.trunk_vlans(sp)
        access = topology.access_vlan(sp)
        vlan = f"trunk {format_trunk(trunk)}" if trunk else (str(access) if access else None)
        # A TRUNK port with no address is CORRECT, not a miss: it terminates no
        # VLAN, and the guest's 802.1Q subinterfaces carry the addresses. Judging
        # it by "has an IP" would flunk a properly configured trunk -- and with
        # require_reachable that would fail the apply that just configured it.
        ok = True if trunk else bool(ip and net)
        egress = _switch_gives_egress(sw, type_by_node.get(node))
        # A port FS serves by native DHCP gets its gateway in the lease when the
        # node's Network Parameters network IS this port's network -- the seeded
        # OOB segment included (live-verified on 2.2.35: a BASIC guest DHCP-served
        # on OOB Mgmt with Network Parameters = OOB Mgmt got the default route and
        # HTTPS out). A gateway outside the port's subnet is left out of the lease.
        if not egress and _is_seeded_oob_switch(sw) and routable and nid is not None \
                and (prt or {}).get("dhcp_server") \
                and str((prt or {}).get("addrmode") or "").upper() == "DHCP" \
                and (vms.get(node) or {}).get("auto_params_network") == nid:
            egress = True
        return ReachRow(node=node, port=port_name, ip=ip, network=net,
                        switch=sw.get("name"), routable=routable, egress=egress,
                        ok=ok, vlan=vlan)

    rows: list[ReachRow] = []
    if intent is not None:
        for nd in intent.nodes:
            pmap = {p["name"]: p for p in (vms.get(nd.name) or {}).get("ports", [])}
            for lk in nd.links:
                rows.append(row_for(nd.name, lk.port, pmap.get(lk.port)))
    else:
        for v in state["vms"]:
            for p in v.get("ports", []):
                if p.get("cable"):
                    rows.append(row_for(v["name"], p["name"], p))

    # EVERY addressed port is a destination, not just each VM's first one.
    # Taking one primary IP per VM meant a node with a management NIC was only
    # ever probed on that NIC -- and in a topology where every guest has one,
    # the data ports (the VLANs, the whole point) were never examined. The
    # matrix said green because it had not looked.
    targets: list[tuple[str, str, str]] = []      # (vm name, port name, ip)
    for v in state["vms"]:
        for p in v.get("ports", []):
            if p.get("ipv4addr"):
                targets.append((v["name"], p.get("name", "?"), p["ipv4addr"]))
    pairs = []
    for src in {v["name"] for v in state["vms"]}:
        for dst, dst_port, dst_ip in targets:
            if src == dst:
                continue
            ok, why = t.reachable(src, dst_ip)
            pairs.append({"src": src, "dst": dst, "dst_port": dst_port,
                          "dst_ip": dst_ip, "reachable": ok, "why": why})
    pairs.sort(key=lambda p: (p["src"], p["dst"], p["dst_port"]))
    return {"rows": rows, "pairs": pairs}


def assert_converged(c: FabricStudioClient, fabric_id: int | str,
                     intent: Intent, require_reachable: bool = False) -> dict[str, Any]:
    """Re-read the fabric and confirm every desired resource + link exists.
    Returns ``{ok, missing, warnings, reachability}`` -- ``ok`` is the bottom
    line. When ``require_reachable`` (set by ``apply`` once it has booted), a
    declared node-port with no reachable IP also counts as ``missing`` -- that's
    the "booted + reachable" bar. Pre-boot (``require_reachable=False``) the
    reachability table is informational only, so a model-only `--no-boot`
    converge still reports ``ok``."""
    st = fa.read_fabric_state(c, fabric_id)
    net_names = {n["name"] for n in st["networks"]}
    sw_names = {s["name"] for s in st["switches"]}
    vm_by_name = {v["name"]: v for v in st["vms"]}
    cur_link_switch = {(lk["vm_id"], lk["vm_port_name"]): lk["switch_id"] for lk in st["links"]}
    sw_id = {s["name"]: s["id"] for s in st["switches"]}

    missing: list[str] = []
    for n in intent.networks:
        if n.name not in net_names:
            missing.append(f"network {n.name}")
    for s in intent.switches:
        if s.name not in sw_names:
            missing.append(f"switch {s.name}")
    for nd in intent.nodes:
        vm = vm_by_name.get(nd.name)
        if not vm:
            missing.append(f"node {nd.name}")
            continue
        for lk in nd.links:
            want = sw_id.get(lk.switch)
            if str(cur_link_switch.get((vm["id"], lk.port))) != str(want):
                missing.append(f"link {nd.name}.{lk.port}→{lk.switch}")
    # Floating-switch smell is non-fatal (a mgmt-only topology is legitimately
    # un-uplinked for egress) -- report it as a warning, not a missing resource.
    warnings = _floating_switch_warnings(intent, st["switches"])

    reach = reachability_report(st, intent)
    if require_reachable:
        for r in reach["rows"]:
            if not r.ok:
                missing.append(f"address {r.node}.{r.port} (no reachable IP)")
    return {
        "ok": not missing,
        "missing": missing,
        "warnings": warnings,
        "reachability": {
            "rows": [r.__dict__ for r in reach["rows"]],
            "pairs": reach["pairs"],
        },
    }
