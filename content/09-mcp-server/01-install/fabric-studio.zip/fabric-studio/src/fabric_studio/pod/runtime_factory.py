"""Runtime adapter selection for Fabric Studio vs FortiPoC pods."""
from __future__ import annotations

import requests
import urllib3

from fabric_studio.pod.fortipoc_runtime import FortiPoCRuntime
from fabric_studio.pod.runtime import PodRuntime

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def runtime_for(pod_type: str, server: str, username: str, password: str):
    """Return a runtime adapter instance for the given pod_type ('fs' or 'fortipoc')."""
    if pod_type == "fortipoc":
        return FortiPoCRuntime(server=server, username=username, password=password)
    return PodRuntime(server=server, username=username, password=password)


def detect_pod_type(host: str, username: str, password: str, timeout: int = 8) -> str:
    """Probe `host` to decide whether it speaks Fabric Studio or FortiPoC.

    Heuristic: FortiPoC's /api/v0/login returns `{status: success, csrf-token: …}`
    on valid creds. Fabric Studio doesn't expose that endpoint at all (it uses
    its own /api/v1/auth flow), so a successful login response uniquely
    identifies FortiPoC. Falls back to 'fs' on anything ambiguous so existing
    behavior is preserved when callers don't supply pod_type explicitly.
    """
    try:
        r = requests.post(
            f"https://{host}/api/v0/login",
            json={"username": username, "password": password},
            verify=False, timeout=timeout,
        )
        if r.status_code == 200:
            body = r.json()
            if body.get("status") == "success" and "csrf-token" in body:
                return "fortipoc"
    except Exception:
        pass
    return "fs"
