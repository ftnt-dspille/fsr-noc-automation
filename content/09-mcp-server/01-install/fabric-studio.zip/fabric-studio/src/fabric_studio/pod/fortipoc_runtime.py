"""FortiPoC runtime adapter.

Exposes the same surface as `fabric_studio.pod.runtime.PodRuntime` that `backend.discovery`
depends on: `get_running_fabric`, `get_model_vms`, `get_runtime_vms`. The
FortiPoC REST API (`/api/v0.6/...`) is much thinner than Fabric Studio's:
it returns device names + per-access external/internal port pairs but no
internal management IPs. We recover those by joining the API response with
the FortiPoC host's `iptables` NAT table read over SSH.

Reference docs (live on the pod): `/static/fpdoc/api.html`, `/static/fpdoc/cli.html`.
"""
from __future__ import annotations

import asyncio
import re
from typing import Any

import asyncssh
import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# FortiPoC license-prefix → our vm_type taxonomy.
# Anything not matched here is treated as an "infrastructure" VM (vyos, win,
# wan_sim, lxc) and dropped — we only model devices our checks know about.
_LICENSE_TO_TYPE = (
    ("FMG", "FMG"),
    ("FAZ", "FAZ"),
    ("FAC", "FAC"),
    ("FSR", "SOAR"),
    ("FML", "FML"),
    ("FGT", "FGT"),
    ("FGVM", "FGT"),
)


def _infer_vm_type(name: str, license_id: str | None) -> str | None:
    """Map a FortiPoC device to one of our vm_type slugs, or None to drop."""
    lic = (license_id or "").upper()
    for prefix, vt in _LICENSE_TO_TYPE:
        if lic.startswith(prefix):
            return vt
    # Fall back to name hints (clients/vyos/win/wan_sim have no license).
    n = name.lower()
    if n.startswith(("vyos", "wan_", "client", "zz_win", "z_tool")):
        return None
    return None


class _FortiPoCAPI:
    """Minimal session-cookie REST client for /api/v0.x."""

    def __init__(self, host: str, username: str, password: str):
        self.base = f"https://{host}"
        self.host = host
        self.session = requests.Session()
        self.session.verify = False
        self.username = username
        self.password = password
        self._csrf: str | None = None

    def login(self) -> None:
        r = self.session.post(
            f"{self.base}/api/v0/login",
            json={"username": self.username, "password": self.password},
            timeout=20,
        )
        r.raise_for_status()
        body = r.json()
        if body.get("status") != "success":
            raise RuntimeError(f"FortiPoC login failed: {body}")
        self._csrf = body.get("csrf-token")

    def get(self, path: str) -> dict:
        r = self.session.get(f"{self.base}{path}", timeout=20)
        r.raise_for_status()
        return r.json()


def _read_ssh_nat_table(host: str, username: str, password: str) -> dict[int, str]:
    """SSH into the FortiPoC host, dump the SSH DNAT chain, return
    {external_port: internal_ipv4}. The admin shell restricts arbitrary
    commands but allows `expert firewall iptables -t nat -S FP_PRE_SSH`.
    """
    async def _run() -> str:
        conn = await asyncio.wait_for(
            asyncssh.connect(
                host, port=22, username=username, password=password,
                known_hosts=None, client_keys=[],
            ),
            timeout=20,
        )
        async with conn:
            r = await asyncio.wait_for(
                conn.run("expert firewall iptables -t nat -S FP_PRE_SSH"),
                timeout=20,
            )
            return r.stdout or ""

    text = asyncio.run(_run())
    out: dict[int, str] = {}
    for line in text.splitlines():
        m = re.search(r"--dport (\d+).*to-destination (\d+\.\d+\.\d+\.\d+):22", line)
        if m:
            out[int(m.group(1))] = m.group(2)
    return out


class FortiPoCRuntime:
    """Drop-in replacement for `PodRuntime` covering the methods that
    `backend.discovery.discover_pod` calls. Other PodRuntime methods raise
    NotImplementedError — they're FS-specific (task polling, fs-cli, etc.)
    and verification on FortiPoC doesn't use them.
    """

    def __init__(self, server: str, username: str, password: str):
        self.pod_host = server
        self.username = username
        self.password = password
        self._api = _FortiPoCAPI(server, username, password)
        self._api.login()
        # Cached cross-references built lazily on first model_vms call.
        self._nat_ssh: dict[int, str] | None = None
        self._poc: dict | None = None

    # --- discovery surface ----------------------------------------------------

    def get_running_fabric(self) -> dict | None:
        """Return the running PoC as an FS-shaped fabric dict.

        FortiPoC exposes one running PoC at a time via /api/v0/poc/list
        (entries with `running: true`). We surface its pk as the fabric id
        and the name as fabric.name. No console_password (FortiPoC doesn't
        expose one over REST), no version (the platform's API version is
        unrelated to the fabric).
        """
        body = self._api.get("/api/v0/poc/list")
        for pk, p in (body.get("pocs") or {}).items():
            if p.get("running"):
                self._poc = p
                return {
                    "id": int(p.get("pk", pk)),
                    "name": p.get("name", ""),
                    "version": "fortipoc",
                    "console_password": "",
                }
        return None

    def get_model_vms(self, fabric_id: int) -> list[dict]:
        """Return FS-shaped model VM dicts.

        Each entry has `id`, `name`, `vm_type`, `port_idx`, `accesses`, `ports`.
        - `port_idx` is derived from the SSH external port (port_idx =
          external_ssh_port - 11000). FortiPoC's SSH base happens to match
          FS's `ACCESS_PORT_BASE["SSH"]`, so existing ssh-direct paths just
          work. HTTPS/HTTP bases differ — see module docstring.
        - `ports` carries the management IPv4 we recovered from iptables.
        - VMs that don't map to one of our vm_types (vyos, clients, win10,
          wan_sim, lxc helpers) are filtered out.
        """
        body = self._api.get("/api/v0.6/poc/current/devices/list")
        devices = body.get("devices") or {}
        if self._nat_ssh is None:
            self._nat_ssh = _read_ssh_nat_table(
                self.pod_host, self.username, self.password,
            )
        out: list[dict] = []
        for pk_str, d in devices.items():
            name = d.get("name", "")
            license_id = (d.get("license") or {}).get("id")
            vm_type = _infer_vm_type(name, license_id)
            if vm_type is None:
                continue
            ssh_ext: int | None = None
            accesses: list[dict[str, Any]] = []
            for a in d.get("info") or []:
                kind = a.get("access")
                if kind == "SSH":
                    ssh_ext = a.get("external")
                if kind in ("SSH", "HTTPS", "HTTP"):
                    accesses.append({"type": kind, "mode": "PUBLIC",
                                     "port": a.get("external")})
            if ssh_ext is None:
                continue
            mgmt_ip = self._nat_ssh.get(int(ssh_ext))
            port_idx = int(ssh_ext) - 11000  # see method docstring
            out.append({
                "id": int(d.get("pk", pk_str)),
                "name": name,
                "vm_type": vm_type,
                "port_idx": port_idx,
                "accesses": accesses,
                "ports": [{"mgmt": True, "ipv4addr": mgmt_ip}] if mgmt_ip else [],
            })
        return out

    def get_runtime_vms(self, fabric_id: int) -> list[dict]:
        """Return FS-shaped runtime VM dicts: id, status, license.served, fabric.

        FortiPoC's only liveness signal is `state: "Running"` per device;
        we map that to `status.powered`. There's no equivalent of
        post_boot_prepared or a separate licensed bit — if state==Running
        we assume booted-and-licensed (treat dim signals as up).
        """
        body = self._api.get("/api/v0.6/poc/current/devices/list")
        devices = body.get("devices") or {}
        out: list[dict] = []
        for pk_str, d in devices.items():
            powered = d.get("state") == "Running"
            license_id = (d.get("license") or {}).get("id")
            out.append({
                "id": int(d.get("pk", pk_str)),
                "fabric": int(fabric_id),
                "status": {"powered": powered,
                           "post_boot_prepared": powered,
                           "licensed": bool(license_id)},
                "license": {"served": {"name": license_id}} if license_id else {},
            })
        return out

    def get_system_health(self) -> dict:
        """Return a dashboard-shaped health dict from the FortiPoC API.

        FortiPoC's /api/v0/poc/list gives the platform version + the running
        PoC's name, device count, and license counts (derived from each
        device's license.id). Disk / serial / uptime aren't exposed over
        the REST surface, so those stay null. The shape matches PodRuntime's
        version so the same Dashboard card renders for both pod types.
        """
        info: dict = {"hostname": None, "version": None, "serial": None,
                      "uptime_seconds": None, "frontend_version": None,
                      "licenses_total": 0, "licenses_by_type": {},
                      "license_enabled_count": 0,
                      "disk": None, "errors": []}
        try:
            body = self._api.get("/api/v0/poc/list")
        except Exception as exc:
            info["errors"].append(f"poc/list: {type(exc).__name__}")
            return info
        info["version"] = body.get("version") or "fortipoc"
        running = None
        for _, p in (body.get("pocs") or {}).items():
            if p.get("running"):
                running = p
                break
        if running:
            info["hostname"] = running.get("name") or self.pod_host
        else:
            info["hostname"] = self.pod_host
        # Per-device licenses live on the devices/list endpoint; cheap to
        # fetch here and gives the Dashboard a license-count it can show.
        try:
            d_body = self._api.get("/api/v0.6/poc/current/devices/list")
            devices = (d_body.get("devices") or {}).values()
            by_type: dict[str, int] = {}
            enabled = 0
            for d in devices:
                lic = (d.get("license") or {}).get("id")
                if not lic:
                    continue
                t = _infer_vm_type(d.get("name", ""), lic) or "other"
                by_type[t] = by_type.get(t, 0) + 1
                if d.get("state") == "Running":
                    enabled += 1
            info["licenses_total"]        = sum(by_type.values())
            info["licenses_by_type"]      = by_type
            info["license_enabled_count"] = enabled
        except Exception as exc:
            info["errors"].append(f"devices/list: {type(exc).__name__}")
        return info

    # --- not-implemented surface (FS-only operations) -------------------------

    def __getattr__(self, name: str):
        raise NotImplementedError(
            f"FortiPoCRuntime does not implement '{name}' — FS-only API "
            "(task polling, fs-cli, VM install, etc.)"
        )
