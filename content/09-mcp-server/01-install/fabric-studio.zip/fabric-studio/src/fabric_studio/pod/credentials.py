"""Per-VM credential and FortiFlex config ID resolution."""
import os
import re

# Default SSH username per VM type (used by setup wizard + env fallback).
VM_SSH_USER = {"FGT": "admin", "FMG": "admin", "FAZ": "admin", "SOAR": "csadmin"}


def _nameid_key(nameid: str) -> str:
    """Sanitise a VM nameid into an env-var suffix (e.g. 'fgt000' → 'FGT000')."""
    return re.sub(r"[^A-Z0-9]", "_", nameid.upper())


def fortiflex_config_id(vm_type: str) -> int | None:
    """
    Return the FortiFlex config ID for a VM type, or None if not configured.

    Resolution order:
      FORTIFLEX_CONFIG_ID_<VM_TYPE>  (per-type)
      FORTIFLEX_CONFIG_ID            (global fallback)
    """
    raw = (
        os.environ.get(f"FORTIFLEX_CONFIG_ID_{vm_type.upper()}")
        or os.environ.get("FORTIFLEX_CONFIG_ID")
    )
    try:
        return int(raw) if raw else None
    except (ValueError, TypeError):
        return None


def vm_credentials(vm: dict) -> tuple[str, str]:
    """
    Return (username, password) for a VM.

    Resolution order:
      username: VM_USER_<NAMEID>  →  VM_SSH_USER[vm_type]  →  "admin"
      password: VM_PASS_<NAMEID>  →  vm["password"]  →  vm["http_password"]  →  ""
    """
    nameid  = vm.get("nameid") or vm.get("name", "")
    vm_type = vm.get("vm_type", "")
    key     = _nameid_key(nameid)

    username = (
        os.environ.get(f"VM_USER_{key}")
        or VM_SSH_USER.get(vm_type, "admin")
    )
    password = (
        os.environ.get(f"VM_PASS_{key}")
        or vm.get("password")
        or vm.get("http_password")
        or ""
    )
    return username, password
