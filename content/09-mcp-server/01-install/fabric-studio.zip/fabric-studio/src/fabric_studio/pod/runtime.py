"""Fabric Studio runtime wrapper (PodRuntime)."""
import asyncio
import contextlib
import time
from urllib.parse import urlparse

import asyncssh

from fabric_studio.client import FabricStudioClient


class PodRuntime:
    TASK_POLL_INTERVAL = 10

    def __init__(self, server: str, username: str, password: str):
        self.client   = FabricStudioClient(
            server=server, username=username, password=password, verify_ssl=False
        )
        self.pod_host = urlparse(self.client.server).hostname or server

    def _get(self, endpoint: str) -> dict:
        r = self.client.get(endpoint)
        r.raise_for_status()
        return r.json()

    def _post(self, endpoint: str, data: dict | None = None) -> dict:
        r = self.client.post(endpoint, json_data=data or {})
        r.raise_for_status()
        return r.json()

    def _patch(self, endpoint: str, data: dict) -> dict:
        r = self.client.request("PATCH", endpoint, json_data=data)
        r.raise_for_status()
        return r.json()

    def get_running_fabric(self) -> dict | None:
        try:
            return self._get("api/v1/runtime/fabric").get("object")
        except Exception:
            return None

    def get_system_health(self) -> dict:
        """Fetch hostname / version / uptime / licenses / disk in one go.

        The four sub-calls hit Fabric Studio in parallel via a small thread
        pool — total wall-clock is one RTT instead of four. Each is
        best-effort; a partial response is still useful for the UI.
        """
        from concurrent.futures import ThreadPoolExecutor

        out: dict = {"hostname": None, "version": None, "serial": None,
                     "uptime_seconds": None, "frontend_version": None,
                     "licenses_total": 0, "licenses_by_type": {},
                     "license_enabled_count": 0,
                     "disk": None, "errors": []}

        def safe(field, ep):
            try:
                return field, self._get(ep).get("object"), None
            except Exception as exc:
                return field, None, f"{type(exc).__name__}"

        eps = [
            ("information", "api/v1/system/information"),
            ("hostname",    "api/v1/system/hostname"),
            ("license",     "api/v1/system/license"),
            ("disk",        "api/v1/system/disk/detail"),
        ]
        with ThreadPoolExecutor(max_workers=4) as ex:
            futs = [ex.submit(safe, f, ep) for f, ep in eps]
            for f in futs:
                field, val, err = f.result()
                if err:
                    out["errors"].append(f"{field}: {err}")
                    continue
                if field == "information":
                    v = val or {}
                    out.update({
                        "version":          v.get("version"),
                        "serial":           v.get("serial_number"),
                        "uptime_seconds":   v.get("uptime"),
                        "frontend_version": v.get("frontend_version"),
                    })
                elif field == "hostname":
                    out["hostname"] = val if isinstance(val, str) else None
                elif field == "license":
                    licenses = val or []
                    by_type: dict[str, int] = {}
                    enabled = 0
                    for lic in licenses:
                        t = lic.get("vm_type") or lic.get("lic_type") or "?"
                        by_type[t] = by_type.get(t, 0) + 1
                        if lic.get("enable"):
                            enabled += 1
                    out.update({
                        "licenses_total":        len(licenses),
                        "licenses_by_type":      by_type,
                        "license_enabled_count": enabled,
                    })
                elif field == "disk":
                    v = val or {}
                    lvm = v.get("lvm") or {}
                    # The free-size / threshold fields at the top level are about
                    # UNALLOCATED disk space (always 0 once provisioned) — NOT
                    # disk usage. Real layout lives in lvm.{vgs,lvs,pvs}.
                    # Live usage % isn't exposed over REST; Fabric Studio's UI
                    # streams it via websocket. We surface the layout the user
                    # can recognize from the Fabric Studio dashboard.
                    out["disk"] = {
                        "device":      v.get("device"),
                        "vgs": [
                            {"name": g.get("vg_name"), "size": g.get("vg_size"),
                             "free": g.get("vg_free"),
                             "pv_count": g.get("pv_count"),
                             "lv_count": g.get("lv_count")}
                            for g in (lvm.get("vgs") or [])
                        ],
                        "lvs": [
                            {"name": lv.get("lv_name"), "size": lv.get("lv_size"),
                             "vg_name": lv.get("vg_name")}
                            for lv in (lvm.get("lvs") or [])
                        ],
                        "pvs": [
                            {"name": pv.get("pv_name"), "size": pv.get("pv_size"),
                             "free": pv.get("pv_free"), "vg_name": pv.get("vg_name")}
                            for pv in (lvm.get("pvs") or [])
                        ],
                    }
        return out

    def get_model_vms(self, fabric_id: int) -> list[dict]:
        """Return model VMs with ports and accesses expanded."""
        resp = self._get(
            f"api/v1/model/fabric/{fabric_id}/vm"
            "?related_fields=ports&related_fields=accesses"
        )
        return resp.get("object", [])

    def get_runtime_vms(self, fabric_id: int) -> list[dict]:
        """Return runtime VMs with status and served-license expanded."""
        resp = self._get(
            "api/v1/runtime/vm"
            "?related-fields=status&related-fields=license.served"
            f"&fabric={fabric_id}"
        )
        vms = resp.get("object", [])
        if isinstance(vms, list):
            vms = [v for v in vms if v.get("fabric") == fabric_id]
        return vms

    def get_device_tasks(self, vm_id: int, limit: int = 3) -> list[dict]:
        """Return recent install tasks for a VM, most recent first."""
        try:
            resp = self._get(
                f"api/v1/task/device?device_id={vm_id}"
                f"&limit={limit}&order_by=-created_date"
            )
            return resp.get("object", [])
        except Exception:
            return []

    def get_task_log(self, task_id: int) -> str:
        """Return the raw log text for a task."""
        r = self.client.get(f"api/v1/task/{task_id}:log")
        r.raise_for_status()
        return r.text

    def reinstall_vm_license(self, vm_id: int) -> int | None:
        resp = self._post(
            f"api/v1/runtime/vm/{vm_id}/license",
            {"reinstall": True, "refresh": True},
        )
        return resp.get("object", {}).get("id")

    def reinstall_vm(self, vm_id: int, power_on: bool = True) -> int | None:
        """Full device reinstall (not just license). Returns task ID or None."""
        resp = self._post(
            f"api/v1/runtime/vm/{vm_id}",
            {"power_on": power_on, "license": True},
        )
        return resp.get("object", {}).get("id")

    def update_vm_parameters(self, fabric_id: int, vm_id: int, params: dict) -> dict:
        """PATCH model VM parameters (e.g. expert hooks)."""
        return self._patch(
            f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}/parameters",
            {"object": params},
        )

    def get_vm_license_mode(self, vm_id: int) -> str | None:
        """Return the current license mode string for a VM, or None on error."""
        try:
            resp = self._get(f"api/v1/model/vm/{vm_id}/license")
            return (resp.get("object") or {}).get("mode")
        except Exception:
            return None

    def patch_vm_license_mode_none(self, vm_id: int) -> dict:
        """Reset VM license mode to NONE via the model API."""
        return self._patch(
            f"api/v1/model/vm/{vm_id}/license",
            {"object": {"mode": "NONE", "license": ""}},
        )

    def trigger_device_install(self, vm_id: int) -> int | None:
        """Trigger a full device install via the runtime API. Returns task ID or None."""
        resp = self._post(f"api/v1/runtime/device/{vm_id}")
        return resp.get("object", {}).get("id")

    def cancel_tasks(self, task_ids: list[int], wait_timeout: int = 60) -> bool:
        """Cancel all given tasks and wait for the pod to have no running tasks."""
        for tid in task_ids:
            with contextlib.suppress(Exception):
                self.client.request("DELETE", f"api/v1/task/{tid}").raise_for_status()
        return self.wait_for_running_tasks(timeout=wait_timeout)

    def wait_for_task(self, task_id: int, timeout: int = 300) -> int | None:
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                rc = self._get(f"api/v1/task/{task_id}").get("object", {}).get("returncode")
                if rc is not None:
                    return rc
            except Exception:
                pass
            time.sleep(self.TASK_POLL_INTERVAL)
        return None

    def wait_for_running_tasks(self, timeout: int = 600, poll_interval: int = 10,
                               log_fn=None) -> bool:
        """Poll until no tasks are running or timeout. Returns True if cleared."""
        deadline   = time.time() + timeout
        start      = time.time()
        last_names: list = []
        while time.time() < deadline:
            try:
                resp  = self._get("api/v1/task?running=true")
                tasks = resp.get("object", [])
                if not tasks:
                    return True
                names   = [t.get("name", f"task {t.get('id')}") for t in tasks]
                elapsed = int(time.time() - start)
                if log_fn and names != last_names:
                    log_fn(f"  [dim]  waiting ({elapsed}s): {', '.join(names)}[/dim]")
                    last_names = names
                elif log_fn and elapsed % 30 == 0 and elapsed > 0:
                    log_fn(f"  [dim]  still waiting ({elapsed}s): {', '.join(names)}[/dim]")
            except Exception:
                pass
            time.sleep(poll_interval)
        return False

    def run_cli(self, command: str, timeout: int = 20) -> str:
        """Run a Fabric Studio CLI command over SSH and return stdout."""
        async def _run():
            conn = await asyncio.wait_for(
                asyncssh.connect(
                    self.pod_host, port=22,
                    username=self.client.username,
                    password=self.client.password,
                    known_hosts=None, client_keys=[],
                ),
                timeout=timeout,
            )
            async with conn:
                result = await asyncio.wait_for(conn.run(command), timeout=timeout)
                return result.stdout or ""
        return asyncio.run(_run())
