"""Port forwarding helpers and VM access utilities."""

# Port-forwarding base offsets per access type (Fabric Studio convention).
# Mirrors fabric_studio.admin.ACCESS_FORWARD_BASE: HTTPS2HTTP (pod terminates TLS,
# proxies to guest :80) gets its own 16000 range, HTTP its 18000 range.
ACCESS_PORT_BASE = {
    "SSH":       11000,
    "HTTPS":     13000,
    "HTTPS2HTTP": 16000,
    "RDP":       17000,
    "HTTP":      18000,
    "VNC":       14000,
    "SPICE":     15000,
}


def external_port(port_idx: int, access_type: str) -> int | None:
    base = ACCESS_PORT_BASE.get(access_type.upper())
    return base + port_idx if base is not None else None


def public_accesses(vm: dict) -> list[dict]:
    return [a for a in vm.get("accesses", []) if a.get("mode") == "PUBLIC"]


def vm_external_url(pod_host: str, vm: dict, access_type: str) -> str | None:
    port_idx = vm.get("port_idx")
    if port_idx is None:
        return None
    if not any(a.get("type") == access_type for a in public_accesses(vm)):
        return None
    port = external_port(port_idx, access_type)
    scheme = {"SSH": "ssh", "HTTPS": "https", "HTTP": "http"}.get(access_type, access_type.lower())
    return f"{scheme}://{pod_host}:{port}"


def get_vm_mgmt_ip(vm: dict) -> str | None:
    """Return the management port IPv4 address for a VM, or None."""
    for port in vm.get("ports", []):
        if port.get("mgmt") and port.get("ipv4addr"):
            return port["ipv4addr"]
    return None
