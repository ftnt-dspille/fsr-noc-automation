"""``fabric-studio-mcp connect``: add this server to the coding agents installed on this machine.

Each agent has its own ``mcp add`` command; this runs it, so no agent's config file is edited here. It prints the exact
command first, never replaces an entry that already exists unless ``--replace`` is given, and checks the result with the
agent's own ``mcp list``/``get``.
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path

from fabric_studio.mcp import skill

Runner = Callable[[Sequence[str]], tuple[int, str]]
Which = Callable[[str], str | None]

# FortiAgent's launcher is inside the app on macOS and is not on PATH there.
_FORTIAGENT_APP = "/Applications/FortiAgent.app/Contents/Resources/bin/fortiagent"


@dataclass(frozen=True)
class Agent:
    key: str
    label: str
    server_name: str
    program: str
    fallback: str | None = None   # where the program lives when it is not on PATH

    def find(self, which: Which, env: dict[str, str], exists: Callable[[str], bool] = os.path.exists) -> str | None:
        override = env.get(f"{self.key.upper()}_BIN")
        if override and exists(override):
            return override
        found = which(self.program)
        if found:
            return found
        return self.fallback if self.fallback and exists(self.fallback) else None

    def present_argv(self, exe: str, name: str) -> list[str]:
        """A command that succeeds when ``name`` is already configured (or lists it: see ``is_listed``)."""
        return {
            "fortiagent": [exe, "mcp", "show", name],
            "claude": [exe, "mcp", "get", name],
            "codex": [exe, "mcp", "get", name],
            "opencode": [exe, "mcp", "list"],
        }[self.key]

    def is_present(self, rc: int, output: str, name: str) -> bool | None:
        """True or False when the agent answered; None when it did not (its check failed: not the same as absent)."""
        if self.key == "opencode":   # `list` is the only check: look for the name in its rows
            if rc != 0:
                return None
            return any(name in line.split() for line in output.splitlines())
        if self.key == "fortiagent":   # `show` fails for an unknown name; an engine that is down fails the same way
            return True if rc == 0 else (False if "no mcp server is named" in output.lower() else None)
        return rc == 0

    def add_argv(self, exe: str, name: str, command: str) -> list[str]:
        return {
            "fortiagent": [exe, "mcp", "add", name, "--", command],
            "claude": [exe, "mcp", "add", name, "--scope", "user", "--", command],
            "codex": [exe, "mcp", "add", name, "--", command],
            "opencode": [exe, "mcp", "add", "--global", name, "--", command],
        }[self.key]

    def replace_argv(self, exe: str, name: str, command: str) -> list[list[str]] | None:
        """The commands that swap an existing entry for this one, or None when the agent cannot do it."""
        if self.key == "fortiagent":
            return [[exe, "mcp", "update", name, "--", command]]
        if self.key == "claude":
            return [[exe, "mcp", "remove", name], self.add_argv(exe, name, command)]
        if self.key == "codex":
            return [[exe, "mcp", "remove", name], self.add_argv(exe, name, command)]
        return None   # opencode has no non-interactive remove

    def list_argv(self, exe: str) -> list[str]:
        return [exe, "mcp", "list"]


AGENTS: dict[str, Agent] = {a.key: a for a in (
    Agent("fortiagent", "FortiAgent", "Fabric Studio", "fortiagent", _FORTIAGENT_APP),
    Agent("claude", "Claude Code", "fabric-studio", "claude"),
    Agent("codex", "Codex", "fabric-studio", "codex"),
    Agent("opencode", "opencode", "fabric-studio", "opencode"),
)}


def _run(argv: Sequence[str]) -> tuple[int, str]:
    try:
        p = subprocess.run(list(argv), capture_output=True, text=True, timeout=90, stdin=subprocess.DEVNULL)
    except (OSError, subprocess.SubprocessError) as e:
        return 1, f"{type(e).__name__}: {e}"
    return p.returncode, (p.stdout + p.stderr).strip()


def self_command(argv0: str | None = None, which: Which = shutil.which) -> str:
    """The absolute path an agent should start: this program, whether it was run by name or by path."""
    arg = argv0 if argv0 is not None else sys.argv[0]
    p = Path(arg)
    if p.name.startswith("fabric-studio-mcp") and (p.is_absolute() or p.exists()):
        return str(p.absolute())
    return which("fabric-studio-mcp") or str(Path(arg).absolute())


def _quote(argv: Sequence[str]) -> str:
    """The command as it would be typed: the program by name (the full path is only needed to run it)."""
    shown = [Path(argv[0]).name, *argv[1:]]
    return " ".join(f'"{a}"' if " " in a else a for a in shown)


def _tilde(p: Path, home: Path) -> str:
    try:
        return "~/" + p.relative_to(home).as_posix()
    except ValueError:
        return str(p)


def _plan_skills(agents: list[Agent], env: dict[str, str], home: Path, replace: bool) -> tuple[list[tuple[Agent, Path]], list[str]]:
    """The skill folders to write, and what to say about the rest. Never overwrites a different copy without --replace."""
    src = skill.source()
    if src is None:
        return [], ["The skill is not part of this install, so it was not copied."]
    todo: list[tuple[Agent, Path]] = []
    notes: list[str] = []
    keys = {a.key for a in agents}
    claude_dir = skill.folder("claude", {}, home)   # opencode also reads Claude Code's default folder
    for a in agents:
        if a.key == "fortiagent":
            notes.append(f"FortiAgent: import the skill in the app (Skills, then Import) from {src}")
            continue
        dst = skill.folder(a.key, env, home)
        if dst is None:
            continue
        if a.key == "opencode" and (("claude" in keys and not env.get("CLAUDE_CONFIG_DIR")) or (claude_dir / "SKILL.md").is_file()):
            notes.append(f"opencode: reads Claude Code's skills folder ({_tilde(claude_dir, home)}), so it needs no copy of its own.")
            continue
        st = skill.state(src, dst)
        if st == "current":
            notes.append(f"{a.label}: skill already installed in {_tilde(dst, home)}.")
        elif st == "different" and not replace:
            notes.append(f"{a.label}: a different copy of the skill is in {_tilde(dst, home)}. Use --replace to update it.")
        else:
            todo.append((a, dst))
    return todo, notes


def connect(args: argparse.Namespace, *, run: Runner = _run, which: Which = shutil.which,
            ask: Callable[[str], str] = input, out: Callable[[str], None] = print,
            env: dict[str, str] | None = None, command: str | None = None,
            exists: Callable[[str], bool] = os.path.exists, home: Path | None = None) -> int:
    env = dict(os.environ) if env is None else env
    home = home or Path.home()
    command = args.agent_command or command or self_command(which=which)
    found = {k: a.find(which, env, exists) for k, a in AGENTS.items()}
    wanted = args.agent or []
    unknown = [w for w in wanted if w != "all" and w not in AGENTS]
    if unknown:
        out(f"Not a known agent: {', '.join(unknown)}. Choose from: {', '.join(AGENTS)}, all.")
        return 2
    keys = list(AGENTS) if "all" in wanted else wanted or [k for k, exe in found.items() if exe]
    if not keys:
        out("No supported agent found on this machine (looked for: "
            + ", ".join(a.program for a in AGENTS.values()) + ").")
        out(f"Add the server by hand: the command to give your agent is  {command}")
        return 1

    plans: list[tuple[Agent, str, str]] = []
    for k in keys:
        agent, exe = AGENTS[k], found[k]
        if exe is None:
            out(f"{agent.label}: not installed here ({agent.program} not found); skipped.")
            continue
        plans.append((agent, exe, args.server_name or agent.server_name))
    if not plans:
        return 1

    failed = 0
    todo: list[tuple[Agent, str, str, list[list[str]]]] = []
    for agent, exe, name in plans:
        rc, text = run(agent.present_argv(exe, name))
        present = agent.is_present(rc, text, name)
        if present is None:
            out(f"{agent.label}: could not check whether '{name}' is already there ({text[:160] or 'no output'}); "
                f"skipped so nothing is overwritten.")
            failed += 1
            continue
        if present:
            steps = agent.replace_argv(exe, name, command) if args.replace else None
            if not args.replace:
                out(f"{agent.label}: already connected as '{name}'. Use --replace to point it at {command}.")
                continue
            if steps is None:
                out(f"{agent.label}: already connected as '{name}', and {agent.program} cannot replace an entry "
                    f"from the command line. Remove it in {agent.label}, then run this again.")
                failed += 1
                continue
        else:
            steps = [agent.add_argv(exe, name, command)]
        todo.append((agent, exe, name, steps))

    skills, skill_notes = ([], []) if args.no_skill else _plan_skills([a for a, _, _ in plans], env, home, args.replace)
    for agent, _exe, _name, steps in todo:
        out(f"{agent.label}:")
        for s in steps:
            out(f"  {_quote(s)}")
        for a, dst in skills:
            if a is agent:
                out(f"  copy the skill to {_tilde(dst, home)}")
    for a, dst in skills:   # an agent whose MCP entry already exists still gets its skill
        if a not in [t[0] for t in todo]:
            out(f"{a.label}:")
            out(f"  copy the skill to {_tilde(dst, home)}")
    for note in skill_notes:
        out(note)
    if not todo and not skills:
        return 1 if failed else 0
    if args.dry_run:
        out("Dry run: nothing was changed.")
        return 1 if failed else 0
    if not args.yes and ask(f"Run {'this' if len(todo) + len(skills) == 1 else 'these'}? [Y/n] ").strip().lower() not in ("", "y", "yes"):
        out("Left as it was.")
        return 1

    for agent, exe, name, steps in todo:
        for s in steps:
            rc, text = run(s)
            if rc != 0:
                out(f"{agent.label}: failed ({_quote(s)}): {text[:300]}")
                failed += 1
                break
        else:
            lrc, listing = run(agent.list_argv(exe))
            seen = any(name in line for line in listing.splitlines())
            if lrc != 0:   # the add succeeded; the agent just cannot list right now (opencode needs its service)
                out(f"{agent.label}: added as '{name}' (could not confirm with {agent.program} mcp list).")
            elif seen:
                out(f"{agent.label}: connected as '{name}'.")
            else:
                out(f"{agent.label}: {agent.program} mcp list does not show '{name}' after adding it.")
                failed += 1
    src = skill.source()
    for agent, dst in skills:
        try:
            skill.install(src, dst)   # src is not None: _plan_skills only plans when the skill is there
        except OSError as e:
            out(f"{agent.label}: could not copy the skill to {_tilde(dst, home)}: {e}")
            failed += 1
        else:
            out(f"{agent.label}: skill installed in {_tilde(dst, home)}.")
    if failed:
        return 1
    out("Next: ask the agent: List my managed Fabric Studio instances.")
    return 0
