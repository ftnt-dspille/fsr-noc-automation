"""Fabric Studio MCP server (stdio).

Run directly:
    fabric-studio-mcp          (or: python -m fabric_studio.mcp.server)

Or register in an MCP client (see tools/fs_mcp/README.md). Most tools are
non-destructive: GETs against the FS REST API plus read-only guest SSH
(``csadm ... --show-details`` / config-marker stat). A small number MUTATE the
pod model and are gated behind ``confirm=True`` so they never fire by accident
(e.g. ``set_vm_access_public``, which flips a guest's SSH/HTTPS2HTTP access to
PUBLIC and reinstalls it to allocate the external forward). Pod login creds
resolve from the backend ``Pod`` DB row (or ``--pod-user``/``--pod-pass`` env);
guest SSH creds come only from the server's environment (``FS_SOAR_SSH_USER`` /
``FS_SOAR_SSH_PASS``, or the older ``VM_USER_SOAR01`` / ``VM_PASS_SOAR01``); no tool takes a password.
"""
from __future__ import annotations

import contextvars
import functools
import glob
import inspect
import json
import logging
import os
import re
import shlex
import sys
from concurrent.futures import ThreadPoolExecutor
from typing import Annotated, Any

import anyio
import requests
from mcp.server.elicitation import ElicitationResult
from mcp.server.mcpserver import Context, MCPServer
from mcp.server.mcpserver.exceptions import ToolError, UnexpectedToolError
from mcp.server.mcpserver.resolve import Elicit, Resolve
from mcp.shared.exceptions import MCPError
from mcp.types import ToolAnnotations
from pydantic import BaseModel, Field, ValidationError

from fabric_studio import admin as fs_admin
from fabric_studio.admin import FabricStudioClient
from fabric_studio.channels.ssh import _jump_exec
from fabric_studio.client import FabricStudioAuthError
from fabric_studio.client.login_guard import LoginCooldown
from fabric_studio.mcp import diagnose as _diagnose
from fabric_studio.mcp import fleet
from fabric_studio.mcp import instances as inst
from fabric_studio.parsers.fortisoar import csadm_license_details
from fabric_studio.pod.runtime_factory import runtime_for
from fabric_studio.resolve import pod_creds as _pod_creds
from fabric_studio.resolve import resolve_fabric_id, resolve_vm
from fabric_studio.resolve import soar_mgmt_ip as _soar_mgmt_ip

# Marker probe for the guest first-boot config wizard (see config-vm.sh): success
# touches /home/csadmin/.vm_configured, failure touches .vm_configuration_failed.
# /home/csadmin is mode 700 on the appliance, so the probe runs as root via
# sudo -S (sh -c keeps the if/elif syntax whole under sudo).
_CONFIG_MARKER_PROBE = "sh -c {}".format(shlex.quote(
    "if [ -e /home/csadmin/.vm_configuration_failed ]; then echo FAILED; "
    "elif [ -e /home/csadmin/.vm_configured ]; then echo CONFIGURED; "
    "else echo PENDING; fi"))

def _arguments_message(tool: str, err: ValidationError) -> str:
    """One line per bad argument, naming it and what was sent, instead of pydantic's multi-line report."""
    parts = []
    for e in err.errors():
        where = ".".join(str(x) for x in e["loc"]) or "arguments"
        sent = "" if e["type"] == "missing" else f" (you sent {str(e.get('input'))[:60]!r})"
        parts.append(f"{where}: {e['msg']}{sent}")
    return f"{tool}: invalid arguments. " + "; ".join(parts)


class _Server(MCPServer):
    async def call_tool(self, name, arguments, context=None):
        try:
            return await super().call_tool(name, arguments, context)
        except ToolError as e:
            if isinstance(e.__cause__, ValidationError) and not isinstance(e, UnexpectedToolError):
                raise ToolError(_arguments_message(name, e.__cause__)) from e.__cause__
            raise


mcp = _Server("fabric-studio")

# Overall wall-clock cap per tool call. A healthy pod answers in well under a
# second; this only bounds a slow/unreachable pod so the call returns a clean
# error long before the MCP client's own ~2m timeout drops the connection.
_TOOL_DEADLINE_S = 60
# Tools that wait on a VM reinstall carry their own ``timeout_s`` (up to 900); the
# wrapper must outlast it or it would report a timeout while the install runs on.
_LONG_TOOL_DEADLINE_S = 1200

# asyncssh logs each remote command at INFO, and a guest command line carries the login password.
logging.getLogger("asyncssh").setLevel(logging.WARNING)


_READ_ONLY = ToolAnnotations(read_only_hint=True, open_world_hint=False)
_LOCAL_WRITE = ToolAnnotations(read_only_hint=False, destructive_hint=False, open_world_hint=False)
_MUTATING = ToolAnnotations(read_only_hint=False, destructive_hint=True, idempotent_hint=False,
                            open_world_hint=False)


class _Approval(BaseModel):
    approve: bool = Field(False, description="Run it now?")


def _approval_message(name: str, plan: Any) -> str:
    # a plan that names a device is about that device, not the pod; the preview's own "re-run with confirm" notes
    # are for the agent, and the person is the one being asked
    what = f"the device {plan['device']}" if isinstance(plan, dict) and plan.get("device") else "the pod"
    shown = {k: v for k, v in plan.items() if k not in ("dry_run", "note", "note2")} if isinstance(plan, dict) else plan
    body = json.dumps(shown, indent=2, default=str)
    if len(body) > 1800:
        body = body[:1800] + "\n... (truncated)"
    return f"{name} will change {what}. Plan:\n{body}"


def _can_elicit(ctx: Context) -> bool:
    """Did the client declare form elicitation? (A bare ``elicitation: {}`` counts, as in the SDK.)"""
    caps = ctx.client_capabilities
    e = caps.elicitation if caps is not None else None
    return e is not None and (e.form is not None or e.url is None)


def _judge(approval: Any) -> tuple[str, Any]:
    """Read the SDK's answer to the approval resolver: ``ok``, ``declined``, ``noop`` or ``cannot_ask``."""
    if getattr(approval, "action", "accept") != "accept":
        return "declined", None
    data = approval.data
    if isinstance(data, dict):
        return ("noop", data["noop"]) if "noop" in data else ("cannot_ask", data.get("cannot_ask"))
    return ("ok", None) if getattr(data, "approve", False) else ("declined", None)


async def _ask_human(ctx: Context, name: str, plan: Any) -> bool | None:
    """Ask the person (MCP elicitation), showing what is about to happen. ``True`` approved, ``False``
    declined, ``None`` the client cannot ask. ``FS_MCP_ASSUME_CONFIRMED=1`` skips the question for
    unattended scripts: it is the operator's switch, an agent cannot set it."""
    if os.environ.get("FS_MCP_ASSUME_CONFIRMED") == "1":
        return True
    try:
        r = await ctx.elicit(message=_approval_message(name, plan), schema=_Approval)
    except Exception:
        logging.getLogger(__name__).exception("the client could not answer the approval question")
        return None
    return r.action == "accept" and bool(r.data.approve)


_STEP: contextvars.ContextVar[list | None] = contextvars.ContextVar("fs_mcp_step", default=None)
_HEARTBEAT_S = 10


def _step(message: str) -> None:
    """Tell the person what a long tool is doing now. It rides the next progress update."""
    holder = _STEP.get()
    if holder is not None:
        holder[0] = message


async def _heartbeat(ctx: Context, name: str, holder: list) -> None:
    """While a long change runs in its worker thread, send the client a progress update every few
    seconds (elapsed time and the current step), so it shows activity and does not time out."""
    start = anyio.current_time()
    while True:
        await anyio.sleep(_HEARTBEAT_S)
        elapsed = int(anyio.current_time() - start)
        try:
            await ctx.report_progress(elapsed, None, f"{name}: {holder[0] or 'working'} ({elapsed}s)")
        except Exception:
            return


def _internal(fn):
    """A tool implementation that is not registered itself: the consolidated tools (``pods``, ``fabric``,
    ``vm``, ``tasks``) call it. Fewer, broader tools are easier for an agent to choose between."""
    return fn


def _explain(e: Exception, host: Any = None) -> ToolError:
    """Turn an operational failure into a message the client can act on. The SDK shows a client only the
    text of a ``ToolError``; any other exception arrives as a bare "Error executing tool", which hides a
    login cooldown, an unreachable pod or an HTTP refusal. Known failures get a hint; an unknown one keeps
    its type and message (cut short) and is logged with its traceback on the server."""
    text = str(e)
    where = f" {host}" if isinstance(host, str) and host else " the pod"
    if isinstance(e, LoginCooldown):
        text = re.sub(r"the last attempt failed \(Exception: Request failed.*?\); retry",
                      "the last attempt could not reach it; retry", text)
        return ToolError(f"{text}. Wait that long before the next call: retrying in a loop extends the pod's "
                         "rate-limit block.")
    if isinstance(e, FabricStudioAuthError):
        return ToolError(text)
    if isinstance(e, requests.exceptions.SSLError):
        return ToolError(f"TLS to{where} failed ({text[:160]}).")
    # The client wraps a failed request in a bare Exception("Request failed: <requests error>").
    if (isinstance(e, (requests.exceptions.ConnectionError, requests.exceptions.Timeout))
            or (type(e) is Exception and text.startswith("Request failed"))):
        low = text.lower()
        why = ("timed out" if "timed out" in low or "timeout" in low else
               "refused the connection" if "refused" in low else
               "does not resolve" if "name or service" in low or "nodename" in low or "resolution" in low else
               "did not answer")
        return ToolError(f"cannot reach{where} over HTTPS: it {why}. Check that it is powered on and that this "
                         "machine can reach it (pods view reach); a VPN may be needed.")
    if isinstance(e, fs_admin.FabricStudioAdminError):
        hint = ""
        m = re.search(r"HTTP (\d{3})", text)
        code = int(m.group(1)) if m else 0
        if code == 401:
            hint = " The pod rejected the login or the session expired: check the password for this pod."
        elif code == 403:
            hint = " This account is not allowed to do that on the pod."
        elif code == 404:
            hint = " It does not exist on the pod: check the id or name."
        elif code == 409 or "in-flight" in text or "conflict" in text.lower():
            hint = " Another task is in flight on the pod: see tasks, and retry when it finishes."
        elif code >= 500:
            hint = " The pod failed to answer properly: retry once, and check pods view health."
        return ToolError(text + hint)
    logging.getLogger(__name__).exception("unexpected failure in a tool")
    return ToolError(f"unexpected {type(e).__name__}: {text[:300]} (the server log has the traceback)")


def _exit_error(e: SystemExit) -> ToolError:
    """The library's lookup helpers (a VM, fabric or login that is not found) end with ``sys.exit(message)``.
    Left alone, that is not an ordinary error: it escapes the tool and drops the connection. The message is
    already the helpful part ("VM 'x' not found. Available: ..."), so hand it to the client as the tool error."""
    return ToolError(str(e.code) if isinstance(e.code, str) and e.code else "the request could not be resolved")


def _tool(fn=None, *, deadline_s: int = _TOOL_DEADLINE_S, mutating: bool = False, local_write: bool = False):
    """Register a tool so a blocking pod call never freezes the stdio event loop.

    The ``mcp`` SDK runs a *sync* tool function inline on the asyncio event loop
    (see ``func_metadata.call_fn_with_arg_validation``). A blocking ``requests``
    call there stalls the whole server -- it can't answer the client, which then
    closes the connection and takes every fabric-studio tool down with it. So we
    run each sync tool in a worker thread under an overall deadline; the loop (and
    the stdio transport) stays responsive throughout. Already-async tools manage
    their own timeouts and don't block the loop, so they pass through unchanged.

    Every tool carries MCP annotations so a client can prompt correctly: read-only by default,
    ``local_write`` for the registry/lockout files, ``mutating`` for anything that changes a pod. A
    ``mutating`` tool has a ``confirm`` parameter; when it is true the server FIRST runs the tool as a
    dry run, then asks the person to approve that plan, and only then runs it. The agent cannot
    approve for them: if the client cannot ask, the change is refused.
    """
    if fn is None:
        return functools.partial(_tool, deadline_s=deadline_s, mutating=mutating, local_write=local_write)
    ann = _MUTATING if mutating else _LOCAL_WRITE if local_write else _READ_ONLY
    if inspect.iscoroutinefunction(fn):
        @functools.wraps(fn)
        async def _guard(*args, **kwargs):
            if isinstance(kwargs.get("host"), str):
                kwargs["host"] = _registered_host(kwargs["host"])
            try:
                return await fn(*args, **kwargs)
            except SystemExit as e:
                raise _exit_error(e) from None
            except (ToolError, MCPError, ExceptionGroup):
                raise
            except Exception as e:
                raise _explain(e, kwargs.get("host")) from e
        return mcp.tool(annotations=ann)(_guard)
    sig = inspect.signature(fn)

    async def _run(**kw):
        if isinstance(kw.get("host"), str):
            kw["host"] = _registered_host(kw["host"])
        try:
            with anyio.fail_after(deadline_s):
                return await anyio.to_thread.run_sync(functools.partial(fn, **kw), abandon_on_cancel=True)
        except SystemExit as e:
            raise _exit_error(e) from None
        except (ToolError, MCPError):
            raise
        except TimeoutError:
            raise ToolError(
                f"{fn.__name__} exceeded {deadline_s}s and was aborted "
                "(pod slow or unreachable); the MCP server stays up -- retry, or "
                "use the CLI/SSH path for this pod.") from None
        except Exception as e:
            raise _explain(e, kw.get("host")) from e

    _CANNOT_ASK = ("this client cannot ask the person to approve; run it from a client that supports "
                   "MCP elicitation, or set FS_MCP_ASSUME_CONFIRMED=1 for an unattended run")

    async def _approval(**named):
        """Runs before the tool body, driven by the SDK. With ``confirm`` it previews the change (read only)
        and asks the person. The SDK asks in whichever way the client's protocol version allows: a request
        mid-call for older clients, a multi-round result for newer ones such as Claude Code. A plain
        ``ctx.elicit`` call cannot reach a newer client at all."""
        ctx = named.pop("ctx")
        if not named.get("confirm"):
            return None
        plan = await _run(**{**named, "confirm": False})
        if isinstance(plan, dict) and plan.get("noop"):
            return {"noop": plan}
        if os.environ.get("FS_MCP_ASSUME_CONFIRMED") == "1":
            return _Approval(approve=True)
        if not _can_elicit(ctx):
            return {"cannot_ask": plan}
        return Elicit(message=_approval_message(fn.__name__, plan), schema=_Approval)

    @functools.wraps(fn)
    async def _runner(*args, **kwargs):
        ctx = kwargs.pop("ctx", None)
        approval = kwargs.pop("approval", None)
        bound = sig.bind(*args, **kwargs)
        bound.apply_defaults()
        kw = dict(bound.arguments)
        if mutating and kw.get("confirm") and approval is not None:
            verdict, plan = _judge(approval)
            if verdict == "noop":
                # Nothing would change, so there is nothing to approve. Answer from the preview: running the
                # tool again could act on state that changed since, with no question asked.
                return {"executed": False, "reason": "nothing to change", **plan}
            if verdict == "cannot_ask":
                return {"executed": False, "reason": _CANNOT_ASK, "plan": plan}
            if verdict == "declined":
                return {"executed": False, "reason": "the person declined"}
        elif mutating and kw.get("confirm"):  # called directly (not through the SDK): ask here
            plan = await _run(**{**kw, "confirm": False})
            if isinstance(plan, dict) and plan.get("noop"):
                return {"executed": False, "reason": "nothing to change", **plan}
            ok = await _ask_human(ctx, fn.__name__, plan) if ctx is not None else None
            if ok is not True:
                why = "the person declined" if ok is False else _CANNOT_ASK
                return {"executed": False, "reason": why, "plan": plan}
        if not (mutating and ctx is not None):
            return await _run(**kw)
        holder: list = [None]
        _STEP.set(holder)
        try:
            async with anyio.create_task_group() as tg:
                tg.start_soon(_heartbeat, ctx, fn.__name__, holder)
                try:
                    return await _run(**kw)
                finally:
                    tg.cancel_scope.cancel()
        except BaseExceptionGroup as group:
            # The task group wraps the tool's own error; the client must see its message, not "unhandled errors".
            if len(group.exceptions) == 1:
                raise group.exceptions[0] from None
            raise

    if mutating:  # the SDK injects a Context into a parameter annotated as one, and runs the approval resolver
        _approval.__signature__ = sig.replace(
            parameters=[inspect.Parameter("ctx", inspect.Parameter.POSITIONAL_OR_KEYWORD, annotation=Context),
                        *sig.parameters.values()], return_annotation=inspect.Signature.empty)
        _approval.__annotations__ = {**getattr(fn, "__annotations__", {}), "ctx": Context}
        _approval.__annotations__.pop("return", None)
        approval_type = Annotated[ElicitationResult[_Approval], Resolve(_approval)]
        _runner.__signature__ = sig.replace(parameters=[
            *sig.parameters.values(),
            inspect.Parameter("ctx", inspect.Parameter.KEYWORD_ONLY, annotation=Context),
            inspect.Parameter("approval", inspect.Parameter.KEYWORD_ONLY, annotation=approval_type, default=None)])
        _runner.__annotations__ = {**getattr(fn, "__annotations__", {}), "ctx": Context, "approval": approval_type}
    return mcp.tool(annotations=ann)(_runner)

_FABRIC_DECL = re.compile(r"^\s*fabric:\s*(\S+)")


@functools.lru_cache(maxsize=1)
def _fabric_topologies() -> dict[str, str]:
    """Map a fabric name to the topology that declares it. Each
    ``<workspace>/topologies/<dir>/intent.yaml`` (for every ``$FS_WORKSPACE`` folder)
    carries a top-level ``fabric: <name>`` key; this returns ``{fabric_name: topology_dir}``
    so the instance listings can say which topology generated a running fabric. Empty when
    no workspace is set. Read once, best-effort: an unreadable intent file is skipped."""
    out: dict[str, str] = {}
    intents = [i for ws in inst.workspace_dirs()
               for i in glob.glob(os.path.join(ws, "topologies", "*", "intent.yaml"))]
    for intent in intents:
        topo = os.path.basename(os.path.dirname(intent))
        try:
            with open(intent, encoding="utf-8") as fh:
                for line in fh:
                    m = _FABRIC_DECL.match(line)
                    if m:
                        out[m.group(1).strip().strip("\"'")] = topo
                        break
        except OSError:
            continue
    return out

# One authenticated client per host; FS login is cheap but not free.
_CLIENTS: dict[str, FabricStudioClient] = {}


class UnmanagedHostError(ToolError, ValueError):
    """A tool was pointed at a host that is not registered. A ``ToolError`` so the SDK passes the
    message to the client (it hides any other exception text) and Claude can say what to do."""


def _known_host(host: str) -> bool:
    """A host we were told about: a registered instance, or a Pod row in the local database."""
    if not inst.HOST_OK.match(host or ""):
        return False
    if host in inst.load_registry():
        return True
    try:
        from sqlmodel import select

        from fabric_studio.db import get_session
        from fabric_studio.models import Pod
        with get_session() as s:
            return s.exec(select(Pod).where(Pod.host == host)).first() is not None
    except Exception:
        return False


def _registered_host(host: str) -> str:
    """The managed instance's host for what the person said: the host itself, or a name it was registered
    under (``pod-250-178``). Every tool gets the host, so links and logins use the real address."""
    registry = inst.load_registry()
    if host in registry:
        return host
    named = [h for h, v in registry.items() if str(v.get("name") or "").lower() == host.strip().lower()]
    return named[0] if len(named) == 1 else host


def _login(host: str) -> tuple[str, str]:
    """A managed instance's own login first (its env file or keychain entry), else the shared
    chain (keychain default, DB row, ``$POD_*``) but only for a host we know. A tool's ``host``
    argument is model-controlled, so an unknown host must never receive the shared password."""
    own = inst.creds_for(host)
    if own:
        return own
    if not _known_host(host):
        named = [h for h, v in inst.load_registry().items() if str(v.get("name") or "").lower() == str(host).lower()]
        if len(named) == 1:  # a registered NAME is not a host: say which host it is, not that it is unregistered
            raise UnmanagedHostError(f"{host!r} is the name of the managed instance at {named[0]}: pass that host "
                                     f"({named[0]}) as host")
        raise UnmanagedHostError(f"{host!r} is not a managed instance: register it with add_instance "
                                 "(from an env file that names it) before using it")
    return _pod_creds(host, None, None)


def _connect(host: str, timeout_s: int = 30,
             creds: tuple[str, str] | None = None) -> FabricStudioClient:
    """A logged-in client. The core client reuses the shared cached session and guards new
    logins with a per-pod lock and cooldown (``fabric_studio.client.login_guard``)."""
    u, p = creds or _login(host)
    return FabricStudioClient(host, u, p, timeout_s=timeout_s)


def _client(host: str) -> FabricStudioClient:
    c = _CLIENTS.get(host)
    if c is None:
        c = _CLIENTS[host] = _connect(host)
    return c


def _ssh_creds() -> tuple[str, str]:
    """The FortiSOAR guest login, from the server's environment only (never a tool argument)."""
    user = os.environ.get("FS_SOAR_SSH_USER") or os.environ.get("VM_USER_SOAR01") or "csadmin"
    pw = os.environ.get("FS_SOAR_SSH_PASS") or os.environ.get("VM_PASS_SOAR01")
    if not pw:
        raise ToolError("the FortiSOAR guest login is not configured: set FS_SOAR_SSH_PASS (and, if it is not "
                        "csadmin, FS_SOAR_SSH_USER) in the MCP server's environment")
    return user, pw


def _resolve(host: str, vm: str | None, fabric: str | None,
             vm_type: str | None = None) -> tuple[FabricStudioClient, int, dict]:
    """(client, fabric_id, vm_dict) for the common host/vm/fabric tool params."""
    c = _client(host)
    fid = resolve_fabric_id(c, fabric)
    v = resolve_vm(c, fid, vm, vm_type)
    return c, fid, v


# ── Inventory ────────────────────────────────────────────────────────────────

@_internal
def list_pods() -> list[dict[str, Any]]:
    """FS pods known to the backend DB. Each row carries the connection ``host``
    (what every other tool's ``host`` argument expects), the pod's own device
    ``hostname`` (from ``GET api/v1/system/hostname``; ``None`` if the pod is
    unreachable), an ``online`` flag (FS API reachable + login succeeded in a
    short probe timeout), plus ``pod_type`` / ``username`` / ``tags`` /
    ``device_count``.
    ``tags`` is the human-label mechanism - tag pods (e.g. ``builder``,
    ``soar-testing``) to tell them apart."""
    try:
        from sqlmodel import select

        from fabric_studio.db import get_session
        from fabric_studio.models import Device, Pod
        with get_session() as s:
            rows: list[dict[str, Any]] = []
            for p in s.exec(select(Pod)).all():
                cnt = len(s.exec(
                    select(Device).where(Device.pod_id == p.id)).all())
                rows.append({"pod_id": p.id, "host": p.host,
                             "pod_type": p.pod_type or "fs",
                             "username": p.username, "tags": p.tags or [],
                             "device_count": cnt})
    except Exception as e:
        # No backend DB in this checkout: the managed-instance registry is the list.
        rows = [{"pod_id": None, "host": h, "pod_type": "fs", "username": e_.get("user"),
                 "tags": e_.get("tags") or [], "device_count": None, "name": e_.get("name")}
                for h, e_ in inst.load_registry().items()]
        if not rows:
            return [{"error": f"DB pod lookup failed ({e}) and no instance is registered; "
                              "use discover_instances then add_instance"}]

    # Probe each pod in parallel with a throwaway short-timeout client so a
    # stale/unreachable DB row fails fast (~10s blackhole, instant refused)
    # instead of stalling the whole list. online = login succeeded; the hostname
    # comes from the same probe's system/hostname GET.
    def _probe(host: str) -> tuple[str, tuple[str | None, bool]]:
        try:
            c = _connect(host, 10)  # logs in
            return host, (fs_admin.get_pod_hostname(c), True)
        except Exception:
            return host, (None, False)

    with ThreadPoolExecutor(max_workers=min(8, len(rows) or 1)) as ex:
        probed = dict(ex.map(_probe, [r["host"] for r in rows]))
    for r in rows:
        hn, online = probed.get(r["host"], (None, False))
        r["hostname"] = hn
        r["online"] = online
    return rows


# ── Managed instances ────────────────────────────────────────────────────────

def _probe(host: str) -> dict[str, Any]:
    """Short-timeout login: ``{online, hostname}`` (never raises, never returns secrets)."""
    try:
        c = _connect(host, 10)
        return {"online": True, "hostname": fs_admin.get_pod_hostname(c)}
    except BaseException as e:  # SystemExit from a missing login included
        return {"online": False, "error": f"{type(e).__name__}: {str(e)[:120]}"}


@_internal
def discover_instances(probe: bool = False) -> list[dict[str, Any]]:
    """Every Fabric Studio pod we hold a trace of: ``.env`` / ``.env.<name>`` files (here, in
    fabric_studio_fixer, ``~/.fsh`` and ``FS_ENV_DIRS``), ``fabric.toml``, ``pods.txt`` /
    ``faig_pods.txt`` and topology ``vars.*.yml``. Per host: where it was found, the login
    user, whether a password is on file (never the password), and whether it is already a
    managed instance. ``probe=True`` also logs in to each with credentials to see if it is up.
    Pass the ones you want managed to ``add_instance``."""
    rows = inst.instances_status(inst.discover(), inst.load_registry())
    locks = inst.lockouts()
    for r in rows:
        r["lockouts"] = locks.get(r["host"], [])
        r["locked"] = inst.is_locked(r["lockouts"])
    if probe:
        todo = [r["host"] for r in rows if r["has_password"] or r["registered"]]
        with ThreadPoolExecutor(max_workers=min(8, len(todo) or 1)) as ex:
            probed = dict(zip(todo, ex.map(_probe, todo), strict=True))
        for r in rows:
            r.update(probed.get(r["host"], {"online": None}))
    return rows


@_internal
def list_instances(probe: bool = True) -> list[dict[str, Any]]:
    """The managed instances (the registry in ``~/.fsh/instances.json``): host, name, login
    user, tags, how its password is held (env file path or keychain), and with ``probe`` whether
    it is online. See ``discover_instances`` for pods not managed yet."""
    reg = inst.load_registry()
    rows = [{"host": h, "name": e.get("name"), "user": e.get("user"), "tags": e.get("tags") or [],
             "env_file": e.get("env_file"), "password_in": "env file" if e.get("env_file") else "keychain",
             "added_at": e.get("added_at")} for h, e in sorted(reg.items())]
    locks = inst.lockouts()
    for r in rows:
        r["lockouts"] = locks.get(r["host"], [])
        r["locked"] = inst.is_locked(r["lockouts"])
    if probe and rows:
        with ThreadPoolExecutor(max_workers=min(8, len(rows))) as ex:
            for r, p in zip(rows, ex.map(_probe, [r["host"] for r in rows]), strict=True):
                r.update(p)
    return rows


def _pod_overview(host: str, only_running: bool,
                  creds: tuple[str, str] | None = None) -> dict[str, Any]:
    try:
        c = _connect(host, 20, creds)
    except BaseException as e:
        return {"host": host, "online": False, "error": f"{type(e).__name__}: {str(e)[:120]}"}
    try:
        fabrics = fs_admin.list_fabrics(c)
        running = {}
        for v in fs_admin.runtime_vms(c):
            running.setdefault(str(v.get("fabric")), set()).add(v.get("id"))
        out, up_total = [], 0
        locks = inst.lockouts().get(host, [])
        topo_map = _fabric_topologies()
        for f in fabrics:
            vms = fs_admin.list_fabric_vms(c, f.get("id"))
            live = running.get(str(f.get("id")), set())
            devices = []
            for v in vms:
                st = (fs_admin.get_vm_runtime_state(c, v["id"]).get("status") or {}) if v.get("id") in live else {}
                devices.append({"id": v.get("id"), "name": v.get("name"), "vm_type": v.get("vm_type"),
                                "up": bool(st.get("powered")), "ready": bool(st.get("post_boot_prepared"))})
            up = sum(d["up"] for d in devices)
            up_total += up
            if only_running and not up:
                continue
            out.append({"id": f.get("id"), "name": f.get("name"), "status": f.get("status"),
                        "topology": topo_map.get(f.get("name")),
                        "locked": inst.is_locked(locks, f.get("name")),
                        "devices_up": up, "devices_total": len(devices), "devices": devices})
        return {"host": host, "online": True, "devices_up": up_total, "lockouts": locks,
                "locked": inst.is_locked(locks), "fabrics": out}
    except Exception as e:
        return {"host": host, "online": True, "error": f"{type(e).__name__}: {str(e)[:160]}"}


@_internal
def instances_overview(hosts: list[str] | None = None,
                       only_running: bool = False) -> list[dict[str, Any]]:
    """The devices up in every fabric of every managed instance (or just ``hosts``): per pod,
    each fabric with its devices (``up`` = powered, ``ready`` = first boot finished) and counts.
    ``only_running`` leaves out fabrics with nothing powered. An unreachable pod is reported
    with its error rather than failing the call."""
    targets = hosts or sorted(inst.load_registry())
    if not targets:
        return [{"error": "no managed instances; run discover_instances, then add_instance"}]
    with ThreadPoolExecutor(max_workers=min(6, len(targets))) as ex:
        return list(ex.map(lambda h: _pod_overview(h, only_running), targets))


@_internal
def whats_up(include_unmanaged: bool = True, vm_type: str | None = None,
             name_contains: str | None = None) -> dict[str, Any]:
    """Only what is online (each pod and fabric also says whether it is ``locked`` against changes): for every managed instance, and every pod with a password in a
    discovered ``.env*`` file (``include_unmanaged``), the fabrics that have powered devices
    and just those devices. Each pod says where it came from: ``instance`` (managed, with its
    name) or the ``.env`` file. Pods that did not answer are listed under ``unreachable``
    with the reason, nothing else. Use ``instances_overview`` for the full per-fabric detail.

    Filters: ``vm_type`` (comma list, case-insensitive: ``FGT``, ``FMG``, ``FAZ``, ``FWB``,
    ``LXC``, ``BASIC``...) and ``name_contains`` keep only matching devices; pods and fabrics
    left with none are dropped. ``whats_up(vm_type="FGT")`` is every online FortiGate."""
    want = {t.strip().upper() for t in (vm_type or "").split(",") if t.strip()}
    needle = (name_contains or "").lower()
    reg = inst.load_registry()
    targets: dict[str, dict[str, Any]] = {
        h: {"source": "instance", "instance": e.get("name"), "env_file": e.get("env_file"), "creds": None}
        for h, e in reg.items()}
    if include_unmanaged:
        for row in inst.discover():
            if row["host"] in targets:
                continue
            for src in row["sources"]:
                f = src.get("source")
                if src.get("kind") == "env file" and row.get("has_password") and f:
                    try:
                        creds = inst.creds_from_env_file(inst.allowed_env_file(f))
                    except ValueError:
                        continue
                    if creds:
                        targets[row["host"]] = {"source": f, "instance": None, "env_file": f, "creds": creds}
                        break
    if not targets:
        return {"pods": [], "unreachable": [], "note": "no instances or env files with a password found"}
    hosts = sorted(targets)
    with ThreadPoolExecutor(max_workers=min(6, len(hosts))) as ex:
        overviews = list(ex.map(lambda h: _pod_overview(h, True, targets[h]["creds"]), hosts))
    pods, down = [], []
    for h, ov in zip(hosts, overviews, strict=True):
        t = targets[h]
        if not ov.get("online") or ov.get("error"):
            down.append({"host": h, "source": t["source"], "error": ov.get("error"),
                         "lockouts": inst.lockouts().get(h, [])})
            continue
        if not ov["devices_up"]:
            continue
        fabrics = []
        for f in ov["fabrics"]:
            devs = [{"name": d["name"], "type": d["vm_type"], "ready": d["ready"]}
                    for d in f["devices"] if d["up"]
                    and (not want or str(d["vm_type"]).upper() in want)
                    and (not needle or needle in str(d["name"]).lower())]
            if devs:
                fabrics.append({"fabric": f["name"], "id": f["id"], "topology": f.get("topology"),
                                "locked": f["locked"], "devices": devs})
        if not fabrics:
            continue
        pods.append({"host": h, "source": t["source"], "instance": t["instance"],
                     "devices_up": sum(len(f["devices"]) for f in fabrics),
                     "locked": ov["locked"], "lockouts": ov["lockouts"], "fabrics": fabrics})
    return {"pods": pods, "unreachable": down}


@_internal
def list_lockouts() -> list[dict[str, Any]]:
    """Every engaged lockout (a freeze on apply/provision/services/destroy for a pod, or one
    fabric on it; ``fabric: "*"`` means the whole pod), with who set it, when and why, and
    whether the pod is a managed instance. Read only: engaging or lifting one is
    ``fs_topology lockout`` and needs the owner's go-ahead."""
    reg = inst.load_registry()
    return [{"host": h, "managed": h in reg, "instance": (reg.get(h) or {}).get("name"), **lk}
            for h, ls in sorted(inst.lockouts().items()) for lk in ls]


def _each(hosts: list[str] | None, fn: Any, timeout_s: int = 20) -> list[dict[str, Any]]:
    """Run ``fn(client, host)`` on every managed instance (or ``hosts``) in parallel. An
    unreachable pod is reported with its error instead of failing the call."""
    targets = hosts or sorted(inst.load_registry())
    if not targets:
        return [{"error": "no managed instances; run discover_instances, then add_instance"}]

    def one(h: str) -> dict[str, Any]:
        try:
            c = _connect(h, timeout_s)
        except BaseException as e:  # SystemExit from a missing login included
            return {"host": h, "online": False, "error": f"{type(e).__name__}: {str(e)[:120]}"}
        try:
            return {"host": h, "online": True, **fn(c, h)}
        except Exception as e:
            return {"host": h, "online": True, "error": f"{type(e).__name__}: {str(e)[:160]}"}

    with ThreadPoolExecutor(max_workers=min(6, len(targets))) as ex:
        return list(ex.map(one, targets))


@_internal
def find_device(query: str, hosts: list[str] | None = None, up_only: bool = False) -> list[dict[str, Any]]:
    """Where is this device? Case-insensitive name match across every managed instance (or
    ``hosts``): pod, instance, fabric, type, powered/ready, whether the pod or fabric is
    locked, and where its public SSH/HTTPS/RDP forwards would sit (only live if the access is
    PUBLIC; ``reach_matrix`` tests them)."""
    locks = inst.lockouts()
    reg = inst.load_registry()
    out = []
    for pod in _each(hosts, lambda c, h: {"devices": fleet.device_rows(c)}):
        for r in fleet.match(pod.get("devices") or [], query, up_only):
            h = pod["host"]
            out.append({"host": h, "instance": (reg.get(h) or {}).get("name"), "fabric": r["fabric"],
                        "name": r["name"], "type": r["vm_type"], "up": r["up"], "ready": r["ready"],
                        "locked": inst.is_locked(locks.get(h), r["fabric"]),
                        "forwards": fleet.forwards(h, r["port_idx"]) if r["up"] else {}})
        if pod.get("error") or not pod.get("online"):
            out.append({"host": pod["host"], "error": pod.get("error"), "online": pod.get("online")})
    return out


@_internal
def pods_health(hosts: list[str] | None = None) -> list[dict[str, Any]]:
    """Is it safe to act on each pod: hostname, tasks running (an install in flight), the
    running fabric, hugepage headroom, whether a local apply holds the pod lock, and any
    lockout. ``busy`` is true when a task is running or an apply holds the lock. (For one
    pod's version, disk and licence counts use ``pod_health``.)"""
    locks = inst.lockouts()
    rows = _each(hosts, lambda c, h: fleet.health(c, h))
    for r in rows:
        if "host" in r:
            r["lockouts"] = locks.get(r["host"], [])
            r["locked"] = inst.is_locked(r["lockouts"])
    return rows


@_internal
def licenses_overview(hosts: list[str] | None = None) -> list[dict[str, Any]]:
    """Licensing per pod: FortiCloud/FortiFlex registered, the FS license pool by type, and
    for every powered device the mode and the serial FS served it. This is FS-side state; a
    served serial can still be a UUID-locked stub or the guest can reject it, so confirm with
    ``validate_license_match`` / ``read_guest_license`` on the device in question."""
    return _each(hosts, lambda c, h: fleet.licensing(c), timeout_s=30)


@_internal
def reach_matrix(hosts: list[str] | None = None, devices: bool = False) -> list[dict[str, Any]]:
    """Can THIS workstation reach each pod (HTTPS 443, SSH 22)? With ``devices=True`` also the
    SSH and HTTPS forward of every powered device. Separates "pod down" from "forward
    blocked". TCP/banner/TLS handshakes only, no logins."""
    return _each(hosts, lambda c, h: fleet.reach(c, h, devices), timeout_s=10)


@_tool(local_write=True)
def engage_lockout(host: str, reason: str, fabric: str = "*") -> dict[str, Any]:
    """Freeze apply/provision/services/destroy on a managed pod (``fabric="*"``, the default)
    or one fabric on it. ``reason`` is required and shown to whoever hits the freeze.
    Refuses to overwrite an existing lockout. There is deliberately NO tool to lift one:
    that is ``fs_topology lockout off`` and needs the owner's go-ahead."""
    if host not in inst.load_registry():
        return {"ok": False, "error": f"{host} is not a managed instance"}
    return inst.engage_lockout(host, fabric, reason)




@_internal
def device_credentials_hint(host: str, device: str, fabric: str | None = None) -> dict[str, Any]:
    """How to log in to a device without guessing: the default user for its type, where its
    password comes from, the exact ``fabric ssh`` command, its forwards and (FortiGate) the API
    token minting command. Never returns a password. A rejected login is usually the wrong
    route or an armed lockout, not a wrong password, so use these commands."""
    rows = fleet.match(_each([host], lambda c, h: {"devices": fleet.device_rows(c)})[0].get("devices") or [], device)
    rows = [r for r in rows if fabric is None or r["fabric"] == fabric]
    exact = [r for r in rows if str(r["name"]).lower() == device.lower()] or rows
    if len(exact) > 1 and fabric is None and sum(r["up"] for r in exact) == 1:
        exact = [r for r in exact if r["up"]]  # the same name in a stopped fabric is not the one meant
    if len(exact) != 1:
        return {"ok": False, "error": f"{len(exact)} devices match {device!r} on {host}",
                "matches": [{"fabric": r["fabric"], "name": r["name"]} for r in exact]}
    return {"ok": True, "host": host, "fabric": exact[0]["fabric"], "name": exact[0]["name"],
            "type": exact[0]["vm_type"], **fleet.credentials_hint(host, exact[0])}


@_tool(local_write=True)
def add_instance(host: str | None = None, env_file: str | None = None, name: str | None = None,
                 tags: list[str] | None = None, user: str | None = None, store: str = "env_file",
                 verify: bool = True, dry_run: bool = False) -> dict[str, Any]:
    """Make a pod a managed instance. Give ``env_file`` (a ``.env*`` file from
    ``discover_instances``; its host and login are used) and/or ``host``. ``store`` is
    ``env_file`` (remember the file, copy nothing) or ``keychain`` (copy the password into the
    OS keychain). ``verify`` logs in first and refuses a pod that rejects the login;
    ``dry_run`` checks everything and changes nothing. Passwords are never taken as arguments
    or returned. Only a local registry entry is written; the pod itself is untouched."""
    return inst.register(host, env_file, name=name, tags=tags, user=user, store=store,
                         verify=verify, dry_run=dry_run)


@_tool(local_write=True)
def remove_instance(host: str, forget_secret: bool = False) -> dict[str, Any]:
    """Stop managing a pod (removes its registry entry; the pod and its env file are untouched).
    ``forget_secret`` also deletes a keychain password stored for it."""
    _CLIENTS.pop(host, None)
    return inst.unregister(host, forget_secret=forget_secret)


@_internal
def list_fabrics(host: str) -> list[dict[str, Any]]:
    """List the fabrics on a pod (id, name, running state)."""
    c = _client(host)
    return [{"id": f.get("id"), "name": f.get("name"), "status": f.get("status")}
            for f in fs_admin.list_fabrics(c)]


@_internal
def list_vms(host: str, fabric: str | None = None) -> list[dict[str, Any]]:
    """List model VMs in a fabric (id, name, vm_type, firmware id and ``version``: the firmware's version, or
    its image name when it has none, such as a Linux image). ``fabric`` may be an id, a name, or omitted (the
    running fabric)."""
    c = _client(host)
    fid = resolve_fabric_id(c, fabric)
    try:
        fws = {f.get("id"): f for f in fs_admin.list_all_firmwares(c)}
    except Exception:
        fws = {}
    return [{"id": v.get("id"), "name": v.get("name"), "vm_type": v.get("vm_type"),
             "firmware": v.get("firmware"), "version": _firmware_label(fws.get(v.get("firmware")))}
            for v in fs_admin.list_fabric_vms(c, fid)]


def _firmware_label(fw: dict[str, Any] | None) -> str | None:
    if not fw:
        return None
    if fw.get("major") is not None and str(fw.get("vm_type") or "") not in ("LXC", "BASIC", "WINDOWS"):
        return ".".join(str(fw.get(k)) for k in ("major", "minor", "patch") if fw.get(k) is not None) + \
            (f" build {fw['build']}" if fw.get("build") else "")
    return str(fw.get("path") or "").rsplit("/", 1)[-1] or fw.get("version_s")


@_internal
def list_snapshots(host: str, vm_type: str | None = "SOAR") -> list[dict[str, Any]]:
    """List bootable home-repository firmwares ("snapshots") on a pod, optionally
    filtered by ``vm_type`` (default SOAR; pass null for all types). Home repository ONLY:
    to ask whether an image can be installed (FortiGate, FortiManager, ...) use ``list_firmwares``. Each row
    carries ``is_diff`` (a diff/overlay vs a standalone base) and ``diff_from``
    (the base firmware id) - overlays can't be repacked in place, only their base
    can - plus on-disk ``size``."""
    c = _client(host)
    out = []
    for f in fs_admin.list_home_firmwares(c, vm_type):
        ver = f"{f.get('major')}.{f.get('minor')}.{f.get('patch')}{f.get('version_s') or ''}"
        out.append({"id": f.get("id"), "vm_type": f.get("vm_type"), "version": ver,
                    "build": f.get("build"), "status": f.get("status"),
                    "path": f.get("path"), "is_diff": f.get("is_diff"),
                    "diff_from": f.get("diff_from"), "size": f.get("size")})
    return out


@_internal
def list_firmwares(host: str, vm_type: str | None = None, include_remote: bool = True) -> list[dict[str, Any]]:
    """Firmware images a pod can install, across ALL repositories (``home``, ``fortinet``, ...),
    optionally for one ``vm_type`` (FGT, FMG, FAZ, FSM, SOAR, ...). Answers "is the image there?",
    the first thing to check when an install fails or a plan names an image.

    ``local`` is true for ``ready``/``downloaded`` images, which install at once. A ``remote`` image is
    in a repository but not on the pod yet: Fabric Studio downloads it when it is installed, so the
    first install is slower and needs the pod's internet access. ``usable`` is false for a 0-byte
    stub. Set ``include_remote=false`` to see only what is on the pod already."""
    c = _client(host)
    out = []
    for f in fs_admin.list_all_firmwares(c, vm_type):
        status = f.get("status")
        local = status in ("ready", "downloaded")
        if not local and not include_remote:
            continue
        ver = f"{f.get('major')}.{f.get('minor')}.{f.get('patch')}{f.get('version_s') or ''}"
        out.append({"id": f.get("id"), "vm_type": f.get("vm_type"), "version": ver, "build": f.get("build"),
                    "status": status, "local": local, "usable": bool(f.get("size")),
                    "repository": (f.get("repository") or {}).get("name"), "size": f.get("size"),
                    "path": f.get("path")})
    out.sort(key=lambda r: (str(r["vm_type"]), str(r["version"]), r["build"] or 0))
    return out


# -- Pod / VM detail, topology & access ----------------------------------------

@_internal
def pod_health(host: str) -> dict[str, Any]:
    """Pod system health: device hostname, Fabric Studio version/serial/uptime,
    license counts by type, and disk LVM layout (volume groups / logical /
    physical volumes). Answers "is this pod healthy, and does it have disk for a
    build/install?" Same source as the REST ``/api/pods/health``. Each sub-field
    is best-effort; a partial response (with ``errors``) is still useful."""
    u, p = _login(host)
    pod_type = "fs"
    try:
        from sqlmodel import select

        from fabric_studio.db import get_session
        from fabric_studio.models import Pod
        with get_session() as s:
            row = s.exec(select(Pod).where(Pod.host == host)).first()
            if row:
                pod_type = row.pod_type or "fs"
    except Exception:
        pass
    rt = runtime_for(pod_type, host, u, p)
    get_health = getattr(rt, "get_system_health", None)
    if get_health is None:
        return {"hostname": None, "errors": [
            f"pod_type {pod_type!r} exposes no system_health"]}
    return get_health()


@_internal
def vm_detail(host: str, vm: str | None = None, fabric: str | None = None,
              vm_type: str | None = None) -> dict[str, Any]:
    """One-shot full picture of a VM: runtime state (powered/post_boot_prepared/
    licensed, in-flight task), loaded firmware id, license mode + served pool id,
    hypervisor params (cpu_count/memory), disks, and access entries with their
    external ports (no live probe -- use ``vm_access`` for reachability).
    Collapses the common "show me this VM" into a single call instead of 3-4."""
    c, fid, v = _resolve(host, vm, fabric, vm_type)
    vid = v["id"]
    rt = fs_admin.get_vm_runtime_state(c, vid)
    mode = fs_admin.get_vm_license_mode(c, fid, vid)
    rv = fs_admin.get_runtime_vm(c, vid)
    port_idx = rv.get("port_idx")
    accesses = []
    for a in fs_admin.list_vm_accesses(c, fid, vid):
        t = a.get("type")
        base = fs_admin.ACCESS_FORWARD_BASE.get(t)
        ext = (base + int(port_idx)) if (base is not None
                                         and port_idx is not None) else None
        accesses.append({"type": t, "mode": a.get("mode"),
                         "guest_dport": a.get("dport"), "external_port": ext})
    return {"vm_id": vid, "name": v.get("name"), "vm_type": v.get("vm_type"),
            "firmware": v.get("firmware"), "runtime_exists": rt.get("exists"),
            "status": rt.get("status"), "task": rt.get("task"),
            "license_mode": mode.get("mode"), "license_served_id": mode.get("served"),
            "params": fs_admin.get_vm_parameters(c, vid),
            "disks": fs_admin.list_vm_disks(c, vid),
            "port_idx": port_idx, "accesses": accesses}


@_internal
def vm_access(host: str, vm: str | None = None, fabric: str | None = None,
              vm_type: str | None = None, probe: bool = True) -> dict[str, Any]:
    """A VM's configured access entries (SSH/HTTP/HTTPS/RDP) and, when
    ``probe=True``, live reachability of each PUBLIC forward at
    ``pod_host:(base + port_idx)`` -- SSH 11000+, HTTPS 13000+, HTTPS2HTTP 16000+,
    HTTP 18000+, RDP 17000+ (``port_idx`` comes from the runtime VM). Returns per
    access ``{type, mode, guest_dport, external_port, ok, detail}``; the last
    three are null for PRIVATE accesses or a VM with no ``port_idx`` yet (not
    installed). Use this to answer "how do I reach this VM?"."""
    c, fid, v = _resolve(host, vm, fabric, vm_type)
    rv = fs_admin.get_runtime_vm(c, v["id"])
    port_idx = rv.get("port_idx")
    probed: dict[str, dict[str, Any]] = {}
    if probe and port_idx is not None:
        for p in fs_admin.probe_vm_accesses(c, fid, v["id"], host):
            probed[p["type"]] = p
    out = []
    for a in fs_admin.list_vm_accesses(c, fid, v["id"]):
        t = a.get("type")
        base = fs_admin.ACCESS_FORWARD_BASE.get(t)
        ext = (base + int(port_idx)) if (base is not None
                                         and port_idx is not None) else None
        p = probed.get(t, {})
        out.append({"type": t, "mode": a.get("mode"),
                    "guest_dport": a.get("dport"), "external_port": ext,
                    "ok": p.get("ok"), "detail": p.get("detail"),
                    **({"open": _open_at(host, t, ext)} if ext and a.get("mode") == "PUBLIC" else {})})
    return {"vm_id": v["id"], "name": v.get("name"), "port_idx": port_idx,
            "accesses": out,
            "note": ("`open` is where to go from a browser or a terminal. HTTPS2HTTP puts TLS in front of the "
                     "guest's plain-HTTP port (a web app's login page). The login is the device's own: Fortinet "
                     "devices use the fabric's password; a Linux or other generic guest uses its image's login. "
                     "Never put a password in a link or an answer.")}


def _open_at(host: str, kind: str, port: int) -> str:
    """How a person reaches one public forward."""
    if kind in ("HTTPS", "HTTPS2HTTP"):
        return f"https://{host}:{port}/"
    if kind == "HTTP":
        return f"http://{host}:{port}/"
    if kind == "SSH":
        return f"ssh -p {port} <user>@{host}"
    return f"{host}:{port}"


# ── Mutating (gated behind confirm=True) ──────────────────────────────────────

@_tool(deadline_s=_LONG_TOOL_DEADLINE_S, mutating=True)
def set_vm_access_public(host: str, vm: str | None = None, fabric: str | None = None,
                         vm_type: str | None = None,
                         types: list[str] | None = None,
                         reinstall: bool = True, confirm: bool = False,
                         timeout_s: int = 600) -> dict[str, Any]:
    """MUTATING. Make a guest's access types PUBLIC so FS allocates an external
    port-forward, then (by default) reinstall that one VM to apply the forward.

    ``types`` defaults to ``["SSH", "HTTPS2HTTP"]``; any of
    SSH/HTTPS/HTTPS2HTTP/HTTP/RDP are accepted. A missing access entry is created,
    an existing one is flipped to PUBLIC (idempotent -- a forward already public is
    left alone). The external forward is only allocated when the VM runtime is
    applied, so ``reinstall=True`` runs ``install_vm`` on this guest alone (the
    rest of the fabric is untouched) and waits for it.

    Set ``confirm=True`` to actually run it; without it this is a dry-run that
    reports what WOULD change and makes no PATCH/install. Returns the resulting
    access entries with their external ports (``pod_host:external_port``: SSH
    11000+idx, HTTPS 13000+idx, HTTPS2HTTP 16000+idx, HTTP 18000+idx, RDP
    17000+idx)."""
    want = [t.upper() for t in (types or ["SSH", "HTTPS2HTTP"])]
    bad = [t for t in want if t not in fs_admin.ACCESS_FORWARD_BASE]
    if bad:
        return {"error": f"unknown access type(s): {bad}; "
                         f"valid: {sorted(fs_admin.ACCESS_FORWARD_BASE)}"}
    c, fid, v = _resolve(host, vm, fabric, vm_type)
    vid = v["id"]

    def _accesses() -> list[dict[str, Any]]:
        rv = fs_admin.get_runtime_vm(c, vid)
        port_idx = rv.get("port_idx")
        rows = []
        for a in fs_admin.list_vm_accesses(c, fid, vid):
            t = a.get("type")
            base = fs_admin.ACCESS_FORWARD_BASE.get(t)
            ext = (base + int(port_idx)) if (base is not None
                                             and port_idx is not None) else None
            rows.append({"type": t, "mode": a.get("mode"),
                         "guest_dport": a.get("dport"), "external_port": ext})
        return rows

    before = _accesses()
    not_public = [t for t in want
                  if next((a for a in before if a["type"] == t
                           and a["mode"] == "PUBLIC"), None) is None]
    if not confirm:
        return {"dry_run": True, "vm_id": vid, "name": v.get("name"),
                "would_set_public": not_public,
                "would_reinstall": bool(reinstall and not_public),
                "accesses": before,
                "note": "re-run with confirm=True to apply"}

    allowed = fs_admin.ensure_public_forwards_allowed(c)
    changed = fs_admin.ensure_public_access(c, fid, vid, tuple(want))
    installed = None
    if reinstall and (changed or any(a["external_port"] is None
                                     for a in before if a["type"] in want)):
        task = fs_admin.install_vm(c, vid)
        tid = task.get("id") if isinstance(task, dict) else None
        if tid:
            fs_admin.wait_task(c, tid, timeout_s=timeout_s)
            installed = {"task_id": tid,
                         "returncode": fs_admin.get_task(c, tid).get("returncode")}
    return {"vm_id": vid, "name": v.get("name"), "pod_host": host,
            "changed_to_public": changed, "pod_flags_set": allowed,
            "reinstalled": installed, "accesses": _accesses()}


def _host_port_switch_names(c: FabricStudioClient, fid: int) -> dict[int, str]:
    """Map a switchport id -> its switch name, for labelling host/guest peers."""
    out: dict[int, str] = {}
    for s in fs_admin.list_switches(c, fid):
        for p in (s.get("ports") or []):
            out[p] = s.get("name")
    return out


def _norm(s: str | None) -> str:
    return re.sub(r"\s+", " ", (s or "").strip().lower())


def _resolve_network(c: FabricStudioClient, fid: int,
                     network: str | int | None) -> dict[str, Any] | None:
    """Resolve a network by NAME (case-insensitive, the normal way -- so tools
    never make a caller look up an id) or by numeric id. Returns the network dict
    or None. ``network=None`` means "let the caller auto-detect" (returns None)."""
    if network is None:
        return None
    nets = fs_admin.list_networks(c, fid)
    s = str(network)
    if s.isdigit():
        by_id = next((n for n in nets if str(n.get("id")) == s), None)
        if by_id:
            return by_id
    return next((n for n in nets if _norm(n.get("name")) == _norm(s)), None)


def _system_host_view(c: FabricStudioClient, fid: int) -> dict[str, Any]:
    """System Host device id, whether its runtime is installed, and each port
    with the switch it uplinks (via peer), its address and dhcp/nat flags."""
    sh = fs_admin.get_system_host(c, fid)
    hid = sh.get("id")
    sw_by_sp = _host_port_switch_names(c, fid)
    ports = []
    for p in (sh.get("ports") or []):
        ports.append({"name": p.get("name"), "id": p.get("id"),
                      "ipv4addr": p.get("ipv4addr"),
                      "uplinks_switch": sw_by_sp.get(p.get("peer")),
                      "dhcp_service": p.get("dhcp_service"),
                      "egress_nat": p.get("egress_nat")})
    # The System Host is a HOST device, not a guest VM, so it has no
    # runtime.vmstatus row -- judge "installed" by its last install task's
    # returncode, not get_vm_runtime_state (which is always exists=False here).
    last_rc = None
    if hid is not None:
        try:
            t = fs_admin.latest_device_task(c, hid)
            last_rc = (t or {}).get("returncode")
        except Exception:
            last_rc = None
    return {"device_id": hid, "last_install_returncode": last_rc,
            "installed": last_rc == 0, "ports": ports}


@_internal
def system_host(host: str, fabric: str | None = None) -> dict[str, Any]:
    """The fabric's System Host (native DHCP/NAT/router device): its device id,
    whether its runtime is installed (``installed=False`` means no DHCP server or
    NAT egress is actually live, however the model reads), and each port with the
    switch it uplinks, its address, and its ``dhcp_service`` / ``egress_nat``
    flags. Use this to answer "does this fabric hand out DHCP / provide egress,
    and on which network?" before wiring a guest to it."""
    c = _client(host)
    fid = resolve_fabric_id(c, fabric)
    return {"pod_host": host, "fabric_id": fid, **_system_host_view(c, fid),
            "needs_dhcp_install": fs_admin.devices_needing_dhcp_install(c, fid)}


def _rebuild_guest_forwards(c: FabricStudioClient, fid: int,
                            timeout_s: int = 600) -> list[dict[str, Any]]:
    """Synchronize every guest VM that has a PUBLIC access, to rebuild the
    external port-forwards a System Host install drops. Syncs the GUESTS only --
    never the host (a host sync wipes mgmt1's runtime egress address). Returns
    one row per guest touched."""
    out: list[dict[str, Any]] = []
    for v in fs_admin.list_fabric_vms(c, fid):
        vid = v.get("id")
        try:
            acc = fs_admin.list_vm_accesses(c, fid, vid)
        except Exception:
            acc = []
        if not any(a.get("mode") == "PUBLIC" for a in acc):
            continue
        try:
            t = fs_admin.synchronize_device(c, vid)
            tid = t.get("id") if isinstance(t, dict) else None
            rc = None
            if tid:
                fs_admin.wait_task(c, tid, timeout_s=timeout_s)
                rc = fs_admin.get_task(c, tid).get("returncode")
            out.append({"vm_id": vid, "name": v.get("name"),
                        "sync_task": tid, "returncode": rc})
        except Exception as e:
            out.append({"vm_id": vid, "name": v.get("name"), "error": str(e)})
    return out


@_tool(deadline_s=_LONG_TOOL_DEADLINE_S, mutating=True)
def install_system_host(host: str, fabric: str | None = None,
                        enable_dhcp_ports: list[str] | None = None,
                        synchronize_after: bool = True,
                        confirm: bool = False, timeout_s: int = 600) -> dict[str, Any]:
    """MUTATING. Install the fabric's System Host so its DHCP server and NAT
    egress actually come up (the model can show ``dhcp_service: True`` while the
    host has never been installed, in which case nothing is served). Optionally
    turn on ``dhcp_service`` for the named host ports first (e.g. ``["int1"]``).

    ORDERING MATTERS: a guest's DHCP *reservation* is written into the host's
    lease table only by a host **install** -- a synchronize never writes leases.
    So set the guest port to DHCP FIRST (``set_vm_port_dhcp``), THEN run this; a
    host installed before the reservation exists serves an empty table and the
    guest gets no lease. The install also DROPS every guest's external port
    forward, so with ``synchronize_after=True`` (default) this rebuilds them by
    synchronizing each GUEST that has a public access.

    FOOTGUN (handled): never synchronize the HOST to rebuild forwards. The host's
    external uplink port (``mgmt1``, the egress-NAT interface) holds its address
    only at runtime -- the model shows ``null`` -- so a host synchronize re-pushes
    that null and wipes the address, killing egress for the ENTIRE fabric (ICMP +
    TCP out dead, though L2-to-gateway and DNS still work, which masks it). This
    tool rebuilds forwards per-guest for exactly that reason.

    Host-side only -- it does not power-cycle the fabric's guests (but a guest
    whose reservation just landed must still (re)install to pick up its lease:
    see ``set_vm_port_dhcp(reinstall=True)``). Set ``confirm=True`` to run;
    otherwise it reports the current System Host view and what it WOULD do."""
    c = _client(host)
    fid = resolve_fabric_id(c, fabric)
    view = _system_host_view(c, fid)
    hid = view["device_id"]
    if hid is None:
        return {"error": "no System Host device in this fabric"}
    if not confirm:
        return {"dry_run": True, "pod_host": host, "fabric_id": fid,
                "system_host": view, "would_enable_dhcp_ports": enable_dhcp_ports or [],
                "would_install": True, "would_synchronize_after": synchronize_after,
                "note": "run set_vm_port_dhcp FIRST if a guest needs a lease; "
                        "re-run with confirm=True to apply"}
    enabled: list[str] = []
    for pname in (enable_dhcp_ports or []):
        hp = next((p for p in fs_admin.get_system_host(c, fid).get("ports", [])
                   if p.get("name") == pname), None)
        if hp and not hp.get("dhcp_service"):
            fs_admin._patch(c, f"api/v1/model/host/port/{hp['id']}",
                            {"object": {"dhcp_service": True}}, "set_dhcp_service")
            enabled.append(pname)
    task = fs_admin.install_device(c, hid)
    tid = task.get("id") if isinstance(task, dict) else None
    rc = None
    if tid:
        fs_admin.wait_task(c, tid, timeout_s=timeout_s)
        rc = fs_admin.get_task(c, tid).get("returncode")
    # Rebuild the GUESTS' external forwards (the host install drops them), by
    # synchronizing each guest -- NEVER the host itself. Synchronizing the host
    # re-pushes its model config, and its external uplink port (mgmt1, the
    # egress-NAT interface) carries its address only at runtime (model is null),
    # so a host sync wipes that address and kills the whole fabric's egress. A
    # per-guest sync rebuilds the dropped forward without touching egress.
    rebuilt = _rebuild_guest_forwards(c, fid, timeout_s) if synchronize_after else None
    return {"pod_host": host, "fabric_id": fid, "dhcp_ports_enabled": enabled,
            "install_task": tid, "install_returncode": rc,
            "guest_forwards_rebuilt": rebuilt,
            "system_host": _system_host_view(c, fid),
            "needs_dhcp_install": fs_admin.devices_needing_dhcp_install(c, fid)}


@_tool(deadline_s=_LONG_TOOL_DEADLINE_S, mutating=True)
def set_vm_port_dhcp(host: str, vm: str | None = None, fabric: str | None = None,
                     vm_type: str | None = None, port: str = "eth0",
                     network: str | None = None, reservation_ip: str | None = None,
                     set_network_params: bool = True,
                     reinstall: bool = True, confirm: bool = False,
                     timeout_s: int = 600) -> dict[str, Any]:
    """MUTATING. Point a guest port at a System-Host-served DHCP reservation so
    the guest gets its address, default gateway and DNS from the fabric's System
    Host (fixing a guest that came up with a static auto-config IP and no route /
    wrong DNS / no egress).

    Mirrors FS "static DHCP": FS disables auto-config on the port, keeps a fixed
    in-subnet address as the reservation, and sets the System Host as the DHCP
    server on the port's network. ``network`` is the network **name** (preferred,
    case-insensitive) or an id, and defaults to the "auto network" of the switch
    the port is cabled to (its ``auto_address`` network) -- so normally you pass
    only ``vm`` and never touch an id. ``reservation_ip`` defaults to the port's
    current in-subnet address. With ``reinstall=True`` the guest is reinstalled
    (it alone) so it becomes a DHCP client; the System Host must already be
    installed (see ``install_system_host``) for a lease to be served.

    With ``set_network_params=True`` (default) it also repoints the VM's
    **Network Parameters** (``auto_params_network`` + the gateway/DNS FS injects)
    at the SAME network -- i.e. it uses the auto network rather than a leftover
    custom gateway/DNS, so they can't disagree with the DHCP segment (a leftover
    203.0.113.254 resolver on a Management guest is exactly this bug).

    Set ``confirm=True`` to run; otherwise this is a dry-run describing the change."""
    c, fid, v = _resolve(host, vm, fabric, vm_type)
    vid = v["id"]
    ports = fs_admin.get_vm_ports(c, fid, vid)
    vp = next((p for p in ports if p.get("name") == port), None)
    if vp is None:
        return {"error": f"port {port!r} not found on {v.get('name')}; "
                         f"have {[p.get('name') for p in ports]}"}
    # Resolve the switch the port is cabled to (via its switchport peer).
    peer = vp.get("peer")
    sw = next((s for s in fs_admin.list_switches(c, fid)
               if peer in (s.get("ports") or [])), None)
    # Default to the "auto network" of the cabled switch (its auto_address net),
    # so the caller normally passes no network at all; an explicit network is
    # resolved by name (preferred) or id.
    if network is not None:
        net = _resolve_network(c, fid, network)
        if net is None:
            names = [n.get("name") for n in fs_admin.list_networks(c, fid)]
            return {"error": f"network {network!r} not found; fabric networks: {names}"}
    else:
        aa = sw.get("auto_address_network") if sw else None
        net = _resolve_network(c, fid, aa) if aa else None
    if net is None:
        return {"error": "could not auto-detect the port's network (switch has no "
                         "auto_address network); pass network= by name. port cabled "
                         f"to switch={sw.get('name') if sw else None}"}
    sh = _system_host_view(c, fid)
    hid = sh["device_id"]
    resv = reservation_ip or vp.get("ipv4addr")
    mask = net.get("ipv4netmask") or vp.get("ipv4netmask") or "255.255.255.0"
    plan = {"vm_id": vid, "name": v.get("name"), "port": port,
            "switch": sw.get("name") if sw else None,
            "network": {"id": net.get("id"), "name": net.get("name"),
                        "gateway": net.get("ipv4gateway")},
            "dhcp_server_device": hid, "reservation_ip": resv, "netmask": mask,
            "system_host_installed": sh["installed"], "would_reinstall": reinstall}
    if not resv:
        return {"error": "no reservation IP: the port has no current address; "
                         "pass reservation_ip=<in-subnet addr>", "plan": plan}
    if not confirm:
        warn = ("AFTER applying this, run install_system_host so the reservation is "
                "written into the DHCP lease table (a synchronize does not write "
                "leases, only a host install does), then this guest picks up its "
                "lease on reinstall.")
        if not sh["installed"]:
            warn += " The System Host has no successful install yet."
        return {"dry_run": True, **plan, "warning": warn,
                "note": "re-run with confirm=True to apply"}
    # NOTE: do NOT disable auto_config here. With FS address-management OFF the
    # port renders as `iface eth0 inet manual` (FS configures nothing + no
    # runtimedhcpentry), so the guest gets no address at all. set_port_ipv4 with
    # dhcp_server forces addrmode=DHCP, which is what we want -> `inet dhcp`.
    fs_admin.set_port_ipv4(c, fid, vid, vp["id"], resv, mask,
                           dhcp_server=hid, network=net.get("id"))
    # Point the VM's Network Parameters (gateway/DNS FS injects) at the SAME
    # network, so they match the DHCP segment instead of whatever gateway/DNS the
    # VM was created with -- a mismatch here is how a Management-net guest ended up
    # with a 203.0.113.254 gateway/DNS and no working resolver.
    netfields = None
    if set_network_params:
        netfields = {"auto_params_network": net.get("id"),
                     "ipv4gateway": net.get("ipv4gateway"),
                     "ipv4dns1": net.get("ipv4dns1") or net.get("ipv4gateway"),
                     "ipv4dns2": net.get("ipv4dns2")}
        fs_admin._patch(c, f"api/v1/model/vm/{vid}", {"object": netfields},
                        "set_vm_netparams")
    installed = None
    if reinstall:
        task = fs_admin.install_vm(c, vid)
        tid = task.get("id") if isinstance(task, dict) else None
        if tid:
            fs_admin.wait_task(c, tid, timeout_s=timeout_s)
            installed = {"task_id": tid,
                         "returncode": fs_admin.get_task(c, tid).get("returncode")}
    final = next((p for p in fs_admin.get_vm_ports(c, fid, vid)
                  if p.get("name") == port), {})
    return {**plan, "applied": True, "reinstalled": installed,
            "network_params": ({"auto_params_network": net.get("name"),
                                "gateway": net.get("ipv4gateway"),
                                "dns1": netfields["ipv4dns1"]} if netfields else None),
            "port_now": {k: final.get(k) for k in
                         ("ipv4addr", "ipv4netmask", "network", "dhcp_server")}}


def _port_and_network(c: FabricStudioClient, fid: int, vid: int, port: str,
                      network: str | int | None):
    """(vp, switch, net) for a guest port: find the port, the switch it is cabled
    to, and the target network (explicit by name/id, else the cabled switch's
    auto_address network). Returns (None, ..., error) shapes handled by callers."""
    ports = fs_admin.get_vm_ports(c, fid, vid)
    vp = next((p for p in ports if p.get("name") == port), None)
    if vp is None:
        return None, None, None, [p.get("name") for p in ports]
    sw = next((s for s in fs_admin.list_switches(c, fid)
               if vp.get("peer") in (s.get("ports") or [])), None)
    if network is not None:
        net = _resolve_network(c, fid, network)
    else:
        aa = sw.get("auto_address_network") if sw else None
        net = _resolve_network(c, fid, aa) if aa else None
    return vp, sw, net, None


@_tool(deadline_s=_LONG_TOOL_DEADLINE_S, mutating=True)
def set_vm_port_auto(host: str, vm: str | None = None, fabric: str | None = None,
                     vm_type: str | None = None, port: str = "eth0",
                     network: str | None = None, reservation_ip: str | None = None,
                     reinstall: bool = True, confirm: bool = False,
                     timeout_s: int = 600) -> dict[str, Any]:
    """MUTATING. Put a guest port on its **auto network** -- FS-managed static
    addressing (the default, most reliable way to wire a guest). FS auto-addresses
    the port from the network (writing Debian ``iface <port> inet static`` with
    address/netmask/gateway, which LXC images consume via their ifupdown shim and
    qcow guests get injected directly) and points the VM's Network Parameters at
    the same network. No DHCP server needed -- unlike ``set_vm_port_dhcp``, which
    renders ``inet dhcp`` and needs the System Host actually leasing.

    ``network`` is a name (preferred) or id and defaults to the cabled switch's
    auto network, so normally you pass only ``vm``. ``reservation_ip`` pins a
    specific in-subnet address (default: keep the port's current one, else FS
    auto-picks a free one). Set ``confirm=True`` to apply; otherwise a dry-run."""
    c, fid, v = _resolve(host, vm, fabric, vm_type)
    vid = v["id"]
    vp, sw, net, portnames = _port_and_network(c, fid, vid, port, network)
    if vp is None:
        return {"error": f"port {port!r} not found on {v.get('name')}; have {portnames}"}
    if net is None:
        return {"error": "could not resolve the port's network; pass network= by "
                         f"name. port cabled to switch={sw.get('name') if sw else None}"}
    addr = reservation_ip or vp.get("ipv4addr")
    mask = net.get("ipv4netmask") or vp.get("ipv4netmask") or "255.255.255.0"
    plan = {"vm_id": vid, "name": v.get("name"), "port": port, "mode": "auto/static",
            "switch": sw.get("name") if sw else None,
            "network": {"id": net.get("id"), "name": net.get("name"),
                        "gateway": net.get("ipv4gateway")},
            "address": addr or "(FS auto-picks)", "would_reinstall": reinstall}
    if not confirm:
        return {"dry_run": True, **plan, "note": "re-run with confirm=True to apply"}
    # Clean FS auto-address static: address-management ON, addrmode STA, clear any
    # dhcp_server (a leftover dhcp_server forces addrmode DHCP / inet dhcp).
    obj = {"auto_config": True, "addrmode": "STA", "dhcp_server": None,
           "network": net.get("id")}
    if addr:
        obj["ipv4addr"] = addr
        obj["ipv4netmask"] = mask
    fs_admin._patch(c, f"api/v1/model/fabric/{fid}/vm/{vid}/port/{vp['id']}",
                    {"object": obj}, "set_port_static_auto")
    fs_admin._patch(c, f"api/v1/model/vm/{vid}",
                    {"object": {"auto_params_network": net.get("id"),
                                "ipv4gateway": net.get("ipv4gateway"),
                                "ipv4dns1": net.get("ipv4dns1") or net.get("ipv4gateway"),
                                "ipv4dns2": net.get("ipv4dns2")}}, "set_vm_netparams")
    installed = None
    if reinstall:
        task = fs_admin.install_vm(c, vid)
        tid = task.get("id") if isinstance(task, dict) else None
        if tid:
            fs_admin.wait_task(c, tid, timeout_s=timeout_s)
            installed = {"task_id": tid,
                         "returncode": fs_admin.get_task(c, tid).get("returncode")}
    final = next((p for p in fs_admin.get_vm_ports(c, fid, vid)
                  if p.get("name") == port), {})
    return {**plan, "applied": True, "reinstalled": installed,
            "network_params": {"auto_params_network": net.get("name"),
                               "gateway": net.get("ipv4gateway")},
            "port_now": {k: final.get(k) for k in
                         ("ipv4addr", "ipv4netmask", "addrmode", "dhcp_server")}}




@_internal
def vm_disks(host: str, vm: str | None = None, fabric: str | None = None,
             vm_type: str | None = None) -> list[dict[str, Any]]:
    """A VM's disks (``model.vmdisk``): the base firmware disk (``extra=False``)
    and any data disks (``extra=True``, ``capacity`` in MiB). Useful before/after
    a firmware repack to see on-disk layout, and to confirm a data disk attached."""
    c, _fid, v = _resolve(host, vm, fabric, vm_type)
    return fs_admin.list_vm_disks(c, v["id"])


@_internal
def fabric_topology(host: str, fabric: str | None = None) -> dict[str, Any]:
    """A fabric's L3 networks (subnets: name, ipv4network/netmask/gateway/dns) and
    L2 switches (name, mgmt flag, auto_address_network). ``fabric`` may be an id,
    a name, or omitted (the running fabric)."""
    c = _client(host)
    fid = resolve_fabric_id(c, fabric)
    return {"fabric_id": fid,
            "networks": fs_admin.list_networks(c, fid),
            "switches": fs_admin.list_switches(c, fid)}


@_internal
def fabric_resources(host: str, fabric: str | None = None) -> dict[str, Any]:
    """Configured vCPU / memory / disk per VM across a fabric, plus totals.
    Answers "how much CPU and RAM does this fabric allocate?" Per-VM values are
    the ``model/vm/{id}/parameters`` overrides; ``cpu_count``/``memory_mib`` of 0
    means no override (the firmware ``.meta`` default applies) and is listed in
    ``fw_default_vms`` rather than summed. Disk is data-disk capacity in MiB (the
    base firmware disk reports 0). Allocation, not live usage. ``fabric`` may be
    an id, a name, or omitted (the running fabric)."""
    c = _client(host)
    fid = resolve_fabric_id(c, fabric)
    vms = []
    for v in fs_admin.list_fabric_vms(c, fid):
        par = fs_admin.get_vm_parameters(c, v["id"])
        disks = fs_admin.list_vm_disks(c, v["id"])
        vms.append({"id": v["id"], "name": v.get("name"), "vm_type": v.get("vm_type"),
                    "cpu_count": int(par.get("cpu_count") or 0),
                    "memory_mib": int(par.get("memory") or 0),
                    "disk_mib": sum(int(d.get("capacity") or d.get("declared") or 0)
                                    for d in disks)})
    mem = sum(r["memory_mib"] for r in vms)
    return {"fabric_id": fid, "vms": vms,
            "total": {"vm_count": len(vms),
                      "cpu_count": sum(r["cpu_count"] for r in vms),
                      "memory_mib": mem, "memory_gib": round(mem / 1024, 1),
                      "disk_mib": sum(r["disk_mib"] for r in vms)},
            "fw_default_vms": [r["name"] for r in vms
                               if not r["cpu_count"] or not r["memory_mib"]]}


# ── Runtime / license state ──────────────────────────────────────────────────

@_internal
def vm_state(host: str, vm: str | None = None, fabric: str | None = None,
             vm_type: str | None = None) -> dict[str, Any]:
    """Runtime + model state for one VM: powered/post_boot_prepared/licensed,
    the loaded firmware id, and the FS license mode/served-id. ``vm`` may be an
    id, a name, or omitted (the single SOAR VM)."""
    c, fid, v = _resolve(host, vm, fabric, vm_type)
    rt = fs_admin.get_vm_runtime_state(c, v["id"])
    mode = fs_admin.get_vm_license_mode(c, fid, v["id"])
    return {"vm_id": v["id"], "name": v.get("name"), "vm_type": v.get("vm_type"),
            "firmware": v.get("firmware"), "runtime_exists": rt.get("exists"),
            "status": rt.get("status"), "task": rt.get("task"),
            "license_mode": mode.get("mode"), "license_served_id": mode.get("served")}


@_internal
def fs_license_pool(host: str) -> list[dict[str, Any]]:
    """The pod's FS license pool (``system/license``): id, serial (name), vm_type."""
    c = _client(host)
    return [{"id": lic.get("id"), "serial": lic.get("name"),
             "vm_type": lic.get("vm_type")} for lic in fs_admin.list_fs_licenses(c)]


def _license_now(c: FabricStudioClient, fid: int, vid: int) -> dict[str, Any]:
    mode = fs_admin.get_vm_license_mode(c, fid, vid)
    served_id = mode.get("served")
    serial = None
    if served_id:
        try:
            serial = (fs_admin.get_fs_license(c, served_id) or {}).get("name")
        except Exception:
            serial = None
    return {"mode": mode.get("mode"), "served_id": served_id, "served_serial": serial}


@_internal
def fs_license_assignment(host: str, vm: str | None = None,
                          fabric: str | None = None,
                          vm_type: str | None = None) -> dict[str, Any]:
    """What license FS has assigned a model VM: license mode, served pool id, and
    the served license's serial (name)."""
    c, fid, v = _resolve(host, vm, fabric, vm_type)
    return {"vm_id": v["id"], **_license_now(c, fid, v["id"])}


@_internal
def forticloud_status(host: str) -> dict[str, Any]:
    """The pod's FortiFlex/FortiCloud account state (the FS license source).
    Registered ⇒ FS auto-licenses VMs on install."""
    c = _client(host)
    acct = fs_admin.get_forticloud_account(c)
    flexvm = (acct or {}).get("flexvm") or {}
    return {"registered": fs_admin.forticloud_registered(c),
            "username": flexvm.get("username")}


# ── Tasks ────────────────────────────────────────────────────────────────────

@_tool(deadline_s=_LONG_TOOL_DEADLINE_S)
def diagnose(host: str, fabric: str | None = None, probe: bool = True, deep: bool = False,
             topology: str | None = None) -> dict[str, Any]:
    """START HERE when a fabric is failing or you do not know why. Read-only. (A login problem is not this:
    use ``vm`` with ``include=["credentials"]``.) Checks every VM in the
    fabric (the running one when ``fabric`` is omitted) against what usually goes wrong, in one call:
    failed install tasks (their log is read and the cause named, for example a missing license or a
    0-byte firmware stub), firmware missing or not downloaded, VMs not installed, powered off or not
    finished booting, a license that was never served, public forwards that do not answer
    (``probe=false`` skips that), another fabric running on the pod, tasks still in flight, and a
    lockout. Returns a ``verdict`` (healthy / needs attention / problems found) and ``findings`` ranked
    error > warn > info, each with the evidence and the next step. Nothing is changed.

    ``deep=true`` adds device-level checks where the build has them: the per-device ``verify`` (powered,
    booted, forwards answering, license as Fabric Studio records it) and, with ``topology`` naming the
    intent, that topology's ``healthchecks`` phase. They take longer, so ask for them when the quick
    answer is not enough."""
    c = _client(host)
    fid = resolve_fabric_id(c, fabric)
    name = next((f.get("name") for f in fs_admin.list_fabrics(c) if f.get("id") == fid), None)
    facts = _diagnose.gather(c, host, fid, name, inst.lockouts().get(host, []), probe=probe)
    result = _diagnose.analyse(facts)
    return _diagnose.deep(facts, result, topology) if deep else result


@_internal
def list_tasks(host: str, vm: str | None = None, fabric: str | None = None,
               limit: int = 5) -> dict[str, Any]:
    """Currently-running FS tasks, plus (if ``vm`` given) that VM's most recent
    device tasks. Use to see whether an install/license op is in flight."""
    c = _client(host)
    running = [{"id": t.get("id"), "name": t.get("name"),
                "returncode": t.get("returncode")}
               for t in fs_admin.list_running_tasks(c)]
    recent = []
    if vm is not None:
        fid = resolve_fabric_id(c, fabric)
        v = resolve_vm(c, fid, vm, None)
        data = c.get(f"api/v1/task/device?device_id={v['id']}"
                     f"&limit={limit}&order_by=-created_date").json()
        for x in (data.get("object") or []):
            recent.append({"id": x.get("id"), "name": x.get("name"),
                           "returncode": x.get("returncode")})
    return {"running": running, "recent_for_vm": recent}


@_internal
def task_log(host: str, task_id: int | str, tail_lines: int = 50) -> dict[str, Any]:
    """The execution log of an FS task -- where Fabric Studio records the *reason*
    a device task failed (e.g. ``No license for fgt000 (FLEX,LIC)`` behind a bare
    ``rc=254``). Pairs with ``list_tasks`` (which returns task ids + returncode).
    ``tail_lines`` bounds huge multi-hour build logs; pass ``0`` for the full log.
    Returns ``{task_id, tail_lines, log, full_length, truncated}``."""
    c = _client(host)
    full = fs_admin.get_task_log(c, task_id)
    if not full:
        try:
            known = fs_admin.get_task(c, task_id)
        except fs_admin.FabricStudioAdminError:
            known = None
        if not known:
            raise ToolError(f"there is no task {task_id} on {host}. Call tasks without a task_id to see what is "
                            "running and what ran recently.")
    log = full
    truncated = False
    if tail_lines and full:
        lines = full.splitlines()
        if len(lines) > tail_lines:
            log = "\n".join(lines[-tail_lines:])
            truncated = True
    return {"task_id": task_id, "tail_lines": tail_lines, "log": log,
            "full_length": len(full), "truncated": truncated}


# ── Guest SSH (read-only) ────────────────────────────────────────────────────

# These tools are ``async def`` and ``await`` the jump-SSH coroutine directly:
# MCPServer runs tools inside its own event loop, so ``asyncio.run()`` here would
# raise "cannot be called from a running event loop".

def _require_soar(v: dict) -> None:
    """The guest tools SSH in with a FortiSOAR login. Trying it on any other device would throw a
    password at something that is not a FortiSOAR, so refuse before connecting."""
    if (v.get("vm_type") or "").upper() != "SOAR":
        raise ToolError(f"{v.get('name')!r} is a {v.get('vm_type')} VM; the guest_license, guest_config and "
                        "license_match checks are for FortiSOAR (SOAR) VMs only")


async def _guest_csadm_license(host: str, c, fid: int, v: dict) -> tuple[str, str]:
    """(mgmt_ip, raw csadm output) from ``csadm license --show-details``."""
    pu, pp = _login(host)
    su, sp = _ssh_creds()
    ip = _soar_mgmt_ip(c, fid, v)
    _rc, out, _err = await _jump_exec(
        host, pu, pp, ip, su, sp, "csadm license --show-details", 120, True)
    return ip, out or ""


@_internal
async def read_guest_license(host: str, vm: str | None = None,
                             fabric: str | None = None) -> dict[str, Any]:
    """Jump-SSH into the SOAR guest and parse ``csadm license --show-details``.
    Returns the parsed license dict + a usability flag (any FSR-Auth-* line means
    the guest is duplicate/blocked even if 'licensed' is true).

    SOAR-only: ``csadm`` exists on FortiSOAR guests only; this errors out for
    FSM/FGT/FMG/FAZ and any non-SOAR ``vm_type``."""
    c, fid, v = _resolve(host, vm, fabric, "SOAR")
    _require_soar(v)
    ip, out = await _guest_csadm_license(host, c, fid, v)
    lic = csadm_license_details(out)
    auth_block = any("FSR-Auth" in line or "fsr_auth" in line.lower()
                     for line in out.splitlines())
    return {"mgmt_ip": ip, "license": lic,
            "usable": bool(lic.get("licensed")) and not auth_block,
            "auth_block": auth_block, "raw": out[:2000]}


@_internal
async def guest_config_status(host: str, vm: str | None = None,
                              fabric: str | None = None) -> dict[str, Any]:
    """Whether the FortiSOAR first-boot config wizard (``config-vm.sh``) has
    finished on the guest. CONFIGURED = ``.vm_configured`` present (safe to
    snapshot); PENDING = still provisioning; FAILED = ``.vm_configuration_failed``.
    FS ``post_boot_prepared`` fires well before CONFIGURED.

    SOAR-only: the ``.vm_configured`` marker is FortiSOAR's first-boot wizard."""
    c, fid, v = _resolve(host, vm, fabric, "SOAR")
    _require_soar(v)
    pu, pp = _login(host)
    su, sp = _ssh_creds()
    ip = _soar_mgmt_ip(c, fid, v)
    _rc, out, _err = await _jump_exec(
        host, pu, pp, ip, su, sp, _CONFIG_MARKER_PROBE, 60, True)  # sudo: 700 home
    token = (out or "").strip().splitlines()[-1].strip() if (out or "").strip() else ""
    state = {"CONFIGURED": "CONFIGURED", "FAILED": "FAILED"}.get(token, "PENDING")
    return {"mgmt_ip": ip, "state": state, "configured": state == "CONFIGURED"}


@_internal
async def validate_license_match(host: str, vm: str | None = None,
                                 fabric: str | None = None) -> dict[str, Any]:
    """Compare the license FS assigned the VM (model served serial) against what
    the booted guest actually runs (csadm serial). ``match`` is the bottom line.

    SOAR-only: the guest probe runs ``csadm`` (FortiSOAR); it errors for other
    guest types."""
    c, fid, v = _resolve(host, vm, fabric, "SOAR")
    _require_soar(v)
    _ip, out = await _guest_csadm_license(host, c, fid, v)
    lic = csadm_license_details(out)
    return fs_admin.validate_license_match(c, fid, v, lic)


# ── Snapshots ─────────────────────────────────────────────────────────────────

_SNAPSHOT_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$")


@_tool(deadline_s=1800, mutating=True)
def snapshot_vm(host: str, action: str, name: str, vm: str | None = None, fabric: str | None = None,
                vm_type: str | None = None, link: bool = True, confirm: bool = False) -> dict[str, Any]:
    """MUTATING. Save a VM's disks as a new firmware in the pod's home repository, so a reinstall (or a new
    VM) can boot from it. ``action``: ``diff`` = only what changed since the original firmware (small and
    fast to take; installing it downloads the original too; diffs never chain, so any one can be deleted
    without breaking another); ``full`` = one standalone image (larger: 5.4 GB against 4.7 GB for a FortiAnalyzer, no dependency on
    the original, a full install to restore). ``name`` must be new: an existing firmware of that name is never replaced.

    THE VM IS POWERED OFF HARD while its disks are exported, then powered back on and waited for: expect
    downtime of several minutes, and anything not yet written to disk is lost (shut the guest down from
    inside first when it matters). With ``link=true`` (default) the VM's firmware pointer moves to the
    snapshot so a reinstall boots it; ``link=false`` leaves the pointer alone. Without ``confirm=true``
    this only previews; with it, the person is asked to approve the plan before anything is powered off."""
    if action not in ("diff", "full"):
        raise ToolError("action must be 'diff' or 'full'")
    if not _SNAPSHOT_NAME.fullmatch(name):
        raise ToolError("name must be 1-80 characters: letters, digits, '.', '_' or '-', starting with a letter or digit")
    c, _, v = _resolve(host, vm, fabric, vm_type)
    taken = [f.get("path") for f in fs_admin.list_all_firmwares(c) if str(f.get("path", "")).endswith(name)]
    if taken:
        raise ToolError(f"a firmware named {name!r} already exists ({taken[0]}); choose a new name")
    plan = {"action": action, "vm": v.get("name"), "vm_id": v["id"], "vm_type": v.get("vm_type"),
            "snapshot_name": name, "link_vm_to_snapshot": link,
            "steps": ["hard power-off", f"export disks ({action}) as firmware {name!r}",
                      "power on and wait until ready"],
            "downtime": "several minutes; unsaved guest state is lost"}
    if not confirm:
        return {"dry_run": True, **plan, "note": "re-run with confirm=true to take it"}
    snap = fs_admin.take_diff_snapshot(c, v["id"], name, link=link, diff=(action == "diff"))
    return {"executed": True, **plan, "snapshot": {k: snap.get(k) for k in ("id", "path", "size", "is_diff", "diff_from")}}


# ── VM lifecycle and licensing ────────────────────────────────────────────────

_LIFECYCLE_ACTIONS = ("on", "off", "restart", "reinstall", "cancel_task")


def _refuse_if_locked(host: str) -> None:
    """A lockout is a deliberate freeze by the pod's owner. Power and license changes respect it."""
    locks = inst.lockouts().get(host, [])
    if locks:
        why = "; ".join(f"{lk['fabric']}: {lk.get('reason') or 'no reason given'}" for lk in locks)
        raise ToolError(f"{host} is locked ({why}). A lockout is a deliberate freeze: ask whoever set it. "
                        "This server cannot lift one.")


def _powered(c: FabricStudioClient, vid: int) -> bool:
    return bool((fs_admin.get_vm_runtime_state(c, vid).get("status") or {}).get("powered"))


@_tool(deadline_s=_LONG_TOOL_DEADLINE_S, mutating=True)
def vm_lifecycle(host: str, action: str, vm: str | None = None, fabric: str | None = None,
                 vm_type: str | None = None, task_id: int | str | None = None, confirm: bool = False,
                 timeout_s: int = 600) -> dict[str, Any]:
    """MUTATING. Use this when asked to power on or off, start, stop, restart, reboot, rebuild or reinstall a
    VM, or to kill/cancel a hung task: call it directly (it previews, and nothing happens until the person
    approves), do not read state first. ``action``:
    ``on`` = power on and wait until ready; ``off`` = HARD power off (appliance guests ignore the
    ACPI shutdown, so unsaved guest state is lost; shut the guest down from inside first when it
    matters); ``restart`` = hard power off, then on, wait until ready; ``reinstall`` = rebuild the
    guest from its firmware, which WIPES everything changed inside it (snapshot first with
    ``snapshot_vm`` if it matters); ``cancel_task`` = cancel the in-flight task ``task_id`` (frees
    the queue when an install hangs; the VM it was working on may be left half built).

    A pod runs one fabric at a time and this acts on a single VM of the running fabric. It refuses
    on a locked pod. Without ``confirm=true`` it only previews; with it, the person is asked to
    approve the plan before anything happens."""
    if action not in _LIFECYCLE_ACTIONS:
        raise ToolError(f"action must be one of {', '.join(_LIFECYCLE_ACTIONS)}")
    _refuse_if_locked(host)
    if action == "cancel_task":
        if task_id is None:
            raise ToolError("cancel_task needs task_id (see the tasks tool for what is running)")
        c = _client(host)
        task = fs_admin.get_task(c, task_id)
        plan = {"action": action, "task_id": task_id, "task": task.get("name") or task.get("description"),
                "running": task.get("returncode") is None,
                "note": "the VM the task was working on may be left half built"}
        if not confirm:
            return {"dry_run": True, **plan, "note2": "re-run with confirm=true to cancel it"}
        fs_admin.cancel_task(c, task_id)
        return {"executed": True, **plan}
    c, _, v = _resolve(host, vm, fabric, vm_type)
    vid = v["id"]
    powered = _powered(c, vid)
    steps = {"on": ["power on", "wait until ready"], "off": ["hard power off"],
             "restart": ["hard power off", "power on", "wait until ready"],
             "reinstall": ["rebuild the guest from its firmware (guest state is lost)", "wait until ready"]}[action]
    plan = {"action": action, "vm": v.get("name"), "vm_id": vid, "vm_type": v.get("vm_type"),
            "powered_now": powered, "steps": steps,
            "noop": (action == "on" and powered) or (action == "off" and not powered)}
    if plan["noop"]:
        plan["reason"] = f"already {'on' if powered else 'off'}"
    if not confirm:
        return {"dry_run": True, **plan, "note": "re-run with confirm=true to do it"}
    if plan["noop"]:
        return {"executed": False, **plan}
    if action == "off":
        _step("powering off")
        fs_admin.wait_task(c, fs_admin.power_off_device(c, vid), timeout_s=timeout_s, label=f"power-off vm {vid}")
        fs_admin.wait_powered(c, vid, want=False, timeout_s=timeout_s)
    elif action == "on":
        _step("powering on")
        fs_admin.wait_task(c, fs_admin.power_on_device(c, vid), timeout_s=timeout_s, label=f"power-on vm {vid}")
        fs_admin.wait_vm_ready(c, vid, timeout_s=timeout_s)
    elif action == "restart":
        fs_admin.power_cycle(c, vid, off_timeout_s=min(timeout_s, 240), ready_timeout_s=timeout_s, progress=_step)
    else:
        _step("reinstalling")
        task = fs_admin.install_vm(c, vid)
        fs_admin.wait_vm_ready(c, vid, timeout_s=timeout_s, task_id=task.get("id"))
    st = fs_admin.get_vm_runtime_state(c, vid).get("status") or {}
    return {"executed": True, **plan, "now": {"powered": st.get("powered"), "ready": st.get("post_boot_prepared")}}


_LICENSE_MODES = ("NONE", "AUTO")


@_tool(deadline_s=_LONG_TOOL_DEADLINE_S, mutating=True)
def set_vm_license(host: str, mode: str, vm: str | None = None, fabric: str | None = None,
                   vm_type: str | None = None, reinstall: bool = True, confirm: bool = False,
                   timeout_s: int = 600) -> dict[str, Any]:
    """MUTATING. Choose how Fabric Studio licenses one VM when it installs. ``mode``: ``NONE`` =
    install unlicensed (eval: the API, CLI and GUI work, nothing is spent); ``AUTO`` = take a
    license from the pod's pool or FortiFlex, which USES IT UP. A bare ``AUTO`` behaves differently
    per pod: it can take a pooled license, stop because several FortiFlex configurations match, or
    fail the install with ``No license for <node>``. The preview shows the current mode, the license
    now served, how many pooled licenses match the device type, and whether FortiFlex is registered.

    The mode only takes effect on the next install, so ``reinstall=true`` (the default) reinstalls the
    guest, which WIPES whatever was changed inside it; ``reinstall=false`` changes the setting only.
    It refuses on a locked pod. Without ``confirm=true`` it only previews; with it, the person is asked
    to approve the plan first."""
    mode = mode.upper()
    if mode not in _LICENSE_MODES:
        raise ToolError(f"mode must be one of {', '.join(_LICENSE_MODES)}")
    _refuse_if_locked(host)
    c, fid, v = _resolve(host, vm, fabric, vm_type)
    vid = v["id"]
    now = _license_now(c, fid, vid)
    pool = [lic for lic in fs_admin.list_fs_licenses(c)
            if str(lic.get("vm_type") or "").upper() == str(v.get("vm_type") or "").upper()]
    try:
        flex = fs_admin.forticloud_registered(c)
    except Exception:
        flex = None
    plan = {"vm": v.get("name"), "vm_id": vid, "vm_type": v.get("vm_type"), "mode_now": now.get("mode"),
            "served_now": now.get("served_serial"), "new_mode": mode, "would_reinstall": reinstall,
            "pooled_licenses_matching": len(pool), "fortiflex_registered": flex}
    if mode == "AUTO":
        plan["warning"] = ("AUTO uses up a license: a pooled one, or FortiFlex points. If several FortiFlex "
                           "configurations match it stops; if none can serve it the install fails.")
    if not confirm:
        return {"dry_run": True, **plan, "note": "re-run with confirm=true to apply"}
    fs_admin.set_vm_license_mode(c, fid, vid, mode=mode)
    installed = None
    if reinstall:
        _step("reinstalling to apply the license mode")
        task = fs_admin.install_vm(c, vid)
        fs_admin.wait_vm_ready(c, vid, timeout_s=timeout_s, task_id=task.get("id"))
        installed = {"task_id": task.get("id")}
    return {"executed": True, **plan, "reinstalled": installed,
            "now": _license_now(c, fid, vid)}


# ── Consolidated read-only tools ──────────────────────────────────────────────

def _need(view: str, **given: Any) -> None:
    missing = [k for k, v in given.items() if not v]
    if missing:
        raise ToolError(f"view {view!r} needs {', '.join(missing)}")


def _all_failed_alike(out: dict[str, Any]) -> None:
    """When every section failed with the same error (pod down, login refused), that is one failure of the
    whole call, not several sections to read: raise it so the client sees an error and not a success."""
    errs = {v.get("error") for v in out.values() if isinstance(v, dict) and set(v) == {"error"}}
    if out and len(errs) == 1 and all(isinstance(v, dict) and set(v) == {"error"} for v in out.values()):
        raise ToolError(errs.pop())


def _guarded(fn: Any, **kw: Any) -> Any:
    """One section of a multi-section answer: a failure is reported in place, not allowed to hide the rest."""
    try:
        return fn(**kw)
    except UnmanagedHostError:
        raise
    except SystemExit as e:
        return {"error": str(e.code) if isinstance(e.code, str) else "could not be resolved"}
    except Exception as e:
        return {"error": str(e) if isinstance(e, ToolError) else str(_explain(e, kw.get("host")))}


_POD_VIEWS = ("online", "overview", "health", "licenses", "reach", "lockouts", "instances", "known", "find",
              "firmwares", "snapshots")


@_tool
def pods(view: str, host: str | None = None, hosts: list[str] | None = None, query: str | None = None,
         vm_type: str | None = None, devices: bool = False, probe: bool = True,
         include_remote: bool = True) -> Any:
    """Read-only. Anything about pods (the Fabric Studio hosts) rather than one fabric. Pick a ``view``:
    ``online`` = only what is up now, per pod and fabric (start here for "what is running");
    ``overview`` = every device in every fabric of every managed pod;
    ``health`` = is the pod safe to act on: Fabric Studio version, uptime, tasks running, locks (``host`` for
    one pod's detail, else every managed pod);
    ``licenses`` = FortiFlex/FortiCloud state and the license pool (``host`` for one pod's pool and account);
    ``reach`` = can this workstation reach each pod (443, 22), ``devices=true`` also probes devices;
    ``lockouts`` = freezes engaged against apply/destroy;
    ``instances`` = the pods this server manages (``probe=false`` skips the live check);
    ``known`` = every pod we hold a trace of (env files, database);
    ``find`` = where is the device named ``query``;
    ``firmwares`` = images a pod can install (needs ``host``; ``vm_type`` such as FGT, FMG, FAZ, SOAR);
    ``snapshots`` = bootable home-repository firmwares (needs ``host``).
    ``host`` is one pod; ``hosts`` limits a multi-pod view; omit both for all managed pods. A multi-pod view
    (``online``, ``overview``, ``health``, ``licenses``, ``reach``) covers every pod in ONE call: do not call it
    once per pod."""
    if view not in _POD_VIEWS:
        raise ToolError(f"unknown view {view!r}; choose from {', '.join(_POD_VIEWS)}")
    if view == "online":
        return whats_up(vm_type=vm_type, name_contains=query)
    if view == "overview":
        return instances_overview(hosts or ([host] if host else None))
    if view == "health":
        return pod_health(host) if host else pods_health(hosts)
    if view == "licenses":
        if not host:
            return licenses_overview(hosts)
        return {"overview": _guarded(licenses_overview, hosts=[host]), "pool": _guarded(fs_license_pool, host=host),
                "forticloud": _guarded(forticloud_status, host=host)}
    if view == "reach":
        return reach_matrix(hosts or ([host] if host else None), devices)
    if view == "lockouts":
        return list_lockouts()
    if view == "instances":
        return list_instances(probe)
    if view == "known":
        return {"pods": list_pods(), "discovered": discover_instances(probe=False)}
    if view == "find":
        _need(view, query=query)
        return find_device(query, hosts or ([host] if host else None))
    _need(view, host=host)
    if view == "firmwares":
        return list_firmwares(host, vm_type, include_remote)
    return list_snapshots(host, vm_type or "SOAR")


_FABRIC_SECTIONS = {"fabrics": lambda host, fabric: list_fabrics(host),
                    "vms": lambda host, fabric: list_vms(host, fabric),
                    "topology": lambda host, fabric: fabric_topology(host, fabric),
                    "resources": lambda host, fabric: fabric_resources(host, fabric),
                    "system_host": lambda host, fabric: system_host(host, fabric)}


@_tool
def fabric(host: str, fabric: str | None = None, include: list[str] | None = None) -> dict[str, Any]:
    """Read-only. Describe one fabric on a pod. ``include`` any of: ``fabrics`` (every fabric on the pod and
    which one runs), ``vms`` (VMs with type and firmware id), ``topology`` (L3 networks, subnets, gateways,
    DNS), ``resources`` (vCPU/memory/disk per VM and totals), ``system_host`` (the native DHCP/NAT device:
    installed or not, its ports). Default: ``vms``. ``fabric`` is an id or name; omit it for the running fabric."""
    want = include or ["vms"]
    bad = [w for w in want if w not in _FABRIC_SECTIONS]
    if bad:
        raise ToolError(f"unknown include {bad}; choose from {', '.join(_FABRIC_SECTIONS)}")
    resolve_fabric_id(_client(host), fabric)   # a fabric that does not exist is one error, not one per section
    out = {w: _guarded(_FABRIC_SECTIONS[w], host=host, fabric=fabric) for w in want}
    _all_failed_alike(out)
    return out


_VM_SECTIONS = ("state", "detail", "access", "disks", "license", "license_match", "guest_license",
                "guest_config", "credentials")


@_tool(deadline_s=_LONG_TOOL_DEADLINE_S)
async def vm(host: str, vm: str | None = None, fabric: str | None = None, vm_type: str | None = None,
             include: list[str] | None = None) -> dict[str, Any]:
    """Read-only. Inspect one VM (``vm`` is an id or name; omit it for the single SOAR VM). ``include`` any of:
    ``state`` (powered, booted, licensed, in-flight task, firmware), ``detail`` (state plus CPU/memory, disks
    and access entries), ``access`` (SSH/HTTPS/RDP entries and, live, whether each public forward answers),
    ``disks``, ``license`` (the license Fabric Studio assigned it), ``license_match`` (does that serial match
    the one the FortiSOAR guest uses), ``guest_license`` (the FortiSOAR guest's own license, over SSH),
    ``guest_config`` (FortiSOAR first-boot wizard status), ``credentials`` (the default login for this device
    type and where its password lives: use this for "I cannot log in"). Default: ``state``."""
    want = include or ["state"]
    bad = [w for w in want if w not in _VM_SECTIONS]
    if bad:
        raise ToolError(f"unknown include {bad}; choose from {', '.join(_VM_SECTIONS)}")
    base = {"host": host, "vm": vm, "fabric": fabric}
    sync = {"state": lambda: vm_state(**base, vm_type=vm_type), "detail": lambda: vm_detail(**base, vm_type=vm_type),
            "access": lambda: vm_access(**base, vm_type=vm_type), "disks": lambda: vm_disks(**base, vm_type=vm_type),
            "license": lambda: fs_license_assignment(**base, vm_type=vm_type),
            "credentials": lambda: device_credentials_hint(host, vm or "", fabric)}
    guest = {"license_match": validate_license_match, "guest_license": read_guest_license,
             "guest_config": guest_config_status}
    out: dict[str, Any] = {}
    for w in want:
        try:
            if w in sync:
                with anyio.fail_after(_TOOL_DEADLINE_S):
                    out[w] = await anyio.to_thread.run_sync(sync[w], abandon_on_cancel=True)
            else:
                out[w] = await guest[w](**base)
        except UnmanagedHostError:
            raise
        except Exception as e:
            out[w] = {"error": str(e) if isinstance(e, ToolError) else str(_explain(e, host))}
    _all_failed_alike(out)
    return out


@_tool
def tasks(host: str, vm: str | None = None, fabric: str | None = None, task_id: int | str | None = None,
          limit: int = 5, tail_lines: int = 50) -> dict[str, Any]:
    """Read-only. Fabric Studio tasks on a pod. With no ``task_id``: the tasks running now, plus (with ``vm``)
    that VM's most recent tasks and their return codes (an in-flight install shows here). With ``task_id``:
    that task's execution log, which holds the REASON a device task failed (for example ``No license for
    fgt000``, behind a bare ``rc=254``); ``tail_lines`` bounds a long log, 0 = all of it."""
    if task_id is not None:
        return task_log(host, task_id, tail_lines)
    return list_tasks(host, vm, fabric, limit)


# ── Resources and prompts ─────────────────────────────────────────────────────
# Resources are read-only data a client can attach without the model calling a tool; prompts are
# ready-made requests the person picks (slash commands in Claude Code). Both only point at the tools.

async def _json_resource(fn: Any, *args: Any) -> str:
    out = await anyio.to_thread.run_sync(lambda: fn(*args))
    return json.dumps(out, indent=2, default=str)


@mcp.resource("fabric-studio://pods", mime_type="application/json",
              description="The pods this server manages (host, name), without contacting them")
async def pods_resource() -> str:
    return await _json_resource(list_instances, False)


@mcp.resource("fabric-studio://pods/{host}/fabric", mime_type="application/json",
              description="The running fabric on a managed pod: its VMs with power, license and firmware")
async def fabric_resource(host: str) -> str:
    return await _json_resource(lambda: {"vms": list_vms(host)})


@mcp.resource("fabric-studio://pods/{host}/firmwares", mime_type="application/json",
              description="Every firmware image a managed pod can install, marked local, remote or unusable (0-byte stub)")
async def firmwares_resource(host: str) -> str:
    return await _json_resource(list_firmwares, host)


@mcp.prompt(name="troubleshoot-failed-install",
            description="Find out why a device or fabric install on a pod failed")
def troubleshoot_failed_install(host: str, fabric: str = "") -> str:
    target = f" in fabric {fabric!r}" if fabric else ""
    return (f"An install failed on the Fabric Studio pod {host!r}{target}. Call `diagnose` for it first and read its "
            "findings in order. If a finding names a task, read that task's log with `tasks`. Explain the cause in "
            "plain terms, say what you checked and what you did not, and propose the smallest fix. Do not change "
            "anything: if a fix needs a change to the pod, show the preview and let me approve it.")


@mcp.prompt(name="snapshot-before-change",
            description="Save a VM's disks as a snapshot before upgrading or reinstalling it")
def snapshot_before_change(host: str, vm: str, change: str = "an upgrade") -> str:
    return (f"I am about to do {change} on {vm!r} on pod {host!r}. Check first with `vm` (include state and "
            "detail) that it is healthy and with `pods` (view snapshots) that the name you pick is unused. "
            "Explain that `snapshot_vm` hard powers the VM off for several minutes and say whether a diff or a full "
            "snapshot fits (a diff is small but needs the original firmware; a full one stands alone). Then preview "
            "the snapshot and wait for my approval.")


@mcp.prompt(name="pod-health-check", description="Is this pod safe to build on right now")
def pod_health_check(host: str) -> str:
    return (f"Is the Fabric Studio pod {host!r} safe to build on? Use `pods` (views health and lockouts) and `tasks` "
            "to check for a lockout, tasks in flight, and the fabric that is running (a new fabric would stop it). "
            "Then run `diagnose` on the running fabric. Answer with one line of verdict and the evidence behind it.")


# The ``build`` tool lives in its own module and registers itself on ``mcp``; a reload of this module (the
# tests do) makes a fresh ``mcp``, so the tool module is reloaded to register on that one.
import importlib  # noqa: E402

for _tool_module in ("fabric_studio.mcp.build", "fabric_studio.mcp.device", "fabric_studio.mcp.rawexec",
                     "fabric_studio.mcp.register", "fabric_studio.mcp.firmware"):
    if _tool_module in sys.modules:
        importlib.reload(sys.modules[_tool_module])
    else:
        importlib.import_module(_tool_module)


def main() -> None:
    # No arguments: the MCP server, which is how Claude starts it. A command name: set up or inspect pods.
    if len(sys.argv) > 1:
        from fabric_studio.mcp import cli
        raise SystemExit(cli.main(sys.argv[1:]))
    mcp.run()


if __name__ == "__main__":
    main()
