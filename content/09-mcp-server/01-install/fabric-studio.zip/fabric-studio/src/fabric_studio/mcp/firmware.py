"""The ``firmware`` MCP tool: put an image on a pod so a fabric can use it.

An upload goes into the pod's home repository (``firmware:import``). Fabric Studio lists a new file only after a
home-repository refresh, so the tool refreshes and then waits for the firmware row to appear, and returns the name
to put in a node's ``image:``. Only files under the lab workspace (``$FS_WORKSPACE``) can be sent: the agent must
not be able to ship an arbitrary file from the workstation to a pod.
"""
from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Any

from mcp.server.mcpserver.exceptions import ToolError

from fabric_studio import admin as fs_admin
from fabric_studio.mcp import instances as inst
from fabric_studio.mcp.server import _LONG_TOOL_DEADLINE_S, _client, _tool

# what Fabric Studio installs from: LXC rootfs zips, Fortinet .out/.zip images, qcow2/img disks, ISOs
SUFFIXES = (".zip", ".qcow2", ".img", ".iso", ".out", ".vmdk")
SETTLE_S = 90


def _allowed(path: str) -> Path:
    p = Path(path).expanduser()
    roots = [r.resolve() for r in inst.workspace_dirs() if r.is_dir()]
    if not p.is_absolute() and roots:
        p = roots[0] / p
    try:
        p = p.resolve(strict=True)
    except (OSError, RuntimeError):
        raise ToolError(f"{path} does not exist") from None
    if not any(p.is_relative_to(r) for r in roots):
        raise ToolError("only files inside the lab workspace ($FS_WORKSPACE) can be uploaded"
                        + ("" if roots else "; this server has no workspace configured"))
    if not p.is_file() or not p.name.lower().endswith(SUFFIXES):
        raise ToolError(f"{p.name} is not a firmware image ({', '.join(SUFFIXES)})")
    return p


def _row(c: Any, name: str) -> dict[str, Any] | None:
    return next((f for f in fs_admin.list_home_firmwares(c)
                 if f.get("name") == name or os.path.basename(str(f.get("path") or "")) == name), None)


def _show(f: dict[str, Any]) -> dict[str, Any]:
    return {"id": f.get("id"), "name": os.path.basename(str(f.get("path") or "")) or f.get("name"),
            "vm_type": f.get("vm_type"), "status": f.get("status"), "size": f.get("size")}


def _settle(c: Any, name: str) -> dict[str, Any] | None:
    """Refresh the home repository until ``name`` shows as a firmware: an import is not listed until then."""
    deadline = time.monotonic() + SETTLE_S
    while True:
        fs_admin.refresh_home_repository(c)
        row = _row(c, name)
        if (row and row.get("vm_type")) or time.monotonic() > deadline:
            return row
        time.sleep(5)


@_tool(deadline_s=_LONG_TOOL_DEADLINE_S, mutating=True)
def firmware(action: str, host: str, path: str | None = None, name: str | None = None,
             confirm: bool = False) -> dict[str, Any]:
    """MUTATING (``upload``, ``refresh``). Put a firmware image on a pod so a fabric can use it.
    ``upload`` sends a local file (``path``, inside the lab workspace) into the pod's home repository under
    ``name`` (default: the file's name), refreshes the repository so Fabric Studio lists it, and returns the
    firmware row: put its ``name`` in a node's ``image:``, then ``build`` plan and apply. The file name decides
    the type: an LXC rootfs must be named ``LXC_*.zip``; a ``.qcow2`` becomes a BASIC VM. A name already in the
    home repository is not uploaded again (pick another ``name`` for a new version).
    ``refresh`` re-reads the home repository, for a file that was copied onto the pod some other way.
    To see what a pod already has, use ``pods`` view ``firmwares``. Without ``confirm=true`` it returns what it
    would do. A multi-GB image takes minutes."""
    c = _client(host)
    if action == "refresh":
        if not confirm:
            return {"dry_run": True, "would": "refresh the home repository", "note": "re-run with confirm=true"}
        fs_admin.refresh_home_repository(c)
        return {"refreshed": True, "home": [_show(f) for f in fs_admin.list_home_firmwares(c)]}
    if action != "upload":
        raise ToolError("action is upload or refresh")
    if not path:
        raise ToolError("upload needs path, the image file to send")
    p = _allowed(path)
    dest = name or p.name
    if not dest.lower().endswith(SUFFIXES) or "/" in dest:
        raise ToolError(f"name {dest!r} must be a plain file name ending in one of {', '.join(SUFFIXES)}")
    have = _row(c, dest)
    if have:
        return {"uploaded": False, "reason": f"{dest} is already in the home repository", "firmware": _show(have)}
    plan = {"host": host, "file": p.name, "name": dest, "size_mb": round(p.stat().st_size / 2**20, 1)}
    if dest.lower().endswith(".zip") and not dest.startswith("LXC_") and p.name.startswith("LXC_"):
        plan["warning"] = "an LXC rootfs is typed LXC only when its name starts with LXC_"
    if not confirm:
        return {"dry_run": True, **plan, "note": "re-run with confirm=true to upload; the person is asked first"}
    c.timeout_s = max(c.timeout_s, int(p.stat().st_size / 2**20 / 2) + 600)   # about 2 MB/s, plus margin
    fs_admin.upload_firmware(c, str(p), dest_name=dest)
    row = _settle(c, dest)
    if not row:
        raise ToolError(f"uploaded {dest} but the home repository does not list it after {SETTLE_S}s of refreshes")
    out = {"uploaded": True, **plan, "firmware": _show(row), "use_as": f"image: '{dest}'"}
    if not row.get("vm_type"):
        out["warning"] = "Fabric Studio did not recognise its type; check the file name (LXC_*.zip, *.qcow2)"
    return out
