"""The ``run`` tool: run a command over SSH, or make an API call, on any device whose access is public.

The ``device`` tool is the careful way to configure a FortiGate. This is the way that reaches everything else, and
reaches the FortiGate in ways ``device`` does not: any command, any API endpoint, any device type. It is built to
be easy: name the device, give a ``command`` or an ``api`` request, and read the answer.

* A command or request that only reads runs at once. A known read-only command (``get``, ``show``, ``ls``,
  ``ps``, ``df``...) or a GET needs no approval. Anything else is shown to the person first, exactly as it will be
  sent, and runs only after they approve; the agent cannot approve for them.
* Nothing is guessed to be safe: any shell syntax (``;``, ``&&``, ``$()``, redirects, backticks) makes a command
  need approval, and so does every unfamiliar command.
* The login is the one Fabric Studio holds for the device and never passes through the agent. The output has
  secrets hidden where FortiOS marks them (``set password ENC ...``); other output is returned as the device
  printed it, so ``cat`` of a secret file shows it.
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import os
import re
import urllib.parse
from pathlib import Path
from typing import Any

from mcp.server.mcpserver.exceptions import ToolError

from fabric_studio.mcp import device as dev
from fabric_studio.mcp import fortios as fos
from fabric_studio.mcp import fortios_cli as cli
from fabric_studio.mcp import podrelay
from fabric_studio.mcp.server import _LONG_TOOL_DEADLINE_S, _refuse_if_locked, _tool

FORTIOS_LIKE = {"FGT", "FMG", "FAZ"}   # a FortiOS-style CLI: needs a terminal session and its SSH quirks
MAX_OUTPUT = 20000
MAX_TIMEOUT_S = 300

# shell syntax: any of these and the command is no longer something we can call read-only
SHELL_SYNTAX_RX = re.compile(r"[;&`$(){}<>\\\n\r]|\|\|")
CONTROL_RX = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

# Commands with no way to change anything, whatever their arguments. Everything else that is read-only has a rule
# of its own below, because the same command often has a mutating form (``ifconfig eth0 down``, ``date -s``).
LINUX_ALWAYS_READ = {"ls", "cat", "head", "tail", "grep", "egrep", "ps", "df", "du", "free", "uptime", "uname",
                     "whoami", "id", "pwd", "lsblk", "lscpu", "lsmod", "wc", "stat", "file", "which", "netstat",
                     "nslookup", "dig", "traceroute"}
FOLLOWING = {"-f", "--follow", "-F"}   # never ends: not a read
IP_READ = {"addr", "address", "a", "link", "l", "route", "r", "neigh", "n", "neighbor"}
IP_VERBS = {"show", "list", "ls", "get", "lst"}
SYSTEMCTL_READ = {"status", "is-active", "is-enabled", "list-units", "list-unit-files", "show"}
DOCKER_READ = {"ps", "images", "logs", "inspect", "version", "info"}
JOURNALCTL_WRITES = ("--vacuum", "--rotate", "--flush", "--sync", "--relinquish", "--setup-keys", "--update-catalog")
DMESG_OK = {"-T", "-H", "-x", "-k", "-u", "--ctime", "--human", "--kernel", "--userspace"}


def _linux_read_only(head: list[str]) -> bool:
    """Is this command, with these arguments, only a read? A name alone is never enough."""
    cmd, args = head[0], head[1:]
    if cmd in LINUX_ALWAYS_READ:
        return not (FOLLOWING & set(args))
    if cmd == "ip":
        words = [a for a in args if not a.startswith("-")]
        return bool(words) and words[0] in IP_READ and (len(words) == 1 or words[1] in IP_VERBS or words[1] == "dev")
    if cmd == "systemctl":
        return bool(args) and args[0] in SYSTEMCTL_READ
    if cmd == "docker":
        return bool(args) and args[0] in DOCKER_READ and not (FOLLOWING & set(args))
    if cmd == "journalctl":
        return not (FOLLOWING & set(args)) and not any(a.startswith(JOURNALCTL_WRITES) for a in args)
    if cmd == "ss":
        return not any(a in ("-K", "--kill") or (a.startswith("-") and not a.startswith("--") and "K" in a) for a in args)
    if cmd == "dmesg":
        return all(a in DMESG_OK for a in args)
    if cmd == "hostname":
        return all(a.startswith("-") for a in args)          # a name would SET the hostname
    if cmd == "date":
        return all(a == "-u" or a.startswith("+") or a in ("-R", "--utc", "--rfc-email") for a in args)
    if cmd == "ifconfig":
        return len(args) == 0 or (len(args) == 1 and args[0] not in ("up", "down"))
    return False


def _filter_ok(words: list[str]) -> bool:
    """A pipe target that can only transform what flows through it: never a file operand, never an output file."""
    cmd, args = words[0].lower(), words[1:]
    if cmd in ("grep", "egrep"):
        return True   # reads stdin and prints; no flag of grep writes a file
    if cmd in ("sort", "uniq"):
        return all(a.startswith("-") for a in args) and not any(a.startswith(("-o", "--output")) for a in args)
    if cmd in ("head", "tail", "wc", "cut"):
        return not (FOLLOWING & set(args))
    return False


FORTIOS_READ_FIRST = {"get", "show"}
FORTIOS_READ_EXECUTE = {"ping", "ping6", "traceroute", "traceroute6", "date", "time", "ping-options"}
# ``diagnose`` and ``execute`` forms that only read, word for word (``diagnose`` as a whole can clear, kill and debug)
FORTIOS_READ_PHRASES = (
    ("diagnose", "dvm", "device", "list"), ("diagnose", "dvm", "adom", "list"), ("diagnose", "dvm", "group", "list"),
    ("diagnose", "fgfm", "session-list"), ("diagnose", "vpn", "tunnel", "list"),
    ("diagnose", "vpn", "ike", "gateway", "list"), ("diagnose", "ip", "route", "list"),
    ("diagnose", "ip", "address", "list"), ("diagnose", "sys", "ha", "status"),
    ("diagnose", "sys", "ha", "checksum", "show"), ("diagnose", "test", "update", "info"),
    ("execute", "log", "fortianalyzer", "test-connectivity"),
    ("diagnose", "debug", "crashlog", "read"), ("diagnose", "autoupdate", "versions"),
)
FORTIOS_PROTECTED_API_RX = re.compile(r"/cmdb/system/(admin|api-user|accprofile)(/|\?|$)", re.I)
API_PATH_RX = re.compile(r"^/[A-Za-z0-9_./:@,=&?%+-]*$")
METHODS = ("GET", "POST", "PUT", "DELETE")
# FortiManager / FortiAnalyzer speak JSON-RPC: ``get /dvmdb/adom/root/device``; only ``get`` reads
JSONRPC_TYPES = {"FMG", "FAZ"}
JSONRPC_VERBS = ("GET", "SET", "ADD", "UPDATE", "DELETE", "EXEC", "CLONE", "MOVE", "REPLACE")
JSONRPC_PROTECTED_RX = re.compile(r"/system/admin/(user|profile)(/|$)|/sys/login|/sys/logout", re.I)
JSONRPC_HINTS = {
    -11: ("the account Fabric Studio holds for this device is not allowed to use JSON-RPC. Allow it on the device "
          "(command='config system admin user\\nedit admin\\nset rpc-permit read-write\\nend', which is a change) "
          "and ask again"),
    -6: "the URL does not exist on this device (check the ADOM name and the path)",
    -3: "the object does not exist",
}


def _words(segment: str) -> list[str]:
    return segment.split()


def classify_command(command: str, vm_type: str) -> tuple[bool, str]:
    """``(read_only, why)``. Strict by design: a command is read-only only when it is plainly one of a short list
    of reads, with at most a pipe into a plain filter."""
    text = command.strip()
    if not text:
        return False, "empty"
    if CONTROL_RX.search(text):
        return False, "contains control characters"
    if "\n" in text or "\r" in text or SHELL_SYNTAX_RX.search(text):
        return False, ("is several lines, so it is a script and not a plain read" if "\n" in text or "\r" in text
                       else "contains shell syntax (; & | > $ and the like)")
    segments = [seg.strip() for seg in text.split("|")]
    head = _words(segments[0])
    if not head:
        return False, "empty"
    first = head[0].lower()
    fortios = vm_type in FORTIOS_LIKE
    if fortios:
        low = [w.lower() for w in head]
        # a listed phrase may take a name after it (``diagnose vpn tunnel list name to-site2``) only when it lists
        phrase = any(tuple(low[:len(p)]) == p and (len(low) == len(p) or p[-1] in ("list", "session-list"))
                     for p in FORTIOS_READ_PHRASES)
        ok = (first in FORTIOS_READ_FIRST or phrase
              or (first == "execute" and len(head) > 1 and low[1] in FORTIOS_READ_EXECUTE))
    else:
        ok = _linux_read_only([first, *head[1:]])
    if not ok:
        return False, f"{head[0]} is not a known read-only command"
    for seg in segments[1:]:
        w = _words(seg)
        if not w or not (w[0].lower() == "grep" if fortios else _filter_ok(w)):
            return False, "pipes into something that is not a plain filter"
    return True, "a known read-only command"


def parse_api(api: str) -> tuple[str, str, dict[str, str]]:
    """``"GET /api/v2/monitor/system/status"`` (or just the path) to ``(method, path, query)``."""
    parts = api.strip().split(None, 1)
    method, target = ("GET", parts[0]) if parts and parts[0].startswith("/") else (parts[0].upper(), parts[1]) if len(parts) == 2 else ("", "")
    if method not in METHODS + JSONRPC_VERBS or not target:
        raise ToolError("api is a request such as 'GET /api/v2/monitor/system/status' (method, then path; "
                        f"the method is one of {', '.join(METHODS)} and defaults to GET)")
    path, _, query = target.partition("?")
    if (not API_PATH_RX.fullmatch(path + ("?" + query if query else "")) or ".." in path or "//" in path
            or "/./" in path or path.endswith("/.") or re.search(r"%(?!20)", path + query, re.I)):
        raise ToolError(f"{target!r} is not a usable API path: it starts with / and holds only letters, digits and "
                        "/ . _ - : @ , = & ? (a space is %20)")
    return method, path, dict(urllib.parse.parse_qsl(query, keep_blank_values=True))


def scrub_text(text: str, t: fos.Target) -> str:
    """Hide the secrets FortiOS marks: ``set password ENC ...`` lines, any ``ENC ...`` value, the login itself."""
    return fos._scrub(fos.mask_set_lines(text), t)


def _clip(text: str) -> tuple[str, bool]:
    return (text[:MAX_OUTPUT], True) if len(text) > MAX_OUTPUT else (text, False)


# ── running ──────────────────────────────────────────────────────────────────

def _ssh_fortios(t: fos.Target, command: str, timeout_s: int) -> dict[str, Any]:
    lines = [ln for ln in command.replace("\r", "").split("\n") if ln.strip()]

    async def go(sh: cli._Shell) -> dict[str, Any]:
        out, failed = [], None
        for n, line in enumerate(lines):
            text = await sh.run(line, timeout_s=timeout_s)
            out.append(text if len(lines) == 1 else f"$ {line}\n{text}".rstrip())
            if len(lines) > 1 and n < len(lines) - 1 and text.strip() and cli.FAIL_RX.search(text):
                failed = line   # a script stops at its first refused line, as a person would stop
                with contextlib.suppress(Exception):
                    await sh.run("abort")
                break
        return {"output": "\n".join(out), **({"failed_line": failed} if failed else {})}
    return cli.session(t, go, timeout_s=timeout_s + 30)


def _ssh_linux(t: fos.Target, command: str, timeout_s: int) -> dict[str, Any]:
    import asyncssh
    fos.check_cooldown(t)

    # many guest images (the toolbox LXC among them) take keys only: offer the device-access key that a fabric's
    # deviceconfig installs, before the password
    key = Path(os.environ.get("FSH_DEVICE_ACCESS_KEY") or Path.home() / ".fsh" / "device_access_key")
    keys = [str(key)] if key.is_file() else []

    async def attempt(user: str, password: str) -> Any:
        async with asyncssh.connect(t.host, port=t.ssh_port, username=user, password=password, known_hosts=None,
                                    client_keys=keys, agent_path=None,
                                    preferred_auth=[*(["publickey"] if keys else []), "password",
                                                    "keyboard-interactive"]) as conn:
            return await conn.run(command, check=False, timeout=timeout_s)

    async def go() -> dict[str, Any]:
        try:
            *earlier, last = t.logins()   # generic guests: root or admin, the fabric's password or the image's
            for user, password in earlier:
                try:
                    r = await attempt(user, password)
                    break
                except asyncssh.PermissionDenied:
                    continue
            else:
                r = await attempt(*last)
        except asyncssh.PermissionDenied:
            raise fos.login_refused(t, guest=True) from None
        except (OSError, asyncssh.Error, TimeoutError) as e:
            raise fos.Unreachable(f"cannot reach {t.name} over SSH at {t.host}:{t.ssh_port} ({type(e).__name__}). Its "
                                  "SSH access must be PUBLIC, and the guest must have finished booting.") from None
        return {"output": (r.stdout or "") + (("\n" + r.stderr) if r.stderr else ""), "exit_status": r.exit_status}
    return asyncio.run(go())


def _jsonrpc(t: fos.Target, verb: str, url: str, body: Any) -> dict[str, Any]:
    """One FortiManager / FortiAnalyzer JSON-RPC request inside its own session: log in as the account Fabric
    Studio holds, send it, log out. The password goes only into the login call and never into the result."""
    if isinstance(body, dict) and "url" in body:   # the url is what the protected-path check saw
        raise fos.DeviceError("put the path in api, not in body: a body may not carry its own url")
    import requests
    import urllib3
    urllib3.disable_warnings()
    endpoint = f"https://{t.host}:{t.https_port}/jsonrpc"

    def post(payload: dict[str, Any]) -> dict[str, Any]:
        # a FortiManager holds an exec/add (authorizing a device) open for ~20-30 s even with create_task
        wait = fos.HTTP_TIMEOUT_S if payload.get("method") in ("get", None) or payload.get("id") != 2 else 180
        try:
            r = requests.post(endpoint, json=payload, verify=False, timeout=wait)
        except requests.exceptions.RequestException as e:
            raise fos.Unreachable(f"cannot reach {t.name} over HTTPS at {t.host}:{t.https_port} ({type(e).__name__}). "
                                  "Its HTTPS access must be PUBLIC and the device must be up.") from None
        try:
            return r.json()
        except ValueError:
            raise fos.DeviceError(f"{t.name} answered {r.status_code} with something that is not JSON-RPC; it is "
                                  "probably still booting") from None

    fos.check_cooldown(t)
    login = post({"id": 1, "method": "exec", "params": [{"url": "/sys/login/user",
                                                         "data": {"user": t.user, "passwd": t.password}}]})
    _check_jsonrpc_login(t, login, bool(login.get("session")))
    session = login["session"]
    try:
        params = {**(body if isinstance(body, dict) else {}), "url": url}
        res = post({"id": 2, "method": verb.lower(), "params": [params], "session": session})
    finally:
        with contextlib.suppress(Exception):
            post({"id": 3, "method": "exec", "params": [{"url": "/sys/logout"}], "session": session})
    return _jsonrpc_result(res)


def _jsonrpc_status(res: dict[str, Any]) -> tuple[int, str]:
    first = (res.get("result") or [{}])[0] if isinstance(res.get("result"), list) else {}
    st = first.get("status") or {}
    return int(st.get("code", -1)), str(st.get("message") or "")


def _check_jsonrpc_login(t: fos.Target, login: dict[str, Any], session_held: bool) -> None:
    code, msg = _jsonrpc_status(login)
    if code != 0 or not session_held:
        if code in (-22, -20, -21):
            raise fos.login_refused(t)
        raise fos.DeviceError(f"{t.name} refused the JSON-RPC login (code {code}: {msg})"
                              + (f": {JSONRPC_HINTS[code]}" if code in JSONRPC_HINTS else ""))


def _jsonrpc_result(res: dict[str, Any]) -> dict[str, Any]:
    code, msg = _jsonrpc_status(res)
    first = (res.get("result") or [{}])[0] if isinstance(res.get("result"), list) else {}
    out: dict[str, Any] = {"status": code, "message": msg, "data": first.get("data")}
    if code != 0 and code in JSONRPC_HINTS:
        out["hint"] = JSONRPC_HINTS[code]
    return out


def _relay_jsonrpc(t: fos.Target, ip: str, verb: str, url: str, body: Any) -> dict[str, Any]:
    if isinstance(body, dict) and "url" in body:
        raise fos.DeviceError("put the path in api, not in body: a body may not carry its own url")
    fos.check_cooldown(t)
    got = podrelay.jsonrpc(t, ip, verb, url, body)
    _check_jsonrpc_login(t, got["login"], got["result"] is not None)
    return _jsonrpc_result(got["result"])


def _api(t: fos.Target, vm_type: str, method: str, path: str, query: dict[str, str], body: Any,
         relay_ip: str | None = None) -> dict[str, Any]:
    if vm_type in JSONRPC_TYPES:
        if method not in JSONRPC_VERBS:
            raise ToolError(f"a {vm_type} API call is JSON-RPC: a verb ({', '.join(v.lower() for v in JSONRPC_VERBS)}) "
                            "and a URL, such as 'get /dvmdb/adom/root/device'; body holds data, filter or fields")
        res = (_relay_jsonrpc(t, relay_ip, method, path, body) if relay_ip else _jsonrpc(t, method, path, body))
        parsed: Any = fos.mask(res)
        text = json.dumps(parsed, indent=1, default=str)
        shown, cut = _clip(text)
        return {**(parsed if not cut else {"status": res["status"], "body": shown,
                                           "note": "the answer is long; ask for a narrower URL or add fields/filter"}),
                "truncated": cut}
    if method in JSONRPC_VERBS and method not in METHODS:
        raise ToolError(f"{method.lower()} is a FortiManager/FortiAnalyzer JSON-RPC verb; this device takes "
                        f"{', '.join(METHODS)}")
    if vm_type == "FGT" and not re.match(r"^/api/v2/(cmdb|monitor|log)/", path):
        raise ToolError("a FortiGate API path starts with /api/v2/cmdb/, /api/v2/monitor/ or /api/v2/log/")
    if relay_ip:
        code, text = podrelay.api(t, relay_ip, vm_type, method, path, query, body)
        return _shape(t, vm_type, code, text, lambda: json.loads(text))
    if vm_type == "FGT":
        try:
            r = fos.call(t, "ro" if method == "GET" else "rw", method, path[len("/api/v2/"):], query or None, body, raw=True)
        except fos.RestUnavailable as e:
            raise fos.DeviceError(f"the API is not available on {t.name}: {e.short}. Run a command over SSH instead "
                                  "(command=...).") from None
    else:
        import requests
        import urllib3
        urllib3.disable_warnings()
        try:
            r = requests.request(method, f"https://{t.host}:{t.https_port}{path}", params=query or None, json=body,
                                 auth=(t.user, t.password), verify=False, timeout=fos.HTTP_TIMEOUT_S)
        except requests.exceptions.RequestException as e:
            raise fos.Unreachable(f"cannot reach {t.name} over HTTPS at {t.host}:{t.https_port} ({type(e).__name__}). "
                                  "Its HTTPS access must be PUBLIC and the device must be up.") from None
    return _shape(t, vm_type, r.status_code, r.text, r.json)


def _shape(t: fos.Target, vm_type: str, status: int, raw: str, parse: Any) -> dict[str, Any]:
    try:
        parsed: Any = fos.mask(parse())
        text = json.dumps(parsed, indent=1, default=str)
    except ValueError:
        parsed, text = None, scrub_text(raw, t)
    shown, cut = _clip(text)
    res: dict[str, Any] = {"status": status, "truncated": cut}
    if cut:
        res["body"] = shown
        res["note"] = "the answer is long; ask for a narrower path, or add filters to the query"
    else:
        res["body"] = parsed if parsed is not None else shown
    if status == 401 and vm_type != "FGT":
        res["hint"] = ("this device did not accept its Fabric Studio login over HTTP basic authentication; many "
                       "appliances need their own API token. Run a command over SSH instead.")
    return res


@_tool(deadline_s=_LONG_TOOL_DEADLINE_S, mutating=True)
def run(host: str, device: str, command: str | None = None, api: str | None = None, body: dict[str, Any] | None = None,
        fabric: str | None = None, timeout_s: int = 30, confirm: bool = False) -> dict[str, Any]:
    """MUTATING unless it only reads. Use this to read from or run something on ANY device of a fabric by name:
    FortiGate, FortiManager, FortiAnalyzer or a Linux guest. For example the firmware version of a FortiAnalyzer
    is ``command="get system status"``, and the free disk of a Linux guest is ``command="df -h"``. It runs a
    command over SSH, or makes an API call over HTTPS, with the login Fabric Studio holds for the device (you never
    need or see a password). It uses the device's public access, or relays through the pod when that access is
    not public (``through`` in the result says so). Give EITHER
    ``command`` OR ``api``.

    ``command`` is what you would type at the device's prompt: ``get system status``, ``show system interface``,
    ``ls /var/log``, ``df -h``. ``api`` is a request: ``GET /api/v2/monitor/system/status`` (the method defaults
    to GET; POST, PUT and DELETE take a ``body``). On a FortiManager or FortiAnalyzer ``api`` is JSON-RPC: a
    verb (get, set, add, update, delete, exec) and a URL, such as ``get /dvmdb/adom/root/device`` or
    ``exec /dvm/cmd/add/dev-list``, with ``body`` holding the rest of the params (data, fields, filter); the
    tool opens and closes the session. A FortiGate, FortiManager and FortiAnalyzer get a FortiOS CLI; any other
    device gets a shell. Several lines in ``command`` run in order and stop at the first refusal. Read-only
    ``diagnose`` forms such as ``diagnose dvm device list`` and ``diagnose vpn tunnel list`` count as reads.

    A command that only reads (get, show, ls, ps, df, a pipe into grep...) and every GET run at once. Anything
    else, including anything with shell syntax, returns a PLAN first: the exact command or request, as it will be
    sent. With ``confirm=true`` the person is asked to approve it, then it runs. Do not pass ``confirm`` for a
    read. For configuring a FortiGate prefer the ``device`` tool, which shows a real before and after.

    Returns the output (``output`` for a command, ``status`` and ``body`` for an API call), with FortiOS secrets
    hidden. The device must be powered on; the tool says in plain words when something blocks it, and tries a
    login once only."""
    if bool(command) == bool(api):
        raise ToolError("give exactly one of command (to run over SSH, e.g. 'get system status') or api (e.g. "
                        "'GET /api/v2/monitor/system/status')")
    if not 1 <= timeout_s <= MAX_TIMEOUT_S:
        raise ToolError(f"timeout_s is 1 to {MAX_TIMEOUT_S}")
    via = "api" if api else "ssh"
    t, row = dev.resolve(host, device, fabric, need=("HTTPS",) if api else ("SSH",), relay=True)
    vm_type = row["vm_type"] or ""
    relay_ip = row.get("relay_ip")
    try:
        if api:
            method, path, query = parse_api(api)
            protected = (FORTIOS_PROTECTED_API_RX if vm_type == "FGT"
                         else JSONRPC_PROTECTED_RX if vm_type in JSONRPC_TYPES else None)
            if protected and method != "GET" and protected.search(path):
                raise ToolError("that path holds the accounts this tool signs in with; changing them here could lock "
                                "it out of the device. Use the device's own GUI for administrator accounts.")
            read_only, why = method == "GET", "a GET request"
            request = f"{method} {path}" + (f"?{urllib.parse.urlencode(query)}" if query else "")
            asked: dict[str, Any] = {"request": request, **({"body": fos.mask(body)} if body else {})}
        else:
            if CONTROL_RX.search(command or ""):
                raise ToolError("a command cannot contain control characters")
            read_only, why = classify_command(command or "", vm_type)
            asked = {"command": command}
        plan = {"device": t.name, "fabric": t.fabric, "type": vm_type, "via": via, "read_only": read_only, "why": why,
                "login": f"{t.user} ({row.get('login_source', 'Fabric Studio')})",
                **({"through": f"the pod (its {via.upper()} access is not public)"} if relay_ip else {}), **asked}
        if not read_only:
            if not confirm:
                return {"dry_run": True, **plan,
                        "warnings": [f"{'this request' if api else 'this command'} is not known to be read-only "
                                     f"({why}), so it needs the person's approval before it runs"],
                        "note": "re-run with confirm=true to run it; the person is asked first"}
            _refuse_if_locked(t.host)
        if api:
            result = _api(t, vm_type, method, path, query, body, relay_ip)
        else:
            if relay_ip:
                result = podrelay.command(t, relay_ip, command or "", timeout_s, linux=vm_type not in FORTIOS_LIKE)
            else:
                result = (_ssh_fortios if vm_type in FORTIOS_LIKE else _ssh_linux)(t, command or "", timeout_s)
            result["output"] = scrub_text(result["output"], t)
            result["output"], cut = _clip(result["output"])
            if cut:
                result["truncated"] = True
                result["note"] = "the output is long; filter it (| grep ...) or ask for less"
        return {"executed": True, **plan, **result}
    except fos.DeviceError as e:
        raise ToolError(fos._scrub(str(e), t)) from None
