"""Cross-instance helpers for the Fabric Studio MCP: find a device, pod health, licensing and
reachability. Each function takes an open ``FabricStudioClient`` and returns plain data (no
secrets), so the server tools stay thin and these are testable with a stub client."""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from fabric_studio import admin as fs_admin

# Device user by vm_type, as `fabric ssh` picks it (tools/fs_ssh.DEFAULT_USER).
DEFAULT_USER = {"FAIG": "fortinet", "LXC": "root"}


def device_rows(c: Any, only_fabric: str | None = None) -> list[dict[str, Any]]:
    """Every modelled device on the pod: fabric, name, type, whether it is powered and its
    ``port_idx`` (public forwards sit at ``base + port_idx``). ``only_fabric`` limits the walk to one
    fabric by name: reading every fabric's runtime state is the slow part on a busy pod."""
    runtime = {str(v.get("id")): v for v in fs_admin.runtime_vms(c)}
    rows = []
    for f in fs_admin.list_fabrics(c):
        if only_fabric is not None and f.get("name") != only_fabric:
            continue
        for v in fs_admin.list_fabric_vms(c, f.get("id")):
            rt = runtime.get(str(v.get("id")))
            up, ready = False, False
            if rt is not None:
                st = fs_admin.get_vm_runtime_state(c, v["id"]).get("status") or {}
                up, ready = bool(st.get("powered")), bool(st.get("post_boot_prepared"))
            rows.append({"fabric_id": f.get("id"), "fabric": f.get("name"), "id": v.get("id"),
                         "name": v.get("name"), "vm_type": v.get("vm_type"), "up": up,
                         "ready": ready, "port_idx": (rt or {}).get("port_idx")})
    return rows


def forwards(host: str, port_idx: Any) -> dict[str, str]:
    """Where a device's public forwards would be (only live if its access is PUBLIC)."""
    if port_idx is None:
        return {}
    return {t: f"{host}:{base + int(port_idx)}" for t, base in fs_admin.ACCESS_FORWARD_BASE.items()}


def match(rows: list[dict[str, Any]], query: str, up_only: bool = False) -> list[dict[str, Any]]:
    q = query.strip().lower()
    hits = [r for r in rows if q in str(r["name"]).lower() and (r["up"] or not up_only)]
    return sorted(hits, key=lambda r: (str(r["name"]).lower() != q, not r["up"], str(r["name"]).lower()))


def read_pod_lock(host: str) -> dict[str, Any] | None:
    """The reconciler's per-pod mutex (``~/.fsh/locks/<host>.lock``), if a run holds it."""
    safe = "".join(ch if ch.isalnum() or ch in "_.-" else "_" for ch in host)
    try:
        info = json.loads((Path.home() / ".fsh" / "locks" / f"{safe}.lock").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return {"holder": info.get("holder"), "fabric": info.get("fabric"), "pid": info.get("pid"),
            "age_min": round((time.time() - float(info.get("created") or 0)) / 60)}


def health(c: Any, host: str) -> dict[str, Any]:
    """Is it safe to act on this pod: running tasks, the running fabric, hugepage headroom,
    the apply lock. Each part is best effort."""
    out: dict[str, Any] = {"hostname": None, "errors": []}

    def part(key: str, fn: Any) -> None:
        try:
            out[key] = fn()
        except Exception as e:
            out["errors"].append(f"{key}: {type(e).__name__}: {str(e)[:100]}")

    part("hostname", lambda: fs_admin.get_pod_hostname(c))
    part("tasks_running", lambda: [{"id": t.get("id"), "name": t.get("name") or t.get("description")}
                                   for t in fs_admin.list_running_tasks(c)])
    part("running_fabric", lambda: (fs_admin.get_running_fabric(c) or {}).get("name"))
    part("hugepages", lambda: (lambda f, t: {"free": f, "total": t} if t else None)(
        fs_admin.hugepages_free(c), fs_admin.hugepages_available(c)))  # None: pod reports none
    out["apply_lock"] = read_pod_lock(host)
    out["busy"] = bool(out.get("tasks_running")) or out["apply_lock"] is not None
    return out


def licensing(c: Any) -> dict[str, Any]:
    """FortiCloud/FortiFlex registration, the FS pool by type, and what each powered device
    was served. Pool state only: the guest's own license is a separate check."""
    pool = fs_admin.list_fs_licenses(c)
    by_id = {str(lic.get("id")): lic for lic in pool}
    counts: dict[str, int] = {}
    for lic in pool:
        counts[str(lic.get("vm_type"))] = counts.get(str(lic.get("vm_type")), 0) + 1
    devices = []
    for r in device_rows(c):
        if not r["up"]:
            continue
        try:
            mode = fs_admin.get_vm_license_mode(c, r["fabric_id"], r["id"])
        except Exception as e:
            devices.append({"fabric": r["fabric"], "name": r["name"], "vm_type": r["vm_type"],
                            "error": f"{type(e).__name__}: {str(e)[:80]}"})
            continue
        served = by_id.get(str(mode.get("served"))) or {}
        devices.append({"fabric": r["fabric"], "name": r["name"], "vm_type": r["vm_type"],
                        "mode": mode.get("mode"), "served_serial": served.get("name"),
                        "served": bool(mode.get("served"))})
    return {"forticloud_registered": fs_admin.forticloud_registered(c), "pool": counts, "devices": devices}


def reach(c: Any, host: str, devices: bool) -> dict[str, Any]:
    """Can THIS workstation reach the pod (HTTPS 443, SSH 22) and, with ``devices``, the
    SSH/HTTPS forward of every powered device."""
    out: dict[str, Any] = {}
    for label, port, kind in (("https_443", 443, "HTTPS"), ("ssh_22", 22, "SSH")):
        ok, detail = fs_admin.probe_access_port(host, port, kind, timeout=4.0)
        out[label] = {"ok": ok, "detail": detail}
    if devices:
        out["devices"] = []
        for r in device_rows(c):
            if not (r["up"] and r["port_idx"] is not None):
                continue
            probes = {}
            for kind in ("SSH", "HTTPS"):
                ok, detail = fs_admin.probe_access_port(
                    host, fs_admin.ACCESS_FORWARD_BASE[kind] + int(r["port_idx"]), kind, timeout=4.0)
                probes[kind] = {"ok": ok, "detail": detail if not ok else None}
            out["devices"].append({"fabric": r["fabric"], "name": r["name"], "vm_type": r["vm_type"], **probes})
    return out


def credentials_hint(host: str, row: dict[str, Any]) -> dict[str, Any]:
    """How to log in to a device, never the password itself."""
    name, vm_type = row["name"], row["vm_type"]
    hint: dict[str, Any] = {
        "user": DEFAULT_USER.get(vm_type or "", "admin"),
        "password_comes_from": ["the VM's own password in the pod API (overrides the fabric's)",
                                "a generic guest's image login (firmware metadata)", "the fabric's password"],
        "usual_users": "root or admin (a generic guest is tried with the other one if the first is refused)",
        **({"generic_vm": "Fabric Studio never sets a BASIC device's password and refuses the fabric "
                          "password: the login is the image's own, from the firmware metadata "
                          "`credentials` entry, which `fabric ssh` uses (user may not be admin)"}
           if (vm_type or "").upper() == "BASIC" else {}),
        "ssh": f'uv run fabric ssh "{name}" --pod {host}',
        "ssh_plan_without_secrets": f'uv run fabric ssh "{name}" --pod {host} --show',
        "never": "hand-written ssh/sshpass: ssh-config blocks, ControlMaster and retried prompts "
                 "report a correct password as wrong and arm the FortiOS admin lockout",
        "forwards": forwards(host, row.get("port_idx")), "powered": row["up"],
    }
    if vm_type == "FGT":
        hint["api_token"] = (f"uv run python -m tools.fgt_mint_api_key --host {host} --port <SSH forward port> "
                             "--api-user <name> --trusthost <cidr>   # reads $FGT_ADMIN_PASSWORD")
    return hint
