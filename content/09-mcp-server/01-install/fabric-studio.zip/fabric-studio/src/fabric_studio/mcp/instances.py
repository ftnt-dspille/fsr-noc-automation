"""Managed Fabric Studio instances: find the pods we hold credentials for, and register them.

An *instance* is one Fabric Studio pod (``host``). Where pod logins are kept:

* ``.env`` / ``.env.<name>`` files: ``FS_POD_HOST`` + ``FS_POD_USER`` + ``FS_POD_PASS`` (the
  ``fabric`` CLI's names) or ``POD_USERNAME`` + ``POD_PASSWORD`` with the host named in the
  header comment. A ``FGT_HOST`` line is a guest on a pod, so it only hints at the pod host.
* ``fabric.toml`` (``host``), ``pods.txt`` / ``faig_pods.txt`` (one host per line) and
  ``topologies/*/config/vars.*.yml`` (``pod_host``), in each ``$FS_WORKSPACE`` folder.

The registry (``~/.fsh/instances.json``, mode 0600) is the list of instances this tooling
manages. It holds no passwords: a registered instance either points at its env file or has
its password in the platform keychain. Secrets are read inside this process and never
returned.
"""
from __future__ import annotations

import json
import os
import re
import tempfile
import time
from collections.abc import Callable, Iterable
from pathlib import Path
from typing import Any

ENV_NAME = re.compile(r"^\.env(\.[A-Za-z0-9_.-]+)?$")
# a header comment that is nothing but a hostname (``# pod1.example.com``)
HOST_IN_TEXT = re.compile(r"^[ \t]*([a-z0-9][a-z0-9-]*(?:\.[a-z0-9-]+)+)[ \t]*$", re.I | re.M)
IPV4 = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")
HOST_OK = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?$")

POD_HOST_KEYS = ("FS_POD_HOST", "POD_HOST", "FS_HOST")
POD_USER_KEYS = ("FS_POD_USER", "POD_USERNAME", "POD_USER")
POD_PASS_KEYS = ("FS_POD_PASS", "POD_PASSWORD", "POD_PASS")


def workspace_dirs() -> list[Path]:
    """Lab workspace folders to read ``.env*`` files, ``fabric.toml``, ``pods.txt`` and
    ``topologies/`` from: the path-separated ``$FS_WORKSPACE``, else ``~/fabric-studio`` when it exists, so a
    client that cannot pass environment variables (FortiAgent) needs no setting."""
    env = os.environ.get("FS_WORKSPACE")
    if env is not None:
        return [Path(p).expanduser() for p in env.split(os.pathsep) if p]
    default = Path.home() / "fabric-studio"
    return [default] if default.is_dir() else []


def registry_path() -> Path:
    return Path(os.environ.get("FSH_INSTANCES_FILE") or Path.home() / ".fsh" / "instances.json")


def search_roots() -> list[Path]:
    """Directories whose env files may be read: the ``FS_WORKSPACE`` folders, ``~/.fsh``
    and any ``FS_ENV_DIRS`` (path-separator list)."""
    roots = [*workspace_dirs(), Path.home() / ".fsh"]
    roots += [Path(p).expanduser() for p in os.environ.get("FS_ENV_DIRS", "").split(os.pathsep) if p]
    seen, out = set(), []
    for r in roots:
        try:
            rr = r.resolve()
        except OSError:
            continue
        if rr.is_dir() and rr not in seen:
            seen.add(rr)
            out.append(rr)
    return out


def parse_env(path: Path) -> tuple[dict[str, str], str]:
    """(values, comment text) of a dotenv-style file. Quotes and ``export`` are stripped."""
    values: dict[str, str] = {}
    comments: list[str] = []
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#"):
            comments.append(line.lstrip("# "))
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        key, sep, val = line.partition("=")
        if not sep:
            continue
        val = val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
            val = val[1:-1]
        elif " #" in val:
            val = val.split(" #", 1)[0].rstrip()
        values[key.strip()] = val
    return values, "\n".join(comments)


def _first(values: dict[str, str], keys: Iterable[str]) -> str | None:
    for k in keys:
        if values.get(k):
            return values[k]
    return None


def env_file_candidate(path: Path) -> dict[str, Any] | None:
    """What a ``.env*`` file says about a pod, with no secret values. ``None`` if nothing."""
    values, comments = parse_env(path)
    host = _first(values, POD_HOST_KEYS)
    how = "env var"
    if not host:
        m = HOST_IN_TEXT.search(comments)
        if m and _first(values, POD_PASS_KEYS):
            host, how = m.group(1).lower(), "header comment"
    if not host and values.get("FGT_HOST"):
        host, how = values["FGT_HOST"], "FGT_HOST (a guest port-forward on the pod)"
    if not host or not HOST_OK.match(host):
        return None
    has_pw = bool(_first(values, POD_PASS_KEYS))
    return {"host": host, "source": str(path), "kind": "env file", "host_from": how,
            "user": _first(values, POD_USER_KEYS), "has_password": has_pw}


def _hosts_from_lines(path: Path) -> list[str]:
    out = []
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.split("#", 1)[0].strip()
        if line and HOST_OK.match(line) and ("." in line):
            out.append(line)
    return out


def discover(roots: list[Path] | None = None) -> list[dict[str, Any]]:
    """Every Fabric Studio host we hold some trace of, merged by host."""
    roots = roots or search_roots()
    found: dict[str, dict[str, Any]] = {}

    def note(host: str, **rec: Any) -> None:
        e = found.setdefault(host, {"host": host, "sources": [], "user": None, "has_password": False})
        e["sources"].append({k: v for k, v in rec.items() if k in ("source", "kind", "host_from")})
        e["user"] = e["user"] or rec.get("user")
        e["has_password"] = e["has_password"] or bool(rec.get("has_password"))

    for root in roots:
        for p in sorted(root.glob(".env*")):
            if p.is_file() and ENV_NAME.match(p.name) and not p.name.endswith((".example", ".sample")):
                try:
                    cand = env_file_candidate(p)
                except OSError:
                    continue
                if cand:
                    note(**cand)
    for ws in workspace_dirs():
        toml = ws / "fabric.toml"
        if toml.is_file():
            for raw in toml.read_text(errors="replace").splitlines():
                m = re.match(r'\s*host\s*=\s*"([^"]+)"', raw)
                if m and HOST_OK.match(m.group(1)):
                    note(m.group(1), source=str(toml), kind="fabric.toml")
        for name in ("pods.txt", "faig_pods.txt"):
            f = ws / name
            if f.is_file():
                for h in _hosts_from_lines(f):
                    note(h, source=str(f), kind="host list")
        for f in sorted((ws / "topologies").glob("*/config/vars.*.yml")):
            m = re.search(r'^\s*pod_host\s*:\s*"?([^"\s#]+)"?', f.read_text(errors="replace"), re.M)
            if m and HOST_OK.match(m.group(1)):
                note(m.group(1), source=str(f), kind="topology vars")
    return sorted(found.values(), key=lambda e: e["host"])


# -- registry ---------------------------------------------------------------------------------

def load_registry() -> dict[str, dict[str, Any]]:
    p = registry_path()
    if not p.is_file():
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return dict(data.get("instances") or {})


def _save_registry(instances: dict[str, dict[str, Any]]) -> None:
    p = registry_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=p.parent, prefix=".instances-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump({"instances": instances}, fh, indent=2, sort_keys=True)
        os.chmod(tmp, 0o600)
        os.replace(tmp, p)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def allowed_env_file(path: str | os.PathLike[str]) -> Path:
    """The resolved path of an env file this tooling may read, else ``ValueError``."""
    p = Path(path).expanduser()
    if not p.is_absolute():
        p = (workspace_dirs() or [Path.home() / ".fsh"])[0] / p
    p = p.resolve()
    if not ENV_NAME.match(p.name):
        raise ValueError(f"{p.name!r} is not a .env file name (.env or .env.<name>)")
    if not any(p.parent == r or r in p.parents for r in search_roots()):
        raise ValueError(f"{p} is outside the folders this tool reads env files from "
                         "(FS_WORKSPACE, ~/.fsh, or FS_ENV_DIRS)")
    if not p.is_file():
        raise ValueError(f"{p} does not exist")
    return p


def creds_from_env_file(path: Path) -> tuple[str, str] | None:
    values, _ = parse_env(path)
    pw = _first(values, POD_PASS_KEYS)
    if not pw:
        return None
    return _first(values, POD_USER_KEYS) or "admin", pw


def creds_for(host: str) -> tuple[str, str] | None:
    """The login of a registered instance, from its env file or the keychain; else ``None``."""
    entry = load_registry().get(host)
    if not entry:
        return None
    if entry.get("env_file"):
        try:
            path = allowed_env_file(entry["env_file"])
            if (env_file_candidate(path) or {}).get("host") != host:
                return None  # the file no longer names this host: never send its password there
            return creds_from_env_file(path)
        except ValueError:
            return None
    try:
        from fabric_studio.keychain import get_secret
    except ImportError:
        return None
    pw = get_secret(host)
    return (entry.get("user") or "admin", pw) if pw else None


def register(host: str | None = None, env_file: str | None = None, *, name: str | None = None,
             tags: list[str] | None = None, user: str | None = None, store: str = "env_file",
             verify: bool = True, dry_run: bool = False,
             connect: Callable[[str, str, str], Any] | None = None,
             set_secret: Callable[[str, str], None] | None = None, allow_group: bool = False) -> dict[str, Any]:
    """Add (or update) a managed instance. The login comes from ``env_file``
    (a ``.env*`` inside the allowed folders) or, with no file, from a keychain password stored for
    exactly this host (never the shared default or ``$POD_PASSWORD``). ``store`` is ``env_file`` (remember the file, copy
    nothing) or ``keychain`` (copy the password into the keychain). ``verify`` logs in first."""
    if store not in ("env_file", "keychain", "group"):
        return {"ok": False, "error": "store must be 'env_file' or 'keychain'"}
    if store == "group" and not allow_group:
        # Only the person's own `setup --shared-login` may send a group's shared password to a new host; the MCP
        # tool's host is model-chosen.
        return {"ok": False, "error": "store must be 'env_file' or 'keychain'"}
    path: Path | None = None
    if env_file:
        try:
            path = allowed_env_file(env_file)
        except ValueError as e:
            return {"ok": False, "error": str(e)}
        named = (env_file_candidate(path) or {}).get("host")
        if not named:
            return {"ok": False, "error": f"{path.name} does not name a pod host, so its password "
                                          "cannot be tied to one; add FS_POD_HOST to it"}
        if host and host != named:
            return {"ok": False, "error": f"{path.name} is for {named}, not {host}: an env file's "
                                          "password is only ever used on the host it names"}
        host = named
    if not host or not HOST_OK.match(host):
        return {"ok": False, "error": "no pod host: pass host, or an env file that names one "
                                      "(FS_POD_HOST, or a header comment that is just the hostname)"}
    creds = creds_from_env_file(path) if path else None
    if creds is None:
        # Only a password stored for THIS host. The shared default / $POD_PASSWORD fallbacks are
        # never used here: ``host`` is model-controlled, and verifying would send that password to it.
        try:
            from fabric_studio.keychain import get_secret
            pw = get_secret(host)
        except Exception as e:  # keychain unavailable: say so, not the secret
            return {"ok": False, "host": host, "error": f"no login found for {host}: {e}"}
        if not pw and store == "group":
            # The shared login of the host's group: only for a host the person's OWN pod-groups.toml names, so a
            # model-chosen host that matches no pattern never receives a shared password.
            from fabric_studio.keychain import get_secret as _get
            from fabric_studio.keychain import pod_group_account
            account = pod_group_account(host)
            if not account:
                return {"ok": False, "host": host, "error": f"{host} matches no group in ~/.fsh/pod-groups.toml"}
            pw = _get(account)
            if not pw:
                return {"ok": False, "host": host, "error": f"no password stored for the group login {account!r}"}
        if not pw:
            return {"ok": False, "host": host, "error": f"no login stored for {host}: pass an env_file "
                    "that names it, or store its password in the keychain under that host"}
        creds = (user or "admin", pw)
    login_user = user or creds[0]
    result: dict[str, Any] = {"ok": True, "host": host, "user": login_user, "store": store,
                              "env_file": str(path) if path else None, "dry_run": dry_run}
    if verify:
        try:
            if connect is None:
                from fabric_studio.admin import FabricStudioClient

                def connect(h: str, u: str, p: str) -> Any:
                    # A cached session cookie is accepted for the username alone, so a wrong
                    # password would "verify" off someone else's session. Check the password.
                    prev = os.environ.get("FSH_NO_SESSION_CACHE")
                    os.environ["FSH_NO_SESSION_CACHE"] = "1"
                    try:
                        return FabricStudioClient(h, u, p, timeout_s=15)
                    finally:
                        if prev is None:
                            os.environ.pop("FSH_NO_SESSION_CACHE", None)
                        else:
                            os.environ["FSH_NO_SESSION_CACHE"] = prev
            client = connect(host, login_user, creds[1])
            from fabric_studio import admin as fs_admin
            result["hostname"] = fs_admin.get_pod_hostname(client)
            result["verified"] = True
        except Exception as e:
            return {"ok": False, "host": host, "error": f"login to {host} failed: {type(e).__name__}: {e}"}
    if dry_run:
        return result
    entry = {"name": name or (load_registry().get(host) or {}).get("name") or host.split(".")[0],
             "user": login_user, "tags": sorted(set(tags or (load_registry().get(host) or {}).get("tags") or [])),
             "added_at": (load_registry().get(host) or {}).get("added_at") or time.strftime("%Y-%m-%dT%H:%M:%S%z")}
    if store == "keychain":
        try:
            if set_secret is None:
                from fabric_studio.keychain import set_secret as _set
                set_secret = _set
            set_secret(host, creds[1])
        except Exception as e:
            return {"ok": False, "host": host, "error": f"the keychain refused the password ({e}); "
                                                        "use store='env_file' instead"}
    elif store == "group":
        pass   # nothing stored: the login is resolved through the group at use time
    elif path:
        entry["env_file"] = str(path)
    else:
        return {"ok": False, "host": host, "error": "store='env_file' needs an env_file"}
    inst = load_registry()
    inst[host] = entry
    _save_registry(inst)
    result["registered"] = entry["name"]
    return result


def unregister(host: str, *, forget_secret: bool = False) -> dict[str, Any]:
    inst = load_registry()
    if host not in inst:
        return {"ok": False, "error": f"{host} is not a registered instance"}
    del inst[host]
    _save_registry(inst)
    out: dict[str, Any] = {"ok": True, "host": host}
    if forget_secret:
        try:
            from fabric_studio.keychain import delete_secret
            out["keychain_removed"] = delete_secret(host)
        except Exception:
            out["keychain_removed"] = False
    return out


def instances_status(rows: list[dict[str, Any]], registry: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    """Mark each discovered host with whether it is registered."""
    out = []
    for r in rows:
        e = registry.get(r["host"])
        out.append({**r, "registered": bool(e), "name": (e or {}).get("name")})
    for host, e in registry.items():
        if not any(r["host"] == host for r in rows):
            out.append({"host": host, "sources": [{"kind": "registry"}], "user": e.get("user"),
                        "has_password": True, "registered": True, "name": e.get("name")})
    return sorted(out, key=lambda r: r["host"])


def lockouts() -> dict[str, list[dict[str, Any]]]:
    """Engaged mutation kill-switches by pod host (read only; the files are written by
    ``fs_topology lockout``). ``fabric`` is ``*`` when the whole pod is frozen. A pod is also
    reported when ``$FSH_LOCKOUT`` (``<host>:<fabric>``) names it."""
    out: dict[str, list[dict[str, Any]]] = {}
    d = Path.home() / ".fsh" / "lockouts"
    for f in sorted(d.glob("*.lockout")) if d.is_dir() else []:
        try:
            info = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        host, fabric = info.get("pod_host"), info.get("fabric")
        if host and fabric:
            out.setdefault(host, []).append({
                "fabric": fabric, "reason": info.get("reason") or "", "by": info.get("by"),
                "since": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(float(info.get("created") or 0)))})
    env = os.environ.get("FSH_LOCKOUT", "")
    if ":" in env:
        host, _, fabric = env.rpartition(":")
        out.setdefault(host, []).append({"fabric": fabric, "reason": "FSH_LOCKOUT in the environment",
                                         "by": None, "since": None})
    return out


def is_locked(locks: list[dict[str, Any]] | None, fabric: str | None = None) -> bool:
    """Whether ``fabric`` (or, with ``None``, the whole pod) is covered by ``locks``."""
    return any(lk["fabric"] == "*" or (fabric is not None and lk["fabric"] == fabric) for lk in locks or [])


def engage_lockout(host: str, fabric: str, reason: str) -> dict[str, Any]:
    """Freeze apply/provision/services/destroy for ``fabric`` (``*`` = every fabric) on
    ``host``. Same file ``fs_topology lockout on`` writes. Refuses to overwrite an existing
    one and never lifts one."""
    if not reason.strip():
        return {"ok": False, "error": "a reason is required (the next person reads it)"}
    if not HOST_OK.match(host) or not fabric or "/" in fabric:
        return {"ok": False, "error": "bad host or fabric"}
    d = Path.home() / ".fsh" / "lockouts"
    d.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9_.-]", "_", f"{host}:{fabric}")
    path = d / f"{safe}.lockout"
    payload = {"pod_host": host, "fabric": fabric, "reason": reason.strip(),
               "by": os.environ.get("USER") or os.environ.get("LOGNAME"),
               "pid": os.getpid(), "created": time.time()}
    try:
        with open(path, "x", encoding="utf-8") as fh:
            json.dump(payload, fh)
    except FileExistsError:
        return {"ok": False, "error": f"{fabric!r} on {host} is already locked out",
                "lockout": lockouts().get(host)}
    return {"ok": True, "host": host, "fabric": fabric, "path": str(path),
            "lift": f"fs_topology.py --host {host} lockout off {fabric}  (needs the owner's go-ahead)"}
