"""The ``fabric-studio-mcp`` program. It only decides what to start: the MCP server (which imports the whole ``mcp``
package, over a second) is loaded for no arguments, and the pod commands (setup, pods, remove, connect) never pay for it."""
from __future__ import annotations

import sys


def main() -> None:
    # No arguments: the MCP server, which is how an agent starts it. A command name: set up, inspect or connect.
    if len(sys.argv) > 1:
        from fabric_studio.mcp import cli
        raise SystemExit(cli.main(sys.argv[1:]))
    from fabric_studio.mcp import server
    server.main()
