"""The Fabric Studio agent skill, as ``fabric-studio-mcp connect`` installs it.

The skill is two files (SKILL.md and api-index.md). Claude Code, Codex and opencode read a skill from a folder named
for it, so installing is a copy. FortiAgent imports a skill in the app: there is no folder to write.
"""
from __future__ import annotations

import shutil
from collections.abc import Mapping
from pathlib import Path

NAME = "fabric-studio"
FILES = ("SKILL.md", "api-index.md")


def source() -> Path | None:
    """The folder holding the skill: the copy the wheel carries, else the checkout's skills/ folder."""
    pkg = Path(__file__).resolve().parent.parent   # .../fabric_studio
    for p in (pkg / "_skill", pkg.parent.parent / "skills" / NAME):
        if (p / "SKILL.md").is_file():
            return p
    return None


def folder(agent: str, env: Mapping[str, str], home: Path) -> Path | None:
    """Where the agent reads this skill from, or None when it has no such folder (FortiAgent imports it in the app).

    Claude Code and Codex are verified against the programs; opencode's path is from its documentation, and it also
    reads Claude Code's folder."""
    if agent == "claude":
        return Path(env.get("CLAUDE_CONFIG_DIR") or home / ".claude") / "skills" / NAME
    if agent == "codex":
        return Path(env.get("CODEX_HOME") or home / ".codex") / "skills" / NAME
    if agent == "opencode":
        return home / ".config" / "opencode" / "skills" / NAME
    return None


def state(src: Path, dst: Path) -> str:
    """'missing' (not installed), 'current' (same files as ``src``) or 'different' (installed, but not these files)."""
    if not (dst / "SKILL.md").is_file():
        return "missing"
    same = all((dst / n).is_file() and (dst / n).read_bytes() == (src / n).read_bytes() for n in FILES)
    return "current" if same else "different"


def install(src: Path, dst: Path) -> None:
    dst.mkdir(parents=True, exist_ok=True)
    for n in FILES:
        shutil.copyfile(src / n, dst / n)
