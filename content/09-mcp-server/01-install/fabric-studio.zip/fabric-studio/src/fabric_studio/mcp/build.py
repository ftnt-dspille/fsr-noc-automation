"""The ``build`` tool: make a fabric on a pod from a topology (an intent file).

One tool with an action, not a tool per step: ``topologies`` lists what can be built, ``examples`` shows how
the existing topologies do a thing, ``validate`` checks one
with no pod, ``plan`` shows what applying it would change, ``apply`` builds it, ``status`` follows the build.
The apply runs detached (an install takes minutes) and records its progress under ``~/.fsh/mcp-runs``.

The topology and variables are model-controlled, so a topology resolves only to a bundled intent or one under
a workspace folder, variable values are plain tokens, and the pod login reaches the build process through its
environment only, never its arguments or the run record.
"""
from __future__ import annotations

import importlib.resources
import json
import os
import re
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Any

from mcp.server.mcpserver.exceptions import ToolError

from fabric_studio import admin as fs_admin
from fabric_studio._platform import detached_popen_kwargs, pid_alive
from fabric_studio.mcp import instances as inst
from fabric_studio.mcp.server import (
    _LONG_TOOL_DEADLINE_S,
    _client,
    _known_host,
    _login,
    _refuse_if_locked,
    _tool,
)
from fabric_studio.topology import images as topo_images
from fabric_studio.topology import run as topo

ACTIONS = ("topologies", "examples", "validate", "plan", "apply", "status")
VAR_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,63}$")
# intents expand ``${...}`` (including ``${file:...}``), so a value is a plain token and never a reference
FABRIC_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")
VAR_VALUE = re.compile(r"^[A-Za-z0-9_.:/@+ -]{0,200}$")
RUN_ID = re.compile(r"^[0-9]{8}-[0-9]{6}-[0-9a-f]{4}$")
TOPOLOGY_NAME = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_./-]{0,120}$")


def _runs_dir() -> Path:
    return inst.registry_path().parent / "mcp-runs"


def _bundled_root() -> Path:
    return Path(str(importlib.resources.files("fabric_studio.topologies")))


def _roots() -> list[tuple[str, Path]]:
    """Where an intent may come from: the bundled starters, then each workspace's ``topologies`` and
    ``examples/fabrics`` folders."""
    roots = [("bundled", _bundled_root())]
    for ws in inst.workspace_dirs():
        roots += [("workspace", ws / "topologies"), ("workspace", ws / "examples" / "fabrics")]
    return [(src, r) for src, r in roots if r.is_dir()]


def _intents() -> list[tuple[str, Path]]:
    out = []
    for src, root in _roots():
        out += [(src, p) for p in sorted(root.glob("*/intent.yaml"))]
    return out


def _resolve_topology(topology: str | None) -> Path:
    """The ``intent.yaml`` for a topology name. Anything that is not the name of a listed topology is refused."""
    if not topology or not TOPOLOGY_NAME.fullmatch(topology) or ".." in topology.split("/"):
        raise ToolError("topology must be the name of a topology that action=topologies lists")
    name = topology.rstrip("/").split("/")[-1]
    for _, path in _intents():
        if path.parent.name == name:
            return path.resolve()
    known = ", ".join(sorted({p.parent.name for _, p in _intents()})) or "none"
    raise ToolError(f"no topology {topology!r}; action=topologies lists them (have: {known})")


def _check_variables(variables: dict[str, Any] | None) -> dict[str, str]:
    out: dict[str, str] = {}
    for k, v in (variables or {}).items():
        sv = str(v)
        if not VAR_NAME.fullmatch(str(k)):
            raise ToolError(f"bad variable name {k!r}")
        if not VAR_VALUE.fullmatch(sv) or "${" in sv or ".." in sv:
            raise ToolError(f"bad value for variable {k!r}: use plain text (letters, digits and . _ : / @ + - space)")
        if k == "fabric_name" and not FABRIC_NAME.fullmatch(sv):
            raise ToolError("bad fabric_name: start with a letter or digit, then letters, digits . _ - (max 64)")
        out[str(k)] = sv
    return out


def _listing() -> list[dict[str, Any]]:
    import yaml
    rows = []
    for source, path in _intents():
        try:
            doc = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        defaults = {k: str((v or {}).get("default", "")) for k, v in (doc.get("variables") or {}).items() if isinstance(v, dict)}
        fabric = re.sub(r"\$\{var\.(\w+)\}", lambda m, d=defaults: d.get(m.group(1), m.group(0)), str(doc.get("fabric") or ""))
        rows.append({
            "name": path.parent.name, "source": source, "fabric": fabric or None,
            "description": str(doc.get("description") or "")[:200],
            "devices": sorted({str(n.get("type")) for n in doc.get("nodes") or [] if isinstance(n, dict)}),
            "variables": {k: {"default": (v or {}).get("default"), "description": (v or {}).get("description")}
                          for k, v in (doc.get("variables") or {}).items() if isinstance(v, dict)}})
    return rows


def _validate(path: Path, variables: dict[str, str]) -> dict[str, Any]:
    try:
        intent = topo.load(str(path), variables=variables)
    except Exception as e:
        return {"ok": False, "topology": path.parent.name, "errors": [f"{type(e).__name__}: {e}"], "warnings": []}
    errors, warnings = topo.lint(intent)
    return {"ok": not errors, "topology": path.parent.name, **topo.shape(intent), "errors": errors,
            "warnings": warnings}


def _plan(host: str, path: Path, variables: dict[str, str], prune: bool) -> dict[str, Any]:
    if not _known_host(host):
        raise ToolError(f"{host!r} is not a managed instance: register it with add_instance first")
    c = _client(host)
    try:
        intent = topo.load(str(path), host=host, variables=variables)
        plan = topo.rec.plan(c, intent, prune=prune)
    except (fs_admin.FabricStudioAdminError, ValueError, FileNotFoundError) as e:
        return {"ok": False, "host": host, "topology": path.parent.name, "error": str(e)}
    running = (fs_admin.get_running_fabric(c) or {}).get("name")
    summary = topo.summarise(plan)
    firmware, fw_errors = topo.check_firmware(c, intent)
    if intent.images and topo_images._builder() is None:
        # uploading or building firmware lives in the terraform checkout: without it apply stops at the images phase
        fw_errors = [*fw_errors, f"this topology uploads images ({', '.join(im.name for im in intent.images)}) and "
                     "this server has no image builder (the fabric_studio_terraform checkout). Upload the firmware to "
                     "the pod first and name it in image:, or run the apply from that checkout (make apply)."]
    if fw_errors:
        summary["errors"] = summary["errors"] + fw_errors
        summary["blocked"] = True
    return {"ok": True, "host": host, "topology": path.parent.name, "fabric": intent.fabric, "prune": prune,
            **summary, "firmware": firmware, "would_stop": running if running and running != intent.fabric else None,
            **_lock_state(host, intent.fabric)}


def _lock_state(host: str, fabric: str) -> dict[str, Any]:
    """Whether a lockout covers this fabric, and the owner's own words for it: the person needs who and why."""
    locks = [lk for lk in inst.lockouts().get(host, []) if lk["fabric"] in ("*", fabric)]
    if not locks:
        return {"locked": False}
    return {"locked": True,
            "lockout": [{"fabric": lk["fabric"], "reason": lk.get("reason"), "by": lk.get("by"),
                         "since": lk.get("since")} for lk in locks],
            "lockout_note": "apply is refused while this lockout holds. Only the person who set it may lift it; "
                            "tell the user who set it and why, and do not try to lift or work around it."}


def _run_paths(run_id: str) -> tuple[Path, Path, Path]:
    d = _runs_dir()
    return d / f"{run_id}.json", d / f"{run_id}.log", d / f"{run_id}.rc"


def _alive(pid: int) -> bool:
    return pid_alive(pid)


def _start(host: str, path: Path, variables: dict[str, str], prune: bool, preview: dict[str, Any]) -> dict[str, Any]:
    runs = _runs_dir()
    runs.mkdir(parents=True, exist_ok=True)
    for meta in runs.glob("*.json"):
        m = json.loads(meta.read_text(encoding="utf-8"))
        if m.get("host") == host and not _run_paths(m["run_id"])[2].exists() and _alive(m["pid"]):
            return {**preview, "started": False, "error": f"run {m['run_id']} is still going on this pod"}
    run_id = time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4]
    meta_p, log_p, rc_p = _run_paths(run_id)
    user, password = _login(host)
    env = os.environ.copy()
    # PYTHONUTF8: the log is redirected output, which Windows would otherwise encode as cp1252 (no "✓")
    env.update(FS_POD_HOST=host, FS_POD_USER=user, FS_POD_PASS=password, PYTHONUTF8="1")
    cmd = [sys.executable, "-m", "fabric_studio.topology.run", "apply", str(path), "--host", host,
           *(["--prune"] if prune else []), *[a for k, v in variables.items() for a in ("--var", f"{k}={v}")]]
    # the runner records the exit code, so the end of the run is knowable after the server restarts
    runner = [sys.executable, "-m", "fabric_studio.mcp._runner", str(rc_p), *cmd]
    with open(log_p, "wb") as log:
        proc = subprocess.Popen(runner, env=env, stdin=subprocess.DEVNULL, stdout=log,
                                stderr=subprocess.STDOUT, **detached_popen_kwargs())
    meta_p.write_text(json.dumps({"run_id": run_id, "pid": proc.pid, "host": host, "fabric": preview.get("fabric"),
                                  "topology": path.parent.name, "variables": variables,
                                  "started": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "log": str(log_p)}, indent=2), encoding="utf-8")
    return {"started": True, "run_id": run_id, "host": host, "fabric": preview.get("fabric"),
            "would_stop": preview.get("would_stop"),
            "next": "call build with action=status and this run_id to follow it; the tasks tool shows the installs"}


def _status(run_id: str | None, tail_lines: int) -> dict[str, Any]:
    runs = _runs_dir()
    runs.mkdir(parents=True, exist_ok=True)
    if not run_id:
        rows = []
        for meta in sorted(runs.glob("*.json"), reverse=True)[:10]:
            m = json.loads(meta.read_text(encoding="utf-8"))
            rows.append({"run_id": m["run_id"], "fabric": m["fabric"], "host": m["host"], "started": m["started"],
                         "state": "finished" if _run_paths(m["run_id"])[2].exists()
                         else ("running" if _alive(m["pid"]) else "lost")})
        return {"runs": rows}
    if not RUN_ID.fullmatch(run_id):
        raise ToolError(f"bad run_id {run_id!r}")
    meta_p, log_p, rc_p = _run_paths(run_id)
    if not meta_p.exists():
        raise ToolError(f"no run {run_id!r}")
    m = json.loads(meta_p.read_text(encoding="utf-8"))
    text = log_p.read_text(encoding="utf-8", errors="replace") if log_p.exists() else ""
    if rc_p.exists():
        rc, state = int(rc_p.read_text(encoding="utf-8").strip() or -1), "finished"
    else:
        rc, state = None, ("running" if _alive(m["pid"]) else "lost")
    tail = text.splitlines()[-max(1, min(tail_lines, 200)):]
    converged = topo.CONVERGED in text
    running_for = int(time.time() - meta_p.stat().st_mtime)
    hint = None
    if state == "running":
        hint = (f"running for {running_for // 60} min. "
                + ("The log stays empty for the first minute or two while the plan is read from the pod; that "
                   "is normal. " if not tail or not "".join(tail).strip() else "")
                + "Adding a node to a running fabric usually takes 5-20 minutes, a fresh fabric 15-40, a "
                  "FortiSOAR build hours. Check again in a few minutes; do not start another apply.")
    return {"run_id": run_id, "state": state, "exit_code": rc, "succeeded": rc == 0 and converged,
            "converged": converged, "fabric": m["fabric"], "host": m["host"], "started": m["started"],
            **({"progress": hint} if hint else {}),
            "log_tail": [ln[:300] for ln in tail],
            **({"next": "if it failed, call diagnose on this pod and fabric; it names what is wrong"}
               if state != "running" and not (rc == 0 and converged) else {})}


def _build(action: str, host: str | None, topology: str | None, variables: dict[str, Any] | None, prune: bool,
           run_id: str | None, tail_lines: int, pattern: str | None, confirm: bool) -> dict[str, Any]:
    """What ``build`` and ``build_plan`` share: every action, with ``apply`` only reached through ``build``."""
    if action not in ACTIONS:
        raise ToolError(f"action must be one of {', '.join(ACTIONS)}")
    if action == "topologies":
        return {"topologies": _listing()}
    if action == "examples":
        from fabric_studio.mcp.examples import examples
        return examples(_intents(), pattern)
    if action == "status":
        return _status(run_id, tail_lines)
    path = _resolve_topology(topology)
    values = _check_variables(variables)
    if action == "validate":
        return _validate(path, values)
    if not host:
        raise ToolError(f"{action} needs host (a managed instance; the pods tool lists them)")
    from fabric_studio.mcp.device import _pod_host
    host = _pod_host(host)
    preview = _plan(host, path, values, prune)
    if action == "plan":
        return preview
    # apply
    if not preview["ok"] or preview.get("blocked"):
        return {**preview, "started": False, "error": preview.get("error") or "the plan is blocked; fix it first"}
    _refuse_if_locked(host)
    if not preview["has_changes"] and not prune:
        return {**preview, "started": False, "noop": True, "reason": "the fabric already matches this topology"}
    if not confirm:
        return {**preview, "started": False, "dry_run": True,
                "note": "re-run with confirm=true to build it; it stops the fabric named in would_stop"}
    return _start(host, path, values, prune, preview)


@_tool(deadline_s=_LONG_TOOL_DEADLINE_S, mutating=True)
def build(action: str, host: str | None = None, topology: str | None = None,
          variables: dict[str, Any] | None = None, prune: bool = False, run_id: str | None = None,
          tail_lines: int = 25, pattern: str | None = None, confirm: bool = False) -> dict[str, Any]:
    """MUTATING (only ``action=apply`` changes anything). Make a fabric on a pod from a topology. To look first, use
    ``build_plan`` (read-only: ``topologies``, ``examples``, ``validate``, ``plan``, ``status``); this tool is for
    ``apply``, though it still answers the others.
    ``action``: ``topologies`` = what can be built (name, devices, variables); ``examples`` = how the existing
    topologies do a thing (no ``pattern``: the patterns, such as ``client_behind_gate`` or ``lxc_key_access``;
    with one: real YAML snippets to copy when writing or editing an intent); ``validate`` = check a topology
    with no pod; ``plan`` = what applying it to ``host`` would create, change, reinstall or delete, plus
    ``would_stop``, the fabric running there now, which applying a different fabric stops; ``apply`` = build
    it; ``status`` = follow a build by ``run_id`` (no ``run_id`` lists recent runs).

    Do it in that order: ``topologies``, ``validate``, ``plan``, then ``apply``. ``variables`` override a
    topology's defaults, for example ``{"fgt_image": "7.4"}`` (firmware by version prefix; left empty, the
    newest usable image on the pod is used). A pod runs ONE fabric at a time, so ``apply`` stops the fabric
    running there now. A changed device is reinstalled, which loses its in-guest state. ``prune=true`` also
    deletes what the topology does not declare in that fabric, such as the ISP Router Fabric Studio seeds into
    every fabric (it blocks later plans as a black hole); ``deletes`` in the plan lists every one, so read it first.

    ``apply`` without ``confirm=true`` only returns the plan. With it the person is asked to approve, then the
    build starts detached and this returns a ``run_id`` at once. ``confirm`` means nothing for the other
    actions. Refused on a locked pod, a blocked plan, or a pod with a build already running. When a build
    fails, call ``diagnose`` for the pod and fabric."""
    return _build(action, host, topology, variables, prune, run_id, tail_lines, pattern, confirm)


READ_ACTIONS = tuple(a for a in ACTIONS if a != "apply")


@_tool(deadline_s=_LONG_TOOL_DEADLINE_S)
def build_plan(action: str = "plan", host: str | None = None, topology: str | None = None,
               variables: dict[str, Any] | None = None, prune: bool = False, run_id: str | None = None,
               tail_lines: int = 25, pattern: str | None = None) -> dict[str, Any]:
    """Read-only. Look at a build before, or while, it happens: nothing here changes a pod or a file.
    ``action``: ``topologies`` = what can be built (name, devices, variables); ``examples`` = how the existing
    topologies do a thing (no ``pattern``: the patterns; with one: YAML snippets to copy); ``validate`` = check a
    topology with no pod; ``plan`` (the default) = what applying it to ``host`` would create, change, reinstall
    or delete, which firmware each device gets, and ``would_stop``, the fabric running there now, which applying
    stops; ``status`` = follow a build by ``run_id`` (no ``run_id`` lists recent runs). Plan first, then ``build``
    with ``action=apply`` to do it. Same arguments as ``build``, so a plan here is the plan ``build`` shows."""
    if action not in READ_ACTIONS:
        raise ToolError(f"build_plan only looks: action must be one of {', '.join(READ_ACTIONS)}; use build to apply")
    return _build(action, host, topology, variables, prune, run_id, tail_lines, pattern, False)
