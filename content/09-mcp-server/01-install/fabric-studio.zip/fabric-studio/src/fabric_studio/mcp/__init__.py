"""MCP server for Fabric Studio pods (install with the ``mcp`` extra)."""
