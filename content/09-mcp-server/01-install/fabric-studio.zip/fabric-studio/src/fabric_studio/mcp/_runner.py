"""Run a command and record its exit code in a file: ``python -m fabric_studio.mcp._runner RC_FILE CMD...``.

The ``build`` tool starts a fabric build detached, and the build can outlive the MCP server. The exit code
file is how the end of a run stays knowable afterwards. This replaces a ``sh -c '...; echo $? > file'``
wrapper, which does not exist on Windows.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        print("usage: _runner RC_FILE CMD [ARG...]", file=sys.stderr)
        return 2
    rc_file, cmd = Path(argv[0]), argv[1:]
    try:
        rc = subprocess.call(cmd)
    except OSError as e:
        print(f"could not start {cmd[0]!r}: {e}", flush=True)
        rc = 127
    rc_file.write_text(f"{rc}\n", encoding="utf-8")
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
