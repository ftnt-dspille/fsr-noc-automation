"""The ``device`` tool: look at and configure what is inside a device of a built fabric.

One tool with an action. Reading (``status``, ``config``) never asks. Changing (``set``, ``delete``) first returns
a plan, a real before/after diff read from the device, and only runs with ``confirm=true``; the result is
read back from the device and says whether it really holds what was asked.

The agent states what it wants, never how: which transport (the API, or the CLI over SSH when the API is not a
way in), which API key, which firmware quirk and which FortiOS spelling are decided in ``fortios`` and
``fortios_cli`` and reported in plain words when something goes wrong; a result says which one it used (``via``). FortiGate only
for now; a FortiManager or FortiAnalyzer is refused by name, not mishandled.
"""
from __future__ import annotations

import re
import time
from typing import Any

from mcp.server.mcpserver.exceptions import ToolError

from fabric_studio import admin as fs_admin
from fabric_studio.mcp import fleet
from fabric_studio.mcp import fortios as fos
from fabric_studio.mcp import fortios_cli as cli
from fabric_studio.mcp.server import _LONG_TOOL_DEADLINE_S, _client, _tool

ACTIONS = ("status", "config", "set", "delete")
# sections where a wrong change can cut the tool's own way in, or the device off from its network
RISKY = {"system/interface": "an interface or its allowed access", "router/static": "a route", "system/global":
         "a global setting such as the admin ports", "system/settings": "the VDOM settings",
         "system/ha": "high availability", "system/dns": "DNS"}
KEY_IS_NUMBER = ("policyid", "id", "seq-num")
# guests Fabric Studio does not set a login on: their login is the image's own, from the firmware's metadata
GENERIC_TYPES = ("LXC", "BASIC", "VYOS", "WINDOWS")
SAFE_USER = re.compile(r"[A-Za-z0-9._][A-Za-z0-9._-]{0,63}")


def _pick(rows: list[dict[str, Any]], device: str, fabric: str | None) -> dict[str, Any]:
    rows = [r for r in rows if fabric is None or r["fabric"] == fabric]
    exact = [r for r in rows if str(r["name"]).lower() == device.lower()] or fleet.match(rows, device)
    if len(exact) > 1 and fabric is None and sum(r["up"] for r in exact) == 1:
        exact = [r for r in exact if r["up"]]  # the same name in a stopped fabric is not the one meant
    if len(exact) != 1:
        names = ", ".join(f"{r['fabric']}/{r['name']}" for r in exact) or "none"
        raise ToolError(f"{len(exact)} devices match {device!r} ({names}); pass fabric to say which one")
    return exact[0]


def _pod_host(host: str) -> str:
    from fabric_studio.mcp.server import _registered_host
    return _registered_host(host)


def mgmt_ip(c: Any, row: dict[str, Any]) -> str:
    """The device's address on its management port, from the fabric's model."""
    ports = fs_admin.get_vm_ports(c, row["fabric_id"], row["id"])
    ip = next((p.get("ipv4addr") for p in ports if p.get("mgmt") and p.get("ipv4addr")), None)
    if not ip:
        raise ToolError(f"{row['name']} has no management address in the fabric's model")
    return str(ip)


def image_login(c: Any, vm: dict[str, Any]) -> tuple[str | None, str | None]:
    """The (user, password) the VM's firmware metadata declares (``json_meta.model.credentials``), else
    (None, None). Metadata can come from a third-party repository, so only a plain user name and a printable
    one-line password are taken."""
    fw = vm.get("firmware")
    fw_id = fw.get("id") if isinstance(fw, dict) else fw
    if fw_id is None:
        return None, None
    try:
        obj = c.get(f"api/v1/system/repository/firmware/{int(fw_id)}?related_fields=json_meta").json().get("object")
    except Exception:
        return None, None
    obj = (obj[0] if obj else {}) if isinstance(obj, list) else (obj or {})
    cred = ((obj.get("json_meta") or {}).get("model") or {}).get("credentials") or {}
    user, password = (cred.get("@login") or None, cred.get("@password") or None) if isinstance(cred, dict) else (None, None)
    if user is not None and not SAFE_USER.fullmatch(str(user)):
        user = None
    if password is not None and ("\n" in str(password) or not str(password).isprintable()):
        password = None
    return user, password


def login_for(c: Any, r: dict[str, Any], vm: dict[str, Any], fab: dict[str, Any]
              ) -> tuple[str, str | None, str, str | None]:
    """(user, password, where it came from, a second password to try) for a device. A password set on the VM
    overrides everything. Fabric Studio writes the fabric's password into an LXC container, so an LXC tries that
    before its image's login; a qcow guest (BASIC, VyOS, Windows) keeps the login baked into its image, which the
    firmware metadata declares, so it tries that first. The user is the image's, else the type's default."""
    vm_type = str(r.get("vm_type") or "").upper()
    user = fleet.DEFAULT_USER.get(str(r.get("vm_type") or ""), "admin")
    m_user, m_pw = image_login(c, vm) if vm_type in GENERIC_TYPES else (None, None)
    user = m_user or user
    fab_pw = fab.get("password") or None
    if vm.get("password"):
        return user, vm["password"], "the VM's password", None
    order = [(fab_pw, "the fabric's password"), (m_pw, "the image's login (firmware metadata)")]
    if vm_type != "LXC":
        order.reverse()
    order = [(p, w) for p, w in order if p]
    if not order:
        return user, None, "the fabric's password", None
    alt = order[1][0] if len(order) > 1 else None
    return user, order[0][0], order[0][1], alt


def resolve(host: str, device: str, fabric: str | None, *, types: tuple[str, ...] | None = None,
            need: tuple[str, ...] = ("SSH",), relay: bool = False) -> tuple[fos.Target, dict[str, Any]]:
    """Resolve a device name on a pod to where and how to reach it, and the row that describes it. The login comes
    from the pod's own record of the device (its password, else the fabric's) and stays inside the Target.
    ``types`` limits which kinds of device are acceptable; ``need`` names the access that must be PUBLIC. With
    ``relay`` a closed access is not refused: the row gets ``relay_ip``, the device's address inside the fabric,
    for a caller that reaches it through the pod instead."""
    host = _pod_host(host)
    c = _client(host)
    # the named fabric, else the running one: walking every fabric's runtime state is slow on a busy pod
    near = fabric or (fs_admin.get_running_fabric(c) or {}).get("name")
    rows = fleet.device_rows(c, near) if near else []
    if not any(str(r["name"]).lower() == device.lower() for r in rows) and fabric is None:
        rows = fleet.device_rows(c)  # not in the running fabric: look everywhere, so the answer can name where it is
    r = _pick(rows, device, fabric)
    if types is not None and r["vm_type"] not in types:
        raise ToolError(f"{r['name']} is a {r['vm_type']}, and the device tool configures FortiGates only. To read "
                        f"something from {r['name']} or run a command on it, use the run tool (command=... over SSH).")
    if not r["up"]:
        raise ToolError(f"{r['name']} is powered off. A pod runs one fabric at a time and {r['fabric']} is not "
                        "the one running; building or starting it brings it up.")
    if not r["ready"] or r["port_idx"] is None:
        raise ToolError(f"{r['name']} is still booting; ask again in a minute")
    modes = {a.get("type"): a.get("mode") for a in fs_admin.list_vm_accesses(c, r["fabric_id"], r["id"])}
    closed = [k for k in need if modes.get(k) != "PUBLIC"]
    if closed and relay:
        r = {**r, "relay_ip": mgmt_ip(c, r)}
    elif closed:   # SSH is the way in that always works; HTTPS only adds the API
        raise ToolError(f"{r['name']}'s {' and '.join(closed)} access is not PUBLIC, so this server cannot reach it. "
                        "Make the device's access public on the pod (set_vm_access_public), then try again.")
    vm = next((v for v in fs_admin.list_fabric_vms(c, r["fabric_id"]) if v.get("id") == r["id"]), {})
    fab = next((f for f in fs_admin.list_fabrics(c) if f.get("id") == r["fabric_id"]), {})
    user, password, source, alt_pw = login_for(c, r, vm, fab)
    if not password:
        raise ToolError(f"Fabric Studio holds no password for {r['name']} and its image declares none, so there is "
                        "nothing to sign in with")
    r = {**r, "login_source": source}
    idx = int(r["port_idx"])
    # generic guests usually log in as root or admin: when the one tried is refused, the other is tried once
    alt = {"root": "admin", "admin": "root"}.get(user) if str(r.get("vm_type") or "").upper() in GENERIC_TYPES else None
    return fos.Target(host=host, name=r["name"], fabric=r["fabric"], user=user,
                      https_port=fs_admin.ACCESS_FORWARD_BASE["HTTPS"] + idx,
                      ssh_port=fs_admin.ACCESS_FORWARD_BASE["SSH"] + idx, password=password, alt_user=alt,
                      alt_password=alt_pw), r


def _target(host: str, device: str, fabric: str | None) -> fos.Target:
    return resolve(host, device, fabric, types=("FGT",))[0]


def _read(t: fos.Target, path: str, vdom: str | None, via: str | None = None, name: Any = None):
    """``(via, why, key, objects)``: from the API, or from the CLI when the API is not a way in. ``via`` pins one,
    because a read-back must use the transport that made the change."""
    why = None
    if via != "cli":
        try:
            key, objs = fos.read_objects(t, path, vdom)
            return "api", None, key, objs
        except fos.RestUnavailable as e:
            if via == "api":
                raise
            why = e.short
    key, objs = cli.read_objects(t, path, vdom, name)
    if key is None and not objs:   # an empty table: the CLI cannot say what names its objects
        key = cli.default_key(path, name)
    return "cli", why, key, objs


def _status(t: fos.Target) -> dict[str, Any]:
    try:
        out: dict[str, Any] = {"device": t.name, "fabric": t.fabric, "via": "api"}
        st = fos.call(t, "ro", "GET", "monitor/system/status")
        res = st.get("results") or {}
        out.update({"version": st.get("version"), "build": st.get("build"), "serial": st.get("serial"),
                    "hostname": res.get("hostname"), "model": res.get("model_name") or res.get("model")})
        for key, path in (("license", "monitor/license/status"), ("ha", "cmdb/system/ha")):
            try:
                data = fos.get(t, path)
                out[key] = _ha(data) if key == "ha" else _license(data)
            except fos.RestUnavailable:
                raise
            except fos.DeviceError as e:
                out[key] = {"error": str(e)}
        return out
    except fos.RestUnavailable as e:
        out = cli.status(t)
        return {**out, "via": "cli", "api": f"not available: {e.short}"}


def _ha(data: Any) -> dict[str, Any]:
    data = data if isinstance(data, dict) else {}
    return {k: data.get(k) for k in ("mode", "group-name", "priority") if data.get(k) is not None}


def _license(data: Any) -> dict[str, Any]:
    """Is it licensed, in plain terms: registered with FortiCare, and until when its support runs."""
    data = data if isinstance(data, dict) else {}
    care = data.get("forticare") or {}
    support = (care.get("support") or {}).get("comprehensive") or (care.get("support") or {}).get("enhanced") or {}
    expires = support.get("expires")
    return {"licensed": care.get("registration_status") == "registered", "support_level": support.get("support_level"),
            "support_expires": time.strftime("%Y-%m-%d", time.gmtime(expires)) if isinstance(expires, (int, float)) else None}


def _config(t: fos.Target, section: str | None, name: Any, vdom: str | None, limit: int) -> dict[str, Any]:
    if not section:
        return {"sections": fos.ALIASES, "note": "pass section as one of these names, or a path such as "
                                                 "system/interface; sensitive values are always hidden"}
    path = fos.section_path(section)
    via, _, key, objs = _read(t, path, vdom, name=name)
    if name is not None:
        obj = fos.find(key, objs, name)
        if obj is None:
            raise ToolError(f"{path} has no object {name!r} on {t.name}"
                            + (f" (it has: {', '.join(str(o.get(key)) for o in objs[:20])})" if key and objs else ""))
        objs = [obj]
    shown = objs[:max(1, min(limit, 200))]
    return {"device": t.name, "section": path, "via": via, "key": key, "count": len(objs), "shown": len(shown),
            "objects": [fos.mask(o) for o in shown]}


def _check_change(action: str, section: str | None, name: Any, values: dict[str, Any] | None) -> str:
    if not section:
        raise ToolError(f"{action} needs section (an alias such as interfaces, or a path such as system/interface)")
    try:
        path = fos.section_path(section)
    except fos.DeviceError as e:
        raise ToolError(str(e)) from None
    if any(path == p or path.startswith(p + "/") for p in fos.PROTECTED):
        raise ToolError(f"{path} holds the accounts this tool signs in with; changing them here could lock it out of "
                        "the device. Use the device's own GUI for administrator accounts.")
    if name is not None and not fos.NAME_RX.fullmatch(str(name)):
        raise ToolError(f"{name!r} is not a usable object name")
    if action == "set":
        if not values:
            raise ToolError("set needs values: the fields to set, for example {\"ip\": \"10.0.2.1 255.255.255.0\"}")
        bad = [f for f in values if not fos.FIELD_RX.fullmatch(str(f))]
        if bad:
            raise ToolError(f"not field names: {bad}. Use FortiOS field names such as allowaccess or ip.")
    return path


def _change(t: fos.Target, action: str, section: str | None, name: Any, values: dict[str, Any] | None,
            vdom: str | None, confirm: bool) -> dict[str, Any]:
    path = _check_change(action, section, name, values)
    via, why, key, objs = _read(t, path, vdom, name=name)
    if key and name is None:
        raise ToolError(f"{path} holds many objects: name says which one (it has: "
                        f"{', '.join(str(o.get(key)) for o in objs[:20]) or 'none yet'})")
    if not key and (name is not None or action == "delete"):
        raise ToolError(f"{path} is a single-object section: omit name, and it cannot be deleted")
    cur = fos.find(key, objs, name)
    want = dict(values or {})
    # the CLI leaves empty fields out of what it shows, so only the API's full object can say a field does not exist;
    # over SSH an invalid field is refused by FortiOS itself, in its own words, when the change runs
    unknown = [f for f in want if cur is not None and via == "api" and f not in cur]
    if unknown:
        raise ToolError(f"{path} has no field {unknown}. Its fields are: {', '.join(sorted(cur))}")
    if action == "delete":
        op, changes = ("delete" if cur is not None else "noop"), []
    elif cur is None:
        op, changes = "create", fos.diff(None, want)
    else:
        changes = fos.diff(cur, want)
        op = "update" if changes else "noop"
    if via == "cli" and op in ("create", "update"):
        cli.validate(t, op, path, key, name, want, cur, vdom)   # FortiOS checks the fields and values; nothing is stored
    warnings = []
    if op != "noop" and path in RISKY:
        warnings.append(f"this changes {RISKY[path]}, which can cut the tool's own access to {t.name}; "
                        "the result is read back, but a lost route or port cannot be undone from here")
    if via == "cli" and op != "noop":
        warnings.append(f"the device's API is not available ({why}), so this goes over SSH as the {t.user} account")
    elif op in ("update", "create", "delete") and not fos.has_key(t, "rw"):
        warnings.append(f"the first change on {t.name} also creates its read-write API user ({fos.LEVELS['rw'][0]})")
    plan = {"device": t.name, "fabric": t.fabric, "section": path, "via": via, "object": name, "op": op, "changes": changes,
            "warnings": warnings, "noop": op == "noop"}
    if op == "delete":
        plan["deletes"] = fos.mask(cur)
    if op == "noop":
        plan["reason"] = "nothing to delete" if action == "delete" else "the device already has these values"
    if not confirm:
        return {"dry_run": True, **plan, "note": "re-run with confirm=true to apply it"}
    # NOTE: deliberately no pod-lockout check (same contract as rawexec.run): a lockout freezes
    # fabric lifecycle and VM power/license changes, not confirmed work on a device.
    if op == "noop":
        return {"executed": False, **plan}
    if via == "cli":
        cli.apply(t, op, path, key, name, want, cur, vdom)
    else:
        where = fos.object_path(path, key, name)
        params = {"vdom": vdom} if vdom else None
        if op == "delete":
            fos.call(t, "rw", "DELETE", where, params)
        else:
            body = {f: fos.wire(f, v, (cur or {}).get(f)) for f, v in want.items()}
            if op == "create":
                body = {key: int(name) if key in KEY_IS_NUMBER and str(name).isdigit() else name, **body} if key else body
                fos.call(t, "rw", "POST", f"cmdb/{path}", params, body)
            else:
                fos.call(t, "rw", "PUT", where, params, body)
    assigned = None
    if op == "create" and key and str(name) == "0":
        # id 0 asks FortiOS for the next free id: the new object is the one that was not there before
        before = {str(o.get(key)) for o in objs}
        new = [o for o in _read(t, path, vdom, via=via)[3] if str(o.get(key)) not in before]
        if len(new) == 1:
            assigned = new[0].get(key)
    if assigned is not None:
        name, plan = assigned, {**plan, "object": assigned, "assigned": f"FortiOS gave the new object {key} {assigned}"}
    after = _read(t, path, vdom, via=via, name=name)[3]
    now = fos.find(key, after, name)
    if op == "delete":
        return {"executed": True, "verified": now is None, **plan,
                **({} if now is None else {"warning": "the object is still there after the delete"})}
    if now is None:
        return {"executed": True, "verified": False, **plan,
                "warning": f"FortiOS accepted the change but {path} has no object {name!r} afterwards"}
    bad = fos.mismatches(now, want)
    secret = fos.unverifiable(want)
    return {"executed": True, "verified": not bad, "mismatches": bad, **plan,
            **({"not_comparable": f"{', '.join(secret)}: the device keeps it encrypted, so it was set but cannot "
                                  "be read back"} if secret else {}),
            **({"warning": "FortiOS accepted the change but does not hold these values as asked"} if bad else {})}


@_tool(deadline_s=_LONG_TOOL_DEADLINE_S, mutating=True)
def device(action: str, host: str, device: str, fabric: str | None = None, section: str | None = None,
           name: str | int | None = None, values: dict[str, Any] | None = None, vdom: str | None = None,
           limit: int = 50, confirm: bool = False) -> dict[str, Any]:
    """MUTATING (only ``set`` and ``delete`` change anything). Look at and configure what is INSIDE a FortiGate of
    a built fabric, by device name. FortiGates only: for any other device (FortiManager, FortiAnalyzer, a Linux
    guest), or for a raw command or API call, use the ``run`` tool. ``action``: ``status`` = firmware, hostname, license and HA mode; ``config`` =
    read a configuration section as structured data (omit ``section`` to list the section names); ``set`` = give
    an object these field values (creates it when ``name`` does not exist); ``delete`` = remove an object.

    ``section`` is an alias (interfaces, routes, policies, addresses, services, dns, ntp, global, ...) or a path
    such as ``system/interface``. ``name`` is the object's name (a policy's id for policies); omit it for a
    single-object section such as ``global`` or ``dns``. ``values`` are FortiOS field names and values:
    ``{"ip": "10.0.2.1 255.255.255.0", "allowaccess": ["https", "ssh"], "status": "up"}``; a list of names is
    sent as a table (``srcaddr``) or as one string (``allowaccess``), and true/false mean enable/disable.
    Passwords, keys and PSKs are never returned.

    ``set`` and ``delete`` without ``confirm=true`` return the plan: the real before/after of each field, read
    from the device. With it the plan is applied and READ BACK:
    ``verified`` says whether the device holds what was asked. Do not read state first, call ``set`` to see the
    plan. Administrator and API-user accounts are refused (they are what this tool signs in with). A pod
    lockout does not block device work — it freezes fabric lifecycle and VM power/license changes; every
    change here still needs the person's approval. The device must be powered on with its SSH access PUBLIC (and HTTPS too, for the API); the tool
    uses the API when the device accepts it and the CLI over SSH when it does not (an unlicensed VM refuses API
    keys), says which it used in ``via``, and tells you in plain words when something blocks it."""
    if action not in ACTIONS:
        raise ToolError(f"action must be one of {', '.join(ACTIONS)}")
    if action in ("set", "delete"):
        _check_change(action, section, name, values)  # a bad request is refused before any pod is touched
    t = _target(host, device, fabric)
    try:
        if action == "status":
            return _status(t)
        if action == "config":
            return _config(t, section, name, vdom, limit)
        return _change(t, action, section, name, values, vdom, confirm)
    except fos.DeviceError as e:
        raise ToolError(fos._scrub(str(e), t)) from None
