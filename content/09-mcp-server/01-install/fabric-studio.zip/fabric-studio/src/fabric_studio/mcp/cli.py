"""Set up and inspect the pods the MCP server manages, from a terminal: ``fabric-studio-mcp setup | pods | remove``.

``setup`` asks for the pod, checks the login, keeps the password in the OS keychain (or, where there is none, in a
private ``~/.fsh/.env.<name>`` file) and registers the pod, so the first question to Claude already finds it. The
password is read with ``getpass``: it is never echoed, never in shell history and never in ``argv``. The MCP
tools still never accept or return a password.
"""
from __future__ import annotations

import argparse
import contextlib
import getpass
import os
import re
import sys
from collections.abc import Callable
from pathlib import Path
from typing import Any

from fabric_studio.mcp import instances

NAME_OK = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")


class _Keychain:
    """The three keychain calls setup needs, in one place so tests can swap them."""

    @staticmethod
    def get(host: str) -> str | None:
        from fabric_studio.keychain import get_secret
        return get_secret(host)

    @staticmethod
    def set(host: str, password: str) -> None:
        from fabric_studio.keychain import set_secret
        set_secret(host, password)

    @staticmethod
    def delete(host: str) -> bool:
        from fabric_studio.keychain import delete_secret
        return delete_secret(host)


def _login_file(name: str) -> Path:
    return Path.home() / ".fsh" / f".env.{name}"


def _write_login_file(path: Path, host: str, user: str, password: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)   # private from the first byte on POSIX
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(f"FS_POD_HOST={host}\nFS_POD_USER={user}\nFS_POD_PASS={password}\n")


def setup(args: argparse.Namespace, *, ask: Callable[[str], str] = input,
          ask_secret: Callable[[str], str] = getpass.getpass, out: Callable[[str], None] = print,
          keychain: Any = _Keychain, register: Callable[..., dict[str, Any]] | None = None) -> int:
    """Register one pod. Returns a process exit code."""
    register = register or instances.register
    host = (args.host or ask("Pod hostname or IP (as in your browser): ")).strip()
    if not host or not instances.HOST_OK.match(host):
        out(f"'{host}' is not a hostname or IP address.")
        return 2
    user = (args.user or ask("Username [admin]: ")).strip() or "admin"
    default_name = host.split(".")[0]
    name = (args.name or ask(f"Name for this pod [{default_name}]: ")).strip() or default_name
    if not NAME_OK.match(name):
        out(f"'{name}' is not a usable name: use letters, digits, '.', '_' and '-'.")
        return 2
    if args.password_stdin:
        password = sys.stdin.readline().rstrip("\r\n")
    elif sys.stdin.isatty() or ask is not input:
        password = ask_secret(f"Password for {user}@{host} (not shown): ")
    else:
        out("There is no terminal to ask for the password on. Run this in a terminal, or pipe it in with --password-stdin.")
        return 2
    if not password:
        out("No password given.")
        return 2

    prior = keychain.get(host)          # restored if the login turns out to be wrong
    try:
        keychain.set(host, password)
        if keychain.get(host) != password:
            raise RuntimeError("the keychain did not keep the password")
        in_keychain = True
    except Exception:
        in_keychain = False             # no usable keychain (a headless Linux box, for example)
    if in_keychain:
        where = "the system keychain"
        result = register(host, user=user, name=name, tags=list(args.tag or []), store="keychain",
                          verify=not args.no_verify)
        if not result.get("ok"):
            _restore(keychain, host, prior)
    else:
        path = _login_file(name)
        _write_login_file(path, host, user, password)
        where = str(path)
        result = register(env_file=str(path), name=name, tags=list(args.tag or []), store="env_file",
                          verify=not args.no_verify)
        if not result.get("ok"):
            with contextlib.suppress(OSError):
                path.unlink()
    if not result.get("ok"):
        out(f"Not registered: {result.get('error')}")
        return 1
    hostname = result.get("hostname")
    out(f"Registered '{name}' ({host}{f', hostname {hostname}' if hostname else ''}) as {user}.")
    out(f"The password is kept in {where}; it is not in the registry.")
    out("Next: connect Claude (see the docs), then ask: List my managed Fabric Studio instances.")
    return 0


def _restore(keychain: Any, host: str, prior: str | None) -> None:
    with contextlib.suppress(Exception):
        if prior is not None:
            keychain.set(host, prior)
        else:
            keychain.delete(host)


def pods(args: argparse.Namespace, *, out: Callable[[str], None] = print) -> int:
    reg = instances.load_registry()
    if not reg:
        out("No pods registered. Run: fabric-studio-mcp setup")
        return 0
    out(f"{'NAME':<16} {'HOST':<32} {'USER':<12} LOGIN")
    for host, e in sorted(reg.items(), key=lambda kv: kv[1].get("name", kv[0])):
        login = e.get("env_file") or "system keychain"
        out(f"{e.get('name', ''):<16} {host:<32} {e.get('user', ''):<12} {login}")
    return 0


def remove(args: argparse.Namespace, *, out: Callable[[str], None] = print,
           ask: Callable[[str], str] = input) -> int:
    reg = instances.load_registry()
    host = next((h for h, e in reg.items() if h == args.pod or e.get("name") == args.pod), None)
    if host is None:
        out(f"'{args.pod}' is not a registered pod. See: fabric-studio-mcp pods")
        return 1
    if not args.yes and ask(f"Stop managing {reg[host].get('name', host)} ({host})? The pod itself is untouched. [y/N] ").strip().lower() != "y":
        out("Left as it was.")
        return 1
    res = instances.unregister(host, forget_secret=not args.keep_password)
    out(f"Removed {host}." + (" Its keychain password was deleted." if res.get("keychain_removed") else ""))
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        prog="fabric-studio-mcp",
        description="Run with no arguments to start the MCP server (Claude does this). The commands below manage pods.")
    sub = ap.add_subparsers(dest="command", required=True)
    s = sub.add_parser("setup", help="add a Fabric Studio pod: asks for its address and login, checks it, remembers it")
    s.add_argument("--host", help="pod hostname or IP (asked if omitted)")
    s.add_argument("--user", help="login name (default admin)")
    s.add_argument("--name", help="a short name for the pod")
    s.add_argument("--tag", action="append", help="a label; repeat for several")
    s.add_argument("--password-stdin", action="store_true", help="read the password from stdin, for scripts")
    s.add_argument("--no-verify", action="store_true", help="skip the login check (not recommended)")
    sub.add_parser("pods", help="list the registered pods")
    r = sub.add_parser("remove", help="stop managing a pod (the pod itself is untouched)")
    r.add_argument("pod", help="its name or host")
    r.add_argument("--yes", action="store_true", help="do not ask")
    r.add_argument("--keep-password", action="store_true", help="leave its password in the keychain")
    return ap


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return {"setup": setup, "pods": pods, "remove": remove}[args.command](args)
