"""Work out what is wrong with a fabric: gather the facts a person would click through, then rank findings.

``gather`` reads the pod (read-only). ``analyse`` is pure: it turns the facts into findings, so every
rule is testable without a pod. Each finding says what is wrong, the evidence, and what to do next."""
from __future__ import annotations

import re
from typing import Any

from fabric_studio import admin as fs_admin
from fabric_studio.admin import FabricStudioClient

SEVERITY = {"error": 0, "warn": 1, "info": 2}

# Extra "deep" checks a build can plug in (the lab repo adds its device-level verify and health phases).
# Each is called as ``check(host=, fabric=, topology=, facts=)`` and returns findings in the shape ``add`` builds.
EXTENSIONS: list[Any] = []

# (regex on a failed task's log, code, what it means, what to do). First match wins.
LOG_PATTERNS: list[tuple[str, str, str, str]] = [
    (r"No license for ([^\n]+)", "license-missing",
     "Fabric Studio has no license to give {0}.",
     "Set `license: none` (eval) on the node, or give it a flex_config / a pooled license that has a free seat."),
    (r"reach remote file code for local file", "firmware-stub",
     "The install points at a 0-byte placeholder firmware row, not a real image.",
     "Pick a firmware whose list_firmwares row is `usable` and `local`, or one that is `remote`."),
    (r"Vm has no parameters|RelatedObjectDoesNotExist", "vm-has-no-parameters",
     "The VM model has no parameters row, so the install cannot read its CPU and memory.",
     "No verified fix: recreate the VM in the fabric (a plan with --prune does this) and reinstall."),
    (r"Can't export when the device is running", "export-while-running",
     "A disk export was attempted on a powered-on device.", "Power the device off, then retry."),
    (r"(?i)no space left|disk quota", "disk-full", "The pod ran out of disk.",
     "Delete unused firmwares or snapshots on the pod."),
]


def _explain(log: str) -> dict[str, str]:
    for pat, code, what, nxt in LOG_PATTERNS:
        m = re.search(pat, log)
        if m:
            return {"code": code, "message": what.format(*m.groups()), "next": nxt}
    last = next((ln.strip() for ln in reversed(log.splitlines()) if ln.strip()), "")
    return {"code": "task-failed", "message": f"The last install task failed: {last[:200]}",
            "next": "Read the full log with task_log; if it names a missing file or service, fix that first."}


def gather(c: FabricStudioClient, host: str, fabric_id: int, fabric_name: str | None,
           lockouts: list[dict[str, Any]], probe: bool = True) -> dict[str, Any]:
    """Everything `analyse` needs about one fabric. Read-only; a failed read becomes a note, not a crash."""
    notes: list[str] = []
    running = fs_admin.get_running_fabric(c)
    firmwares = {f.get("id"): f for f in fs_admin.list_all_firmwares(c)}
    vms = []
    for v in fs_admin.list_fabric_vms(c, fabric_id):
        vid = v["id"]
        rec: dict[str, Any] = {"id": vid, "name": v.get("name"), "vm_type": v.get("vm_type"),
                               "firmware_id": v.get("firmware")}
        fw = firmwares.get(v.get("firmware"))
        rec["firmware"] = None if fw is None else {"status": fw.get("status"), "size": fw.get("size"),
                                                   "path": fw.get("path")}
        rt = fs_admin.get_vm_runtime_state(c, vid)
        rec.update(runtime_exists=rt.get("exists"), task=rt.get("task"), status=rt.get("status") or {})
        try:
            rec["license_mode"] = fs_admin.get_vm_license_mode(c, fabric_id, vid)
            data = c.get(f"api/v1/task/device?device_id={vid}&limit=3&order_by=-created_date").json()
            tasks = []
            for t in data.get("object") or []:
                row = {"id": t.get("id"), "name": t.get("name"), "returncode": t.get("returncode")}
                if row["returncode"] not in (0, None):
                    row["log"] = fs_admin.get_task_log(c, t["id"])[-4000:]
                tasks.append(row)
            rec["tasks"] = tasks
        except Exception as e:
            notes.append(f"{rec['name']}: could not read tasks/license ({type(e).__name__})")
        if probe and rt.get("exists") and (rt.get("status") or {}).get("post_boot_prepared"):
            try:
                rec["access"] = [p for p in fs_admin.probe_vm_accesses(c, fabric_id, vid, host)]
            except Exception as e:
                notes.append(f"{rec['name']}: access probe failed ({type(e).__name__})")
        vms.append(rec)
    return {"host": host, "fabric_id": fabric_id, "fabric": fabric_name,
            "running_fabric_id": (running or {}).get("runtime"), "running_fabric": (running or {}).get("name"),
            "running_tasks": [{"id": t.get("id"), "name": t.get("name")} for t in fs_admin.list_running_tasks(c)],
            "lockouts": lockouts, "vms": vms, "notes": notes}


def analyse(facts: dict[str, Any]) -> dict[str, Any]:
    """Findings ranked error > warn > info, plus a one-line verdict."""
    out: list[dict[str, Any]] = []

    def add(sev: str, code: str, message: str, vm: str | None = None, evidence: Any = None, nxt: str | None = None):
        out.append({"severity": sev, "vm": vm, "code": code, "message": message,
                    **({"evidence": evidence} if evidence is not None else {}), **({"next": nxt} if nxt else {})})

    fab_running = facts["running_fabric_id"] == facts["fabric_id"]
    if facts["lockouts"]:
        add("info", "locked", "Apply, provision and destroy are frozen on this pod (a deliberate lockout).",
            evidence=facts["lockouts"], nxt="Ask the lockout's owner before lifting it; reads still work.")
    if not fab_running:
        other = facts["running_fabric"]
        add("warn", "fabric-not-running",
            f"Fabric {facts['fabric']!r} is not the one running on this pod" + (f" ({other!r} is)." if other else "."),
            nxt="A pod runs one fabric at a time. Applying this fabric stops the other.")
    if facts["running_tasks"]:
        add("info", "task-in-flight", f"{len(facts['running_tasks'])} task(s) are running on the pod.",
            evidence=facts["running_tasks"], nxt="Wait for them before judging a device as broken.")

    for v in facts["vms"]:
        name, st = v["name"], v["status"]
        busy = bool(v.get("task")) or bool(facts["running_tasks"])
        fw = v["firmware"]
        if v["firmware_id"] is not None and fw is None:
            add("error", "firmware-missing", f"Firmware {v['firmware_id']} is not on this pod.", name,
                nxt="list_firmwares shows what exists; point the node at one of those.")
        elif fw is not None:
            if not fw["size"]:
                add("error", "firmware-stub", f"Firmware {v['firmware_id']} is a 0-byte stub; installing it fails (rc 254).",
                    name, evidence=fw, nxt="Choose a firmware that list_firmwares marks usable.")
            elif fw["status"] == "remote":
                add("info", "firmware-remote", f"Firmware {v['firmware_id']} is not downloaded yet; the install fetches it.",
                    name, nxt="The first install is slow and needs the pod's internet access.")
        failed = next((t for t in v.get("tasks", []) if t["returncode"] not in (0, None)), None)
        newest = (v.get("tasks") or [None])[0]
        if failed and newest is failed:  # a later success means the failure is history
            why = _explain(failed.get("log", ""))
            add("error", why["code"], why["message"], name,
                evidence={"task_id": failed["id"], "task": failed["name"], "returncode": failed["returncode"]},
                nxt=why["next"])
        if fab_running:
            if not v["runtime_exists"]:
                add("error", "not-installed", "The VM has no runtime: it was never installed or was destroyed.", name,
                    nxt="Apply the fabric, or install this VM.")
                continue
            if not st.get("powered"):
                add("warn", "powered-off", "The VM is powered off.", name, nxt="Power it on, or reinstall it.")
            elif not st.get("post_boot_prepared"):
                add("info" if busy else "warn", "not-ready",
                    "The VM is on but has not finished booting." + (" An install is running." if busy else ""), name,
                    nxt="Wait; if it stays like this for 10+ minutes, read the VM's last task log.")
            lic = v.get("license_mode") or {}
            if lic.get("mode") not in (None, "NONE") and not lic.get("served") and not st.get("licensed"):
                add("warn", "license-unserved", f"License mode is {lic.get('mode')} but no license was served.", name,
                    nxt="validate_license_match, then check the pool for a free seat of this device type.")
            for p in v.get("access", []):
                if not p.get("ok") and not busy:
                    add("warn", "access-unreachable",
                        f"{p.get('type')} forward is not answering from here: {p.get('detail')}", name,
                        nxt="A fresh guest answers 'Network is unreachable' until it is up; wait, then retry.")
    for n in facts["notes"]:
        add("info", "partial", n)

    return finish(facts, out)


def finish(facts: dict[str, Any], findings: list[dict[str, Any]]) -> dict[str, Any]:
    """Rank findings and give the verdict."""
    # the same cause can be seen twice (the firmware row AND the failed task's log): keep one, with both proofs
    seen: dict[tuple, dict[str, Any]] = {}
    for f in findings:
        key = (f["vm"], f["code"])
        if key in seen:
            if "evidence" in f and "evidence" not in seen[key]:
                seen[key]["evidence"] = f["evidence"]
            elif "evidence" in f:
                seen[key]["also"] = f["evidence"]
            continue
        seen[key] = dict(f)
    out = sorted(seen.values(), key=lambda f: (SEVERITY[f["severity"]], f["vm"] or ""))
    errs = sum(f["severity"] == "error" for f in out)
    warns = sum(f["severity"] == "warn" for f in out)
    verdict = ("problems found" if errs else "needs attention" if warns else "healthy")
    return {"host": facts["host"], "fabric": facts["fabric"], "verdict": verdict,
            "summary": f"{errs} error(s), {warns} warning(s) across {len(facts['vms'])} VM(s)",
            "findings": out}


def deep(facts: dict[str, Any], result: dict[str, Any], topology: str | None) -> dict[str, Any]:
    """Add the plugged-in device-level checks to a result."""
    found = list(result["findings"])
    if not EXTENSIONS:
        found.append({"severity": "info", "vm": None, "code": "deep-unavailable",
                      "message": "This build has no device-level checks to add (verify, health).",
                      "next": "The fabric-building build of the server adds them."})
    for check in EXTENSIONS:
        try:
            found += check(host=facts["host"], fabric=facts["fabric"], topology=topology, facts=facts)
        except Exception as e:
            found.append({"severity": "info", "vm": None, "code": "deep-partial",
                          "message": f"A device-level check could not run: {type(e).__name__}: {e}"})
    return finish(facts, found)
