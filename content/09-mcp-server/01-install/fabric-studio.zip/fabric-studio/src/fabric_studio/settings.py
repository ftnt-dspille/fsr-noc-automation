"""Runtime settings — env-driven, single-user."""
import os
from pathlib import Path

DATA_DIR = Path(os.environ.get("FSH_DATA_DIR", "./data")).resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = DATA_DIR / "state.db"
DB_URL = f"sqlite:///{DB_PATH}"

# Master key for at-rest cred encryption.
# Required in production; for dev a dev-only fallback is used.
MASTER_KEY = os.environ.get("FSH_MASTER_KEY")
if not MASTER_KEY:
    dev_key_path = DATA_DIR / ".dev_master_key"
    if dev_key_path.exists():
        MASTER_KEY = dev_key_path.read_text().strip()
    else:
        from cryptography.fernet import Fernet
        MASTER_KEY = Fernet.generate_key().decode()
        dev_key_path.write_text(MASTER_KEY)
        dev_key_path.chmod(0o600)

DEFAULT_POD_CONCURRENCY = int(os.environ.get("FSH_POD_CONCURRENCY", "6"))
