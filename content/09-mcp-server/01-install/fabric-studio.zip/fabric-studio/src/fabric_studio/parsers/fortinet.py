"""FortiGate / FortiManager / FortiAnalyzer FortiOS CLI parsers.
All three share the same base CLI; per-product specifics live in dedicated modules.
"""
import re
from datetime import datetime

from ._common import int_or_none, parse_kv_lines, strip_ansi

_CONTRACT_EXPIRY_RE = re.compile(
    r"Contract\s+Expiry\s+Date:\s*([A-Za-z]{3}\s+[A-Za-z]{3}\s+\d{1,2}\s+\d{4})",
    re.IGNORECASE,
)


def autoupdate_versions(text: str) -> dict:
    """Parse ``diagnose autoupdate versions`` — extract the AV engine
    Contract Expiry Date and normalize to YYYY-MM-DD.

    FortiOS prints expiry as ``Fri Oct  2 2026``. Multiple sections (AV
    Engine, Virus Definitions, Extended set, etc.) repeat the same date
    — we take the first match. Used by license-valid primitive to support
    optional date-bounded checks (valid_on: YYYY-MM-DD).
    """
    clean = strip_ansi(text or "")
    m = _CONTRACT_EXPIRY_RE.search(clean)
    if not m:
        return {"contract_expiry_date": None, "licensed": False,
                "raw_expiry": None}
    raw = m.group(1)
    try:
        # "Fri Oct  2 2026" — double-space between month and single-digit day
        dt = datetime.strptime(re.sub(r"\s+", " ", raw), "%a %b %d %Y")
        iso = dt.strftime("%Y-%m-%d")
    except ValueError:
        iso = None
    return {"contract_expiry_date": iso, "licensed": iso is not None,
            "raw_expiry": raw}


def system_status(text: str) -> dict:
    """Parse `get system status` (FortiGate / FortiManager / FortiAnalyzer share this command).

    Sample:
        Hostname: FGT-Branch1
        Version: FortiGate-VM64-KVM v7.4.5,build2731
        Serial-Number: FGVMSLTM00000001
        License Status: Valid
        ...
    """
    text = strip_ansi(text)
    raw = parse_kv_lines(text)
    return {
        "hostname":       raw.get("hostname"),
        "version":        raw.get("version"),
        "serial_number":  raw.get("serial_number") or raw.get("serial-number") or raw.get("serial"),
        "license_status": raw.get("license_status"),
        "uptime":         raw.get("uptime") or raw.get("system_time"),
        "ha_mode":        raw.get("current_ha_mode") or raw.get("ha_mode"),
        "licensed":       (raw.get("license_status") or "").lower().startswith("valid"),
        "_raw_fields":    raw,
    }


# name=hub_to_branch1 ver=2 serial=1 10.0.0.1:0->10.0.0.2:0 lgwy=static tun=intf mode=auto bound_if=4
# proxyid_num=1 child_num=0 refcnt=2 ilast=12 olast=12 ad=/0
# stat: rxp=12 txp=14 rxb=1456 txb=1632
# dpd: mode=on-demand on=1 idle=20000ms retry=3 count=0 seqno=0
# natt: mode=none draft=0 interval=0 remote_port=0
# proxyid=hub_to_branch1 proto=0 sa=1 ref=2 serial=1
#   src: 0:10.0.0.0/255.255.0.0:0
#   dst: 0:10.1.0.0/255.255.0.0:0
#   SA:  ref=3 options=10227 type=00 soft=0 mtu=1438 expire=42949/0B replaywin=2048
#        seqno=1 esn=0 replaywin_lastseq=00000000 itn=0 qat=0 hash_search_len=1
_TUNNEL_HEADER_RE = re.compile(
    r'name=(?P<name>\S+)\s+ver=\d+\s+serial=\d+\s+'
    r'(?P<local_ep>\S+?)->(?P<remote_ep>\S+?)\s+'
)

# `get vpn ipsec tunnel summary` (FortiOS 7.x) is a totally different
# single-line-per-tunnel format from `diagnose vpn tunnel list`:
#   'tunnel_name' 1.2.3.4:0  selectors(total,up): N/M  rx(pkt,err): A/B  tx(pkt,err): C/D
# Status semantics: a tunnel is up iff at least one selector is up (M > 0).
_TUNNEL_SUMMARY_RE = re.compile(
    # Not anchored to ^ — the line may be prefixed by a FortiOS prompt
    # ("site1-1 # ") when captured from an interactive session.
    r"'(?P<name>[^']+)'\s+(?P<remote_ep>\S+)\s+"
    r"selectors\(total,up\):\s+(?P<selectors_total>\d+)/(?P<selectors_up>\d+)"
    r".*?rx\(pkt,err\):\s+(?P<rxp>\d+)/(?P<rxe>\d+)"
    r".*?tx\(pkt,err\):\s+(?P<txp>\d+)/(?P<txe>\d+)",
)


def ipsec_tunnel_summary(text: str) -> dict:
    """Parse `get vpn ipsec tunnel summary` (or the per-name variant).

    Approach: each tunnel block starts with `name=...`. We extract name + peer + a flag for
    whether `proxyid_num` > 0 and SA appears (proxy-based liveness) OR a tunneled session shows up.
    """
    text = strip_ansi(text)
    tunnels = []
    blocks = re.split(r'(?=^name=)', text, flags=re.MULTILINE)
    for blk in blocks:
        m = _TUNNEL_HEADER_RE.search(blk)
        if not m:
            continue
        name = m.group("name")
        proxy_m = re.search(r'proxyid_num=(\d+)', blk)
        sa_m = re.search(r'^\s*SA:\s', blk, flags=re.MULTILINE)
        rxp_m = re.search(r'rxp=(\d+)\s+txp=(\d+)', blk)
        # Status heuristic: an SA line implies the tunnel has at least one active SA = up.
        # FortiOS variant: `get vpn ipsec tunnel summary` lists `status=up` directly. Capture that too.
        status_m = re.search(r'\bstatus=(up|down)\b', blk)
        if status_m:
            status = status_m.group(1)
        else:
            status = "up" if (sa_m and proxy_m and int(proxy_m.group(1)) > 0) else "down"
        tunnels.append({
            "name": name,
            "status": status,
            "local_endpoint": m.group("local_ep"),
            "remote_endpoint": m.group("remote_ep"),
            "rx_packets": int(rxp_m.group(1)) if rxp_m else None,
            "tx_packets": int(rxp_m.group(2)) if rxp_m else None,
        })
    # Also accept the `get vpn ipsec tunnel summary` one-line format. This
    # is what production checks actually probe (the diagnose form is for
    # deep-dive debugging). Without this branch the parser returned an
    # empty tunnel list against summary output and every tunnel-up check
    # falsely reported "no tunnels".
    seen_names = {t["name"] for t in tunnels}
    for m in _TUNNEL_SUMMARY_RE.finditer(text):
        name = m.group("name")
        if name in seen_names:
            continue
        sel_up = int(m.group("selectors_up"))
        tunnels.append({
            "name":             name,
            "status":           "up" if sel_up > 0 else "down",
            "local_endpoint":   None,
            "remote_endpoint":  m.group("remote_ep"),
            "rx_packets":       int(m.group("rxp")),
            "tx_packets":       int(m.group("txp")),
            "selectors_total":  int(m.group("selectors_total")),
            "selectors_up":     sel_up,
        })
    # Third format: `get vpn ipsec tunnel name <X>` returns a per-tunnel
    # detail block headed by `gateway` with `name: '<X>'` and `status: up|down`
    # on subsequent indented lines. This is what the tpl-fgt-tunnel-named
    # check probes — the other two branches don't match it (no `name=` and
    # no summary row), so without this the parser silently returned 0
    # tunnels and the check falsely reported "no tunnel up".
    for m in re.finditer(
        r"^gateway\s*\n(?P<body>(?:[ \t]+.*\n?)+)",
        text, flags=re.MULTILINE,
    ):
        body = m.group("body")
        nm = re.search(r"^\s+name:\s*'([^']+)'", body, flags=re.MULTILINE)
        if not nm:
            continue
        name = nm.group(1)
        if name in {t["name"] for t in tunnels}:
            continue
        sm = re.search(r"^\s+status:\s*(up|down)\b", body, flags=re.MULTILINE)
        tunnels.append({
            "name": name,
            "status": sm.group(1) if sm else "down",
            "local_endpoint": None,
            "remote_endpoint": None,
            "rx_packets": None,
            "tx_packets": None,
        })
    up = [t for t in tunnels if t["status"] == "up"]
    return {
        "tunnels":  tunnels,
        "count":    len(tunnels),
        "up_count": len(up),
        "any_up":   bool(up),
        "all_up":   bool(tunnels) and all(t["status"] == "up" for t in tunnels),
        "up_names": [t["name"] for t in up],
    }


# Neighbor        V    AS MsgRcvd MsgSent TblVer InQ OutQ Up/Down  State/PfxRcd
# 10.0.0.1        4 65001     452     449       0   0    0 03:21:14         1
_BGP_ROW_RE = re.compile(
    r'^(?P<neighbor>\d+\.\d+\.\d+\.\d+|[0-9a-fA-F:]+)\s+'
    r'(?P<version>\d+)\s+'
    r'(?P<asn>\d+)\s+'
    r'(?P<msg_rcvd>\d+)\s+'
    r'(?P<msg_sent>\d+)\s+'
    r'(?P<tbl_ver>\d+)\s+'
    r'(?P<inq>\d+)\s+'
    r'(?P<outq>\d+)\s+'
    r'(?P<up_down>\S+)\s+'
    r'(?P<state_or_prefixes>\S+)',
    flags=re.MULTILINE,
)


def bgp_summary(text: str) -> dict:
    """Parse `get router info bgp summary` into per-neighbor rows.

    State semantics: when the last column is numeric → BGP is Established and that's the
    number of prefixes received. Otherwise the column holds the textual state (Active, Idle, …).
    """
    text = strip_ansi(text)
    neighbors = []
    for m in _BGP_ROW_RE.finditer(text):
        state_col = m.group("state_or_prefixes")
        established = state_col.isdigit()
        neighbors.append({
            "neighbor":         m.group("neighbor"),
            "as":               int(m.group("asn")),
            "msg_rcvd":         int(m.group("msg_rcvd")),
            "msg_sent":         int(m.group("msg_sent")),
            "up_down":          m.group("up_down"),
            "state":            "Established" if established else state_col,
            "prefixes_rcvd":    int(state_col) if established else None,
            "established":      established,
        })
    return {
        "neighbors":        neighbors,
        "count":            len(neighbors),
        "established":      sum(1 for n in neighbors if n["established"]),
        "not_established":     [n["neighbor"] for n in neighbors if not n["established"]],
        "established_neighbors": [n["neighbor"] for n in neighbors if n["established"]],
        "all_established":     bool(neighbors) and all(n["established"] for n in neighbors),
        "any_established":     any(n["established"] for n in neighbors),
    }


# == [ port1 ]
# name: port1   mode: static    ip: 10.0.0.1 255.255.255.0   status: up    netbios-forward: disable    type: physical    netflow-sampler: disable    sflow-sampler: disable    explicit-web-proxy: disable    explicit-ftp-proxy: disable    proxy-captive-portal: disable    mtu-override: disable    wccp: disable    drop-overlapped-fragment: disable    drop-fragment: disable
_IF_LINE_RE = re.compile(
    r'^name:\s*(?P<name>\S+)\s+mode:\s*(?P<mode>\S+)\s+ip:\s*(?P<ip>\d+\.\d+\.\d+\.\d+)\s+'
    r'(?P<mask>\d+\.\d+\.\d+\.\d+)\s+status:\s*(?P<status>\S+)',
    flags=re.MULTILINE,
)

# FortiOS 7.4+ emits `get system interface physical` as a nested-block form
# (one iface per multi-line block) rather than the single-line `name: … mode:
# … ip: …` of older releases. Capture: the `==[name]` header, then `mode:`
# `ip:` and `status:` lines that follow before the next `==[` header.
_IF_BLOCK_RE = re.compile(
    r'==\[(?P<name>[^\]]+)\]\s*\n'
    r'(?:[^=]*?\bmode:\s*(?P<mode>\S+))?'
    r'(?:[^=]*?\bip:\s*(?P<ip>\d+\.\d+\.\d+\.\d+)\s+(?P<mask>\d+\.\d+\.\d+\.\d+))?'
    r'(?:[^=]*?\bstatus:\s*(?P<status>\S+))?',
    flags=re.DOTALL,
)


# ── Tier-2 SSH-only diag parsers ─────────────────────────────────────────────

def diag_log_device(text: str) -> dict:
    """Parse `diagnose log device` — log forwarding state to FAZ / syslog / FortiCloud.

    Output is service-name-grouped, each block lists status, connection, dest IP, queue depth.

    Returns: {services: [{name, status, ip, conn, queue_full, ...}], any_disconnected, all_ok}.
    """
    text = strip_ansi(text)
    # Shell-side rejection — FortiOS prints "command parse error" when the
    # operator types a command the build doesn't recognize. Don't let the
    # generic key=value scraper below mistake that error chatter
    # (e.g. "Return code = -61") for service config.
    if "command parse error" in text.lower() or "command fail" in text.lower():
        return {"services": [], "count": 0, "any_disconnected": False,
                "disconnected_names": [], "all_ok": False,
                "parse_error": True, "raw_excerpt": text[:200]}
    services: list[dict] = []
    cur: dict | None = None
    # Pattern: leading "name=...." starts a new device, then key=value pairs.
    for line in text.splitlines():
        s = line.strip()
        if not s: continue
        m = re.match(r'^(?:device|name)\s*=\s*(\S+)', s)
        if m:
            if cur: services.append(cur)
            cur = {"name": m.group(1), "status": None, "ip": None,
                   "conn": None, "queue_full": None}
            continue
        if cur is None: continue
        for k, v in re.findall(r'(\w+)\s*=\s*([^\s,]+)', s):
            lk = k.lower()
            if lk == "ip":              cur["ip"] = v
            elif lk in ("conn", "connection", "state"): cur["conn"] = v.lower()
            elif lk == "status":        cur["status"] = v.lower()
            elif lk in ("queue_full", "queue-full"): cur["queue_full"] = v
    if cur: services.append(cur)
    disc = [s for s in services if s.get("conn") in ("disconnected", "down", "0")]
    return {
        "services": services,
        "count": len(services),
        "any_disconnected": bool(disc),
        "disconnected_names": [s["name"] for s in disc],
        "all_ok": bool(services) and not disc,
    }


def diag_fgfmd(text: str) -> dict:
    """Parse `diagnose test application fgfmd <op>` (FGFM tunnel to FortiManager).

    Common operations include `3` (status). Output shape varies by FortiOS version;
    this parser is intentionally tolerant — it captures key=value pairs into a dict
    and surfaces a few well-known fields plus an `up` heuristic.

    Sample:
        FGFM session state: established
        FGFM session number: 1
        Local addr: 10.100.88.8   Remote addr: 10.100.88.10
        FortiManager IP: 10.100.88.10  Connection time: 1234
    """
    text = strip_ansi(text)
    raw = parse_kv_lines(text)
    state = (raw.get("fgfm_session_state") or raw.get("session_state") or "").lower()
    fmg_ip = raw.get("fortimanager_ip") or raw.get("remote_addr")
    up = state in ("established", "ok") or any(
        word in text.lower() for word in ("established", "registered", "connected")
    )
    return {
        "session_state": state or None,
        "fmg_ip":        fmg_ip,
        "established":   state == "established" or up,
        "up":            up,
        "_raw_fields":   raw,
    }


def fortilogd_lograte(text: str) -> dict:
    """Parse `diagnose fortilogd lograte` (FortiAnalyzer log ingestion rate).

    Output is windowed rates, not a ``N logs/sec`` line:

        last 5 seconds: 0.0, last 30 seconds: 0.0, last 60 seconds: 0.1

    ``receiving`` is true when any window is > 0 (logs are actually arriving over
    OFTP). Returns the three windows plus their max so a check can assert on rate.
    """
    text = strip_ansi(text)
    windows: dict[str, float] = {}
    for secs, val in re.findall(r'last\s+(\d+)\s+seconds?\s*:\s*([\d.]+)', text, re.IGNORECASE):
        windows[f"last_{secs}s"] = float(val)
    rates = list(windows.values())
    max_rate = max(rates) if rates else 0.0
    return {
        **windows,
        "max_rate":  max_rate,
        "receiving": max_rate > 0,
    }


def fdsm_central_mgmt(text: str) -> dict:
    """Parse `diagnose fdsm central-mgmt-status` (FGFM tunnel + FMG registration).

    This is the cross-version FGFM status command — `diagnose test application
    fgfmd <op>` and `get system central-management status` both parse-error on
    7.6.x (FortiOS drops the `status` sub-arg), so this is the one probe that
    works on the fabrics we onboard. Sample:

        Connection status: Up
        Registration status: Registered
        Serial: FMGVMSTM25006487
    """
    text = strip_ansi(text)
    # Match anywhere in the line — the first line often carries a shell prompt
    # prefix (``FGVMSLTM... # Connection status: Up``) that breaks naive kv split.
    def _field(label: str) -> str | None:
        m = re.search(rf'{label}\s*:\s*(\S+)', text, re.IGNORECASE)
        return m.group(1) if m else None
    conn = (_field("Connection status") or "").lower()
    reg = (_field("Registration status") or "").lower()
    serial = _field("Serial")
    return {
        "connection_status":   conn or None,
        "registration_status": reg or None,
        "serial":              serial,
        "up":                  conn == "up",
        "registered":          reg == "registered",
        "_raw_fields":         {"connection_status": conn or None,
                                "registration_status": reg or None,
                                "serial": serial},
    }


# IKE gateway list block:
#   vd: root/0
#   name: hub-to-branch1
#   version: 2
#   interface: port1 4
#   addr: 10.100.88.1:500 -> 10.100.88.8:500
#   created: 12s ago
#   peer-id: branch1
#   IKE SA:  created 1/1  established 1/1  ...
_IKE_NAME_RE = re.compile(r'^name:\s*(\S+)', re.MULTILINE)
_IKE_ADDR_RE = re.compile(r'addr:\s*(\S+)\s*->\s*(\S+)')
_IKE_SA_RE   = re.compile(r'IKE SA:\s*created\s*(\d+)/(\d+)\s*established\s*(\d+)/(\d+)')


def diag_ike_gateway_list(text: str) -> dict:
    text = strip_ansi(text)
    gateways: list[dict] = []
    blocks = re.split(r'(?=^name:\s)', text, flags=re.MULTILINE)
    for blk in blocks:
        nm = _IKE_NAME_RE.search(blk)
        if not nm: continue
        addr = _IKE_ADDR_RE.search(blk)
        sa   = _IKE_SA_RE.search(blk)
        established = bool(sa) and int(sa.group(3)) > 0
        gateways.append({
            "name": nm.group(1),
            "local": addr.group(1) if addr else None,
            "remote": addr.group(2) if addr else None,
            "ike_sa_created":     int(sa.group(1)) if sa else 0,
            "ike_sa_established": int(sa.group(3)) if sa else 0,
            "established":        established,
        })
    return {
        "gateways":   gateways,
        "count":      len(gateways),
        "established_count": sum(1 for g in gateways if g["established"]),
        "all_established":   bool(gateways) and all(g["established"] for g in gateways),
        "down_names":        [g["name"] for g in gateways if not g["established"]],
    }


# Tunnel list block (per child SA):
#   list all ipsec tunnel in vd 0
#   name=hub-to-branch1_0 ver=2 serial=1 10.100.88.1:0->10.100.88.8:0 ...
#   ...
#   proxyid=...  proto=0 sa=1 ref=2 serial=1
#     SA: ...
_TUN_NAME_RE = re.compile(r'name=(\S+)\s+ver=\d+', re.MULTILINE)


def diag_ipsec_tunnel_list(text: str) -> dict:
    text = strip_ansi(text)
    tunnels: list[dict] = []
    blocks = re.split(r'(?=^name=)', text, flags=re.MULTILINE)
    for blk in blocks:
        m = _TUN_NAME_RE.search(blk)
        if not m: continue
        name = m.group(1)
        sa   = re.search(r'\bsa=(\d+)\b', blk)
        sa_block = re.search(r'^\s*SA:\s', blk, flags=re.MULTILINE)
        rxp  = re.search(r'rxp=(\d+)\s+txp=(\d+)', blk)
        up = bool(sa_block) and (not sa or int(sa.group(1)) > 0)
        tunnels.append({
            "name": name,
            "sa_count": int(sa.group(1)) if sa else 0,
            "up": up,
            "rx_packets": int(rxp.group(1)) if rxp else None,
            "tx_packets": int(rxp.group(2)) if rxp else None,
        })
    up = [t for t in tunnels if t["up"]]
    return {
        "tunnels": tunnels,
        "count":   len(tunnels),
        "up_count": len(up),
        "all_up":  bool(tunnels) and len(up) == len(tunnels),
        "down_names": [t["name"] for t in tunnels if not t["up"]],
    }


# ── HA cluster status (FortiGate) ─────────────────────────────────────────────
# `get system ha status` shape (FortiOS 7.x):
#   HA Health Status: OK
#   Model: FortiGate-VM64
#   Mode: HA A-P
#   Group Name: cluster-1
#   ...
#   Master: FGT-A, FGVMSLTM00000001, HA cluster index = 0
#   Slave : FGT-B, FGVMSLTM00000002, HA cluster index = 1
#   number of vcluster: 1
#   vcluster 1: work 169.254.0.1
#       Master: FGVMSLTM00000001
#       Slave : FGVMSLTM00000002
_HA_MASTER_RE = re.compile(r'^Master\s*:\s*([^,\s]+),\s*([^,\s]+)', re.MULTILINE)
_HA_SLAVE_RE  = re.compile(r'^Slave\s*:\s*([^,\s]+),\s*([^,\s]+)', re.MULTILINE)


def ha_status(text: str) -> dict:
    """Parse `get system ha status` into mode + members + health flags."""
    text = strip_ansi(text)
    kv = parse_kv_lines(text)
    members: list[dict] = []
    for m in _HA_MASTER_RE.finditer(text):
        members.append({"role": "master", "name": m.group(1), "serial": m.group(2)})
    for m in _HA_SLAVE_RE.finditer(text):
        members.append({"role": "slave", "name": m.group(1), "serial": m.group(2)})
    mode = kv.get("mode") or ""
    standalone = mode.lower().startswith("standalone")
    health_ok = (kv.get("ha_health_status") or "").lower() == "ok"
    return {
        "mode":        mode,
        "standalone":  standalone,
        "health_ok":   health_ok or standalone,
        "members":     members,
        "master":      next((m["serial"] for m in members if m["role"] == "master"), None),
        "member_count": len(members),
        "group_name":  kv.get("group_name") or kv.get("group"),
        "_raw_fields": kv,
    }


# ── OSPF neighbor table ───────────────────────────────────────────────────────
# `get router info ospf neighbor`:
#   OSPF process 0, VRF 0:
#   Neighbor ID     Pri State           Dead Time   Address         Interface
#   10.0.0.1        1   Full/DR         00:00:32    10.100.55.1     port5
#   10.0.0.2        1   2-Way/DROther   00:00:31    10.100.55.2     port5
_OSPF_NEIGH_RE = re.compile(
    r'^(?P<neighbor>\d+\.\d+\.\d+\.\d+)\s+'
    r'(?P<pri>\d+)\s+'
    # State is "Full/DR", "Full/-", or "Full/ -" on p2p links (space before
    # the dash, since the role column is just "-" when there's no DR/BDR
    # election). Capture everything between pri and the dead-time column,
    # non-greedy, then strip trailing whitespace in code.
    r'(?P<state>\S.+?)\s+'
    r'(?P<dead>\d{1,2}:\d{2}:\d{2})\s+'
    r'(?P<address>\d+\.\d+\.\d+\.\d+)\s+'
    r'(?P<iface>\S+)',
    re.MULTILINE,
)


def ospf_neighbor(text: str) -> dict:
    """Parse `get router info ospf neighbor`. Full state is the healthy one."""
    text = strip_ansi(text)
    rows = []
    for m in _OSPF_NEIGH_RE.finditer(text):
        state = m.group("state")
        rows.append({
            "neighbor":  m.group("neighbor"),
            "state":     state,
            "address":   m.group("address"),
            "interface": m.group("iface"),
            "full":      state.startswith("Full"),
        })
    full = [n for n in rows if n["full"]]
    return {
        "neighbors":    rows,
        "count":        len(rows),
        "full_count":   len(full),
        "all_full":     bool(rows) and len(full) == len(rows),
        "not_full":     [n["neighbor"] for n in rows if not n["full"]],
        "by_neighbor":  {n["neighbor"]: n for n in rows},
    }


# ── SSL-VPN sessions ──────────────────────────────────────────────────────────
# `execute vpn sslvpn list` shape varies; the common one:
#   SSL-VPN Login Users:
#   Index   User    Auth Type   Timeout From       HTTP in/out
#   0       alice   1(1)        300     10.0.0.1   0 0
#   1       bob     1(1)        298     10.0.0.2   123 456
# OR `get vpn ssl monitor`:
#   SSL VPN Login Users:
#       Index  User Group  Auth Type  ...
#       0  alice  Allowed
_SSLVPN_ROW_RE = re.compile(r'^\s*(?P<idx>\d+)\s+(?P<user>\S+)\s+', re.MULTILINE)
_SSLVPN_COUNT_RE = re.compile(r'\b(\d+)\s+(?:tunnel|user|connection|session)s?\b', re.IGNORECASE)


def sslvpn_sessions(text: str) -> dict:
    """Best-effort SSL-VPN session count + per-user rows. Tolerant of CLI variants.

    Strategy: match rows only inside the user-list block (between the 'Login Users:'
    header and the next blank line), then fall back to explicit "N tunnels" stat.
    """
    text = strip_ansi(text)
    rows = []
    block_m = re.search(
        r'SSL[- ]VPN\s+Login\s+Users\s*:\s*\n(?P<block>(?:.*\n)*?)(?:\n|\Z)',
        text, re.IGNORECASE,
    )
    block = block_m.group("block") if block_m else ""
    for m in _SSLVPN_ROW_RE.finditer(block):
        user = m.group("user")
        if user.lower() in ("user", "tunnel", "tunnels", "address", "type", "index"):
            continue
        rows.append({"index": int(m.group("idx")), "user": user})
    explicit = _SSLVPN_COUNT_RE.search(text)
    return {
        "sessions":      rows,
        "count":         len(rows),
        "count_text":    int(explicit.group(1)) if explicit else None,
        "users":         [r["user"] for r in rows],
    }


# ── ZTNA EMS connection (FortiClient EMS) ─────────────────────────────────────
# `diagnose endpoint fctems test-connectivity <name>` (7.4+):
#   Server: ems.example.com  Port: 8013
#   Connect status: Connected
# Older `diagnose endpoint fctems-conn`:
#   FCTEMS connection ... status=connected
_ZTNA_CONNECTED_RE = re.compile(r'(?:Connect\s+status|connection\s+status|status)\s*[:=]\s*(?P<state>\w+)', re.I)
_ZTNA_SERVER_RE    = re.compile(r'Server\s*[:=]\s*(?P<server>\S+)', re.I)


def ztna_ems(text: str) -> dict:
    text = strip_ansi(text)
    state_m = _ZTNA_CONNECTED_RE.search(text)
    server_m = _ZTNA_SERVER_RE.search(text)
    state = state_m.group("state").lower() if state_m else ""
    return {
        "state":     state,
        "connected": state in ("connected", "ok", "up"),
        "server":    server_m.group("server") if server_m else None,
    }


# ── Routing-table entry parser ────────────────────────────────────────────────
# Output of `get router info routing-table all`:
#   S*      0.0.0.0/0 [10/0] via 172.16.0.254, port1
#   B       10.0.0.0/8 [200/0] via 10.100.88.10, port4, 00:05:23
#   B       10.0.0.0/8 [200/0] via 10.100.55.10, port5, 00:05:23
#   C       10.100.88.0/24 is directly connected, port1
#   S       192.168.99.0/24 [10/0] via hub_to_branch1 tunnel 10.100.88.1
_RT_PROTO = {"S": "static", "C": "connected", "B": "bgp", "O": "ospf",
             "R": "rip", "I": "isis", "*": "default", "L": "local",
             "D": "eigrp", "H": "hsrp", "i": "ospf-inter"}

_RT_VIA_RE = re.compile(
    r'^(?P<proto>[SCBO*RILDHi]+)\s+'
    r'(?P<prefix>\d+\.\d+\.\d+\.\d+/\d+)\s+'
    r'(?:\[(?P<ad>\d+)/(?P<metric>\d+)\]\s+)?'
    r'(?:via\s+(?P<next_hop>[^,\s]+)(?:,\s+(?P<iface>[^,\s]+))?'
    r'|is\s+directly\s+connected,\s+(?P<conn_iface>[^,\s]+))',
    re.MULTILINE,
)


def routing_table_entry(text: str) -> dict:
    """Parse `get router info routing-table all` (or `... details <prefix>`).

    Returns:
      {
        routes: [{prefix, protocol, next_hop, interface, ad, metric}, ...],
        by_prefix: {"10.0.0.0/8": [route, ...]},
        prefix_count, ecmp_max,
        protocols: {static: N, bgp: M, ...}
      }
    """
    text = strip_ansi(text)
    rows: list[dict] = []
    for m in _RT_VIA_RE.finditer(text):
        proto_raw = m.group("proto").rstrip("*").rstrip()
        proto = _RT_PROTO.get(proto_raw[:1], proto_raw)
        iface = m.group("iface") or m.group("conn_iface")
        rows.append({
            "prefix":    m.group("prefix"),
            "protocol":  proto,
            "next_hop":  m.group("next_hop"),
            "interface": iface,
            "ad":        int_or_none(m.group("ad")),
            "metric":    int_or_none(m.group("metric")),
        })
    by_prefix: dict[str, list] = {}
    for r in rows:
        by_prefix.setdefault(r["prefix"], []).append(r)
    proto_counts: dict[str, int] = {}
    for r in rows:
        proto_counts[r["protocol"]] = proto_counts.get(r["protocol"], 0) + 1
    return {
        "routes":       rows,
        "by_prefix":    by_prefix,
        "prefix_count": len(by_prefix),
        "ecmp_max":     max((len(v) for v in by_prefix.values()), default=0),
        "protocols":    proto_counts,
        # Convenience flags assertions can read directly when a `prefix` param is set:
        "has_default":  any(r["prefix"] == "0.0.0.0/0" for r in rows),
    }


# ── BGP received-routes parser ────────────────────────────────────────────────
# Output of `get router info bgp neighbors X received-routes`:
#   BGP table version is 0, local router ID is 10.100.88.1
#       Network          Next Hop            Metric LocPrf Weight RouteTag Path
#   *>i 10.0.0.0/8       10.100.88.10        0      100         0 0       65010 i
#   *>i 192.168.1.0/24   10.100.88.10        0      100         0 0       65010 ?
#   Total number of prefixes 2
# FortiOS varies: some firmwares print `10.0.0.0/8` with explicit mask, others
# print the network address alone (`192.0.2.0`) when it's classful. Capture
# both — the mask group is optional and we infer it classfully when absent.
# Metric can also be blank (column shown as whitespace) on some firmware.
_BGP_RX_RE = re.compile(
    r'^[\*\s]+[>\s]?\s*[i\s]?\s*'
    r'(?P<prefix>\d+\.\d+\.\d+\.\d+)(?:/(?P<mask>\d+))?\s+'
    r'(?P<next_hop>\d+\.\d+\.\d+\.\d+)\s+'
    r'(?:(?P<metric>\d+)\s+)?(?P<locpref>\d+)\s+(?P<weight>\d+)',
    re.MULTILINE,
)


def _classful_mask(ip: str) -> int:
    """Return the classful default mask length for an IPv4 network address.
    Used as a fallback when FortiOS omits the `/N` suffix in `bgp received-
    routes` output (it does so for any classful-aligned network).
    """
    first = int(ip.split(".", 1)[0])
    if first < 128: return 8     # class A
    if first < 192: return 16    # class B
    if first < 224: return 24    # class C
    return 32                    # D/E — host-route fallback


def bgp_received_routes(text: str) -> dict:
    """Parse received-routes table for a single neighbor.

    Returns: {prefixes:[..], by_prefix:{prefix:{next_hop, metric, ...}}, count}
    """
    text = strip_ansi(text)
    rows = []
    for m in _BGP_RX_RE.finditer(text):
        prefix_ip = m.group("prefix")
        mask = m.group("mask")
        if mask is None:
            mask = str(_classful_mask(prefix_ip))
        prefix = f"{prefix_ip}/{mask}"
        metric_raw = m.group("metric")
        rows.append({
            "prefix":   prefix,
            "next_hop": m.group("next_hop"),
            "metric":   int(metric_raw) if metric_raw else 0,
            "locpref":  int(m.group("locpref")),
            "weight":   int(m.group("weight")),
        })
    # Also pull the explicit "Total number of prefixes N" if present (some 7.4+ output).
    total_m = re.search(r'Total number of prefixes\s+(\d+)', text)
    total = int(total_m.group(1)) if total_m else len(rows)
    return {
        "routes":    rows,
        "prefixes":  [r["prefix"] for r in rows],
        "by_prefix": {r["prefix"]: r for r in rows},
        "count":     total,
    }


# ── SD-WAN health-check parser ────────────────────────────────────────────────
# Output of `diagnose sys sdwan health-check`:
#   Health Check(google):
#   Seq(1 port1): state(alive), packet-loss(0.000%) latency(2.500), jitter(0.100), bandwidth-up(0kbps), bandwidth-dw(0kbps), bandwidth-bi(0kbps), sla_map=0x0
#   Seq(2 port2): state(dead), packet-loss(100.000%) sla_map=0x0
_SDWAN_HC_HEADER_RE = re.compile(r'^Health Check\((?P<name>[^)]+)\):', re.MULTILINE)
_SDWAN_HC_MEMBER_RE = re.compile(
    r'Seq\((?P<seq>\d+)\s+(?P<iface>\S+)\):\s*'
    r'state\((?P<state>\w+)\),\s*'
    r'packet-loss\((?P<loss>[\d.]+)%\)'
    r'(?:\s+latency\((?P<latency>[\d.]+)\))?'
    r'(?:,\s+jitter\((?P<jitter>[\d.]+)\))?',
)


def sdwan_health_check(text: str) -> dict:
    """Parse `diagnose sys sdwan health-check`.

    Returns: {checks: [{name, members:[{seq, iface, state, loss, latency, jitter}]}],
              by_name: {...}, any_dead, all_alive, max_loss, max_latency}
    """
    text = strip_ansi(text)
    checks: list[dict] = []
    # Split into per-check blocks at each "Health Check(...)".
    parts = re.split(r'(?=^Health Check\()', text, flags=re.MULTILINE)
    for blk in parts:
        h = _SDWAN_HC_HEADER_RE.search(blk)
        if not h: continue
        members = []
        for m in _SDWAN_HC_MEMBER_RE.finditer(blk):
            members.append({
                "seq":       int(m.group("seq")),
                "interface": m.group("iface"),
                "state":     m.group("state").lower(),
                "loss":      float(m.group("loss")),
                "latency":   float(m.group("latency")) if m.group("latency") else None,
                "jitter":    float(m.group("jitter")) if m.group("jitter") else None,
            })
        checks.append({"name": h.group("name"), "members": members})
    all_members = [m for c in checks for m in c["members"]]
    return {
        "checks":      checks,
        "by_name":     {c["name"]: c for c in checks},
        "count":       len(checks),
        "any_dead":    any(m["state"] != "alive" for m in all_members),
        "all_alive":   bool(all_members) and all(m["state"] == "alive" for m in all_members),
        "dead_ifaces": [m["interface"] for m in all_members if m["state"] != "alive"],
        "max_loss":    max((m["loss"] for m in all_members), default=0.0),
        "max_latency": max((m["latency"] or 0.0 for m in all_members), default=0.0),
    }


# ── SD-WAN service parser ─────────────────────────────────────────────────────
# Output of `diagnose sys sdwan service`:
#   Service(1): Address Mode(IPV4) flags=0x200 use-shortcut-sla
#     TOS(0x0/0x0)
#     Protocol(0)
#     Service Name: corp-web
#     Members(2):
#       1: Seq_num(1 port1), alive, sla(0x1), gid(0x1), cfg_order(0), local cost(0), selected
#       2: Seq_num(2 port2), alive, sla(0x1), gid(0x1), cfg_order(1), local cost(0)
#   Service(2): ...
_SDWAN_SVC_HEAD_RE = re.compile(r'^Service\((?P<id>\d+)\):', re.MULTILINE)
_SDWAN_SVC_NAME_RE = re.compile(r'Service Name:\s*(\S+)')
_SDWAN_SVC_MEM_RE  = re.compile(
    r'\d+:\s*Seq_num\((?P<seq>\d+)\s+(?P<iface>\S+)\),?\s*'
    r'(?P<state>alive|dead)\b'
    r'(?P<selected>(?:.*?\bselected\b)?)',
)


def sdwan_service(text: str) -> dict:
    """Parse `diagnose sys sdwan service`.

    Returns: {services: [{id, name, members:[{seq, iface, state, selected}]}],
              by_name, any_dead_member, all_have_alive_member}
    """
    text = strip_ansi(text)
    services: list[dict] = []
    parts = re.split(r'(?=^Service\(\d+\):)', text, flags=re.MULTILINE)
    for blk in parts:
        h = _SDWAN_SVC_HEAD_RE.search(blk)
        if not h: continue
        name_m = _SDWAN_SVC_NAME_RE.search(blk)
        name = name_m.group(1) if name_m else f"svc{h.group('id')}"
        members = []
        for m in _SDWAN_SVC_MEM_RE.finditer(blk):
            members.append({
                "seq":       int(m.group("seq")),
                "interface": m.group("iface"),
                "state":     m.group("state").lower(),
                "selected":  "selected" in m.group("selected"),
            })
        services.append({
            "id":           int(h.group("id")),
            "name":         name,
            "members":      members,
            "member_count": len(members),
            "alive_count":  sum(1 for x in members if x["state"] == "alive"),
            "selected":     [x["interface"] for x in members if x["selected"]],
        })
    return {
        "services":      services,
        "by_name":       {s["name"]: s for s in services},
        "count":         len(services),
        "all_have_alive_member": bool(services) and all(s["alive_count"] >= 1 for s in services),
        "any_no_alive_member":   any(s["alive_count"] == 0 for s in services),
    }


def interfaces_physical(text: str) -> dict:
    """Parse `get system interface physical`.

    Returns:
        {
          "interfaces": [{name, mode, ip, mask, status}, …],
          "by_name":    {"port1": {...}, "port2": {...}}
        }
    """
    text = strip_ansi(text)
    rows = []
    for m in _IF_LINE_RE.finditer(text):
        rows.append({
            "name":   m.group("name"),
            "mode":   m.group("mode"),
            "ip":     m.group("ip"),
            "mask":   m.group("mask"),
            "status": m.group("status"),
            "has_ip": m.group("ip") != "0.0.0.0",
        })
    if not rows:
        # Fall back to the 7.4+ nested-block format. Skip the outer
        # `[onboard]` / category headers — only emit entries that have an
        # `==[name]` header followed by mode/ip/status fields.
        for m in _IF_BLOCK_RE.finditer(text):
            name = m.group("name").strip()
            if name in ("onboard",):
                continue
            ip = m.group("ip")
            if not ip:
                # Header-only block (e.g. category divider) — skip.
                continue
            rows.append({
                "name":   name,
                "mode":   m.group("mode"),
                "ip":     ip,
                "mask":   m.group("mask"),
                "status": m.group("status"),
                "has_ip": ip != "0.0.0.0",
            })
    return {
        "interfaces": rows,
        "by_name":    {r["name"]: r for r in rows},
        "count":      len(rows),
        "up_count":   sum(1 for r in rows if r["status"] == "up"),
    }
