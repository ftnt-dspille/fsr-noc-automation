"""FortiManager-specific parsers."""
import re

from ._common import strip_ansi

# Sample:
# --- There are currently 4 devices/vdoms managed ---
# TYPE            OID    SN               HA   IP              NAME
# fmg/faz enabled
# fortigate-7.4   1234   FGVMSLTM00000001 -    10.0.0.1        Branch1
#         ha_slave:    none
#         con_status=1
_DVM_ROW_RE = re.compile(
    r'^(?P<type>\S+)\s+(?P<oid>\d+)\s+(?P<serial>\S+)\s+(?P<ha>\S+)\s+'
    r'(?P<ip>\d+\.\d+\.\d+\.\d+)\s+(?P<name>\S+)',
    flags=re.MULTILINE,
)


def dvm_device_list(text: str) -> dict:
    """Parse `diagnose dvm device list` into per-device rows.

    Captures the registration line plus the per-device `con_status=N` follow-up.
    """
    text = strip_ansi(text)

    # Count summary if present.
    total_m = re.search(r'There (?:is|are) currently (\d+) devices?', text)
    total = int(total_m.group(1)) if total_m else None

    devices = []
    # Iterate row matches, then look ahead in the same block for con_status.
    rows = list(_DVM_ROW_RE.finditer(text))
    for i, m in enumerate(rows):
        block_end = rows[i + 1].start() if i + 1 < len(rows) else len(text)
        block = text[m.start():block_end]
        con_m = re.search(r'con_status\s*=\s*(\d+)', block)
        con = int(con_m.group(1)) if con_m else None
        # The plain `diagnose dvm device list` reports the live connection in
        # the per-device STATUS line as `conn: up|down`, NOT as `con_status=N`
        # (that form only appears in the verbose per-device output). Treat
        # either signal as connected so connected_count is right for both.
        conn_up = re.search(r'\bconn:\s*up\b', block) is not None
        devices.append({
            "name":          m.group("name"),
            "ip":            m.group("ip"),
            "serial":        m.group("serial"),
            "type":          m.group("type"),
            "ha":            m.group("ha"),
            "oid":           int(m.group("oid")),
            "con_status":    con,
            "connected":     con == 1 or conn_up,
        })
    return {
        "devices":              devices,
        "count":                len(devices),
        "summary_count":        total,
        "connected_count":      sum(1 for d in devices if d["connected"]),
        "by_name":              {d["name"]: d for d in devices},
        "by_serial":            {d["serial"]: d for d in devices},
    }
