"""POSIX-style command parsers — usable across FortiOS (FGT/FMG/FAZ/FML)
and Linux (SOAR) since these tools share the same output format.

Currently:
- ``ping`` — works for both BSD/macOS/FortiOS ping and Linux iputils ping.
"""
from __future__ import annotations

import re

from fabric_studio.parsers._common import strip_ansi

_STATS_RE = re.compile(
    r"(\d+)\s+packets\s+transmitted,\s*(\d+)\s+(?:packets\s+)?received"
    r"(?:,\s*\+?\d+\s+errors)?,\s*(\d+(?:\.\d+)?)%\s+packet\s+loss",
    re.IGNORECASE,
)
_PING_HEADER_RE = re.compile(r"^PING\s+(\S+)", re.MULTILINE)


def ping(text: str) -> dict:
    """Parse ping output into {host, packets_tx, packets_rx, loss_pct, reachable}.

    ``reachable`` is True when packets_rx > 0. Returns ``reachable=False`` when
    no stats line is present (host unreachable, dns failure, etc.).
    """
    clean = strip_ansi(text or "")
    host_m = _PING_HEADER_RE.search(clean)
    stats_m = _STATS_RE.search(clean)
    if not stats_m:
        return {
            "host": host_m.group(1) if host_m else "",
            "packets_tx": 0,
            "packets_rx": 0,
            "loss_pct": 100.0,
            "reachable": False,
            "raw_tail": clean[-200:],
        }
    tx, rx, loss = stats_m.groups()
    rx = int(rx)
    return {
        "host": host_m.group(1) if host_m else "",
        "packets_tx": int(tx),
        "packets_rx": rx,
        "loss_pct": float(loss),
        "reachable": rx > 0,
    }
