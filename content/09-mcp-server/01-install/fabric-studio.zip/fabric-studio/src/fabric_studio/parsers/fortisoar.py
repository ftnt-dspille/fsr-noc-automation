"""FortiSOAR (csadm) output parsers."""
import re

from ._common import int_or_none, parse_kv_lines, strip_ansi


def csadm_license_details(text: str) -> dict:
    """Parse `sudo csadm license --show-details` into structured fields.

    Sample input:
        Type           : Evaluation
        Edition        : Multi-tenant
        Role           : Manager
        Total Users    : 2
        Expiry Date    : 2026-12-09
        Remaining Days : 201
        Serial no      : FSRVMPTM25001655
        Device UUID    : f92b6600bd616fa3b967d2ff15d49d29
    """
    raw = parse_kv_lines(strip_ansi(text))
    licensed = (
        "serial_no" in raw and bool(raw["serial_no"]) and
        "license not found" not in text.lower() and
        "not installed" not in text.lower() and
        "invalid license" not in text.lower()
    )
    return {
        "type":           raw.get("type"),
        "edition":        raw.get("edition"),
        "role":           raw.get("role"),
        "total_users":    int_or_none(raw.get("total_users")),
        "remaining_days": int_or_none(raw.get("remaining_days")),
        "expiry_date":    raw.get("expiry_date"),
        "serial_no":      raw.get("serial_no"),
        "device_uuid":    raw.get("device_uuid"),
        "licensed":       licensed,
        "_raw_fields":    raw,
    }


# Matches: rabbitmq-server..........[Running]      since Fri 2026-05-22 20:16:10 UTC
_SVC_LINE_RE = re.compile(
    r'^([\w\-\.]+?)\.{3,}\s*\[([A-Za-z]+)\](?:\s+since\s+(.+?))?$',
    flags=re.MULTILINE,
)


def csadm_services_status(text: str) -> dict:
    """Parse `sudo csadm services --status` into a list of service rows.

    Returns:
        {
          "services":      [{name, status, since}, …],
          "running":       int,
          "not_running":   int,
          "failed_names":  [str, …],
          "any_not_running": bool,
        }
    """
    text = strip_ansi(text)
    services = []
    for m in _SVC_LINE_RE.finditer(text):
        services.append({
            "name": m.group(1),
            "status": m.group(2),
            "since": (m.group(3) or "").strip(),
        })
    running = sum(1 for s in services if s["status"].lower() == "running")
    not_running = [s for s in services if s["status"].lower() != "running"]
    return {
        "services":        services,
        "running":         running,
        "not_running":     len(not_running),
        "failed_names":    [s["name"] for s in not_running],
        "any_not_running": bool(not_running),
        "count":           len(services),
    }
