"""Shared helpers for parsers."""
import re

_ANSI_RE = re.compile(r'\x1b\[[0-9;]*m')


def strip_ansi(s: str) -> str:
    return _ANSI_RE.sub("", s or "")


def parse_kv_lines(text: str) -> dict:
    """Best-effort parse of 'Key : Value' style output. Returns {snake_case_key: value}."""
    out = {}
    for line in text.splitlines():
        m = re.match(r'^\s*([A-Za-z][\w \-/]+?)\s*:\s*(.+?)\s*$', line)
        if not m:
            continue
        key = m.group(1).strip().lower().replace(" ", "_").replace("-", "_").replace("/", "_")
        out[key] = m.group(2).strip()
    return out


def int_or_none(v):
    try:
        return int(v) if v is not None else None
    except (ValueError, TypeError):
        return None
