"""Output parsers: turn raw CLI text into structured dicts the assertion layer can query with json_path.

Templates declare `probe.parser: <name>`. The orchestrator looks up the function in PARSERS,
runs it on the probe's raw text, and substitutes the result for `body` before assertions evaluate.
"""
from collections.abc import Callable

from . import fortimanager, fortinet, fortisoar, posix

PARSERS: dict[str, Callable[[str], dict]] = {
    "posix.ping":                    posix.ping,
    "fortinet.autoupdate_versions":  fortinet.autoupdate_versions,
    "fortinet.system_status":        fortinet.system_status,
    "fortinet.ipsec_tunnel_summary": fortinet.ipsec_tunnel_summary,
    "fortinet.bgp_summary":          fortinet.bgp_summary,
    "fortinet.interfaces_physical":  fortinet.interfaces_physical,
    "fortinet.diag_log_device":      fortinet.diag_log_device,
    "fortinet.diag_fgfmd":           fortinet.diag_fgfmd,
    "fortinet.fdsm_central_mgmt":    fortinet.fdsm_central_mgmt,
    "fortinet.fortilogd_lograte":    fortinet.fortilogd_lograte,
    "fortinet.diag_ike_gateway_list": fortinet.diag_ike_gateway_list,
    "fortinet.diag_ipsec_tunnel_list": fortinet.diag_ipsec_tunnel_list,
    "fortinet.routing_table_entry":  fortinet.routing_table_entry,
    "fortinet.bgp_received_routes":  fortinet.bgp_received_routes,
    "fortinet.sdwan_health_check":   fortinet.sdwan_health_check,
    "fortinet.sdwan_service":        fortinet.sdwan_service,
    "fortinet.ha_status":            fortinet.ha_status,
    "fortinet.ospf_neighbor":        fortinet.ospf_neighbor,
    "fortinet.sslvpn_sessions":      fortinet.sslvpn_sessions,
    "fortinet.ztna_ems":             fortinet.ztna_ems,
    "fortisoar.csadm_license":       fortisoar.csadm_license_details,
    "fortisoar.csadm_services":      fortisoar.csadm_services_status,
    "fortimanager.dvm_device_list":  fortimanager.dvm_device_list,
}


def apply_parser(name: str, text: str) -> dict:
    fn = PARSERS.get(name)
    if not fn:
        raise KeyError(f"unknown parser: {name}")
    return fn(text)
