"""Credential resolution: pods + devices both follow `inline override -> credential set -> none`."""

from sqlmodel import select

from fabric_studio.crypto import decrypt
from fabric_studio.db import get_session
from fabric_studio.models import CredentialSet, Device, DeviceCredential, Pod


def resolve_pod_credentials(pod: Pod) -> tuple[str, str]:
    """Return (username, password) for a pod. Inline non-empty values override the credential set."""
    inline_user = pod.username
    inline_pass = decrypt(pod.password_enc) if pod.password_enc else ""
    if inline_user and inline_pass:
        return inline_user, inline_pass
    if pod.credential_set_id:
        with get_session() as s:
            cs = s.get(CredentialSet, pod.credential_set_id)
            if cs:
                return cs.username, decrypt(cs.password_enc)
    return inline_user or "admin", inline_pass


def resolve_device_credentials(device: Device) -> tuple[str, str] | None:
    """Resolve a device's creds. Returns None if no creds configured anywhere."""
    with get_session() as s:
        inline = s.exec(select(DeviceCredential).where(DeviceCredential.device_id == device.id)).first()
        if inline and inline.password_enc:
            return inline.username, decrypt(inline.password_enc)
        if device.credential_set_id:
            cs = s.get(CredentialSet, device.credential_set_id)
            if cs:
                return cs.username, decrypt(cs.password_enc)
    return None
