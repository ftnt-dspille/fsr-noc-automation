"""SHARED CORE — SQLModel tables shared by both Project A and Project B.

Pod, Device, DeviceCredential, CredentialSet, CredentialProfile are used by
both the health-check app (A) and the topology/builder (B). A-only tables
(Check, Run, Result, etc.) live in ``backend/models.py`` and import from here
so all 11 tables share one SQLModel metadata registry.
"""
from datetime import UTC, datetime
from typing import Any

from sqlmodel import JSON, Column, Field, SQLModel


class CredentialSet(SQLModel, table=True):
    """Reusable named credentials. Devices and pods can either reference a set or carry inline creds."""
    id: int | None = Field(default=None, primary_key=True)
    name: str = Field(index=True, unique=True)
    username: str
    password_enc: str
    # Hint for UI grouping: 'pod', 'FGT', 'FMG', 'FAZ', 'SOAR', 'FML', or 'any'
    kind: str = Field(default="any", index=True)
    description: str = ""
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class CredentialProfile(SQLModel, table=True):
    """A reusable bundle of credentials for one Fabric Studio host + the
    device families inside it. Lets an operator say "this lab uses the
    'corp-shared' profile" and have both the FS admin login and every
    device-family login applied at once.

    `pod_credential_set_id` is the FS host login (used for /api/v1/auth,
    runtime discovery, etc.). `device_creds_json` is a flat mapping of
    vm_type ('FGT', 'FMG', 'FAZ', 'SOAR', 'FML', 'BASIC') to a
    CredentialSet id — applied to every discovered device of that type
    after a pod is added. Missing vm_types mean "no profile-supplied
    credentials for this family"; the device falls back to whatever the
    operator sets per-device.
    """
    id: int | None = Field(default=None, primary_key=True)
    name: str = Field(index=True, unique=True)
    description: str = ""
    pod_credential_set_id: int | None = Field(
        default=None, foreign_key="credentialset.id", index=True,
    )
    device_creds_json: dict[str, int] = Field(
        default_factory=dict, sa_column=Column(JSON),
    )
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class Pod(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    host: str = Field(index=True, unique=True)
    # "fs" (Fabric Studio, default) or "fortipoc" — selects the runtime adapter
    # in pod.runtime_factory. The two systems expose entirely different REST
    # surfaces, so dispatch is per-pod.
    pod_type: str = Field(default="fs", index=True)
    # Inline creds (fallback / override). If credential_set_id is set, that wins unless these are non-empty.
    username: str = "admin"
    password_enc: str = ""
    credential_set_id: int | None = Field(default=None, foreign_key="credentialset.id", index=True)
    # Profile this pod was created from (if any) — back-pointer so the UI
    # can show "30 pods using profile 'corp-shared'" and so a profile
    # rotation could fan changes back out. Pods without a profile keep
    # their own credential_set_id; profile changes never touch them.
    credential_profile_id: int | None = Field(
        default=None, foreign_key="credentialprofile.id", index=True,
    )
    # Fabric Studio fabric.console_password — used by fs-console (con flavor) for serial-console login.
    console_password_enc: str = ""
    # Phase 5 fabric profile: stable hash of (FS version, sorted vm_types,
    # access-policy fingerprint). Pods with the same signature share an
    # entry in `fabric_profile` and inherit the resolver's avenue rankings.
    fabric_signature: str | None = Field(default=None, index=True)
    tags: list[str] = Field(default_factory=list, sa_column=Column(JSON))
    last_synced_at: datetime | None = None
    added_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class Device(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    pod_id: int = Field(foreign_key="pod.id", index=True)
    vm_id: int                         # Fabric Studio VM ID
    name: str
    vm_type: str = Field(index=True)   # FGT / FMG / FAZ / SOAR / FML
    port_idx: int
    mgmt_ip: str | None = None
    public_accesses: list[dict[str, Any]] = Field(default_factory=list, sa_column=Column(JSON))
    # Full accesses list (all modes incl. SERIAL/VNC/SPICE — needed for fs-console gating).
    accesses_all: list[dict[str, Any]] = Field(default_factory=list, sa_column=Column(JSON))
    # Fabric Studio short slug (e.g. "soar01") — used in ttyd URLs /ttyd/{ssh,con}/<nameid>/.
    nameid: str | None = None
    install_state: str | None = None
    license_state: str | None = None
    power_state: str | None = None
    # If set, this credential set is used to talk to this device (unless DeviceCredential overrides).
    credential_set_id: int | None = Field(default=None, foreign_key="credentialset.id", index=True)
    # When True, the runner skips this device entirely — no health checks
    # run against it. Used during onboarding for devices we can't credential
    # yet (so the rest of the fabric still ships) and for known-broken VMs
    # the operator wants out of the dashboard noise. Toggling False later
    # immediately re-enables the device on the next run.
    health_checks_disabled: bool = Field(default=False, index=True)
    # Free-text note explaining why the device is skipped, surfaced in the
    # device card so the next operator knows what to fix before re-enabling.
    skip_reason: str = ""


class DeviceCredential(SQLModel, table=True):
    """Per-device inline credentials (overrides any credential_set reference on Device)."""
    id: int | None = Field(default=None, primary_key=True)
    device_id: int = Field(foreign_key="device.id", index=True, unique=True)
    username: str
    password_enc: str = ""
