"""Fabric Studio tooling: a REST client, the admin API for fabrics and VMs, transports to the devices
behind a pod, output parsers, and an MCP server.

    fabric_studio.client      FabricStudioClient and the per-pod login guard
    fabric_studio.admin       fabrics, VMs, power, firmware, snapshots, licenses, access, networks, tasks
    fabric_studio.resolve     names to ids; a SOAR guest's management address
    fabric_studio.keychain    pod logins from the OS keychain
    fabric_studio.channels    SSH, jump-host and console transports
    fabric_studio.parsers     device CLI output to data
    fabric_studio.pod         pod runtime adapters
    fabric_studio.mcp         the MCP server (install with the ``mcp`` extra)
"""
