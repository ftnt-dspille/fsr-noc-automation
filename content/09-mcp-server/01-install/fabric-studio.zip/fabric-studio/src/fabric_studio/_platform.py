"""The few places Windows and POSIX differ: a cross-process file lock, "is this pid alive", and detaching a child.

Everything else in the package is portable Python. Keep platform checks here, not scattered.
"""
from __future__ import annotations

import errno
import os
import sys
from typing import IO, Any

IS_WINDOWS = sys.platform == "win32"


def try_lock(fh: IO[Any]) -> None:
    """Take an exclusive, non-blocking lock on ``fh``. Raises ``OSError`` if another process holds it."""
    if IS_WINDOWS:
        import msvcrt
        fh.seek(0)
        msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
    else:
        import fcntl
        fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)


def unlock(fh: IO[Any]) -> None:
    if IS_WINDOWS:
        import msvcrt
        fh.seek(0)
        msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
    else:
        import fcntl
        fcntl.flock(fh, fcntl.LOCK_UN)


def pid_alive(pid: int) -> bool:
    """True if a process with this pid exists (even one we may not signal).

    Never use ``os.kill(pid, 0)`` for this: on Windows it terminates the process.
    """
    if not pid or pid <= 0:
        return False
    if IS_WINDOWS:
        return _pid_alive_windows(pid)
    try:
        os.kill(pid, 0)
    except OSError as e:
        return e.errno == errno.EPERM   # ESRCH = gone; EPERM = exists but not ours
    return True


def _pid_alive_windows(pid: int) -> bool:
    import ctypes
    from ctypes import wintypes

    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    STILL_ACTIVE = 259
    ERROR_ACCESS_DENIED = 5
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.OpenProcess.restype = wintypes.HANDLE
    handle = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return ctypes.get_last_error() == ERROR_ACCESS_DENIED   # exists, not ours
    try:
        code = wintypes.DWORD()
        if not k32.GetExitCodeProcess(handle, ctypes.byref(code)):
            return False
        return code.value == STILL_ACTIVE
    finally:
        k32.CloseHandle(handle)


def detached_popen_kwargs() -> dict[str, Any]:
    """``subprocess.Popen`` arguments that let a child outlive this process and its console."""
    if IS_WINDOWS:
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        return {"creationflags": DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP}
    return {"start_new_session": True}
