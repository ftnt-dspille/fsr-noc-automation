"""SHARED CORE — database engine + session helpers.

The engine and ``get_session`` are shared by both surfaces. Schema migrations
and ``init_db`` stay in ``backend/db.py`` (A owns the DB lifecycle; B reads
from an existing DB and never calls ``init_db``).
"""
from sqlmodel import Session, create_engine

from fabric_studio.settings import DB_URL

engine = create_engine(DB_URL, connect_args={"check_same_thread": False})


def get_session() -> Session:
    return Session(engine)
