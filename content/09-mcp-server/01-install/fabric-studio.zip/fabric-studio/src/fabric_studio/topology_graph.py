"""Fabric topology graph and reachability prediction.

Pulls networks + VM ports + cables + switchport VLAN tags from Fabric Studio, then:
  - Maps each VM port to its L2 SEGMENT -- ``(network_id, vlan)``, not just the
    network. Two ports on one switch in different VLANs share a subnet and are
    still not the same broadcast domain, so the network alone is the wrong unit.
  - Identifies routers (VMs with ports on >=2 segments)
  - Builds a segment-level graph: edge(S1, S2) if some routing VM has interfaces
    in both
  - reachable(src_vm, dst_ip) -> bool via BFS on the segment graph

A port's ``vlan`` is the ACCESS vlan of the switchport it is cabled to (``None``
for an untagged port, a trunk, or an unknown cable). A trunk port carries many
VLANs and terminates none of them on the parent guest -- the guest's 802.1Q
subinterfaces are invisible to FS -- so a trunk contributes no segment here and
routing across it is not predicted. That is deliberate: claiming reachability we
cannot see is how a green rubber-stamp hides a real fault.

Cable info is exposed for integrity checks (a port may have an IP but no cable).
"""
from __future__ import annotations

import ipaddress
from collections import defaultdict, deque
from dataclasses import dataclass, field

ROUTING_VM_TYPES = {"FGT"}  # only FortiGate forwards by default; FMG/FAZ/FML/SOAR don't

# A segment key: (network id, vlan tag or None for untagged).
Seg = tuple[int, "int | None"]


@dataclass
class Port:
    vm_id: int
    vm_name: str
    vm_type: str
    name: str
    ipv4: str | None
    network_id: int | None
    # Access VLAN of the switchport this port is cabled to (None = untagged /
    # trunk / not cabled). Set by the state builders that can see switchports.
    vlan: int | None = None
    # VLANs the switchport carries when it is a TRUNK. A trunk terminates none
    # of them on this port, so it contributes no segment of its own -- but on a
    # ROUTING vm it bridges every VLAN in the list (802.1Q subinterfaces), which
    # is how an FGT-on-a-trunk does inter-VLAN routing.
    trunk: tuple[int, ...] = ()
    # The segments a TRUNK port bridges: one (network, vlan) per carried VLAN.
    # The builder resolves it, because the network a VLAN belongs to is a
    # property of the SWITCH (which subnet its access ports for that VLAN use),
    # not of the trunk port -- a trunk carrying 100 and 200 where each VLAN has
    # its own subnet reaches two DIFFERENT networks, and pairing every carried
    # VLAN with the trunk port's own network gets that wrong.
    trunk_segs: tuple[Seg, ...] = ()


@dataclass
class Network:
    id: int
    name: str
    cidr: str
    gateway: str | None


@dataclass
class Topology:
    networks:  dict[int, Network]        = field(default_factory=dict)
    ports:     list[Port]                = field(default_factory=list)
    by_vm:     dict[str, list[Port]]     = field(default_factory=lambda: defaultdict(list))
    by_net:    dict[int, list[Port]]     = field(default_factory=lambda: defaultdict(list))
    routers:   dict[str, set[int]]       = field(default_factory=dict)  # vm_name -> {net ids}
    net_graph: dict[int, set[int]]       = field(default_factory=lambda: defaultdict(set))
    cables:    list[tuple[int, int]]     = field(default_factory=list)
    # Segment-level views. ``by_seg``/``seg_graph`` are the ones reachability
    # uses; ``by_net``/``net_graph`` are kept as the VLAN-blind projection for
    # callers that only care about subnets.
    by_seg:    dict[Seg, list[Port]]     = field(default_factory=lambda: defaultdict(list))
    seg_graph: dict[Seg, set[Seg]]       = field(default_factory=lambda: defaultdict(set))

    # ── segment helpers ──────────────────────────────────────────────────────

    def seg_name(self, seg: Seg) -> str:
        nid, vlan = seg
        name = self.networks[nid].name if nid in self.networks else str(nid)
        if not vlan:
            return name
        # Don't say "vlan100 vlan100" when the network is already named for it.
        return name if name.strip().lower() == f"vlan{vlan}" else f"{name} vlan{vlan}"

    def network_for_ip(self, ip: str) -> int | None:
        try:
            addr = ipaddress.IPv4Address(ip)
        except ValueError:
            return None
        for nid, net in self.networks.items():
            try:
                if addr in ipaddress.IPv4Network(net.cidr, strict=False):
                    return nid
            except ValueError:
                continue
        return None

    def segment_for_ip(self, ip: str) -> Seg | None:
        """The segment an IP lives on. Prefers the VLAN of the port that actually
        owns the address -- the subnet alone can't tell VLAN 100 from VLAN 200
        when both are carved out of the same network."""
        for p in self.ports:
            if p.ipv4 == ip and p.network_id is not None:
                return (p.network_id, p.vlan)
        nid = self.network_for_ip(ip)
        return None if nid is None else (nid, None)

    def vm_networks(self, vm_name: str) -> set[int]:
        return {p.network_id for p in self.by_vm.get(vm_name, []) if p.network_id is not None}

    def vm_segments(self, vm_name: str) -> set[Seg]:
        return {(p.network_id, p.vlan) for p in self.by_vm.get(vm_name, [])
                if p.network_id is not None}

    def index(self) -> None:
        """(Re)build ``by_net``/``by_seg``/``routers``/graphs from ``ports``.
        Idempotent -- the single place graph assembly lives, so every builder
        (live ``build()`` or an offline state snapshot) agrees."""
        self.by_net = defaultdict(list)
        self.by_seg = defaultdict(list)
        self.net_graph = defaultdict(set)
        self.seg_graph = defaultdict(set)
        self.routers = {}
        for p in self.ports:
            if p.network_id is not None:
                self.by_net[p.network_id].append(p)
                self.by_seg[(p.network_id, p.vlan)].append(p)
        for vm_name, ports in self.by_vm.items():
            vtype = ports[0].vm_type if ports else ""
            if vtype not in ROUTING_VM_TYPES:
                continue
            segs = {(p.network_id, p.vlan) for p in ports
                    if p.network_id is not None and not p.trunk}
            for p in ports:
                if p.trunk_segs:
                    segs |= set(p.trunk_segs)
                elif p.trunk and p.network_id is not None:
                    segs |= {(p.network_id, v) for v in p.trunk}
            if len(segs) < 2:
                continue
            self.routers[vm_name] = {s[0] for s in segs}
            for a in segs:
                for b in segs:
                    if a != b:
                        self.seg_graph[a].add(b)
                        if a[0] != b[0]:
                            self.net_graph[a[0]].add(b[0])

    # ── BFS ──────────────────────────────────────────────────────────────────

    def path_segments(self, src: Seg, dst: Seg) -> list[Seg] | None:
        if src == dst:
            return [src]
        seen = {src}
        q: deque[tuple[Seg, list[Seg]]] = deque([(src, [src])])
        while q:
            cur, path = q.popleft()
            for nxt in self.seg_graph[cur]:
                if nxt in seen: continue
                if nxt == dst: return [*path, nxt]
                seen.add(nxt); q.append((nxt, [*path, nxt]))
        return None

    def path_networks(self, src_net: int, dst_net: int) -> list[int] | None:
        """VLAN-blind path between two networks (kept for callers that only
        reason about subnets). Reachability uses ``path_segments``."""
        if src_net == dst_net:
            return [src_net]
        seen = {src_net}
        q: deque[tuple[int, list[int]]] = deque([(src_net, [src_net])])
        while q:
            cur, path = q.popleft()
            for nxt in self.net_graph[cur]:
                if nxt in seen: continue
                if nxt == dst_net: return [*path, nxt]
                seen.add(nxt); q.append((nxt, [*path, nxt]))
        return None

    def reachable(self, src_vm: str, dst_ip: str) -> tuple[bool, str]:
        """Return (expected_reachable, explanation)."""
        src_segs = self.vm_segments(src_vm)
        if not src_segs:
            return False, "src has no L3 interfaces"
        dst_seg = self.segment_for_ip(dst_ip)
        if dst_seg is None:
            return False, "dst IP not in any fabric network"
        for s in sorted(src_segs, key=lambda x: (x[0], x[1] or 0)):
            path = self.path_segments(s, dst_seg)
            if path:
                if len(path) == 1:
                    return True, f"same L2 ({self.seg_name(s)})"
                hops = " → ".join(self.seg_name(n) for n in path)
                return True, f"L3 via {hops}"
        # A same-subnet, different-VLAN pair is the failure this exists to catch:
        # every naive check says "same L2" and the traffic is dropped at the
        # uplink. Name the VLANs rather than reporting a generic no-path.
        same_net = [s for s in src_segs if s[0] == dst_seg[0] and s[1] != dst_seg[1]]
        if same_net:
            got = ", ".join(str(s[1] if s[1] else "untagged") for s in sorted(
                same_net, key=lambda x: x[1] or 0))
            want = dst_seg[1] if dst_seg[1] else "untagged"
            net = self.networks[dst_seg[0]].name if dst_seg[0] in self.networks else dst_seg[0]
            return False, (f"VLAN mismatch on {net}: src is on vlan {got}, dst on "
                           f"vlan {want} -- same subnet, different broadcast domain")
        ordered = sorted(src_segs, key=lambda x: (x[0], x[1] or 0))
        return False, (f"no path from {[self.seg_name(s) for s in ordered]} "
                       f"to {self.seg_name(dst_seg)}")


def build(client, fabric_id: int) -> Topology:
    t = Topology()
    nets = client.get(f"api/v1/model/fabric/{fabric_id}/network").json()["object"] or []
    for n in nets:
        cidr = f"{n['ipv4network']}/{n['ipv4netmask']}"
        t.networks[n["id"]] = Network(
            id=n["id"], name=n["name"], cidr=cidr,
            gateway=n.get("ipv4gateway"),
        )

    # switchport id → access vlan, so a vm port can inherit the tag of the
    # switchport it is cabled to (peer). Trunks contribute no tag (see module
    # docstring).
    vlan_by_switchport: dict[int, int | None] = {}
    trunk_by_switchport: dict[int, tuple[int, ...]] = {}
    switchport_switch: dict[int, int] = {}
    switches = client.get(f"api/v1/model/fabric/{fabric_id}/switch").json()["object"] or []
    for sw in switches:
        ports = client.get(
            f"api/v1/model/fabric/{fabric_id}/switch/{sw['id']}/port"
        ).json()["object"] or []
        for sp in ports:
            vlan_by_switchport[sp["id"]] = access_vlan(sp)
            trunk_by_switchport[sp["id"]] = trunk_vlans(sp)
            switchport_switch[sp["id"]] = sw["id"]

    vms = client.get(
        f"api/v1/model/fabric/{fabric_id}/vm?related_fields=ports"
    ).json()["object"] or []
    # (switch, vlan) → network, learned from the ACCESS ports: the switch is
    # what ties a VLAN to a subnet, so this is the map a trunk's segments need.
    vlan_net = vlan_network_map(
        [(switchport_switch.get(prt.get("peer")), vlan_by_switchport.get(prt.get("peer")),
          prt.get("network") if prt.get("network") is not None
          else (t.network_for_ip(prt["ipv4addr"]) if prt.get("ipv4addr") else None))
         for vm in vms for prt in vm.get("ports", [])])
    for vm in vms:
        for prt in vm.get("ports", []):
            ip   = prt.get("ipv4addr")
            nid  = prt.get("network")
            if nid is None and ip:
                nid = t.network_for_ip(ip)
            port = Port(vm_id=vm["id"], vm_name=vm["name"], vm_type=vm.get("vm_type", ""),
                        name=prt.get("name", "?"), ipv4=ip, network_id=nid,
                        vlan=vlan_by_switchport.get(prt.get("peer")),
                        trunk=trunk_by_switchport.get(prt.get("peer")) or (),
                        trunk_segs=trunk_segments(
                            trunk_by_switchport.get(prt.get("peer")) or (),
                            switchport_switch.get(prt.get("peer")), vlan_net, nid))
            t.ports.append(port)
            t.by_vm[vm["name"]].append(port)
    t.index()

    cabs = client.get(f"api/v1/model/fabric/{fabric_id}/cable").json()["object"] or []
    t.cables = [(c["conn1"], c["conn2"]) for c in cabs]
    return t


def access_vlan(switchport: dict) -> int | None:
    """The VLAN an ACCESS switchport puts untagged frames on, or None.

    ``mode`` is OVS ``vlan_mode``. FS also honours an implicit form: a port left
    VLAN-unaware but carrying a ``vlan`` tag is treated as access by OVS
    inference. Read both, so an explicitly-tagged port and an inferred one land
    on the same segment -- reading only ``mode`` is exactly how two switches
    configured the same way diverged."""
    if not isinstance(switchport, dict):
        return None
    mode = str(switchport.get("mode") or "").strip().lower()
    if mode == "trunk":
        return None                       # carries many; terminates none
    try:
        vlan = int(switchport.get("vlan") or 0)
    except (TypeError, ValueError):
        return None
    return vlan or None


def trunk_vlans(switchport: dict) -> tuple[int, ...]:
    """VLANs a TRUNK switchport carries, parsed from the FS ``trunk`` string
    (``"100,200"``, ranges allowed: ``"100-104,200"``). Empty for a non-trunk or
    an unparseable list -- the parse is deliberately lenient here because the FS
    API stores the field verbatim without validating it; `parse_trunk` in the
    intent layer is where a malformed list is rejected."""
    if not isinstance(switchport, dict):
        return ()
    if str(switchport.get("mode") or "").strip().lower() != "trunk":
        return ()
    out: list[int] = []
    for chunk in str(switchport.get("trunk") or "").split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        try:
            if "-" in chunk:
                lo, hi = (int(x) for x in chunk.split("-", 1))
                out.extend(range(lo, hi + 1))
            else:
                out.append(int(chunk))
        except ValueError:
            continue
    return tuple(sorted({v for v in out if 1 <= v <= 4094}))


def vlan_network_map(access_ports) -> dict[tuple, int]:
    """``(switch_id, vlan) → network_id``, learned from ACCESS ports.

    A VLAN is tied to a subnet by the switch it lives on, not by any one port.
    ``access_ports`` is an iterable of ``(switch_id, vlan, network_id)``; entries
    with no switch, no vlan or no network are ignored."""
    out: dict[tuple, int] = {}
    for sw, vlan, nid in access_ports:
        if sw is not None and vlan and nid is not None:
            out.setdefault((sw, vlan), nid)
    return out


def trunk_segments(trunk: tuple[int, ...], switch_id, vlan_net: dict[tuple, int],
                   fallback_net) -> tuple[Seg, ...]:
    """The segments a trunk port bridges: each carried VLAN paired with the
    network that VLAN uses ON THIS SWITCH, falling back to the port's own
    network when the switch has no access port for it (nothing to learn from --
    a VLAN carried but not terminated here)."""
    out = []
    for v in trunk:
        nid = vlan_net.get((switch_id, v), fallback_net)
        if nid is not None:
            out.append((nid, v))
    return tuple(out)
