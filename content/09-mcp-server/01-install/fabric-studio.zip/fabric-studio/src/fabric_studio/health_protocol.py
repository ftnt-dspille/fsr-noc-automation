"""Health phase protocol — dependency-inversion seam between A and B.

SHARED CORE — Project B's topology pipeline runs Project A's health checks
through this protocol, without importing A at module load. A registers its
implementation at import time; B calls it through ``get_health_provider()``.
If no provider is registered (e.g. B deployed without A), the health phase
skips cleanly.

Flow::

    B: backend/fabric/health.py   →  get_health_provider()  →  A: backend/engine/health_runner.py
         run_health (control flow)         ↑                            discover_pod + execute_check
                                          registration at import
"""
from __future__ import annotations

from typing import Any, Protocol


class HealthProvider(Protocol):
    """Provided by Project A; called by Project B's health phase.

    Two operations:
    - ``discover_pod(session, pod)`` — populate Device rows for a pod's running fabric.
    - ``execute_check(session, slug, device, pod, params)`` — run one catalog check
      by slug. Returns ``(status, detail)`` or ``None`` if the check isn't seeded.
    """

    def discover_pod(self, session: Any, pod: Any) -> None: ...

    def execute_check(
        self,
        session: Any,
        slug: str,
        device: Any,
        pod: Any,
        params: dict[str, Any],
    ) -> tuple[str, str] | None: ...


_provider: HealthProvider | None = None


def register_health_provider(provider: HealthProvider) -> None:
    """Register A's health provider. Called at import time by A's health_runner."""
    global _provider
    _provider = provider


def get_health_provider() -> HealthProvider | None:
    """Return the registered provider, or None if A isn't installed."""
    return _provider
