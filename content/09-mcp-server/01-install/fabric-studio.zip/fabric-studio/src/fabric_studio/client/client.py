#!/usr/bin/env python3
"""
Simple FortiPOC REST Client

A simplified single-file class for making REST API calls to FortiPOC instances.
"""


import json
import os
from pathlib import Path

import requests

from . import login_guard


class FabricStudioAuthError(Exception):
    """A FortiPoC request was refused with a 403 that looks like a CSRF / session
    denial (Django's HTML "403 Forbidden" page), not a normal RBAC/authz refusal
    (which comes back as JSON). The cause is almost always operational, not a bug
    in the caller: the ``X-FortiPoC-CSRFToken`` header was missing/stale, or a
    cached session on disk went bad. The message carries the corrective action
    because retrying the same call (or blindly re-POSTing ``session/open``) will
    NOT fix a CSRF-header mismatch. Callers may catch this to surface guidance;
    the retry-wrappers in ``tools/*`` should treat it as non-transient (do not
    retry)."""


def _looks_like_csrf_denial(response: "requests.Response") -> bool:
    """True for a 403 that is a FortiPoC/Django CSRF-session denial (HTML page)
    rather than a JSON RBAC/authz refusal. Distinguishes the two by content type
    + body markers so we only flag the operational (fixable) case."""
    if response.status_code != 403:
        return False
    ctype = (response.headers.get("content-type") or "").lower()
    if "application/json" in ctype:
        return False  # RBAC/authz refusal -- a real "not allowed", let it flow
    body = (response.text or "")[:600].lower()
    return ("403 forbidden" in body or "csrf" in body
            or "noarchive" in body or "text/html" in ctype)


# Endpoints that must never trigger the 401 re-auth retry -- they ARE the login
# handshake, so retrying them recurses instead of recovering.
_AUTH_ENDPOINTS = ("api/v1/session/open", "api/v1/session/check")


def _looks_like_session_expiry(response: "requests.Response") -> bool:
    """True for a 401 that means "your session died", which a fresh login fixes.

    FortiPoC expires a session server-side after an idle/absolute timeout and
    then answers every call with 401 ``{"errors": {"global": ["Not
    authenticated"]}}``. That is NOT transient -- polling through it just burns
    the caller's retry budget (a multi-hour ``install_fabric`` wait died this way
    on a task that had actually succeeded), so it has to be fixed by
    re-authenticating rather than waited out. A 401 carrying a different body is
    still treated the same: this client only ever has one credential, so a fresh
    login is the only recovery either way, and it is attempted exactly once."""
    return response.status_code == 401


class FabricStudioClient:
    """
    A simple client for interacting with FortiPOC REST API.

    This client maintains a session with cookies and provides methods for making
    REST API calls to a FortiPOC instance.

    Session reuse: FortiPoC rate-limits the ``session/open`` (login) endpoint per
    source IP -- hammer it and it 403s ("Not authenticated", rcode 246) for a
    while. To avoid re-logging-in on every construction (each process would
    otherwise POST ``session/open`` afresh), the client persists its session
    cookie to ``~/.fsh/sessions/<host>.json`` after a successful login and, on the
    next construction, reuses it -- validating cheaply with a ``session/check`` GET
    and only POSTing ``session/open`` when no live session exists. This is exactly
    how a browser stays logged in. Set ``FSH_NO_SESSION_CACHE=1`` to disable.
    """

    # Where per-host session cookies are cached (0600). Override with FSH_SESSION_DIR.
    _SESSION_DIR = Path(os.environ.get("FSH_SESSION_DIR", os.path.expanduser("~/.fsh/sessions")))

    # Default request timeout in seconds -- applied to every HTTP call unless
    # a caller overrides it. Keeps a hung Fabric Studio from tying up backend
    # worker threads forever.
    DEFAULT_TIMEOUT_S = 15

    def __init__(self, server: str, username: str, password: str, verify_ssl: bool = False,
                 timeout_s: int = DEFAULT_TIMEOUT_S):
        """
        Initialize a FortiPOC REST client.

        Args:
            server: The FortiPOC server URL or IP address
            username: Username for authentication
            password: Password for authentication
            verify_ssl: Whether to verify SSL certificates. Default is False.
        """
        self.server = server.rstrip('/')

        if not self.server.startswith(('http://', 'https://')):
            self.server = f'https://{self.server}'

        # Strip default ports (:443 for https, :80 for http) so the Referer
        # header origin matches what Django's CSRF middleware expects --
        # it rejects "https://host:443/" but accepts "https://host/".
        import re
        self.server = re.sub(r'^(https://[^/:]+):443(/|$)', r'\1\2', self.server)
        self.server = re.sub(r'^(http://[^/:]+):80(/|$)', r'\1\2', self.server)

        self.username = username
        self.password = password
        self.verify_ssl = verify_ssl
        self.timeout_s = timeout_s

        # Create a session to maintain cookies in memory
        self.session = requests.Session()
        self.session.verify = verify_ssl

        # CSRF token will be stored here after login
        self.csrf_token = None

        # Re-entrancy guard for the 401 re-auth retry in request(): login()
        # itself issues requests, and without this a 401 on session/check would
        # recurse into login() forever.
        self._reauthing = False

        # Login automatically when the client is instantiated
        self.login()

    def _get_full_url(self, endpoint: str) -> str:
        """
        Build the full URL for an API endpoint.

        Args:
            endpoint: API endpoint path

        Returns:
            Full URL including server address
        """
        # Remove leading slash if present to avoid double slashes
        if endpoint.startswith('/'):
            endpoint = endpoint[1:]

        return f"{self.server}/{endpoint}"

    def _extract_csrf_token(self) -> str | None:
        """
        Extract the CSRF token from the session cookies.

        Returns:
            The CSRF token value or None if not found.
        """
        for cookie in self.session.cookies:
            if cookie.name == 'fortipoc-csrftoken':
                return cookie.value
        return None

    def request(self, method: str, endpoint: str, data: dict | str | None = None,
                headers: dict[str, str] | None = None, json_data: dict | None = None,
                files: dict | list | tuple | None = None) -> requests.Response:
        """
        Make a REST API request to the FortiPoC instance.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, etc.)
            endpoint: API endpoint to call (e.g., 'api/v1/session/check')
            data: Form data, raw string data, OR multipart form fields when
                ``files`` is set (a dict of non-file form fields)
            headers: Additional HTTP headers
            json_data: JSON data to send (will be converted to string)
            files: multipart file parts -- a ``requests``-shaped ``files`` arg
                (``{field: (filename, fileobj, content_type)}``). When set, the
                request becomes ``multipart/form-data``; ``data`` becomes the
                non-file form fields and ``json_data`` is ignored. Use this
                instead of reaching into ``c.session``/``c._get_full_url`` from
                callers (``fs_admin._post_multipart``).

        Returns:
            The response object from the request

        Raises:
            Exception: If there's an error with the request
        """
        # Prepare headers
        if headers is None:
            headers = {}

        # Add common headers
        headers['Referer'] = f'{self.server}/'

        # Add CSRF token if available
        if self.csrf_token:
            headers['X-FortiPoC-CSRFToken'] = self.csrf_token

        # Make the request
        url = self._get_full_url(endpoint)

        # ``json`` and ``files`` are mutually exclusive in requests: when
        # uploading multipart, only ``data`` (form fields) + ``files`` are sent;
        # otherwise ``json_data`` is the body. Branch here so callers can route
        # multipart uploads through this public method instead of touching
        # ``c.session``/``c._get_full_url`` directly (the leak ``_post_multipart``
        # in fs_admin closes).
        send_kwargs: dict = {
            "headers": headers,
            "data": data,
            "allow_redirects": True,
            # Multipart uploads (firmware, device configs) can be hundreds of MB.
            # Use a 10-minute timeout for those; the default 15s/60s is too short.
            "timeout": 600 if files is not None else self.timeout_s,
        }
        if files is not None:
            send_kwargs["files"] = files
        elif json_data is not None:
            send_kwargs["json"] = json_data

        try:
            response = self.session.request(
                method=method,
                url=url,
                **send_kwargs,
            )

            # Check for CSRF token in response cookies and update if found
            new_token = self._extract_csrf_token()
            if new_token:
                self.csrf_token = new_token

            # Session expiry: re-authenticate once and replay the call. A long
            # poll (wait_task over a multi-minute install_fabric) otherwise sees
            # every remaining poll 401 and gives up on a task that succeeded.
            # Skipped for the login handshake itself (would recurse) and for
            # multipart uploads (the file object is already consumed and cannot
            # be replayed -- those callers must handle the 401 themselves).
            #
            # A POST/PUT/DELETE after expiry does not get the 401: Django's CSRF
            # check runs first and answers 403 (its HTML page), because the
            # CSRF token belonged to the dead session. That is the same expiry
            # in disguise -- live, a ~4h build apply died on the POST that
            # followed a successful ingest. Treat a CSRF 403 as expiry only
            # when a session/check confirms the session is gone; a CSRF 403 on
            # a LIVE session is a real header problem and still raises below.
            replayable = (not self._reauthing and files is None
                          and endpoint.strip('/') not in _AUTH_ENDPOINTS)
            expired = replayable and (
                _looks_like_session_expiry(response)
                or (_looks_like_csrf_denial(response)
                    and not self._session_is_authenticated()))
            if expired:
                self._reauthing = True
                try:
                    self.login(force=True)
                    # The guard stays set ACROSS the replay: a 401 that survives
                    # a fresh login is a real authorization failure, and letting
                    # the replay re-enter here would spin on the rate-limited
                    # session/open endpoint instead of surfacing it.
                    return self.request(method, endpoint, data=data,
                                        headers=headers, json_data=json_data,
                                        files=files)
                finally:
                    self._reauthing = False

            # Flag a CSRF/session denial with actionable guidance instead of
            # letting it surface downstream as an opaque 401 "Not authenticated".
            if _looks_like_csrf_denial(response):
                raise FabricStudioAuthError(
                    f"{method} {endpoint} → 403 Forbidden from {self.server} "
                    f"(FortiPoC CSRF / session denial, not RBAC).\n"
                    f"Likely cause: the X-FortiPoC-CSRFToken header was missing or "
                    f"stale (csrf_token={'set' if self.csrf_token else 'MISSING'}), "
                    f"or a cached session on disk is bad.\n"
                    f"Corrective action:\n"
                    f"  1. Ensure a GET api/v1/session/check ran to seed the CSRF "
                    f"token before this call (the client does this in login()).\n"
                    f"  2. If it persists, the on-disk session cache is likely "
                    f"poisoned -- delete {self._session_cache_path()} or set "
                    f"FSH_NO_SESSION_CACHE=1, then re-run.\n"
                    f"  3. Do NOT blindly retry / re-POST session/open -- a CSRF "
                    f"mismatch is not transient and retrying won't fix it.")

            return response

        except requests.RequestException as e:
            raise Exception(f"Request failed: {e!s}") from e

    def get(self, endpoint: str, headers: dict[str, str] | None = None) -> requests.Response:
        """Make a GET request to the API."""
        return self.request('GET', endpoint, headers=headers)

    def post(self, endpoint: str, data: dict | str | None = None,
             headers: dict[str, str] | None = None, json_data: dict | None = None) -> requests.Response:
        """Make a POST request to the API."""
        return self.request('POST', endpoint, data=data, headers=headers, json_data=json_data)

    def put(self, endpoint: str, data: dict | str | None = None,
            headers: dict[str, str] | None = None, json_data: dict | None = None) -> requests.Response:
        """Make a PUT request to the API."""
        return self.request('PUT', endpoint, data=data, headers=headers, json_data=json_data)

    def delete(self, endpoint: str, headers: dict[str, str] | None = None) -> requests.Response:
        """Make a DELETE request to the API."""
        return self.request('DELETE', endpoint, headers=headers)

    # ── Session cache (avoid the rate-limited session/open on every process) ──

    def _session_cache_path(self) -> Path:
        host = self.server.split('://', 1)[-1].replace('/', '_').replace(':', '_')
        user = ''.join(ch if ch.isalnum() or ch in '_.-' else '_' for ch in (self.username or ''))
        return self._SESSION_DIR / f'{host}__{user}.json'

    def _cache_enabled(self) -> bool:
        return not os.environ.get('FSH_NO_SESSION_CACHE')

    def _load_cached_session(self) -> bool:
        """Load a persisted cookie for this host+user into the session. Returns
        True if a candidate was loaded (still needs a live ``session/check``)."""
        if not self._cache_enabled():
            return False
        try:
            blob = json.loads(self._session_cache_path().read_text())
        except (OSError, ValueError):
            return False
        if blob.get('username') != self.username or not blob.get('cookies'):
            return False
        self.session.cookies = requests.utils.cookiejar_from_dict(blob['cookies'])
        self.csrf_token = blob.get('csrf_token') or self._extract_csrf_token()
        return True

    def _save_session(self) -> None:
        if not self._cache_enabled():
            return
        p = self._session_cache_path()
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            data = {
                'username': self.username,
                'csrf_token': self.csrf_token,
                'cookies': requests.utils.dict_from_cookiejar(self.session.cookies),
            }
            # 0600 -- the session cookie is a credential.
            fd = os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, 'w') as f:
                json.dump(data, f)
        except OSError:
            pass  # cache is best-effort; a write failure must not break the client

    def _session_is_authenticated(self) -> bool:
        """Cheap read-only probe (never hits the rate-limited session/open)."""
        try:
            r = self.get('api/v1/session/check')
            if r.status_code != 200:
                return False
            obj = r.json().get('object') or {}
        except Exception:
            return False
        who = obj.get('username')
        return bool(obj.get('authenticated')) and (not who or who == self.username)

    def login(self, force: bool = False) -> dict:
        """
        Log in to the FortiPOC instance, reusing a cached session when possible.

        Reuses a persisted cookie (validated via ``session/check``) instead of
        POSTing the rate-limited ``session/open`` whenever a live session exists --
        which is what keeps repeated CLI invocations from tripping the login
        rate-limit. Pass ``force=True`` (or set ``FSH_NO_SESSION_CACHE=1``) to
        always do a fresh ``session/open``.

        Returns:
            The JSON response as a dictionary (``{'reused': True}`` on cache hit).
        """
        # 1. Reuse a live cached session -- no session/open POST, no cooldown, no lock.
        if not force and self._reuse_cached_session():
            return {'reused': True}

        # 2. A NEW session is needed. One at a time per pod (across processes), never
        #    while a recent failure has the pod cooling down, and whoever waited for
        #    the lock first looks again: another process may have just logged in.
        if not login_guard.enabled():
            return self._fresh_login()
        dead = requests.utils.dict_from_cookiejar(self.session.cookies) if force else None
        with login_guard.host_lock(self.server):
            if self._reuse_cached_session(not_cookies=dead):
                return {'reused': True}
            login_guard.check_cooldown(self.server)
            try:
                result = self._fresh_login()
            except BaseException as e:
                login_guard.record_failure(self.server, f"{type(e).__name__}: {e}")
                raise
            login_guard.clear(self.server)
            return result

    def _reuse_cached_session(self, not_cookies: dict | None = None) -> bool:
        """Adopt the shared cached session if it is live. ``not_cookies`` is a session we
        already know is dead, so an unchanged cache entry is not mistaken for a new one."""
        if not self._load_cached_session():
            return False
        if not_cookies is not None and requests.utils.dict_from_cookiejar(self.session.cookies) == not_cookies:
            self.session.cookies.clear()
            return False
        if self._session_is_authenticated():
            self.csrf_token = self._extract_csrf_token() or self.csrf_token
            self._save_session()  # refresh cookie/csrf rotation
            return True
        self.session.cookies.clear()  # stale
        return False

    def _fresh_login(self) -> dict:
        """Seed cookies/CSRF, then POST credentials. A CSRF/session 403 is raised as
        FabricStudioAuthError from request() with guidance."""
        self.get('api/v1/session/check')
        # Extract CSRF token from the cookie seeded by session/check BEFORE
        # the POST -- the POST's X-FortiPoC-CSRFToken header must carry it or
        # the server returns 403 (CSRF denial). Without this, the header is
        # missing because self.csrf_token is still None from __init__.
        self.csrf_token = self._extract_csrf_token()
        endpoint = 'api/v1/session/open'
        headers = {'Content-Type': 'application/json'}
        response = self.post(
            endpoint,
            json_data={'username': self.username, 'password': self.password},
            headers=headers
        )

        # Update CSRF token after login (may rotate on successful auth).
        self.csrf_token = self._extract_csrf_token() or self.csrf_token

        # Only persist a session that actually authenticated -- saving an
        # unauthenticated one poisons every later run. A login that returns but is not
        # authenticated is a failure (it also starts the cooldown), not a client that
        # later answers a bare 401.
        if not self._session_is_authenticated():
            raise FabricStudioAuthError(
                f"login to {self.server} was accepted but the session is not authenticated "
                f"(HTTP {response.status_code}); check the credentials and that the pod is healthy")
        self._save_session()
        return response.json()
