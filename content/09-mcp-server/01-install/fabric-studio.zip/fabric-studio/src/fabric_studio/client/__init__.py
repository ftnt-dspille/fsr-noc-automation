"""Fabric Studio REST client."""

from .client import FabricStudioAuthError, FabricStudioClient

__all__ = ["FabricStudioAuthError", "FabricStudioClient"]
