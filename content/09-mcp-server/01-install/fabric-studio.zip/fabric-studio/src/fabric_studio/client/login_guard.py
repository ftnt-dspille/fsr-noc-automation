"""Keep our logins to a pod from tripping its login rate limit / IP block.

A Fabric Studio pod rate-limits ``session/open`` and, past some point, stops answering this
workstation on 443 for a while. A cached session is always tried first (``FabricStudioClient``);
only when a NEW session is really needed does it go through here:

* one new login at a time per pod, across threads and processes (a file lock), and whoever
  waits re-checks the shared session cache afterwards, so a login someone else just finished is
  reused instead of repeated;
* a cooldown after a failed login (60s, 2m, 5m, then 10m), kept on disk, during which we fail
  immediately instead of knocking again (every knock extends a block);
* ``FSH_NO_LOGIN_GUARD=1`` turns all of it off.
"""
from __future__ import annotations

import contextlib
import json
import os
import re
import time
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from fabric_studio._platform import try_lock, unlock

BACKOFF_S = (60, 120, 300, 600)


class LoginCooldown(RuntimeError):
    """A recent login to this pod failed; we are deliberately not trying again yet."""


def enabled() -> bool:
    return not os.environ.get("FSH_NO_LOGIN_GUARD")


def _dir() -> Path:
    d = Path(os.environ.get("FSH_LOGIN_GUARD_DIR") or Path.home() / ".fsh" / "login_guard")
    d.mkdir(parents=True, exist_ok=True)
    return d


def _key(host: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]", "_", host)


def cooldown(host: str) -> dict[str, Any] | None:
    """The active cooldown for ``host`` (``until``, ``failures``, ``error``), else ``None``."""
    try:
        st = json.loads((_dir() / f"{_key(host)}.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return st if float(st.get("until") or 0) > time.time() else None


def record_failure(host: str, error: str) -> None:
    path = _dir() / f"{_key(host)}.json"
    try:
        failures = int(json.loads(path.read_text(encoding="utf-8")).get("failures") or 0)
    except (OSError, ValueError):
        failures = 0
    failures += 1
    wait = BACKOFF_S[min(failures - 1, len(BACKOFF_S) - 1)]
    path.write_text(json.dumps({"failures": failures, "until": time.time() + wait,
                                "error": error[:200], "at": time.time()}), encoding="utf-8")


def clear(host: str) -> None:
    with contextlib.suppress(FileNotFoundError):
        (_dir() / f"{_key(host)}.json").unlink()


@contextlib.contextmanager
def host_lock(host: str, wait_s: float = 60.0) -> Iterator[None]:
    """Hold the per-pod login lock; raises ``LoginCooldown`` if it stays held for ``wait_s``."""
    with open(_dir() / f"{_key(host)}.lock", "w", encoding="utf-8") as fh:
        deadline = time.time() + wait_s
        while True:
            try:
                try_lock(fh)
                break
            except OSError:
                if time.time() > deadline:
                    raise LoginCooldown(f"another login to {host} has held the lock for {wait_s:.0f}s") from None
                time.sleep(0.2)
        try:
            yield
        finally:
            unlock(fh)


def check_cooldown(host: str) -> None:
    cd = cooldown(host)
    if cd:
        left = int(float(cd["until"]) - time.time())
        raise LoginCooldown(f"not logging in to {host}: the last attempt failed ({cd.get('error')}); "
                            f"retry in {left}s (failure #{cd.get('failures')})")
