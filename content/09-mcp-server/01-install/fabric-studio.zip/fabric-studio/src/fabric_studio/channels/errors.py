"""Turn ugly transport errors (requests, asyncssh, asyncio) into one-line
human-readable strings the UI can show without exposing stack traces."""
from __future__ import annotations

import re

# Order matters — most specific first. Each pattern compiles once.
_PATTERNS: list[tuple[re.Pattern, str]] = [
    # — DNS / hostname —
    (re.compile(r"getaddrinfo (?:failed|ENOTFOUND)|Name or service not known|nodename nor servname|"
                r"NameResolutionError", re.I),
     "Hostname does not resolve."),
    (re.compile(r"Temporary failure in name resolution", re.I),
     "DNS lookup temporarily failed."),

    # — TCP refused / unreachable / closed —
    (re.compile(r"\bConnection refused\b|\[Errno 61\]", re.I),
     "Connection refused (no service listening on this port)."),
    (re.compile(r"Network is unreachable|\[Errno 5[0-1]\]", re.I),
     "Network is unreachable (no route — VPN down?)."),
    (re.compile(r"\bHost is down\b|\[Errno 64\]", re.I),
     "Host is down."),
    (re.compile(r"\bNo route to host\b|\[Errno 65\]", re.I),
     "No route to host (gateway / routing issue)."),
    (re.compile(r"Connection reset by peer|ConnectionResetError|\[Errno 54\]", re.I),
     "Connection reset (device closed the socket — restarting or denying access)."),
    (re.compile(r"Broken pipe|\[Errno 32\]", re.I),
     "Broken pipe (device dropped the connection mid-request)."),

    # — Timeouts —
    (re.compile(r"\bReadTimeout\b|\bRead timed out\b|asyncio\.TimeoutError|TimeoutError\(\)", re.I),
     "Server did not respond in time."),
    (re.compile(r"\bConnectTimeoutError\b|\bConnect timeout\b|connection timed out|\[Errno 60\]", re.I),
     "Connection timed out (host not reachable)."),

    # — TLS —
    (re.compile(r"CERTIFICATE_VERIFY_FAILED|certificate verify failed", re.I),
     "TLS certificate verification failed."),
    (re.compile(r"SSL[a-zA-Z_]*Error|TLS[a-zA-Z_]*Error|WRONG_VERSION_NUMBER|"
                r"UNSUPPORTED_PROTOCOL", re.I),
     "TLS handshake error."),

    # — HTTP-level (still bubble up the code we know) —
    (re.compile(r"\b(HTTP[ /]?\d{3})\b"),
     None),  # passthrough — keep the HTTP code; handled separately below.

    # — SSH-specific (asyncssh) —
    (re.compile(r"PermissionDenied|Permission denied", re.I),
     "SSH login refused (bad password or trusted-host policy)."),
    (re.compile(r"DisconnectError\(.*reason='kex_exchange_identification|"
                r"kex_exchange_identification: Connection closed", re.I),
     "SSH closed before the version exchange (interface allowaccess or trusted-host blocks this source)."),
    (re.compile(r"ChannelOpenError\b|open failed", re.I),
     "SSH channel could not be opened (inner host unreachable from the jump host)."),
    (re.compile(r"HostKeyNotVerifiable", re.I),
     "SSH host key changed and could not be verified."),
    (re.compile(r"ssh.*Connection lost|Disconnected by peer|disconnect", re.I),
     "SSH disconnected by the device."),
    (re.compile(r"^ssh timeout$|ssh-jump timeout|ssh: connection timed out", re.I),
     "SSH connection timed out."),

    # — Catch-alls that surface in requests output —
    (re.compile(r"Max retries exceeded with url", re.I),
     "Could not connect after multiple retries."),
    (re.compile(r"NewConnectionError|Failed to establish a new connection", re.I),
     "Could not open a connection to the device."),
    (re.compile(r"requests\.exceptions\.\w+", re.I),
     "HTTP request failed."),
]


def _strip_envelope(s: str) -> str:
    """Trim the noisy prefixes requests/urllib3 wrap raw socket errors in."""
    # 'HTTPSConnectionPool(host=..., port=...): ...' → keep host:port for context.
    m = re.search(r"host='([^']+)',\s*port=(\d+)", s)
    host_port = f"{m.group(1)}:{m.group(2)}" if m else None
    return s, host_port


def humanize(raw: str | Exception) -> str:
    """Return a friendly one-line error for the UI. Never throws.

    Always includes the device host:port if the raw error mentions one, so
    the user knows *where* failed (e.g. 'Connection refused on 10.0.0.1:443').
    """
    if raw is None or raw == "":
        return "Unknown error."
    if isinstance(raw, BaseException):
        raw = f"{type(raw).__name__}: {raw}"
    raw = str(raw)
    s, host_port = _strip_envelope(raw)
    suffix = f" ({host_port})" if host_port else ""

    for rx, msg in _PATTERNS:
        if rx.search(s):
            if msg is None:
                # Passthrough rule — let HTTP code stand on its own.
                m = rx.search(s)
                return f"{m.group(0)}{suffix}"
            return msg + suffix

    # Fallback: take the last useful sentence-ish chunk, capped.
    parts = re.split(r":\s*|\.\s*", s)
    tail = next((p.strip() for p in reversed(parts) if p.strip() and len(p.strip()) < 200), s)
    return (tail[:200] or "Probe failed.") + suffix
