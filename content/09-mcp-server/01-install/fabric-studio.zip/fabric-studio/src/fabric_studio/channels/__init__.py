"""Shared transport channels — the cross-cutting probe transports used by
both Project A (orchestrator/resolver) and Project B (config/ansible/fs_admin).

Moved from backend.engine.channels in Phase 4. Holds the low-level SSH
direct/jump transport (ssh.py), the FS serial console (fs_console.py), and
the ProbeResult/error base types (base.py, errors.py). The A-surface
device-api / fabric-api / fabric-topology / fabric-task-health channels stay
in backend.engine.channels and import from here.
"""
