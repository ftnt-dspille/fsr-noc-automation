"""ssh-direct + ssh-jump channels -- both share one async core.

The jump transport (pod-shell → inner SSH to guest) lives in
``core/channels/jump.py`` -- a unified module shared with Project B's
``backend/fabric/config.py``. This module holds the direct (no-hop)
transport + the public channel API that wraps both.
"""
import asyncio
import time
from typing import Any

import asyncssh

from fabric_studio.channels.base import ProbeResult
from fabric_studio.channels.errors import humanize
from fabric_studio.channels.jump import (
    JUMP_MARKER,
    build_password_payload,
    split_marked,
)
from fabric_studio.credentials import resolve_device_credentials, resolve_pod_credentials
from fabric_studio.pod.ports import external_port
from fabric_studio.pod_shell import _strip_fs_exit_trailer
from fabric_studio.pod_shell import _wrap as _fs_wrap


def _render(template: str, ctx: dict[str, Any]) -> str:
    out = template
    for k, v in ctx.items():
        out = out.replace("{{" + k + "}}", str(v))
    return out


def _device_creds(device_id: int):
    # Compatibility shim for tests + simulator that import this helper.
    from fabric_studio.db import get_session
    from fabric_studio.models import Device
    with get_session() as s:
        d = s.get(Device, device_id)
        if not d:
            return None
        return resolve_device_credentials(d)


async def _direct_exec(host: str, port: int, username: str, password: str,
                       command: str, timeout_s: int, sudo: bool,
                       client_keys: list[str] | None = None) -> tuple:
    """Single-probe SSH dispatch. When `command` contains newlines, split
    and dispatch each non-empty line in the same session - asyncssh's
    conn.run() treats embedded newlines as part of one channel, which
    FortiOS CLI doesn't process. Output is concatenated; exit code is the
    last non-zero (or 0).

    ``client_keys`` (paths) enables key auth; pass a single key for the
    Linux builder. When None/empty, ``client_keys=[]`` forces password-only
    auth (avoids burning the target's MaxAuthTries with default pubkeys)."""
    lines = [ln for ln in (command or "").splitlines() if ln.strip()]
    async with asyncio.timeout(timeout_s):
        async with asyncssh.connect(host, port=port, username=username, password=password,
                                    known_hosts=None,
                                    client_keys=client_keys or []) as conn:
            if len(lines) <= 1:
                stdin_input = (password + "\n") if sudo else None
                r = await conn.run(command, input=stdin_input)
                return r.exit_status or 0, (r.stdout or ""), (r.stderr or "")
            stdout_parts: list[str] = []
            stderr_parts: list[str] = []
            last_ec = 0
            for ln in lines:
                stdin_input = (password + "\n") if sudo else None
                r = await conn.run(ln, input=stdin_input)
                stdout_parts.append(r.stdout or "")
                stderr_parts.append(r.stderr or "")
                if r.exit_status:
                    last_ec = r.exit_status
            return last_ec, "\n".join(stdout_parts), "\n".join(stderr_parts)


async def _direct_exec_many(host: str, port: int, username: str, password: str,
                            commands: list, timeout_s: int, sudo: bool,
                            client_keys: list[str] | None = None) -> list:
    """Run several commands in one SSH session. Returns per-command transcripts.

    ``client_keys`` (paths) enables key auth; see ``_direct_exec``."""
    out = []
    async with asyncio.timeout(timeout_s):
        async with asyncssh.connect(host, port=port, username=username, password=password,
                                    known_hosts=None,
                                    client_keys=client_keys or []) as conn:
            for cmd in commands:
                stdin_input = (password + "\n") if sudo else None
                r = await conn.run(cmd, input=stdin_input)
                out.append({"cmd": cmd, "exit": r.exit_status or 0,
                            "stdout": (r.stdout or "")[:2000], "stderr": (r.stderr or "")[:1000]})
    return out


async def _direct_shell_block(host: str, port: int, username: str, password: str,
                              commands: list, timeout_s: int,
                              client_keys: list[str] | None = None) -> list:
    """Pipe `commands` as one stdin stream into an interactive shell session,
    then `exit`. Required for FortiOS multi-line config blocks: `conn.run()`
    opens a fresh channel per call, so `config system interface` exits its
    config-mode the moment the channel closes and the next line lands at the
    root prompt as "Unknown action 0". Sending everything through a single
    PTY-backed session keeps the CLI's mode context across lines.

    Returns a single-entry list (one merged transcript) to match the
    `exec_many_*` shape. Exit status is the process return code.

    ``client_keys`` (paths) enables key auth; see ``_direct_exec``.
    """
    out: list[dict] = []
    async with asyncio.timeout(timeout_s):
        async with asyncssh.connect(host, port=port, username=username, password=password,
                                    known_hosts=None,
                                    client_keys=client_keys or []) as conn:
            proc = await conn.create_process(term_type="xterm")
            proc.stdin.write("\n".join(commands) + "\nexit\n")
            await proc.stdin.drain()
            result = await proc.wait()
            out.append({"cmd": "\n".join(commands),
                        "exit": result.exit_status or 0,
                        "stdout": (result.stdout or "")[:8000],
                        "stderr": (result.stderr or "")[:1000]})
    return out


async def _pod_connect(pod_host, pod_user, pod_pass):
    """One authenticated pod SSH connection, password first then key.

    An FS pod's API password is not necessarily an SSH credential -- some pods
    are key-only -- so a password refusal falls back to the identity
    ``configured_pod_key`` resolves. The key is deliberately the SECOND choice:
    ``ssh -G`` reports default identities for hosts with no config block, and
    offering those first burns the target's MaxAuthTries.
    """
    from fabric_studio.channels.jump import _is_pod_auth_failure, configured_pod_key
    try:
        return await asyncssh.connect(pod_host, port=22, username=pod_user,
                                      password=pod_pass, known_hosts=None,
                                      client_keys=[])
    except Exception as e:
        key = configured_pod_key(pod_host) if _is_pod_auth_failure(e) else None
        if not key:
            raise
        return await asyncssh.connect(pod_host, port=22, username=pod_user,
                                      known_hosts=None, client_keys=[key])


async def _jump_exec_many(pod_host, pod_user, pod_pass, dev_ip, dev_user, dev_pass,
                          commands: list, timeout_s: int, sudo: bool) -> list:
    """ssh-jump via pod-shell bash + SSH_ASKPASS. Reuses one pod SSH session
    for multiple inner-SSH commands (avoids re-authenticating to the pod per
    command). Each command still runs a separate inner SSH."""
    out = []
    async with asyncio.timeout(timeout_s):
        async with await _pod_connect(pod_host, pod_user, pod_pass) as conn:
            for cmd in commands:
                inner = cmd if not sudo else f"echo {dev_pass!r} | sudo -S {cmd}"
                payload = build_password_payload(dev_ip, dev_user, dev_pass, inner,
                                                 marker=JUMP_MARKER)
                full = _fs_wrap(payload)
                r = await conn.run(full)
                stdout_raw = r.stdout or ""
                clean, _trail_rc = _strip_fs_exit_trailer(stdout_raw)
                inner_out, inner_rc = split_marked(clean, JUMP_MARKER)
                out.append({"cmd": cmd, "exit": inner_rc,
                            "stdout": inner_out[:2000],
                            "stderr": (r.stderr or "")[:1000]})
    return out


def exec_many_direct(device, pod, commands: list, timeout_s: int, sudo: bool = False,
                     shell_block: bool = False) -> list:
    """Public: run command list against device via external SSH port. Raises on connection error.

    `shell_block=True` pipes all commands through one interactive shell -- use
    for FortiOS config blocks (mode context must survive across lines).
    Default mode runs each command in its own channel.
    """
    port = external_port(device.port_idx, "SSH")
    creds = resolve_device_credentials(device)
    if not creds:
        raise RuntimeError("no device credentials configured")
    if shell_block:
        return asyncio.run(_direct_shell_block(pod.host, port, creds[0], creds[1],
                                               commands, timeout_s))
    return asyncio.run(_direct_exec_many(pod.host, port, creds[0], creds[1], commands, timeout_s, sudo))


def exec_many_jump(device, pod, commands: list, timeout_s: int, sudo: bool = False) -> list:
    """Public: run command list against device via pod jump host."""
    if not device.mgmt_ip:
        raise RuntimeError("device has no mgmt IP for jump")
    creds = resolve_device_credentials(device)
    if not creds:
        raise RuntimeError("no device credentials configured")
    pu, pp = resolve_pod_credentials(pod)
    return asyncio.run(_jump_exec_many(pod.host, pu, pp, device.mgmt_ip, creds[0], creds[1],
                                       commands, timeout_s, sudo))


from fabric_studio.channels.fs_console import exec_many as exec_many_fs_console  # noqa: E402

CHANNEL_EXEC = {
    "ssh-direct": exec_many_direct,
    "ssh-jump":   exec_many_jump,
    "fs-console": exec_many_fs_console,
}


async def _jump_exec(pod_host: str, pod_user: str, pod_pass: str,
                     dev_ip: str, dev_user: str, dev_pass: str,
                     command: str, timeout_s: int, sudo: bool) -> tuple:
    """Single-command jump-SSH via pod-shell. Thin wrapper over the unified
    ``fabric_studio.channels.jump`` transport -- kept as an async-named function so
    callers in async contexts (fs_mcp, ansible) can ``await`` it, and so
    tests can monkeypatch it (``ssh._jump_exec``).

    Delegates to the SYNC ``jump_exec`` **on a worker thread**. The
    ``to_thread`` hop is the whole point, not incidental: ``jump_exec`` drives
    its own ``asyncio.run`` internally, and ``asyncio.run`` raises
    ``RuntimeError: asyncio.run() cannot be called from a running event loop``
    when the calling thread already has one. Calling it inline made this
    coroutine unusable by every async caller it was written for -- awaiting it,
    or driving it with ``asyncio.run``, both put a loop on this thread and the
    inner ``asyncio.run`` then blew up. Running on a fresh thread gives the
    inner call the loop-free thread it requires.

    Live-verified: this failed 100% of the time in the services phase (every
    rpc-permit / onboarding-prereq / FGT register-device call returned rc=1 with
    that RuntimeError plus a "coroutine '_jump_async' was never awaited"
    warning), so a fabric booted and clustered fine but no device ever reached
    its FortiManager. Unit tests missed it because they monkeypatch this
    function with a plain async fake that has no nested ``asyncio.run``.

    Threading is safe here: ``jump_exec`` is self-contained (opens its own
    asyncssh connection, shares no state) and the retry/transient-error
    handling stays exactly where it was rather than being reimplemented."""
    from fabric_studio.channels.jump import jump_exec
    rc, stdout, stderr = await asyncio.to_thread(
        jump_exec, pod_host, pod_user, pod_pass, dev_ip,
        auth={"type": "password", "user": dev_user,
              "password": dev_pass, "sudo": sudo},
        command=command, timeout_s=timeout_s)
    return rc, stdout, stderr


def _result(exit_code: int, stdout: str, stderr: str, elapsed_ms: int) -> ProbeResult:
    return ProbeResult(ok=True, status_code=exit_code, text=stdout, body=None,
                       elapsed_ms=elapsed_ms, meta={"stderr": stderr[:2000]})


def probe_direct(spec: dict, device, pod, params: dict[str, Any], timeout_s: int = 15) -> ProbeResult:
    """ssh-direct: SSH to device via external port-forwarded SSH port."""
    if not any(a.get("type") == "SSH" for a in (device.public_accesses or [])):
        return ProbeResult(ok=False, error="device has no public SSH access")
    port = external_port(device.port_idx, "SSH")
    creds = resolve_device_credentials(device)
    if not creds:
        return ProbeResult(ok=False, error="no device credentials configured")
    cmd = _render(spec.get("ssh_command") or "", {"vm_id": device.vm_id, "port_idx": device.port_idx, **params})
    if not cmd:
        return ProbeResult(ok=False, error="ssh_command is required")
    sudo = bool(spec.get("sudo_password_input"))
    t0 = time.time()
    try:
        ec, out, err = asyncio.run(_direct_exec(pod.host, port, creds[0], creds[1], cmd, timeout_s, sudo))
    except TimeoutError:
        return ProbeResult(ok=False, error="SSH connection timed out.",
                           elapsed_ms=int((time.time() - t0) * 1000))
    except Exception as e:
        return ProbeResult(ok=False, error=humanize(e),
                           elapsed_ms=int((time.time() - t0) * 1000))
    return _result(ec, out, err, int((time.time() - t0) * 1000))


def probe_jump(spec: dict, device, pod, params: dict[str, Any], timeout_s: int = 20) -> ProbeResult:
    """ssh-jump: SSH to pod:22 with FS creds, tunnel to device mgmt_ip:22 with device creds."""
    if not device.mgmt_ip:
        return ProbeResult(ok=False, error="device has no mgmt IP")
    creds = resolve_device_credentials(device)
    if not creds:
        return ProbeResult(ok=False, error="no device credentials configured")
    cmd = _render(spec.get("ssh_command") or "", {"vm_id": device.vm_id, "port_idx": device.port_idx, **params})
    if not cmd:
        return ProbeResult(ok=False, error="ssh_command is required")
    sudo = bool(spec.get("sudo_password_input"))
    t0 = time.time()
    pu, pp = resolve_pod_credentials(pod)
    try:
        ec, out, err = asyncio.run(_jump_exec(
            pod.host, pu, pp,
            device.mgmt_ip, creds[0], creds[1],
            cmd, timeout_s, sudo))
    except TimeoutError:
        return ProbeResult(ok=False, error="SSH jump host connection timed out.",
                           elapsed_ms=int((time.time() - t0) * 1000))
    except Exception as e:
        return ProbeResult(ok=False, error=humanize(e),
                           elapsed_ms=int((time.time() - t0) * 1000))
    return _result(ec, out, err, int((time.time() - t0) * 1000))
