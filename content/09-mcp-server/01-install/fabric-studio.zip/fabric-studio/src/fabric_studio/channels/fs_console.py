"""fs-console channel: drive a VM CLI via the pod's ttyd reverse proxy.

Two flavors, gated by the device's Access policy (Fabric Studio UI: per-VM
"Allowed to" column):

  * ssh  → /ttyd/ssh/<nameid>/   — ttyd has already established SSH into
                                    the VM, so we land at a shell prompt.
  * con  → /ttyd/con/<nameid>/   — raw serial console; we have to send
                                    username + fabric.console_password.

Auth: ttyd inherits Fabric Studio's session cookie. We log in via the
existing FabricStudioClient, then attach its cookie jar to both the
precheck HTTP GET and the websocket handshake.

Frame format (ttyd wire protocol):
  client→server:  b'0' = noop          b'1' = input         b'2' = resize
  client→server:  json `{"AuthToken":""}` as the first text frame
  server→client:  b'0' = output bytes  b'1' = pong          b'2'/'3' = window meta
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import re
import time
from typing import Any

import websockets
from websockets.exceptions import ConnectionClosed, InvalidStatus

from fabric_studio.channels.base import ProbeResult
from fabric_studio.channels.errors import humanize
from fabric_studio.client import FabricStudioClient
from fabric_studio.credentials import resolve_pod_credentials
from fabric_studio.crypto import decrypt

# Default CLI login by vm_type when ttyd lands at a serial login prompt.
_CON_USERNAMES = {
    "SOAR": "csadmin",
    "FGT": "admin",
    "FMG": "admin",
    "FAZ": "admin",
    "FML": "admin",
}

# Prompt patterns covering FortiOS (`FGT-VM64 # `, `(global) # `) and
# Linux shells including bracketed prompts like `[csadmin@soar ~]$`.
# Match at end-of-buffer only.
_PROMPT_RX = re.compile(r"(?:[\w\-./\(\)\[\]~@:]+\s*[#$]\s*)\Z")
# FS-ttyd wraps real SSH so the username prompt looks like
# `Username (default 'csadmin'):` — match that variant too.
_LOGIN_RX  = re.compile(r"(?:login|username)[^:\n]*:\s*\Z", re.I)
_PASSWD_RX = re.compile(r"password[^:\n]*:\s*\Z", re.I)

# Strip ANSI/control sequences before prompt matching so a single CSI doesn't
# defeat the trailing-anchor regex.
_ANSI_RX = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b\][^\x07]*\x07")


def _render(template: str, ctx: dict[str, Any]) -> str:
    out = template
    for k, v in ctx.items():
        out = out.replace("{{" + k + "}}", str(v))
    return out


def _strip_ansi(s: str) -> str:
    return _ANSI_RX.sub("", s).replace("\r", "")


def _pod_origin(pod_host: str) -> str:
    """ttyd lives behind the same nginx that serves Fabric Studio."""
    # Fabric Studio is always HTTPS in deployed pods.
    return f"https://{pod_host}"


def _ws_url(pod_host: str, flavor: str, nameid: str) -> str:
    return f"wss://{pod_host}/ttyd/{flavor}/{nameid}/ws"


def _http_url(pod_host: str, flavor: str, nameid: str) -> str:
    return f"https://{pod_host}/ttyd/{flavor}/{nameid}/"


def _login_client(pod) -> FabricStudioClient:
    """Return a logged-in FabricStudioClient — its cookie jar gets reused for ttyd."""
    user, pw = resolve_pod_credentials(pod)
    c = FabricStudioClient(server=pod.host, username=user, password=pw, verify_ssl=False)
    c.login()
    return c


def _cookie_header(client: FabricStudioClient) -> str:
    return "; ".join(f"{c.name}={c.value}" for c in client.session.cookies)


def _precheck(client: FabricStudioClient, pod_host: str, flavor: str, nameid: str) -> tuple[bool, str]:
    """GET the ttyd page with our session. Returns (ok, reason_if_not_ok).

    200/30x → reachable. 401 → device access policy blocks this flavor.
    404 → no such VM slug. Anything else → bubble up as transport error.
    """
    try:
        r = client.session.get(_http_url(pod_host, flavor, nameid),
                               allow_redirects=False, timeout=10, verify=False)
    except Exception as e:
        return False, humanize(e)
    if r.status_code in (200, 301, 302, 303, 307, 308):
        return True, ""
    if r.status_code == 401:
        return False, (f"Device access policy blocks ttyd {flavor!r} for this session "
                       f"(open the VM's Access tab in Fabric Studio).")
    if r.status_code == 404:
        return False, f"ttyd has no '{flavor}' endpoint for nameid={nameid!r} on this pod."
    return False, f"ttyd precheck returned HTTP {r.status_code}."


async def _ws_open(pod_host: str, flavor: str, nameid: str, cookie: str):
    """Open the ttyd websocket and complete the AuthToken handshake."""
    url = _ws_url(pod_host, flavor, nameid)
    origin = _pod_origin(pod_host)
    ws = await websockets.connect(
        url,
        subprotocols=["tty"],
        additional_headers={"Cookie": cookie, "Origin": origin},
        ssl=_insecure_ssl_ctx(),
        open_timeout=10,
        max_size=2 ** 22,
    )
    # ttyd expects the initial AuthToken frame as text.
    await ws.send(json.dumps({"AuthToken": "", "columns": 200, "rows": 50}))
    return ws


def _insecure_ssl_ctx():
    import ssl
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


async def _read_until(ws, pattern: re.Pattern, timeout_s: float) -> str:
    """Accumulate server output frames (opcode '0') until pattern matches at tail.

    Returns the cleaned (ANSI-stripped) buffer. Raises asyncio.TimeoutError.
    """
    buf = ""
    deadline = time.time() + timeout_s
    while True:
        remaining = deadline - time.time()
        if remaining <= 0:
            raise TimeoutError(f"timed out waiting for {pattern.pattern!r}")
        frame = await asyncio.wait_for(ws.recv(), timeout=remaining)
        if isinstance(frame, str):
            frame = frame.encode("utf-8", "replace")
        if not frame:
            continue
        op, payload = frame[:1], frame[1:]
        if op != b"0":
            continue
        buf += payload.decode("utf-8", "replace")
        clean = _strip_ansi(buf)
        if pattern.search(clean):
            return clean


async def _send_input(ws, text: str) -> None:
    # ttyd wire protocol: client→server INPUT opcode is '0' (RESIZE is '1').
    # Send '\r' line endings — terminal Enter key, not shell newline.
    await ws.send(b"0" + text.encode("utf-8"))


# login/username prompt OR an already-settled shell prompt — either ends a nudge.
_LOGIN_OR_PROMPT_RX = re.compile(r"(?:login|username)[^:\n]*:|[#$]\s*\Z", re.I)


async def _settle_console(ws, username: str | None, password: str | None,
                          timeout_s: float) -> tuple[bool, str]:
    """Walk a ttyd console session to a shell prompt, tolerating both flavors
    and the auto-login serial console. Returns ``(ok, how)``.

    ``how`` is ``'auto-login'`` (serial getty dropped straight to a shell —
    no creds needed, e.g. the Linux builder's ``autologin.conf``), ``'login'``
    (sent username + password), or a short failure reason.

    The ``ssh`` flavor prints ``Username (default '…'):`` then ``password:``;
    the ``con`` flavor either auto-logs-in or shows ``login:`` → ``Password:``.
    Nudge with ctrl-c/enter a few times — the ttyd backend may still be
    spinning up when we attach, and a lone newline isn't always enough to
    surface a prompt.
    """
    for _ in range(4):
        try:
            await _send_input(ws, "\x03\r")
            buf = await _read_until(ws, _LOGIN_OR_PROMPT_RX, timeout_s)
        except TimeoutError:
            continue
        except Exception as e:
            return False, f"console read failed: {humanize(e)}"
        if _PROMPT_RX.search(buf):
            return True, "auto-login"
        # login/username prompt → need creds
        if not username:
            return False, "login prompt but no username available"
        if not password:
            return False, "login prompt but no password available"
        try:
            await _send_input(ws, username + "\r")
            await _read_until(ws, _PASSWD_RX, timeout_s)
        except Exception as e:
            return False, f"no password prompt after username ({humanize(e)})"
        try:
            await _send_input(ws, password + "\r")
            await _read_until(ws, _PROMPT_RX, timeout_s)
        except Exception as e:
            return False, f"no shell prompt after password ({humanize(e)})"
        return True, "login"
    return False, "no login or shell prompt after nudges"


async def _exec_session(pod_host: str, device, flavor: str, cookie: str,
                        console_password: str | None,
                        commands: list[str], timeout_s: int) -> list[dict[str, Any]]:
    nameid = device.nameid
    if not nameid:
        raise RuntimeError("device has no Fabric Studio nameid — re-run discovery")
    ws = await _ws_open(pod_host, flavor, nameid, cookie)
    out: list[dict[str, Any]] = []
    try:
        # Both flavors can prompt for login. fabric.console_password covers SSH
        # and serial for FortiOS-family VMs; the Linux builder auto-logs-in
        # (autologin.conf) and needs no password. _settle_console handles both.
        username = _CON_USERNAMES.get(device.vm_type, "admin")
        ok, how = await _settle_console(ws, username, console_password, timeout_s)
        if not ok:
            raise RuntimeError(f"console did not reach a shell prompt: {how}")
        for cmd in commands:
            await _send_input(ws, cmd + "\r")
            transcript = await _read_until(ws, _PROMPT_RX, timeout_s)
            # Trim everything before the last newline that precedes the trailing prompt.
            body = transcript.split(cmd, 1)[-1] if cmd in transcript else transcript
            # Drop the trailing prompt itself.
            body = _PROMPT_RX.sub("", body).rstrip()
            out.append({"cmd": cmd, "exit": 0,
                        "stdout": body[:4000], "stderr": ""})
    finally:
        with contextlib.suppress(Exception):
            await ws.close()
    return out


def _pick_flavor(spec: dict) -> list[str]:
    """spec.flavor: 'ssh' | 'con' | 'auto' (default). auto tries ssh, falls back to con."""
    f = (spec.get("flavor") or "auto").lower()
    if f == "ssh":
        return ["ssh"]
    if f == "con":
        return ["con"]
    return ["ssh", "con"]


def _resolved(pod, flavors: list[str], nameid: str) -> tuple[str | None, str, str]:
    """Run prechecks; return (chosen_flavor, cookie_header, last_error_if_none_chosen)."""
    client = _login_client(pod)
    cookie = _cookie_header(client)
    last = ""
    for flavor in flavors:
        ok, why = _precheck(client, pod.host, flavor, nameid)
        if ok:
            return flavor, cookie, ""
        last = why
    return None, cookie, last


def probe(spec: dict, device, pod, params: dict[str, Any], timeout_s: int = 20) -> ProbeResult:
    """fs-console probe — spec: {flavor?: 'ssh'|'con'|'auto', command: str}."""
    if not device.nameid:
        return ProbeResult(ok=False, error="device has no Fabric Studio nameid — re-run discovery")
    cmd = _render(spec.get("command") or "", {"vm_id": device.vm_id,
                                              "port_idx": device.port_idx,
                                              "nameid": device.nameid,
                                              **params})
    if not cmd:
        return ProbeResult(ok=False, error="command is required")
    flavors = _pick_flavor(spec)
    t0 = time.time()
    try:
        flavor, cookie, why = _resolved(pod, flavors, device.nameid)
    except Exception as e:
        return ProbeResult(ok=False, error=humanize(e),
                           elapsed_ms=int((time.time() - t0) * 1000))
    if not flavor:
        return ProbeResult(ok=False, error=why or "no ttyd flavor reachable",
                           elapsed_ms=int((time.time() - t0) * 1000))
    console_pw = decrypt(pod.console_password_enc) if pod.console_password_enc else ""
    try:
        results = asyncio.run(_exec_session(pod.host, device, flavor, cookie,
                                            console_pw, [cmd], timeout_s))
    except TimeoutError as e:
        return ProbeResult(ok=False, error=f"fs-console ({flavor}) timed out: {e}",
                           elapsed_ms=int((time.time() - t0) * 1000))
    except ConnectionClosed:
        # ttyd closes the websocket without a Close frame when its inner
        # SSH/serial session dies — usually means the device kicked us
        # (concurrent-admin limit, auth throttle, post-config kick).
        # Surface that intent instead of the websockets-library jargon.
        return ProbeResult(ok=False,
                           error=f"fs-console ({flavor}): ttyd session terminated "
                                 f"by device (likely SSH/serial session dropped)",
                           elapsed_ms=int((time.time() - t0) * 1000))
    except InvalidStatus as e:
        return ProbeResult(ok=False, error=f"fs-console ({flavor}) http error: {humanize(e)}",
                           elapsed_ms=int((time.time() - t0) * 1000))
    except Exception as e:
        return ProbeResult(ok=False, error=humanize(e),
                           elapsed_ms=int((time.time() - t0) * 1000))
    r = results[0]
    return ProbeResult(ok=True, status_code=r["exit"], text=r["stdout"],
                       elapsed_ms=int((time.time() - t0) * 1000),
                       meta={"flavor": flavor})


def exec_many(device, pod, commands: list[str], timeout_s: int, sudo: bool = False) -> list[dict[str, Any]]:
    """Scenario setup/teardown entry point. sudo is ignored (no shell-sudo on FortiOS CLI)."""
    if not device.nameid:
        raise RuntimeError("device has no Fabric Studio nameid — re-run discovery")
    flavor, cookie, why = _resolved(pod, _pick_flavor({}), device.nameid)
    if not flavor:
        raise RuntimeError(why or "no ttyd flavor reachable")
    console_pw = decrypt(pod.console_password_enc) if pod.console_password_enc else ""
    return asyncio.run(_exec_session(pod.host, device, flavor, cookie,
                                     console_pw, commands, timeout_s))
