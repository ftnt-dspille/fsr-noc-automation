"""Common shape for probe results across channels."""
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ProbeResult:
    ok: bool                                 # transport-level success (got a response / command ran)
    status_code: int | None = None        # http status (api channels) or exit code (ssh)
    body: Any = None                         # parsed JSON / dict / text
    text: str = ""                           # raw text/stdout
    elapsed_ms: int = 0
    error: str = ""
    meta: dict[str, Any] = field(default_factory=dict)


class ChannelError(Exception):
    pass
