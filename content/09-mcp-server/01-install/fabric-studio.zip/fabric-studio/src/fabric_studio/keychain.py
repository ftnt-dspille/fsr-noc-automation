"""Keychain-backed access for secrets (pod / device passwords, FortiCare creds).

Keeps credentials OUT of ``.env`` / git / shell history: store a secret once
with ``tools/fsh_secret.py`` and the tools read it back at run-time via the
`keyring <https://pypi.org/project/keyring/>`_ library. ``keyring`` talks to the
platform secret store directly (the login Keychain on macOS, the Secret Service
on Linux, Credential Manager on Windows) -- the password never lands on an argv,
in a dotfile, or in the repo.

Convention: every secret is stored under service ``fabric-studio-fixer``
(``SERVICE``), keyed by an ``account`` string:

  * a **pod host** (e.g. ``fabric-studio.example.com``) → the
    FS pod login password, resolved by ``resolve_pod_login``.
  * a **group** account → the shared login of one group of pods. Groups are the user's own, in an optional
    ``~/.fsh/pod-groups.toml`` (``$FSH_POD_GROUPS_FILE``) that maps host patterns to accounts, e.g.
    ``"*.example.com" = "pod-default-cloud"``. Tried before ``pod-default`` (``pod_group_account``).
  * ``pod-default`` (``DEFAULT_POD_ACCOUNT``) → the password for every pod with
    no per-host entry (pods that share one login).
  * a named secret like ``forticare-user`` / ``forticare-pass`` → the SOAR
    ``.bin`` FortiCare credentials, resolved by ``get_secret``.

On macOS every read and write goes through Apple's ``/usr/bin/security`` tool first. The Keychain remembers
"Always Allow" per program, and a Python inside a virtualenv or a ``uv tool`` install is a new program each time
it is rebuilt, so reads through ``keyring`` asked again after every reinstall. ``security`` has one fixed path:
one "Always Allow" lasts, and items written through it already trust it, so they never ask.

No usable backend (``keyring`` missing, or a headless host with no keyring
daemon): every getter returns ``None`` and the callers fall back to the DB Pod
row / env, so nothing breaks on Linux/CI.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
import threading

try:
    import keyring
    import keyring.errors
except ImportError:  # pragma: no cover - keyring is a declared dependency
    keyring = None

SERVICE = "fabric-studio-fixer"
DEFAULT_POD_ACCOUNT = "pod-default"
def _pod_groups() -> list[tuple[str, str]]:
    """``(pattern, account)`` pairs from the pod-groups file, in file order; empty without one. Patterns are
    shell-style (``*.example.com``, ``10.0.*``) and match the pod's host, case-insensitively."""
    from pathlib import Path
    path = Path(os.environ.get("FSH_POD_GROUPS_FILE") or Path.home() / ".fsh" / "pod-groups.toml").expanduser()
    if not path.is_file():
        return []
    import tomllib
    try:
        data = tomllib.loads(path.read_text())
    except (OSError, tomllib.TOMLDecodeError) as e:
        print(f"[warn] ignoring {path}: {e}", file=sys.stderr)
        return []
    groups = data.get("groups", data)
    return [(str(k), str(v)) for k, v in groups.items() if isinstance(v, str) and v]


def _pattern_matches(pattern: str, host: str) -> bool:
    """A pod-groups pattern against a host. IP patterns (``10.0.*``) match only IP addresses, and hostname
    patterns match label by label, so ``*`` never spans a dot (``*.example.com`` is not ``a.b.evil/.example.com``
    or ``evil.example.com.attacker.net``)."""
    import ipaddress
    from fnmatch import fnmatchcase
    pattern, host = pattern.strip().lower().rstrip("."), host.strip().lower().rstrip(".")
    try:
        ipaddress.ip_address(host)
        is_ip = True
    except ValueError:
        is_ip = False
    if re.fullmatch(r"[0-9.*?\[\]-]+", pattern) or ":" in pattern:   # an IP pattern
        return is_ip and fnmatchcase(host, pattern)
    if is_ip:
        return False
    p_labels, h_labels = pattern.split("."), host.split(".")
    return len(p_labels) == len(h_labels) and all(fnmatchcase(h, p) for h, p in zip(h_labels, p_labels, strict=True))


def pod_group_account(host: str) -> str | None:
    """The shared-login account of the first pod group whose pattern matches ``host``, else ``None``."""
    return next((account for pattern, account in _pod_groups() if _pattern_matches(pattern, host or "")), None)


class CredsError(Exception):
    """No usable credentials found (raised by ``resolve_pod_login``)."""


class KeychainBlocked(CredsError):
    """The keyring did not answer in time: on macOS, an access dialog is waiting."""


# ``security find-generic-password -g`` writes the password to stderr as ``password: "text"``, or as
# ``password: 0x<hex>  "..."`` when the bytes are not plain printable ASCII, or ``password: `` when empty.
_PW_LINE = re.compile(r'^password:(?: (?:0x([0-9A-Fa-f]+)(?:\s.*)?|"(.*)"))?\s*$', re.M | re.S)
# exit codes that are a refusal, not a missing item: the user clicked Deny (128), or no dialog can be shown
# (a locked keychain over SSH: 36 "user interaction is not allowed", 51)
_REFUSED = {36, 51, 128}


def _keychain_args() -> list[str]:
    """``FSH_KEYCHAIN_FILE`` points every ``security`` call at another keychain file (the tests use a throwaway
    one, so they never touch the login keychain)."""
    f = os.environ.get("FSH_KEYCHAIN_FILE")
    return [f] if f else []


def _parse_g(stderr: str) -> str | None:
    m = _PW_LINE.search(stderr.strip())
    if not m:
        return None
    if m[1]:
        return bytes.fromhex(m[1]).decode("utf-8", "replace")
    return m[2] if m[2] is not None else ""


def _security_cli(account: str, service: str) -> tuple[bool, str | None]:
    """macOS only: read the item with ``security``. ``(True, value)`` when it answered (``value`` is ``None``
    for no such item), ``(False, None)`` when it did not answer in time (a dialog is waiting). A refusal
    (Deny, or a keychain locked with no way to ask) raises ``CredsError``: a second try through ``keyring``
    would only ask again or fail the same way."""
    if sys.platform != "darwin":
        return False, None
    try:
        p = subprocess.run([SECURITY, "find-generic-password", "-s", service, "-a", account, "-g", *_keychain_args()],
                           capture_output=True, text=True, timeout=_timeout_s())
    except subprocess.TimeoutExpired:
        return False, None
    except OSError:
        return False, None
    if p.returncode == 0:
        return True, _parse_g(p.stderr)
    if p.returncode == 44:   # no such item
        return True, None
    if p.returncode in _REFUSED or "interaction is not allowed" in p.stderr.lower():
        raise CredsError(f"the keychain refused to give out {account!r} ({p.stderr.strip() or p.returncode}). "
                         "If you clicked Deny, run the command again and allow it; over SSH, unlock it first "
                         "with `security unlock-keychain`.")
    return False, None


def has_item(account: str, service: str = SERVICE) -> bool | None:
    """macOS only: whether an item exists, read from its attributes alone, which never asks for permission.
    ``None`` off macOS or when ``security`` did not answer."""
    if sys.platform != "darwin":
        return None
    try:
        p = subprocess.run([SECURITY, "find-generic-password", "-s", service, "-a", account, *_keychain_args()],
                           capture_output=True, text=True, timeout=_timeout_s())
    except (OSError, subprocess.TimeoutExpired):
        return None
    return True if p.returncode == 0 else (False if p.returncode == 44 else None)


_SAFE_KEY = re.compile(r"[A-Za-z0-9._:@/+~-]+")   # one word for `security -i`: no spaces or quotes
SECURITY = "/usr/bin/security"


def _security_set(account: str, password: str, service: str) -> bool:
    """macOS only: create or update the item with ``security``, trusting ``security`` itself so later reads
    never ask. The password goes in as hex on standard input (``security -i``), never on a command line."""
    if sys.platform != "darwin" or not (_SAFE_KEY.fullmatch(account) and _SAFE_KEY.fullmatch(service)):
        return False
    if any(not _SAFE_KEY.fullmatch(k) for k in _keychain_args()):
        raise CredsError("FSH_KEYCHAIN_FILE must be a path without spaces or quotes")
    kc = "".join(f" {k}" for k in _keychain_args())
    # Replace by delete + add: `-U` (update in place) left no readable item when tried on macOS, and a fresh
    # item gets a fresh access list that trusts `security`.
    if _security_delete(account, service) is None and has_item(account, service):
        return False
    line = (f"add-generic-password -s {service} -a {account} -T {SECURITY} "
            f"-X {password.encode().hex()}{kc}\n")
    try:
        p = subprocess.run([SECURITY, "-i"], input=line, capture_output=True, text=True, timeout=_timeout_s())
    except (OSError, subprocess.TimeoutExpired):
        return False
    if p.returncode != 0:
        return False
    # ``security -i`` can exit 0 when the command inside failed: read the item back instead of trusting it
    try:
        found, value = _security_cli(account, service)
    except CredsError:
        return False
    return found and value == password


def _security_delete(account: str, service: str) -> bool | None:
    """macOS only: delete with ``security``. True deleted, False no such item, None not answered."""
    if sys.platform != "darwin":
        return None
    try:
        p = subprocess.run([SECURITY, "delete-generic-password", "-s", service, "-a", account, *_keychain_args()],
                           capture_output=True, text=True, timeout=_timeout_s())
    except (OSError, subprocess.TimeoutExpired):
        return None
    return True if p.returncode == 0 else (False if p.returncode == 44 else None)


def _timeout_s() -> float:
    try:
        return float(os.environ.get("FSH_KEYCHAIN_TIMEOUT_S", "20"))
    except ValueError:
        return 20.0


_KEYRING_STUCK = False


def _mark_stuck() -> None:
    """One keyring call that never answered (a locked Secret Service with no GUI, say) marks the backend
    unusable for the rest of this process, so later reads fail at once instead of each waiting out the limit.
    Not on macOS, where a timeout means one item's dialog is waiting, not a dead backend."""
    global _KEYRING_STUCK
    if sys.platform != "darwin":
        _KEYRING_STUCK = True


def get_secret(account: str, service: str = SERVICE) -> str | None:
    """Read a secret from the platform keyring, or ``None`` if absent / no
    usable backend. Any keyring error (locked store, no daemon) degrades to
    ``None`` so callers fall back to DB / env.

    A read that does not return within ``FSH_KEYCHAIN_TIMEOUT_S`` (20 s) raises
    ``KeychainBlocked``. On macOS that means an "allow access" dialog is waiting
    for the user (the usual cause: the venv's Python was rebuilt, so every item
    needs approving again); without the limit the caller hangs with no sign why.
    """
    # macOS: Apple's own tool first, so one "Always Allow" lasts across Python rebuilds (see the module notes).
    found, cli_value = _security_cli(account, service)
    if found:
        return cli_value
    if sys.platform == "darwin":
        # Never fall back to keyring on macOS: it asks as this Python, which is the dialog that comes back after
        # every reinstall. `security` not answering means a dialog of its own is waiting, or the item is unreadable.
        raise _blocked(account)
    if keyring is None or _KEYRING_STUCK:
        return None
    done, value = _bounded(lambda: keyring.get_password(service, account) or None, account, on_error=None)
    if not done:
        _mark_stuck()
        raise _blocked(account)
    return value["value"]  # type: ignore[index]


def _blocked(account: str) -> KeychainBlocked:
    return KeychainBlocked(
        f"The system keychain did not answer for {account!r} within {_timeout_s():g}s. "
        + ("On macOS a dialog asking to let 'security' use this item may be waiting (it can be behind other "
           "windows): click Always Allow, then try again."
           if sys.platform == "darwin" else "A dialog or a locked keyring may be waiting; unlock it and try again."))


def _bounded(fn, account: str, *, on_error: object) -> tuple[bool, object]:
    """Run one keyring call in a daemon thread, at most ``FSH_KEYCHAIN_TIMEOUT_S``. Returns ``(done, value)``;
    ``done`` is False when the call is still waiting (a macOS access dialog). A ``KeyringError`` gives
    ``on_error``; any other error is raised here, not swallowed in the thread."""
    box: dict[str, object] = {}

    def call() -> None:
        try:
            box["value"] = fn()
        except keyring.errors.KeyringError as e:
            box["value"], box["keyring_error"] = on_error, e
        except Exception as e:
            box["error"] = e

    t = threading.Thread(target=call, name=f"keychain:{account}", daemon=True)
    t.start()
    t.join(_timeout_s())
    if t.is_alive():
        return False, None
    if "error" in box:
        raise box["error"]  # type: ignore[misc]
    return True, box


def set_secret(account: str, password: str, service: str = SERVICE) -> None:
    """Create/update a secret in the platform keyring. Raises ``CredsError`` if
    no keyring backend is available or the store rejects the write."""
    if not password:
        raise CredsError(f"refusing to store an empty password for {account!r}")
    if _security_set(account, password, service):
        return
    if sys.platform == "darwin":
        # Never fall back to keyring here: it stores the item for this Python only, the very item that asks
        # again after every reinstall (and it ignores FSH_KEYCHAIN_FILE, so a test would reach the login keychain).
        raise CredsError(f"the macOS keychain did not store {account!r} (security add-generic-password failed)")
    if keyring is None:
        raise CredsError("keyring is not installed (`uv pip install keyring`)")
    done, box = _bounded(lambda: keyring.set_password(service, account, password), account, on_error=None)
    if not done:
        raise _blocked(account)
    if "keyring_error" in box:  # type: ignore[operator]
        raise CredsError(f"keyring could not store secret: {box['keyring_error']}")  # type: ignore[index]


def delete_secret(account: str, service: str = SERVICE) -> bool:
    """Remove a secret. Returns True if one was deleted, False if none existed
    or there's no usable backend."""
    gone = _security_delete(account, service)
    if gone is not None:
        return gone
    if keyring is None:
        return False
    done, box = _bounded(lambda: keyring.delete_password(service, account), account, on_error=None)
    return done and "keyring_error" not in box  # type: ignore[operator]


_DB_LOOKUP_WARNED: set[str] = set()


def _db_lookup_is_expected(e: BaseException) -> bool:
    """Is this DB miss a normal deployment shape rather than a fault?

    The Pod table is optional (see ``resolve_pod_login``): plenty of installs
    never migrate it, or don't have sqlmodel at all. Both raise on every single
    call, so reporting them as warnings buries a tool's real output -- a prune
    run resolves credentials three times and printed six lines of stack-adjacent
    noise before its first result. A genuinely broken DB (corrupt file, bad
    permissions) is a different thing and still gets reported.
    """
    if isinstance(e, ImportError):          # sqlmodel/fabric_studio.db not installed
        return True
    msg = str(e).lower()
    return "no such table" in msg or "no such column" in msg   # never migrated


def _note_db_lookup_failure(host: str, e: BaseException) -> None:
    """Report a DB credential-lookup failure at most once per host per process,
    and not at all for the expected shapes above (unless ``FSH_DEBUG`` is set)."""
    if os.environ.get("FSH_DEBUG"):
        print(f"[debug] DB pod-cred lookup failed for {host}: {e!r}", file=sys.stderr)
        return
    if _db_lookup_is_expected(e) or host in _DB_LOOKUP_WARNED:
        return
    _DB_LOOKUP_WARNED.add(host)
    print(f"[warn] DB pod-cred lookup failed: {e}", file=sys.stderr)


def resolve_pod_login(host: str, user: str | None = None,
                      pw: str | None = None, *, host_checked: bool = False) -> tuple[str, str]:
    """Resolve (username, password) for an FS pod, preferring the Keychain for
    the password so it never lives in ``.env``. Order:

      1. explicit ``user``+``pw`` (CLI flags) win outright;
      2. **password** ← Keychain (account = ``host``), else the DB Pod row, else
         ``$POD_PASSWORD``, else the Keychain group login (``pod_group_account``), else ``pod-default``;
      3. **username** ← flag, else the DB Pod row, else ``$POD_USERNAME``, else
         ``"admin"``.

    Raises ``CredsError`` if no password can be found anywhere -- the caller
    (each tool's ``_pod_creds``) turns that into a clean ``sys.exit``."""
    if user and pw:
        return user, pw

    db_user = db_pw = None
    try:  # DB is a convenience, not a requirement.
        from sqlmodel import select

        from fabric_studio.credentials import resolve_pod_credentials
        from fabric_studio.db import get_session
        from fabric_studio.models import Pod
        with get_session() as s:
            pod = s.exec(select(Pod).where(Pod.host == host)).first()
            if pod:
                db_user, db_pw = resolve_pod_credentials(pod)
    except Exception as e:
        _note_db_lookup_failure(host, e)

    resolved_user = user or db_user or os.environ.get("POD_USERNAME") or "admin"
    blocked: KeychainBlocked | None = None
    host_pw = None
    if not pw and not host_checked:
        try:
            host_pw = get_secret(host)
        except KeychainBlocked as e:   # one blocked item: fall through, like a missing one
            blocked = e
            print(f"[warn] {e} Falling back to the shared pod login.", file=sys.stderr)
    resolved_pw = pw or host_pw or db_pw or os.environ.get("POD_PASSWORD")
    # then the shared login of the pod's group, then the one shared by every pod
    for account in (pod_group_account(host), DEFAULT_POD_ACCOUNT):
        if resolved_pw or not account:
            continue
        try:
            resolved_pw = get_secret(account)
        except KeychainBlocked as e:
            blocked = blocked or e
    if not resolved_pw:
        if blocked:
            raise blocked
        raise CredsError(
            f"No password for pod {host!r}: store one with "
            f"`uv run python -m tools.fsh_secret set {host}` (or `set {pod_group_account(host) or DEFAULT_POD_ACCOUNT}` "
            f"for every pod), pass --pod-pass, "
            f"or add a Pod row / $POD_PASSWORD.")
    return resolved_user, resolved_pw
