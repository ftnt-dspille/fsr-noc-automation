"""Reusable Fortinet authentication primitives.

Both the onboarding wizard (one-shot 'did the password work' probes) and
the device-api channel (sustained 'call any endpoint with the resulting
session') need the same login flows. This module hosts them in one place
so the wizard and the channel can't drift apart in subtle ways (e.g. a
back-compat field flipped on one side but not the other).

Three Fortinet auth families are supported, each modeled on a piece of
the user's existing proven code:

  fortigate_login()       ./api/v2/authentication
                          ~/PycharmProjects/Miscellaneous/fgt/new_fgt_auth/
                          fortios_api.py
                          Returns the bearer/csrf token + cookies a follow-
                          up request must send back.

  fortimanager_login()    POST /jsonrpc with /sys/login/user
                          ~/PycharmProjects/ConnectorsV2/
                          fortinet-fortianalyzer/operations.py
                          Returns the session token; subsequent JSON-RPC
                          calls embed it as `"session": <token>` in the
                          envelope.

  soar_login()            POST /auth/authenticate
                          Mirror of device_api.py:probe's fsr-jwt mode.
                          Returns the Bearer JWT to put in Authorization.

Each function returns either:
  - LoginOk(...) carrying the credentials to attach to follow-ups, or
  - LoginErr(reason) describing why auth failed in operator-readable terms

so callers can branch cleanly without sniffing exception types.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import httpx

# ── Return shapes ──────────────────────────────────────────────────────────

@dataclass
class LoginOk:
    """Auth succeeded. The caller chooses which bits to send back:

      headers   — Authorization / X-CSRFTOKEN / etc to add to subsequent requests
      cookies   — cookie jar entries (FortiGate's ccsrf_token, etc) to forward
      session   — bare session string (FMG/FAZ embed this in JSON-RPC bodies)
      status_code  — HTTP status of the login response (for telemetry)
    """
    headers: dict[str, str] = field(default_factory=dict)
    cookies: dict[str, str] = field(default_factory=dict)
    session: str = ""
    status_code: int | None = None


@dataclass
class LoginErr:
    """Auth failed. `reason` is operator-readable. `status_code` is the
    HTTP status of the auth attempt when one came back, else None.

    `transport_failed` distinguishes 'we never got a usable response from
    the device' (network error / TLS error / HTML-from-FS / 5xx / non-
    JSON body) from 'we got a clean response, it just rejected the
    credentials'. The operator can fix the second class by changing the
    password; the first class needs investigation (device still booting,
    install incomplete, port-forward misconfigured, etc.) and is not a
    credential problem.
    """
    reason: str
    status_code: int | None = None
    transport_failed: bool = False


# ── Shared helpers ─────────────────────────────────────────────────────────

def _looks_like_html(response) -> bool:
    """Distinguish 'device not actually serving the auth endpoint' from
    'credentials rejected'. On Fabric Studio pods the HTTPS port-forward
    can return an FS-generated HTML error page with HTTP 200 when the
    device's web service isn't responding."""
    ct = (response.headers.get("content-type") or "").lower()
    if "html" in ct:
        return True
    body = (response.text or "").lstrip()[:80]
    return body.startswith("<")


# ── FortiGate / FortiMail ──────────────────────────────────────────────────

def fortigate_login(host: str, port: int, username: str, password: str,
                    timeout_s: int = 10) -> LoginOk | LoginErr:
    """POST /api/v2/authentication with the back-compatible payload
    (username + password + secretkey + ack_post_disclaimer + request_key).
    Detects success two ways so both newer (7.x with ccsrf_token cookie)
    and older (6.x with session_key in body) FortiOS releases work."""
    payload = {
        "username": username,
        "password": password,
        "secretkey": password,             # back-compat alias for pre-7.0
        "ack_post_disclaimer": True,
        "request_key": True,
    }
    try:
        with httpx.Client(verify=False, timeout=timeout_s,
                          follow_redirects=False) as client:
            r = client.post(f"https://{host}:{port}/api/v2/authentication",
                            json=payload)
    except Exception as e:
        return LoginErr(reason=f"network error: {e}"[:300], transport_failed=True)

    if r.status_code >= 500:
        return LoginErr(
            reason=f"FortiGate /api/v2/authentication returned HTTP {r.status_code}",
            status_code=r.status_code, transport_failed=True,
        )
    if _looks_like_html(r):
        return LoginErr(
            reason="device HTTPS port-forward returned HTML (FS error page or "
                   "wrong endpoint) — device web service may not be running",
            status_code=r.status_code, transport_failed=True,
        )

    # Newer FortiOS: ccsrf_token cookie. Use it as both the X-CSRFTOKEN
    # header and a forwarded cookie — different endpoints want different
    # combinations and sending both is universally accepted.
    for name, value in r.cookies.items():
        if "ccsrf_token" in name.lower() and value:
            stripped = value.strip('"')
            return LoginOk(
                headers={"X-CSRFTOKEN": stripped},
                cookies={name: value for name, value in r.cookies.items()},
                status_code=r.status_code,
            )

    # Older FortiOS: session_key in body, used as Bearer.
    try:
        sk = (r.json() or {}).get("session_key")
    except Exception:
        sk = None
    if sk:
        return LoginOk(
            headers={"Authorization": f"Bearer {sk}"},
            session=sk,
            status_code=r.status_code,
        )

    return LoginErr(
        reason="FortiGate auth returned no ccsrf_token cookie or session_key — "
               "bad credentials",
        status_code=r.status_code,
    )


# ── FortiManager / FortiAnalyzer (JSON-RPC) ────────────────────────────────

def fortimanager_login(host: str, port: int, username: str, password: str,
                       timeout_s: int = 10) -> LoginOk | LoginErr:
    """POST /jsonrpc with the exec /sys/login/user envelope. Same protocol
    pyFMG and the fortinet-fortianalyzer FortiSOAR connector use. Success =
    non-empty `session` token in the response body."""
    payload = {
        "method": "exec",
        "params": [
            {"url": "/sys/login/user",
             "data": {"user": username, "passwd": password}},
        ],
        "id": 1,
    }
    try:
        with httpx.Client(verify=False, timeout=timeout_s,
                          follow_redirects=False) as client:
            r = client.post(f"https://{host}:{port}/jsonrpc", json=payload,
                            headers={"Accept": "application/json"})
    except Exception as e:
        return LoginErr(reason=f"network error: {e}"[:300], transport_failed=True)

    if r.status_code >= 500:
        return LoginErr(
            reason=f"FMG/FAZ /jsonrpc returned HTTP {r.status_code}",
            status_code=r.status_code, transport_failed=True,
        )
    if _looks_like_html(r):
        return LoginErr(
            reason="device HTTPS port-forward returned HTML (FS error page or "
                   "wrong endpoint) — device web service may not be running",
            status_code=r.status_code, transport_failed=True,
        )
    try:
        body = r.json() or {}
    except Exception:
        return LoginErr(
            reason="FMG/FAZ /jsonrpc returned non-JSON response",
            status_code=r.status_code, transport_failed=True,
        )

    # Explicit failure marker first — "Login fail" is the canonical wrong-
    # password message FMG/FAZ return inside result[0].status.message.
    results = body.get("result") or []
    first = results[0] if results else {}
    status = (first.get("status") or {}) if isinstance(first, dict) else {}
    msg = status.get("message", "")
    if msg == "Login fail":
        return LoginErr(
            reason="FMG/FAZ rejected credentials (Login fail)",
            status_code=r.status_code,
        )

    session = body.get("session")
    if isinstance(session, str) and session:
        return LoginOk(session=session, status_code=r.status_code)

    # Catch-all: surface FMG's own error message if present so the user
    # has something actionable (most common: code -11 "No permission for
    # the resource" → the admin user needs `set rpc-permit read-write`).
    err = body.get("error") or {}
    detail = err.get("message") if isinstance(err, dict) else None
    return LoginErr(
        reason=detail or msg or "FMG/FAZ auth returned no session token",
        status_code=r.status_code,
    )


# ── FortiSOAR (Django REST) ────────────────────────────────────────────────

def soar_login(host: str, port: int, username: str, password: str,
               timeout_s: int = 10) -> LoginOk | LoginErr:
    """POST /auth/authenticate with {credentials: {loginid, password}}.
    Success = HTTP 200 + `token` in body. Mirrors the existing fsr-jwt
    flow in device_api.py."""
    try:
        with httpx.Client(verify=False, timeout=timeout_s,
                          follow_redirects=False) as client:
            r = client.post(
                f"https://{host}:{port}/auth/authenticate",
                json={"credentials": {"loginid": username, "password": password}},
            )
    except Exception as e:
        return LoginErr(reason=f"network error: {e}"[:300], transport_failed=True)

    if r.status_code != 200:
        # 401/403 = SOAR clearly rejected the creds (auth fail); 5xx = SOAR
        # itself broke (transport-ish). 4xx other than 401/403 we treat as
        # auth-side too since the device DID respond cleanly.
        return LoginErr(
            reason=f"SOAR /auth/authenticate returned HTTP {r.status_code}",
            status_code=r.status_code,
            transport_failed=(r.status_code >= 500),
        )
    if _looks_like_html(r):
        return LoginErr(
            reason="device HTTPS port-forward returned HTML — device web "
                   "service may not be running",
            status_code=r.status_code, transport_failed=True,
        )
    try:
        tok = r.json().get("token")
    except Exception:
        tok = None
    if not tok:
        return LoginErr(
            reason="SOAR auth returned 200 but no token in body",
            status_code=r.status_code,
        )
    return LoginOk(
        headers={"Authorization": f"Bearer {tok}"},
        session=tok,
        status_code=r.status_code,
    )
