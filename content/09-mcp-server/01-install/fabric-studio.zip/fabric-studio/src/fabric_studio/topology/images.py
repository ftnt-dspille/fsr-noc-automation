"""Image hook for the reconciler: uploading firmware and building images before a fabric is applied.

Image builds (a Packer qcow on a builder VM, an LXC image) need the ``fabric_studio_terraform`` checkout,
so this module only answers for that checkout when it is importable (``backend.fabric.images``). Without it,
an intent that declares no ``images:`` plans and applies as normal, and one that declares any is refused
with a message saying what is missing, instead of silently skipping the build.
"""
from __future__ import annotations

from typing import Any


class ImageBuildUnavailable(RuntimeError):
    """The intent declares ``images:`` but no image builder is installed."""


def _builder():
    try:
        from backend.fabric import images as real
    except ImportError:
        return None
    return real


def _refuse(intent) -> None:
    raise ImageBuildUnavailable(
        "this intent declares images: (firmware to upload or build), which needs the fabric_studio_terraform "
        "checkout. Run it from there, or remove images: and use firmware already on the pod.")


def plan_images(c, intent) -> list:
    real = _builder()
    if real:
        return real.plan_images(c, intent)
    if intent.images:
        _refuse(intent)
    return []


def resolve_image_ids(c, intent) -> dict[str, int]:
    real = _builder()
    if real:
        return real.resolve_image_ids(c, intent)
    if intent.images:
        _refuse(intent)
    return {}


def ensure_images(c, intent, progress=None) -> dict[str, int]:
    real = _builder()
    if real:
        return real.ensure_images(c, intent, progress)
    if intent.images:
        _refuse(intent)
    return {}


def run_deferred_builds(c, intent, image_ids: dict[str, int], progress=None) -> Any:
    real = _builder()
    if real:
        return real.run_deferred_builds(c, intent, image_ids, progress)
    if intent.images:
        _refuse(intent)
    return {}
