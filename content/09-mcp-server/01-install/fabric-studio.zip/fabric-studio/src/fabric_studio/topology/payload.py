"""Repository-root discovery and ``/fabric`` payload packing.

Two things live here, both of which used to be copy-pasted into every topology's
``make_confs.py``:

* :func:`repo_root` -- find the checkout root by walking up for a marker. This
  was previously a fixed number of ``os.path.dirname`` calls in each script,
  which is wrong the moment a file moves: the ``soc_stack`` copy used three and
  overshot the root by one, so it failed with a "missing payload dir" pointing
  at a path *outside* the repository. A marker search cannot drift.

* :func:`build_confs` -- pack a tool's ``/fabric`` lifecycle payload into a
  Fabric Studio **deviceconfig RESTORE** (.conf) archive. A tool's payload is
  the shared base lifecycle from ``devices/_base`` OVERLAID with that tool's own
  ``devices/<tool>/payload/``; the overlay wins on path collision, so a tool can
  replace ``20-run-app`` while others keep the generic one.

A topology's ``make_confs.py`` is therefore a list of tool names and one call.
"""
from __future__ import annotations

import io
import os
import re
import tarfile

# Directories/files that only ever exist at the checkout root. ``.git`` is the
# usual one; the others keep this working in an exported tree that has no git
# metadata (a release tarball, a container build context).
_ROOT_MARKERS = (".git", "devices/_base", "pyproject.toml")

# Base lifecycle files (arcnames under ``fabric/``) pulled from devices/_base.
BASE_FILES = ("init", "setup.d/10-docker-up", "setup.d/20-run-app",
              "setup.d/40-tls-front")
# Build-time-only / demo-app files in the base dir that are never shipped.
BASE_SKIP = frozenset({"install-docker.sh", "README.md", "setup.d/15-app-tls",
                       "app/app.env"})


def repo_root(start: str | None = None) -> str:
    """Return the checkout root at or above ``start`` (default: this file).

    Raises :class:`FileNotFoundError` rather than returning a plausible-looking
    wrong directory -- a silently wrong root is what produced the misleading
    "missing payload dir" pointing outside the repository.
    """
    current = os.path.abspath(start or os.path.dirname(__file__))
    while True:
        for marker in _ROOT_MARKERS:
            if os.path.exists(os.path.join(current, marker)):
                return current
        parent = os.path.dirname(current)
        if parent == current:
            raise FileNotFoundError(
                f"no repository root above {start or __file__!r} -- looked for "
                + ", ".join(_ROOT_MARKERS))
        current = parent


def collect_payload(base_dir: str, tool_dir: str, *,
                    base_files: tuple[str, ...] = BASE_FILES) -> dict[str, str]:
    """Return ``{arcname-under-fabric: on-disk path}``; the tool overlay wins.

    ``base_files`` selects which ``devices/_base/`` files to include (default:
    all of ``BASE_FILES``). A tool that needs fewer (e.g. branchsvc uses only
    ``init``, fitng uses ``init`` + ``10-docker-up``) passes a subset."""
    members: dict[str, str] = {}
    for rel in base_files:
        if rel in BASE_SKIP:
            continue
        disk = os.path.join(base_dir, rel)
        if os.path.isfile(disk):
            members[f"fabric/{rel}"] = disk
    for root, dirs, files in os.walk(tool_dir):
        dirs.sort()
        rel_root = os.path.relpath(root, tool_dir)
        for fn in sorted(files):
            # macOS resource forks and Finder metadata must never reach a guest.
            if fn.startswith("._") or fn == ".DS_Store":
                continue
            rel = fn if rel_root == "." else os.path.join(rel_root, fn)
            members[f"fabric/{rel}"] = os.path.join(root, fn)
    return members


def write_conf(members: dict[str, str], out_path: str, *, quiet: bool = False) -> int:
    """Write the ``.conf`` archive. Returns its size in bytes.

    The archive is deterministic -- uid/gid/mtime are zeroed and entries are
    sorted -- so re-running with unchanged inputs produces a byte-identical file
    and does not show up as a spurious change.
    """
    if "fabric/init" not in members:
        raise SystemExit(f"no fabric/init for {out_path} -- base dir wrong?")

    def _filter(ti: tarfile.TarInfo) -> tarfile.TarInfo:
        ti.uid = ti.gid = 0
        ti.uname = ti.gname = ""
        ti.mtime = 0
        base = os.path.basename(ti.name)
        # init and every setup.d step must be executable in the guest.
        ti.mode = 0o755 if (base == "init" or "/setup.d/" in ("/" + ti.name)) else 0o644
        ti.pax_headers = {}
        return ti

    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz", format=tarfile.GNU_FORMAT) as tf:
        for arc in sorted(members):
            tf.add(members[arc], arcname=arc, filter=_filter)
    payload = buf.getvalue()
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with open(out_path, "wb") as fh:
        fh.write(payload)
    if not quiet:
        print(f"[make-confs] wrote {out_path} ({len(payload)} bytes)")
        for arc in sorted(members):
            print(f"    {arc}")
    return len(payload)


def build_confs(topology_dir: str, tools: list[str] | tuple[str, ...], *,
                out_subdir: str = "confs", quiet: bool = False) -> dict[str, str]:
    """Build ``<topology_dir>/<out_subdir>/<tool>.conf`` for each tool.

    Returns ``{tool: conf_path}``. This is the whole body of a topology's
    ``make_confs.py``.
    """
    topology_dir = os.path.abspath(topology_dir)
    root = repo_root(topology_dir)
    base_dir = os.path.join(root, "devices", "_base")
    if not os.path.isdir(base_dir):
        raise SystemExit(f"missing base lifecycle dir: {base_dir}")

    written: dict[str, str] = {}
    for tool in tools:
        tool_dir = os.path.join(root, "devices", tool, "payload")
        if not os.path.isdir(tool_dir):
            raise SystemExit(f"missing payload dir: {tool_dir}")
        out_path = os.path.join(topology_dir, out_subdir, f"{tool}.conf")
        write_conf(collect_payload(base_dir, tool_dir), out_path, quiet=quiet)
        written[tool] = out_path
    return written


def build_deviceconfig(spec: dict, out_dir: str, *, name: str | None = None,
                       quiet: bool = True) -> str:
    """Build a single derived ``.conf`` from a ``deviceconfig: {device: ...}`` spec.

    ``spec`` is the parsed dict: ``{device: <name>, base?: [files], exclude?:
    [globs], inject?: {arcname: content}}``. ``exclude`` globs match the path
    under ``/fabric`` (``agent-images/*``) and drop those payload files. The ``device`` names a directory under ``devices/``;
    its ``payload/`` subdir is overlaid on ``devices/_base/`` (the ``base`` key
    selects which base files to include; default: all). ``inject`` adds synthetic
    files (e.g. per-node ``branch.env``) as in-tar content, not on-disk files.

    ``name`` overrides the output filename (default: ``<device>.conf``). When
    ``inject`` is present, each node's ``.conf`` is unique, so the caller passes
    the node name to avoid collisions (e.g. branch_fabric's 3 nodes all use
    ``device: branchsvc`` but each injects a different ``branch.env``).

    Returns the built ``.conf`` path. Deterministic -- unchanged inputs produce
    a byte-identical file, so re-running with the same payload manufactures no
    drift (the property that makes the plan-only Ring 2 check meaningful)."""
    dev_name = _safe_name(spec["device"], "deviceconfig device")
    if name is not None:
        _safe_name(name, "deviceconfig name")
    root = repo_root(out_dir)
    base_dir = os.path.join(root, "devices", "_base")
    if not os.path.isdir(base_dir):
        raise FileNotFoundError(f"missing base lifecycle dir: {base_dir}")
    base_files = tuple(spec.get("base") or BASE_FILES)
    # Collect base + tool overlay (tool overlay is optional -- base-only is fine).
    tool_dir = os.path.join(root, "devices", dev_name, "payload")
    if os.path.isdir(tool_dir):
        members = collect_payload(base_dir, tool_dir, base_files=base_files)
    else:
        # Base-only (e.g. fitng, fb-client). dev_name == "_base" or no payload dir.
        members = {}
        for rel in base_files:
            if rel in BASE_SKIP:
                continue
            disk = os.path.join(base_dir, rel)
            if os.path.isfile(disk):
                members[f"fabric/{rel}"] = disk
    # Drop payload members the node does not need, by glob on the path under
    # /fabric (e.g. ``agent-images/*``: a gitignored local image bundle a node
    # targeting a different hub version never loads, and which made the upload
    # 240 MB -- long enough to time out the pod's import endpoint).
    excludes = list(spec.get("exclude") or [])
    if excludes:
        import fnmatch
        members = {arc: disk for arc, disk in members.items()
                   if not any(fnmatch.fnmatch(arc[len("fabric/"):], pat)
                              for pat in excludes)}
    # Inject synthetic files (per-node env, authorized_keys, etc.).
    inject = spec.get("inject") or {}
    if inject:
        for arc in inject:
            _safe_arcname(arc)
        inject = _resolve_inject(inject, root)
    out_name = (name or dev_name) + ".conf"
    out_path = os.path.join(out_dir, out_name)
    if inject:
        _write_conf_with_inject(members, inject, out_path, quiet=quiet)
    else:
        write_conf(members, out_path, quiet=quiet)
    return out_path


_SAFE_NAME = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.-]*$")


def _safe_name(value: object, what: str) -> str:
    """A device or output name is one path segment: it is joined into a path, so no separators or ``..``."""
    if not isinstance(value, str) or not _SAFE_NAME.fullmatch(value):
        raise ValueError(f"{what} {value!r} must be letters, digits, '_', '-' or '.' (one path segment)")
    return value


def _safe_arcname(arc: object) -> str:
    """An injected file lands in the payload under ``fabric/``, never outside it."""
    parts = str(arc).split("/")
    if parts[0] != "fabric" or len(parts) < 2 or any(p in ("", "..", ".") for p in parts):
        raise ValueError(f"inject path {arc!r} must be a relative path under fabric/")
    return str(arc)


def _resolve_inject(inject: dict, root: str) -> dict[str, str]:
    """Resolve ``${file:path}`` references in inject values to file contents.

    A ``${file:path}`` reference reads the file at ``path`` (relative to the repo
    root) and substitutes its contents. If the file doesn't exist and ends with
    ``.pub``, the matching private key is generated (ed25519, idempotent) -- this
    is the branch_fabric keypair carve-out: the keypair is generated on first
    build, not by a separate ``make_confs.py``.

    References are resolved **anywhere in the value**, not only when the whole
    value is one reference. The anchored version silently left an embedded
    reference as literal text: a setup script that heredocs a public key into
    ``authorized_keys`` shipped the string ``${file:.../lab_key.pub}`` as the key,
    so the guest came up with an authorized_keys file containing no key, key-only
    SSH refused every login, and nothing in plan/apply ever reported a problem --
    the payload was internally consistent, just wrong."""
    import re as _re
    _FILE_RE = _re.compile(r"\$\{file:(.+?)\}")
    resolved: dict[str, str] = {}

    root_real = os.path.realpath(root)

    def _read(rel: str, arc: str) -> str:
        disk = os.path.join(root, rel)
        # a reference reads a file in the workspace, never one elsewhere on the machine
        if os.path.isabs(rel) or os.path.commonpath([root_real, os.path.realpath(disk)]) != root_real:
            raise ValueError(f"inject {arc!r}: ${{file:{rel}}} must name a file inside the workspace")
        if not os.path.isfile(disk) and disk.endswith(".pub"):
            priv = disk[:-4]  # strip .pub → private key path
            # generating a key writes to this path: it must be a plain location inside the workspace
            if os.path.islink(priv) or os.path.commonpath([root_real, os.path.realpath(priv)]) != root_real:
                raise ValueError(f"inject {arc!r}: will not generate a key at {rel[:-4]!r} (a link, or outside the workspace)")
            _ensure_keypair(priv)
        if not os.path.isfile(disk):
            raise FileNotFoundError(f"inject {arc!r}: file not found: {disk}")
        with open(disk) as fh:
            return fh.read().strip()

    for arc, val in inject.items():
        if not isinstance(val, str):
            resolved[arc] = str(val)
            continue
        # A value that is EXACTLY one reference keeps the old semantics (the
        # whole value becomes the file, surrounding whitespace dropped).
        m = _FILE_RE.fullmatch(val.strip())
        if m:
            resolved[arc] = _read(m.group(1), arc)
            continue
        resolved[arc] = _FILE_RE.sub(lambda mm: _read(mm.group(1), arc), val)
    return resolved


def _ensure_keypair(priv_path: str) -> None:
    """Generate an ed25519 keypair at ``priv_path`` if it doesn't exist.
    Idempotent -- no-op if the private key is already present."""
    if os.path.isfile(priv_path):
        return
    os.makedirs(os.path.dirname(priv_path) or ".", exist_ok=True)
    import subprocess
    subprocess.run(
        ["ssh-keygen", "-t", "ed25519", "-N", "", "-f", priv_path,
         "-C", "fsh-branch-fabric"],
        check=True, capture_output=True, text=True)


def _write_conf_with_inject(members: dict[str, str], inject: dict[str, str],
                            out_path: str, *, quiet: bool = False) -> int:
    """Like :func:`write_conf` but adds synthetic (in-memory) members from
    ``inject``. The inject keys are arcnames (``fabric/app/branch.env``); the
    values are the file contents as strings."""
    if "fabric/init" not in members and not any(k == "fabric/init" for k in inject):
        raise SystemExit(f"no fabric/init for {out_path} -- base dir wrong?")

    def _filter(ti: tarfile.TarInfo) -> tarfile.TarInfo:
        ti.uid = ti.gid = 0
        ti.uname = ti.gname = ""
        ti.mtime = 0
        base = os.path.basename(ti.name)
        ti.mode = 0o755 if (base == "init" or "/setup.d/" in ("/" + ti.name)) else 0o644
        ti.pax_headers = {}
        return ti

    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz", format=tarfile.GNU_FORMAT) as tf:
        inject_keys = set(inject)
        for arc in sorted(members):
            if arc in inject_keys:
                continue
            tf.add(members[arc], arcname=arc, filter=_filter)
        for arc in sorted(inject):
            data = inject[arc].encode()
            ti = tarfile.TarInfo(arc)
            ti.size = len(data)
            tf.addfile(_filter(ti), io.BytesIO(data))
    payload = buf.getvalue()
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with open(out_path, "wb") as fh:
        fh.write(payload)
    if not quiet:
        print(f"[make-confs] wrote {out_path} ({len(payload)} bytes)")
        for arc in sorted(members):
            print(f"    {arc}")
        for arc in sorted(inject):
            print(f"    {arc} (injected)")
    return len(payload)


def build_deviceconfigs(intent, base_dir: str | None = None) -> dict[str, str]:
    """Scan an Intent's nodes for derived ``deviceconfig`` entries and build them.

    For each node with ``nd.device`` set (the derived form -- a dict like
    ``{device: branchsvc, base: [init], inject: {...}}``), this builds a `.conf`
    into ``.fabric/confs/<fabric>/<name>.conf`` (relative to the repo root) and
    replaces ``nd.provision_config`` with the built path. Nodes with literal-path
    ``provision_config`` are untouched.

    Returns ``{node_name: conf_path}``. Called before ``plan`` and ``apply`` so
    the reconciler sees the freshly-built `.conf` and can detect drift."""
    written: dict[str, str] = {}
    if not any(getattr(nd, "device", None) for nd in intent.nodes):
        return written   # nothing to build: a topology with no device payloads needs no checkout
    root = repo_root(base_dir or os.path.dirname(__file__))
    out_dir = os.path.join(root, ".fabric", "confs", _safe_name(intent.fabric, "fabric name"))
    os.makedirs(out_dir, exist_ok=True)
    for nd in intent.nodes:
        spec = getattr(nd, "device", None)
        if not spec:
            continue
        # When inject is present, each node's .conf is unique (per-node env etc.)
        # -- name the output after the NODE to avoid collisions between nodes that
        # share the same device (e.g. branch_fabric's 3 branchsvc nodes).
        name = nd.name if spec.get("inject") else None
        path = build_deviceconfig(spec, out_dir, name=name)
        nd.provision_config = path
        written[nd.name] = path
    return written
