"""Validate, plan and apply a fabric intent.

The MCP ``build`` tool calls ``load``, ``lint`` and ``summarise`` in-process for the read-only steps, and
starts ``python -m fabric_studio.topology.run apply ...`` as a detached process for the apply, because a
build takes minutes and the agent must not hold a request open for it. The detached process reads the pod
login from ``FS_POD_HOST`` / ``FS_POD_USER`` / ``FS_POD_PASS`` (never argv), holds the pod lock for the
whole run, and prints ``converged ✓`` as its last line when the fabric is up.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from typing import Any

from fabric_studio import admin as fa
from fabric_studio.topology import lock as lock_mod
from fabric_studio.topology import payload
from fabric_studio.topology import reconciler as rec

CONVERGED = "converged ✓"


def load(path: str, *, host: str | None = None, variables: dict[str, Any] | None = None) -> rec.Intent:
    """Parse an intent file, with ``variables`` overriding its ``variables:`` defaults. Raises on a
    structural error; never contacts a pod."""
    overrides = tuple(f"{k}={v}" for k, v in (variables or {}).items())
    intent = rec.load_intent(path, pod_host=host, var_overrides=overrides)
    payload.build_deviceconfigs(intent, base_dir=os.path.dirname(os.path.abspath(path)))
    return intent


def lint(intent: rec.Intent) -> tuple[list[str], list[str]]:
    """Cross-resource checks that need no pod: ``(errors, warnings)``."""
    errors = list(rec._lint_topology(intent, None))
    warnings: list[str] = []   # the live-state warnings (floating switches, DHCP) come with the plan
    seen: set[str] = set()
    for n in intent.nodes:
        if n.name in seen:
            errors.append(f"duplicate node name {n.name!r}")
        seen.add(n.name)
    return errors, warnings


def check_firmware(c, intent: rec.Intent) -> tuple[dict[str, dict[str, Any]], list[str]]:
    """Resolve every node's firmware on the pod now, so a version the pod lacks fails the plan and not the
    apply half way through. Returns ``({node: {id, name}}, errors)``; an error names the versions the pod has."""
    found: dict[str, dict[str, Any]] = {}
    errors: list[str] = []
    for nd in intent.nodes:
        try:
            fid = rec._resolve_firmware_id(c, nd)
        except fa.FabricStudioAdminError as e:
            errors.append(str(e))
            continue
        if fid is None:
            errors.append(f"node {nd.name!r}: no usable {nd.type} firmware on the pod")
            continue
        row = next((f for f in fa.list_all_firmwares(c, nd.type) if int(f.get("id") or 0) == fid), {})
        found[nd.name] = {"id": fid, "name": os.path.basename(str(row.get("path") or "")) or row.get("name")}
    return found, errors


def shape(intent: rec.Intent) -> dict[str, Any]:
    return {"fabric": intent.fabric, "nodes": [{"name": n.name, "type": n.type} for n in intent.nodes],
            "networks": [n.name for n in intent.networks], "switches": [s.name for s in intent.switches]}


def summarise(plan: rec.Plan) -> dict[str, Any]:
    """The facts a person approves a plan on: counts, what is blocked, what is reinstalled."""
    ops: dict[str, int] = {}
    for ch in plan.changes:
        ops[ch.op] = ops.get(ch.op, 0) + 1
    return {"changes": {k: v for k, v in ops.items() if k != "noop"},
            "unchanged": ops.get("noop", 0),
            "nodes_to_create": sorted(c.name for c in plan.changes if c.kind == "node" and c.op == "create"),
            "reinstalls": plan.reinstall_nodes,
            "deletes": [f"{c.kind} {c.name}" for c in plan.changes if c.op in ("delete", "replace")],
            "warnings": list(plan.warnings), "errors": list(plan.errors),
            "blocked": bool(plan.errors), "has_changes": bool(plan.mutating), "text": plan.render()}


def _say(message: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {message}", flush=True)


def apply_intent(c, intent: rec.Intent, *, host: str, prune: bool = False, boot_timeout_s: int = 900) -> bool:
    """Plan, then apply under the pod lock. True when the fabric converged."""
    lock_mod.check_lockout(host, intent.fabric)
    handle = lock_mod.acquire(host, fabric=intent.fabric, progress=_say)
    try:
        plan = rec.plan(c, intent, prune=prune)
        print(plan.render(), flush=True)
        if plan.errors:
            print("BLOCKED: fix the topology first", flush=True)
            return False
        summary = rec.apply(c, intent, prune=prune, boot=True, boot_timeout_s=boot_timeout_s, progress=_say)
        conv = summary.get("convergence", {})
        for w in conv.get("warnings", []):
            print(f"  ! {w}", flush=True)
        print(json.dumps(summary, indent=2, default=str), flush=True)
        if not conv.get("ok"):
            print(f"convergence FAILED: missing {conv.get('missing')}", flush=True)
            return False
        print(CONVERGED, flush=True)
        return True
    finally:
        lock_mod.release(handle)


def main(argv: list[str] | None = None) -> int:
    import urllib3
    urllib3.disable_warnings()   # pods use self-signed certificates: one warning per request would fill the log
    ap = argparse.ArgumentParser(prog="python -m fabric_studio.topology.run")
    ap.add_argument("verb", choices=("apply",))
    ap.add_argument("intent")
    ap.add_argument("--host", required=True)
    ap.add_argument("--var", action="append", default=[], metavar="NAME=VALUE")
    ap.add_argument("--prune", action="store_true")
    ap.add_argument("--boot-timeout", type=int, default=900)
    args = ap.parse_args(argv)

    from fabric_studio.admin import FabricStudioAdminError
    from fabric_studio.client.client import FabricStudioClient

    user, password = os.environ.get("FS_POD_USER", ""), os.environ.get("FS_POD_PASS", "")
    if not (user and password):
        print("FS_POD_USER and FS_POD_PASS must be set in the environment", file=sys.stderr)
        return 2
    variables = dict(v.split("=", 1) for v in args.var)
    try:
        intent = load(args.intent, host=args.host, variables=variables)
        c = FabricStudioClient(args.host, user, password, timeout_s=60)
        ok = apply_intent(c, intent, host=args.host, prune=args.prune, boot_timeout_s=args.boot_timeout)
    except (FabricStudioAdminError, lock_mod.LockError, lock_mod.LockoutError, ValueError, FileNotFoundError) as e:
        print(f"apply FAILED: {e}", flush=True)
        return 1
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
