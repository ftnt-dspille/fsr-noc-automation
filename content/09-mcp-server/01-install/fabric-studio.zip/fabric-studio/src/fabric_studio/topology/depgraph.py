"""Dependency graph for the intent layer (Phase 5).

The graph is built from the parsed ``Intent`` -- NOT from live state (that's
``core/topology_graph.py``, which is network reachability and a different
object). This graph drives the **provision phase ordering**: a topological
walk replaces the old ``for _idx, spec in enumerate(intent.config)`` so
``depends_on:`` edges, not list position, sequence the items.

Edges (all directed, ``a → b`` means ``a`` must complete before ``b``):

* explicit ``depends_on`` (node→node, provision-item→provision-item, or
  cross: provision-item→node)
* node → its switches → its networks (a node can't provision until its L2 is up)
* provision item → its own node (the item can't run until the node is booted)
* provision item → that node's ``wait_for:`` gate (the item waits for readiness)

Cycle detection runs at parse time with the path in the error. The walk is
**serial** (concurrency capped at 1) -- list order stays the tiebreaker among
independent items so existing intents behave identically. No new race surface.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from fabric_studio.topology.reconciler import ConfigSpec, Intent


@dataclass
class DepNode:
    """A node in the dependency graph. ``kind`` is ``node`` or ``provision``."""
    kind: str               # "node" | "provision"
    name: str               # node name, or provision label (or "item:<idx>")
    spec: Any               # the NodeSpec or ConfigSpec
    # Nodes that must complete before this one. Each is a ``DepNode.ref`` string
    # (``node:fgt1`` or ``provision:enroll``).
    deps: set[str] = field(default_factory=set)


class DependencyGraph:
    """The provision-ordering dependency graph. Built from an ``Intent``."""

    def __init__(self, intent: Intent):
        self.intent = intent
        self.nodes: dict[str, DepNode] = {}
        self._build()

    def _ref(self, kind: str, name: str) -> str:
        return f"{kind}:{name}"

    def _add(self, kind: str, name: str, spec: Any) -> DepNode:
        ref = self._ref(kind, name)
        if ref not in self.nodes:
            self.nodes[ref] = DepNode(kind=kind, name=name, spec=spec)
        return self.nodes[ref]

    def _build(self) -> None:
        """Build the graph from the intent. All edges are directed (dep → dependent)."""
        # 1. Register all nodes and provision items.
        for nd in self.intent.nodes:
            self._add("node", nd.name, nd)
        for idx, spec in enumerate(self.intent.config):
            name = spec.label or f"item:{idx}"
            self._add("provision", name, spec)

        # 2. Node → switches → networks (L2 must be up before the node).
        sw_names = {s.name for s in self.intent.switches}
        for nd in self.intent.nodes:
            nd_ref = self._ref("node", nd.name)
            for lk in nd.links:
                if lk.switch in sw_names:
                    # The switch is implicitly up when the fabric is converged;
                    # we don't model switch deps explicitly, but a node that
                    # depends_on another node waits for that node's readiness.
                    pass

        # 3. Explicit depends_on on nodes (can reference another node OR a
        #    provision item by label).
        for nd in self.intent.nodes:
            nd_ref = self._ref("node", nd.name)
            for dep in nd.depends_on:
                dep_node = self._ref("node", dep)
                dep_prov = self._ref("provision", dep)
                if dep_node in self.nodes:
                    self.nodes[nd_ref].deps.add(dep_node)
                elif dep_prov in self.nodes:
                    self.nodes[nd_ref].deps.add(dep_prov)
                else:
                    raise ValueError(
                        f"node {nd.name!r} depends_on {dep!r} -- no such node "
                        f"or provision label")

        # 4. Provision item → its node (item can't run until node is booted).
        #    Provision item → that node's wait_for gate (item waits for readiness).
        for idx, spec in enumerate(self.intent.config):
            name = spec.label or f"item:{idx}"
            item_ref = self._ref("provision", name)
            if spec.node:
                node_ref = self._ref("node", spec.node)
                if node_ref not in self.nodes:
                    raise ValueError(
                        f"provision item {name!r} targets undeclared node "
                        f"{spec.node!r}")
                self.nodes[item_ref].deps.add(node_ref)
                # If the node has a wait_for (ready) gate, the item also depends
                # on it -- but the wait_for runs in the guest phase, which Phase 5
                # flips to BEFORE provision. So the gate is already satisfied
                # when the provision phase starts. We model it as a node dep
                # (already done above), not a separate gate dep.

        # 5. Explicit depends_on on provision items (by label or node name).
        for idx, spec in enumerate(self.intent.config):
            name = spec.label or f"item:{idx}"
            item_ref = self._ref("provision", name)
            for dep in spec.depends_on:
                # A dep can be a provision label or a node name.
                dep_prov = self._ref("provision", dep)
                dep_node = self._ref("node", dep)
                if dep_prov in self.nodes:
                    self.nodes[item_ref].deps.add(dep_prov)
                elif dep_node in self.nodes:
                    self.nodes[item_ref].deps.add(dep_node)
                else:
                    raise ValueError(
                        f"provision item {name!r} depends_on {dep!r} -- no such "
                        f"provision label or node")

        # 6. Phase 6: implicit depends_on from ${node.<name>.outputs.<key>}
        #    references in provision item vars. A reference to node X's outputs
        #    means this item depends on the provision item that targets X.
        import re
        _node_output_re = re.compile(r"\$\{node\.(\w+)\.outputs\.(\w+)\}")
        # Map node name → provision items that target it.
        node_to_items: dict[str, list[str]] = {}
        for idx, spec in enumerate(self.intent.config):
            if spec.node:
                name = spec.label or f"item:{idx}"
                node_to_items.setdefault(spec.node, []).append(name)
        for idx, spec in enumerate(self.intent.config):
            if not spec.vars:
                continue
            name = spec.label or f"item:{idx}"
            item_ref = self._ref("provision", name)
            for _val in spec.vars.values():
                if not isinstance(_val, str):
                    continue
                for m in _node_output_re.finditer(_val):
                    target_node = m.group(1)
                    for target_item in node_to_items.get(target_node, []):
                        self.nodes[item_ref].deps.add(
                            self._ref("provision", target_item))

    def detect_cycles(self) -> list[str] | None:
        """Return a cycle path (list of refs) if the graph has a cycle, else None.

        DFS with a recursion stack; on finding a back-edge, reconstruct the path
        from the stack so the error names the cycle."""
        WHITE, GRAY, BLACK = 0, 1, 2
        color: dict[str, int] = {r: WHITE for r in self.nodes}
        parent: dict[str, str | None] = {r: None for r in self.nodes}

        def dfs(u: str) -> list[str] | None:
            color[u] = GRAY
            for v in sorted(self.nodes[u].deps):
                if color[v] == WHITE:
                    parent[v] = u
                    found = dfs(v)
                    if found:
                        return found
                elif color[v] == GRAY:
                    # Back-edge: reconstruct the cycle path from u back to v.
                    path = [v, u]
                    p = parent[u]
                    while p is not None and p != v:
                        path.insert(1, p)
                        p = parent[p]
                    return path
            color[u] = BLACK
            return None

        for r in sorted(self.nodes):
            if color[r] == WHITE:
                found = dfs(r)
                if found:
                    return found
        return None

    def topological_order(self) -> list[DepNode]:
        """Return a serial execution order (topological sort, list order as
        tiebreaker among independent items). Raises on cycle."""
        cycle = self.detect_cycles()
        if cycle:
            raise ValueError(
                f"dependency cycle detected: {' → '.join(cycle)} → {cycle[0]}")

        # Kahn's algorithm with a stable tiebreaker: when multiple nodes have
        # no remaining deps, pick the one with the lowest original list index.
        # This keeps existing intents behaving identically (list order is the
        # tiebreaker, so no-dep intents run in their declared order).
        order: list[DepNode] = []
        # Work on a COPY of each node's deps. This used to mutate `dn.deps` in
        # place, which left the graph consumed: a second call -- or any other
        # method reading deps, such as waves() -- saw every dep already
        # discarded and reported that everything was independent. Silent and
        # wrong rather than noisy.
        remaining = {r: set(dn.deps) for r, dn in self.nodes.items()}
        # Assign a sort key by original position: nodes first (in declared order),
        # then provision items (in declared order).
        key: dict[str, int] = {}
        for i, nd in enumerate(self.intent.nodes):
            key[self._ref("node", nd.name)] = i
        for i, spec in enumerate(self.intent.config):
            name = spec.label or f"item:{i}"
            key[self._ref("provision", name)] = 10000 + i

        while remaining:
            # Nodes with no remaining deps, sorted by original position.
            ready = sorted(
                (r for r, deps in remaining.items() if not deps),
                key=lambda r: key.get(r, 99999))
            if not ready:
                # Shouldn't happen (cycle check passed), but guard against a
                # logic error rather than hanging.
                raise ValueError(
                    f"topological sort stalled: {sorted(remaining)}")
            r = ready[0]
            del remaining[r]
            order.append(self.nodes[r])
            # Remove this ref from all remaining deps.
            for deps in remaining.values():
                deps.discard(r)
        return order

    def provision_order(self) -> list[ConfigSpec]:
        """Return just the provision items in topological order (nodes excluded)."""
        return [dn.spec for dn in self.topological_order() if dn.kind == "provision"]

    def waves(self) -> list[list[DepNode]]:
        """The same topological order, grouped into LAYERS that may run together.

        Wave N holds every node whose dependencies all live in waves < N, so
        items inside one wave are mutually independent by construction and a
        barrier between waves preserves every declared edge. Ordering inside a
        wave keeps the original list position, so a serial walk over
        ``[n for wave in waves() for n in wave]`` is a valid topological order
        and matches ``topological_order()`` closely enough to be swapped in.

        This is what ``topological_order`` throws away: it flattens to one
        item at a time, so four independent per-cluster chains ran end to end.
        Raises on cycle, like its serial twin."""
        cycle = self.detect_cycles()
        if cycle:
            raise ValueError(
                f"dependency cycle detected: {' -> '.join(cycle)} -> {cycle[0]}")

        key: dict[str, int] = {}
        for i, nd in enumerate(self.intent.nodes):
            key[self._ref("node", nd.name)] = i
        for i, spec in enumerate(self.intent.config):
            name = spec.label or f"item:{i}"
            key[self._ref("provision", name)] = 10000 + i

        remaining = {r: set(dn.deps) for r, dn in self.nodes.items()}
        out: list[list[DepNode]] = []
        while remaining:
            ready = sorted((r for r, deps in remaining.items() if not deps),
                           key=lambda r: key.get(r, 99999))
            if not ready:
                raise ValueError(
                    f"topological sort stalled: {sorted(remaining)}")
            out.append([self.nodes[r] for r in ready])
            for r in ready:
                del remaining[r]
            for deps in remaining.values():
                deps.difference_update(ready)
        return out

    def provision_waves(self) -> list[list[ConfigSpec]]:
        """``waves()`` with node entries dropped and empty waves removed.

        An all-nodes wave is normal (every provision item depends on its node
        being converged), and dropping it must not leave a hole that reads as
        "nothing to run here"."""
        out = []
        for wave in self.waves():
            specs = [dn.spec for dn in wave if dn.kind == "provision"]
            if specs:
                out.append(specs)
        return out

    def to_dot(self) -> str:
        """Render the graph as Graphviz DOT. Nodes are ellipses, provision items
        are boxes, edges are directed arrows."""
        lines = ["digraph fabric {"]
        for ref, dn in sorted(self.nodes.items()):
            shape = "ellipse" if dn.kind == "node" else "box"
            label = dn.name if dn.kind == "node" else (dn.spec.label or dn.name)
            lines.append(f'  "{ref}" [label="{label}", shape={shape}];')
        for ref, dn in sorted(self.nodes.items()):
            for dep in sorted(dn.deps):
                lines.append(f'  "{dep}" -> "{ref}";')
        lines.append("}")
        return "\n".join(lines)
