"""Per-pod state lock for the topology reconciler (Terraform-style).

PROJECT B -- topology / builder.

Fabric Studio allows only one fabric install/installing at a time per pod, and
we routinely run several agents against the same pod from the same machine. The
reconciler already calls ``fs_admin.wait_pod_idle`` to avoid stepping on an
in-flight *install*, but that doesn't stop two ``fabric apply`` runs from
interleaving their model mutations (create/cable/license) before either reaches
the install gate. This module is the coarse outer lock: one holder per pod for
the whole mutating run (apply / destroy / config).

The lock is a single file per pod under ``~/.fsh/locks/<host>.lock`` created
with ``O_CREAT | O_EXCL`` (atomic). It records the holder, pid, fabric, and a
creation timestamp. A second acquirer fails fast unless the existing lock is
*stale* -- older than ``ttl_s`` or held by a dead pid -- in which case it's broken
and re-taken. ``--force-unlock`` (``force=True``) breaks any lock unconditionally.

This is a controller-side mutex (same machine / shared home dir), which matches
the real concurrency we hit: parallel agents on one host. It is deliberately not
a distributed lock -- it does not coordinate two *different* machines hitting the
same pod. ``wait_pod_idle`` remains the backstop for that case.
"""
from __future__ import annotations

import errno
import json
import os
import re
import time
from dataclasses import dataclass

_LOCK_DIR = os.path.join(os.path.expanduser("~"), ".fsh", "locks")
# Default staleness window. A normal apply (incl. a SOAR build) can run hours,
# so this is generous; the pid-liveness check breaks dead locks much sooner.
DEFAULT_TTL_S = 6 * 3600

# Per-(pod, fabric) kill-switch, independent of the per-pod lock above: while
# a given fabric on a given pod is locked out, EVERY mutating entrypoint
# (apply/provision/services/destroy) targeting THAT pod+fabric refuses to run,
# checked before the command touches the pod at all. Other fabrics, and the
# same fabric name on a different pod, are unaffected. This is a human safety
# switch ("stop touching this one fabric on this one pod"), not concurrency
# control. `FSH_LOCKOUT` in the environment is the same switch for a single
# shell/CI job without touching shared state on disk -- set it to
# `<pod_host>:<fabric>` to lock just that pair.
_LOCKOUT_DIR = os.path.join(os.path.expanduser("~"), ".fsh", "lockouts")


class LockError(RuntimeError):
    """Raised when a pod lock is held by a live holder and ``force`` is unset."""


class LockoutError(RuntimeError):
    """Raised when a (pod, fabric) mutation kill-switch is engaged."""


def _lockout_key(pod_host: str, fabric: str) -> str:
    return f"{pod_host}:{fabric}"


def _lockout_path(pod_host: str, fabric: str) -> str:
    return os.path.join(_LOCKOUT_DIR, f"{_sanitize(_lockout_key(pod_host, fabric))}.lockout")


def lockout_engage(pod_host: str, fabric: str, reason: str = "") -> str:
    """Engage the kill-switch for ``fabric`` on ``pod_host``. Returns the lock
    file path."""
    os.makedirs(_LOCKOUT_DIR, exist_ok=True)
    path = _lockout_path(pod_host, fabric)
    payload = {
        "pod_host": pod_host, "fabric": fabric, "reason": reason,
        "by": os.environ.get("USER") or os.environ.get("LOGNAME"),
        "pid": os.getpid(), "created": time.time(),
    }
    with open(path, "w") as fh:
        json.dump(payload, fh)
    return path


def lockout_release(pod_host: str, fabric: str) -> bool:
    """Disengage the kill-switch for ``fabric`` on ``pod_host``. Returns True
    if it had been engaged."""
    try:
        os.unlink(_lockout_path(pod_host, fabric))
        return True
    except FileNotFoundError:
        return False


def lockout_status(pod_host: str, fabric: str) -> dict | None:
    """Return the lockout info dict effectively covering ``fabric`` on
    ``pod_host`` -- checking the exact (pod, fabric) entry first, then the
    pod-wide ``*`` entry -- or None if neither is engaged (file check only --
    does not consider ``FSH_LOCKOUT``)."""
    for name in (fabric, "*"):
        info = _read_lock(_lockout_path(pod_host, name))
        if info is not None:
            return info
    return None


def lockout_list() -> list[dict]:
    """Return every currently-engaged lockout (across all pods/fabrics)."""
    try:
        names = os.listdir(_LOCKOUT_DIR)
    except FileNotFoundError:
        return []
    out = []
    for n in names:
        info = _read_lock(os.path.join(_LOCKOUT_DIR, n))
        if info is not None:
            out.append(info)
    return out


def check_lockout(pod_host: str, fabric: str) -> None:
    """Raise ``LockoutError`` if ``fabric`` on ``pod_host`` is locked out --
    either directly, or because ``*`` (every fabric on that pod) is locked out
    -- via file or ``FSH_LOCKOUT``. Call this at the top of every mutating
    entrypoint -- apply/provision/services/destroy -- before any pod call,
    passing the target pod host and fabric name."""
    env = os.environ.get("FSH_LOCKOUT")
    if env and env in (_lockout_key(pod_host, fabric), _lockout_key(pod_host, "*")):
        raise LockoutError(
            f"Lockout is engaged via FSH_LOCKOUT={env!r} -- no apply/install/"
            f"destroy is permitted against fabric {fabric!r} on pod "
            f"{pod_host!r}. Unset FSH_LOCKOUT to resume.")
    for name in (fabric, "*"):
        info = _read_lock(_lockout_path(pod_host, name))
        if info is not None:
            reason = info.get("reason")
            reason_suffix = f" -- {reason}" if reason else ""
            scope = "every fabric" if name == "*" else f"fabric {fabric!r}"
            raise LockoutError(
                f"Lockout is engaged ({_lockout_path(pod_host, name)}) -- no "
                f"apply/install/destroy is permitted against {scope} "
                f"on pod {pod_host!r}. Engaged by {info.get('by')!r} at "
                f"{time.strftime('%H:%M:%S', time.localtime(float(info.get('created') or 0)))}"
                f"{reason_suffix}. Run `fs_topology.py --host {pod_host} lockout "
                f"off {name}` to resume.")


@dataclass
class LockHandle:
    pod_host: str
    path: str
    holder: str
    pid: int
    fabric: str | None
    created: float


def _sanitize(host: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]", "_", host)


def _lock_path(pod_host: str) -> str:
    return os.path.join(_LOCK_DIR, f"{_sanitize(pod_host)}.lock")


def _read_lock(path: str) -> dict | None:
    try:
        with open(path) as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def _pid_alive(pid: int) -> bool:
    if not pid or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except OSError as e:
        # ESRCH = no such process; EPERM = exists but not ours (still alive).
        return e.errno == errno.EPERM
    return True


def _is_stale(info: dict, ttl_s: int) -> bool:
    pid = int(info.get("pid") or 0)
    # A lock whose holder process is gone is always stale, regardless of age.
    if pid and pid != os.getpid() and not _pid_alive(pid):
        return True
    created = float(info.get("created") or 0)
    return (time.time() - created) > ttl_s


def acquire(pod_host: str, *, holder: str = "fabric", fabric: str | None = None,
            ttl_s: int = DEFAULT_TTL_S, force: bool = False,
            progress=None) -> LockHandle:
    """Acquire the pod lock or raise ``LockError``. Breaks a stale lock (expired
    TTL or dead holder); ``force=True`` breaks any lock. ``progress`` (callable)
    gets a one-line note when a lock is broken."""
    os.makedirs(_LOCK_DIR, exist_ok=True)
    path = _lock_path(pod_host)
    created = time.time()
    payload = {
        "holder": holder, "pid": os.getpid(), "fabric": fabric,
        "pod_host": pod_host, "created": created,
    }
    blob = json.dumps(payload).encode()

    def _create() -> LockHandle:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        try:
            os.write(fd, blob)
        finally:
            os.close(fd)
        return LockHandle(pod_host, path, holder, os.getpid(), fabric, created)

    # Retry the create / break-stale / re-create cycle a few times: unlink + the
    # follow-up _create() is NOT atomic, so a second acquirer can win the race and
    # recreate the file between our unlink and our create. Loop so that loser turns
    # into a clean LockError (or another break attempt) instead of an uncaught
    # EEXIST OSError leaking to the caller.
    info: dict = {}
    for _ in range(5):
        try:
            return _create()
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise
        # Lock exists -- decide whether to break it.
        info = _read_lock(path) or {}
        if not (force or _is_stale(info, ttl_s)):
            break
        why = "forced" if force else "stale"
        if progress:
            progress(f"breaking {why} pod lock {path} "
                     f"(held by {info.get('holder')!r} pid {info.get('pid')} "
                     f"fabric {info.get('fabric')!r})")
        try:
            os.unlink(path)
        except OSError:
            pass
        # loop: re-attempt _create(); if someone else recreated it, re-evaluate
    raise LockError(
        f"pod {pod_host} is locked by {info.get('holder')!r} (pid "
        f"{info.get('pid')}, fabric {info.get('fabric')!r}, since "
        f"{time.strftime('%H:%M:%S', time.localtime(float(info.get('created') or 0)))}). "
        f"Another fabric run is in progress -- wait for it, or pass --force-unlock "
        f"if you're certain it's dead.")


def release(handle: LockHandle | None) -> None:
    """Release a lock we hold. Only removes the file if it's still ours (a broken
    + re-taken lock by someone else must not be deleted)."""
    if handle is None:
        return
    info = _read_lock(handle.path)
    if info and int(info.get("pid") or 0) == handle.pid and \
            float(info.get("created") or 0) == handle.created:
        try:
            os.unlink(handle.path)
        except OSError:
            pass


class pod_lock:
    """Context manager around :func:`acquire`/:func:`release`.

        with pod_lock(host, fabric="topo-x", force=args.force_unlock):
            rec.apply(...)
    """

    def __init__(self, pod_host: str, *, holder: str = "fabric",
                 fabric: str | None = None, ttl_s: int = DEFAULT_TTL_S,
                 force: bool = False, progress=None):
        self._args = (pod_host,)
        self._kw = dict(holder=holder, fabric=fabric, ttl_s=ttl_s, force=force,
                        progress=progress)
        self._handle: LockHandle | None = None

    def __enter__(self) -> LockHandle:
        self._handle = acquire(*self._args, **self._kw)
        return self._handle

    def __exit__(self, *exc) -> None:
        release(self._handle)
