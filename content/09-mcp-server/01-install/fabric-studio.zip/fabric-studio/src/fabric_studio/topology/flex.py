"""FortiFlex licensing helpers for the topology reconciler.

PROJECT B -- topology/builder engine. Used by ``fabric_reconciler`` to license a
node from FortiFlex: register the pod's FortiCloud account (so FS can auto-assign)
and resolve a node's ``flex_config`` (id **or** name) to the numeric config id
``fs_admin.set_flex_pool`` needs.

The FortiFlex API and the per-node serial allocation live in ``pyfortiflex``;
this module adds what is specific to this repo: credentials from ``FORTIFLEX_USER``
/ ``FORTIFLEX_PASS`` (env), else the Keychain secrets ``fortiflex-user`` /
``fortiflex-pass`` (never probe the macOS Keychain directly -- go through
``fabric_studio.keychain``), the ``FLEX_<TYPE>_CONFIG`` per-vm-type default, and error
messages that point at the intent / ``fabric.toml`` knob to fix.
"""
from __future__ import annotations

import os
from collections.abc import Callable
from typing import Any

try:
    from pyfortiflex import FlexError, FortiFlexClient, mint_token, owner_description, single_active_config
    from pyfortiflex.allocation import _RESERVED  # noqa: F401 -- tests reset it
    from pyfortiflex.allocation import OWNER_RX as _CLAIMED_RX  # noqa: F401 -- tests
    from pyfortiflex.products import config_family, family_for
except ImportError as e:   # a node with `license: AUTO` or `flex` needs FortiFlex; nothing else does
    raise ImportError(
        "FortiFlex licensing needs the pyfortiflex package: install it with "
        "pip install 'fabric-studio[flex]' (the [mcp] extra includes it)") from e

__all__ = [
    "FlexError", "assert_config_matches_vm_type", "autodetect_config_for_vm_type",
    "env_config_for_type", "get_config", "guest_description", "mint_guest_token",
    "pooled_config_for_vm_type",
    "resolve_config_id", "resolve_flex_creds",
]


def resolve_flex_creds(api_id: str | None = None,
                       password: str | None = None) -> tuple[str, str]:
    """(api_id, password) for the FortiFlex IAM API. Explicit args win, else
    ``FORTIFLEX_USER``/``FORTIFLEX_PASS`` env, else Keychain
    ``fortiflex-user``/``fortiflex-pass``. Raises FlexError if unresolved."""
    api_id = api_id or os.environ.get("FORTIFLEX_USER")
    password = password or os.environ.get("FORTIFLEX_PASS")
    if not api_id or not password:
        try:
            from fabric_studio import keychain
            # FortiFlex auth is the FortiCloud IAM-API OAuth (customerapiauth.fortinet.com),
            # the same IAM API user FortiCare cert-minting uses -- so fall back to the
            # already-stored forticare-* creds before failing.
            api_id = (api_id or keychain.get_secret("fortiflex-user")
                      or keychain.get_secret("forticare-user"))
            password = (password or keychain.get_secret("fortiflex-pass")
                        or keychain.get_secret("forticare-pass"))
        except Exception:
            pass
    if not api_id or not password:
        raise FlexError(
            "FortiFlex credentials not found -- set FORTIFLEX_USER / FORTIFLEX_PASS "
            "(or Keychain fortiflex-user / fortiflex-pass, or forticare-user / forticare-pass)")
    return api_id, password


def _client(api_id: str | None = None, password: str | None = None) -> FortiFlexClient:
    return FortiFlexClient(*resolve_flex_creds(api_id, password))


def env_config_for_type(vm_type: str) -> str | None:
    """The ``FLEX_<TYPE>_CONFIG`` env value for a vm_type (e.g. FGT → the
    ``FLEX_FGT_CONFIG`` variable), or None. Value may be a numeric id or a name."""
    return os.environ.get(f"FLEX_{vm_type.upper()}_CONFIG")


def resolve_config_id(name_or_id: int | str, *, api_id: str | None = None,
                      password: str | None = None) -> int:
    """Resolve a FortiFlex config reference to its numeric id. An int (or
    int-like string) passes through with no API call; a name is matched
    case-insensitively. Raises FlexError on an unknown / ambiguous name."""
    if isinstance(name_or_id, int) or str(name_or_id).strip().isdigit():
        return int(name_or_id)
    return _client(api_id, password).resolve_config_id(name_or_id)


def get_config(config_id: int | str, *, api_id: str | None = None,
               password: str | None = None) -> dict[str, Any] | None:
    """A single FortiFlex config by numeric id, or None if the account has none."""
    return _client(api_id, password).config(config_id)


def autodetect_config_for_vm_type(vm_type: str, *, api_id: str | None = None,
                                  password: str | None = None) -> int:
    """The account's single ACTIVE FortiFlex config for ``vm_type``.

    FS auto-licenses a VM only from a *pool*, and a pool is a (type → config)
    mapping. An ``AUTO`` node with no ``flex_config`` and no ``[flex_configs]``
    entry used to resolve to None, so ``set_flex_pool`` was never called and the
    pod kept ZERO pools -- FS then answers every license request with "no
    licenses available" while looking correctly configured.

    Only unambiguous cases are resolved: 0 or 2+ candidates raise with the list."""
    try:
        return single_active_config(_client(api_id, password), vm_type)
    except FlexError as e:
        raise FlexError(f"{e}. Set the node's flex_config or fabric.toml "
                        f"[flex_configs] {vm_type.upper()}.") from None


def pooled_config_for_vm_type(pool: list[dict[str, Any]], vm_type: str, *,
                              api_id: str | None = None, password: str | None = None) -> int | None:
    """The config a pod's FortiFlex pool already maps for ``vm_type``, or None.

    FS keys a pool row by an opaque numeric ``fp_type``, so the row is found by
    its config's product family instead. Only a confirmed match counts: a config
    that cannot be looked up is skipped, never guessed."""
    want = family_for(vm_type)
    if not want:
        return None
    for row in pool:
        cid = row.get("config")
        if cid is None:
            continue
        try:
            cfg = get_config(cid, api_id=api_id, password=password)
        except Exception:
            continue
        if cfg and want.lower() in config_family(cfg).lower():
            return int(cid)
    return None


def assert_config_matches_vm_type(config_id: int | str, vm_type: str, *,
                                  api_id: str | None = None,
                                  password: str | None = None) -> None:
    """Raise ``FlexError`` if FortiFlex config ``config_id``'s product family
    doesn't match ``vm_type`` -- catching e.g. a FortiSOAR config wired to an FGT
    node BEFORE ``set_flex_pool`` hits FS with an opaque HTTP 500. No-op for an
    unmapped vm_type. Best-effort on lookup failure: only a *confirmed* family
    mismatch is fatal, so a transient API hiccup never blocks a valid config."""
    want = family_for(vm_type)
    if not want:
        return
    try:
        cfg = get_config(config_id, api_id=api_id, password=password)
    except Exception:
        return  # couldn't verify -- let FS be the backstop rather than false-fail
    if cfg is None:
        raise FlexError(
            f"FortiFlex config {config_id} not found in this account -- "
            f"check the node's flex_config or the [flex_configs] / "
            f"FLEX_{vm_type.upper()}_CONFIG value")
    prod = config_family(cfg)
    if want.lower() not in prod.lower():
        raise FlexError(
            f"FortiFlex config {config_id} ({cfg.get('name') or cfg.get('configName')!r}) "
            f"is product type {prod!r}, which does not match node type "
            f"{vm_type.upper()} (expected a {want}-* config). Fix the node's "
            f"flex_config or the fabric.toml [flex_configs] {vm_type.upper()} / "
            f"FLEX_{vm_type.upper()}_CONFIG value.")


def guest_description(fabric: str, node: str, pod: str) -> str:
    """The entitlement description that owns one node's serial (pod-scoped; see
    ``pyfortiflex.allocation``)."""
    return owner_description(fabric, node, pod)


def mint_guest_token(
    config: int | str,
    description: str,
    *,
    api_id: str | None = None,
    password: str | None = None,
    timeout_s: int = 1800,
    poll_interval_s: int = 30,
    progress: Callable[[str], None] | None = None,
) -> dict[str, Any]:
    """Allocate ``description``'s serial on ``config`` and regenerate a fresh
    token. Returns ``{config_id, serial_number, token, created}``.

    ``timeout_s`` is the budget for a created entitlement to reach ACTIVE (it
    flips PENDING→ACTIVE in ~30 min). Allocation rules: ``pyfortiflex.mint_token``."""
    result = mint_token(_client(api_id, password), config, description,
                        timeout_s=timeout_s, poll_interval_s=poll_interval_s,
                        progress=progress)
    return result.as_dict()
