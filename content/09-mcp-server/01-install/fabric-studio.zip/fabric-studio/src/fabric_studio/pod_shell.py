"""Run shell commands on the pod host via the FS CLI escape hatch.

SHARED CORE — pod-shell transport used by both Project A and Project B (the
``tools/`` CLIs). See CLAUDE.md "Code map: three surfaces".


The pod's SSH lands in the restricted ``(fabric-studio)`` CLI, not a real
shell. But ``system repository home shell -- bash -c '<cmd>'`` opens a
bash subprocess and runs the command. Live-verified 2026-05-23:

* ``uid=1000(admin) gid=33(www-data)`` — unprivileged, no sudo.
* No ``curl`` / ``wget`` / ``python`` / ``nc`` — only ``openssl``,
  ``ssh``, ``bash`` + coreutils.
* The FS CLI appends an exit-code line to stdout, like::

      <real stdout>
      0

  We strip the trailing exit-code line so callers see clean stdout.

Used by:
* Phase 3 PodDetail "Diagnose from pod" route (ip route get, ss, openssl).
* Future: Phase 5 fabric-profile signature probe + per-avenue reachability
  precheck.
"""
from __future__ import annotations

import asyncio
import shlex
from dataclasses import dataclass

import asyncssh

from fabric_studio.credentials import resolve_pod_credentials


@dataclass
class PodShellResult:
    ok: bool                  # ssh connection + bash run both succeeded
    exit_code: int            # bash exit status (parsed from FS-CLI trailer)
    stdout: str               # bash stdout with the FS-CLI trailer stripped
    stderr: str               # bash stderr
    error: str = ""           # transport-level error if not ok


def _strip_fs_exit_trailer(raw: str) -> tuple[str, int]:
    """The FS CLI appends '\\n<exit_code>\\n' to stdout. Pull it off."""
    text = raw.rstrip("\n")
    if "\n" not in text:
        # Single-line stdout: the only line *is* the exit code.
        try:
            return "", int(text)
        except ValueError:
            return raw, 0
    body, _, last = text.rpartition("\n")
    try:
        return body, int(last)
    except ValueError:
        return raw, 0


def _wrap(command: str) -> str:
    """Quote a bash command so the FS CLI passes it through cleanly.

    ``system repository home shell -- bash -c <quoted>`` — the ``--``
    stops the FS CLI from interpreting options inside ``command``.
    """
    return f"system repository home shell -- bash -c {shlex.quote(command)}"


async def _run_async(host: str, user: str, password: str,
                     command: str, timeout_s: int) -> PodShellResult:
    full = _wrap(command)
    try:
        async with asyncio.timeout(timeout_s):
            async with asyncssh.connect(host, port=22, username=user,
                                        password=password,
                                        known_hosts=None, client_keys=[]) as conn:
                r = await conn.run(full)
    except TimeoutError:
        return PodShellResult(ok=False, exit_code=-1, stdout="", stderr="",
                              error=f"pod-shell timed out after {timeout_s}s")
    except Exception as e:
        return PodShellResult(ok=False, exit_code=-1, stdout="", stderr="",
                              error=f"{type(e).__name__}: {e}")
    raw_stdout = r.stdout or ""
    stdout, exit_code = _strip_fs_exit_trailer(raw_stdout)
    return PodShellResult(ok=True, exit_code=exit_code,
                          stdout=stdout, stderr=(r.stderr or ""))


def run(pod, command: str, timeout_s: int = 15) -> PodShellResult:
    """Public sync entry point — run a bash command on the pod's host.

    ``pod`` is a Pod model row (anything that has ``.host`` + resolves
    via ``resolve_pod_credentials``).
    """
    user, password = resolve_pod_credentials(pod)
    return asyncio.run(_run_async(pod.host, user, password, command, timeout_s))


def run_on_pod(host: str, user: str, password: str, command: str,
               *, timeout_s: int = 15) -> tuple[int, str]:
    """Sync string-based entry point — run ``command`` (bash) on the pod host.

    Returns ``(exit_code, stdout)`` with the FS-CLI exit-code trailer stripped.
    For callers that have the pod creds as strings (the ``tools/`` CLIs,
    ``fabric_config``) rather than a Pod row — the shared primitive the
    per-fabric operation-flag helpers in ``fs_admin`` build on."""
    res = asyncio.run(_run_async(host, user, password, command, timeout_s))
    if not res.ok:
        return -1, res.error
    return res.exit_code, res.stdout
