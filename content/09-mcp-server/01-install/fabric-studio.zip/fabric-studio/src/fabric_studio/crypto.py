"""At-rest secret encryption (Fernet, key from FSH_MASTER_KEY)."""
from cryptography.fernet import Fernet

from fabric_studio.settings import MASTER_KEY

_f = Fernet(MASTER_KEY.encode() if isinstance(MASTER_KEY, str) else MASTER_KEY)


def encrypt(plaintext: str) -> str:
    if plaintext is None:
        return ""
    return _f.encrypt(plaintext.encode()).decode()


def decrypt(ciphertext: str) -> str:
    if not ciphertext:
        return ""
    return _f.decrypt(ciphertext.encode()).decode()
