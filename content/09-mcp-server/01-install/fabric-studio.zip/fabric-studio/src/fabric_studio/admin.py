"""Fabric Studio admin operations for the verification harness.

SHARED CORE -- the FS admin-API seam imported by BOTH Project B (all ``tools/``)
and Project A (``backend/api/routes/devices.py`` device actions). Keep it
dependency-light and side-effect-honest; it is the single shared FS-mutation
surface. See CLAUDE.md "Code map: three surfaces".


Thin wrappers over ``FabricStudioClient`` that create/destroy/poll fabrics
and their VMs. Ported from ``fabric_studio_api_client/fabric.py`` (external
repo) but rewritten on top of our session-bound client so CSRF handling +
auth state stay encapsulated.

State mutations on a VM (push CLI to apply pass/fail state config) are NOT
handled here -- the harness uses the existing channel layer (ssh-direct /
ssh-jump / fs-console) to SSH into the VM and run setup commands. fs_admin
only owns fabric *lifecycle*.
"""
from __future__ import annotations

import contextlib
import ipaddress
import json
import shlex
import time
from collections.abc import Callable
from typing import Any

from fabric_studio.client.client import FabricStudioClient


class FabricStudioAdminError(Exception):
    pass


def _check(resp, op: str) -> dict[str, Any]:
    if resp.status_code >= 300:
        raise FabricStudioAdminError(f"{op}: HTTP {resp.status_code}: {resp.text[:300]}")
    try:
        data = resp.json()
    except Exception as e:
        raise FabricStudioAdminError(f"{op}: non-JSON response: {e}: {resp.text[:300]}") from e
    # FS sometimes returns HTTP 200 with errors.global non-empty (e.g. when a
    # destroy can't queue because an install is still in-flight). Treat that
    # as a failure so callers don't swallow it silently.
    errs = data.get("errors") or {}
    glob = errs.get("global") if isinstance(errs, dict) else None
    if glob:
        raise FabricStudioAdminError(f"{op}: {glob[0] if isinstance(glob, list) else glob}")
    return data


# ── Internal request helpers (eliminate the PATCH Content-Type + multipart
# private-attr incantations repeated across the wrappers below). Public
# behavior unchanged -- every site still goes through ``c.request(...)`` with
# ``json_data=`` and ``Content-Type: application/json``; the helpers just
# centralize the pattern so callers stay 1-line.

def _patch(c: FabricStudioClient, endpoint: str, body: dict[str, Any], op: str) -> dict[str, Any]:
    """PATCH + JSON body + ``Content-Type: application/json`` + ``_check``.
    ``body`` is sent as-is -- the common ``{"object": {...}}`` wrapper convention
    is the caller's job (most FS PATCH endpoints take it). Returns the parsed
    response dict (``_check`` raises on HTTP/error-global)."""
    return _check(
        c.request("PATCH", endpoint, json_data=body,
                  headers={"Content-Type": "application/json"}),
        op,
    )


def _post_object(c: FabricStudioClient, endpoint: str, obj: dict[str, Any], op: str) -> dict[str, Any]:
    """POST with the ``{"object": obj}`` body wrapper FS requires on most create
    endpoints (vm/access/port-redirect/disk/etc.) + ``Content-Type`` + ``_check``.
    Returns the parsed response dict."""
    return _check(
        c.request("POST", endpoint, json_data={"object": obj},
                  headers={"Content-Type": "application/json"}),
        op,
    )


def _post_multipart(c: FabricStudioClient, endpoint: str, file_path: str,
                    file_field: str, op: str, *,
                    data: dict[str, str] | None = None,
                    dest_name: str | None = None) -> dict[str, Any]:
    """POST a file as ``multipart/form-data`` through the client's public
    ``request()`` -- keeps CSRF / Referer / session handling encapsulated so
    ``fs_admin`` never reaches into ``c._get_full_url`` / ``c.csrf_token`` /
    ``c.session`` directly. ``file_field`` is the form-field name FS expects
    (``input`` for the import routes); ``dest_name`` overrides the filename FS
    sees (it keys firmware by filename); ``data`` is optional non-file form
    fields. Returns the parsed response (``_check`` raises on HTTP/error-global)."""
    import os
    upload_name = dest_name or os.path.basename(file_path)
    with open(file_path, "rb") as fh:
        resp = c.request(
            "POST", endpoint,
            files={file_field: (upload_name, fh, "application/octet-stream")},
            data=data,
        )
    return _check(resp, op)


# ── Fabric lifecycle ─────────────────────────────────────────────────────────

def list_fabrics(c: FabricStudioClient) -> list[dict[str, Any]]:
    data = _check(c.get("api/v1/model/fabric"), "list_fabrics")
    return data.get("object") or []


def get_fabric_by_name(c: FabricStudioClient, name: str) -> dict[str, Any] | None:
    for f in list_fabrics(c):
        if f.get("name") == name:
            return f
    return None


def create_fabric(c: FabricStudioClient, name: str, description: str = "",
                  timeout_s: int = 60, poll_s: int = 2) -> dict[str, Any]:
    """Create a fabric and return the authoritative fabric row (resolved by name).

    NB: ``POST model/fabric`` is ASYNC on this FS -- the ``object`` it returns is
    the "Create Fabric '<name>'" protected_task, NOT the fabric (its ``id`` is a
    task id). The fabric row appears a moment later under a different id. So we
    poll ``get_fabric_by_name`` until it shows up rather than trusting the POST
    body (the same quirk ``tools/fs_lxc_deploy.py`` works around inline)."""
    body = {"name": name, "if_exists": "abort", "description": description}
    _check(c.post("api/v1/model/fabric", json_data=body), "create_fabric")
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        fab = get_fabric_by_name(c, name)
        if fab:
            return fab
        time.sleep(poll_s)
    raise FabricStudioAdminError(f"create_fabric: fabric {name!r} did not appear within {timeout_s}s")


def delete_fabric(c: FabricStudioClient, fabric_id: int | str) -> None:
    resp = c.delete(f"api/v1/model/fabric/{fabric_id}")
    if resp.status_code >= 300:
        raise FabricStudioAdminError(f"delete_fabric: HTTP {resp.status_code}: {resp.text[:300]}")


def ensure_fabric(c: FabricStudioClient, name: str, description: str = "") -> dict[str, Any]:
    """Idempotent -- returns existing fabric or creates a new one."""
    existing = get_fabric_by_name(c, name)
    if existing:
        return existing
    return create_fabric(c, name, description)


# ── Per-fabric operation flag (pod-side, cross-session visibility) ─────────���───
#
# A small JSON marker on the FS pod host recording that a fabric is mid-operation
# (e.g. a detached build is running / has unconsumed output). Complements the
# controller-side ``fabric_lock``: that lock is same-machine only and can go stale;
# this flag is on the appliance, readable by any session or machine, and survives
# a controller crash. The sentinel on the builder node remains the ground truth for
# the discard guard -- this flag is the fast, visible "is something happening on
# this fabric?" signal surfaced in `fabric state`.
#
# Path: ``$HOME/.fsh_ops/<fabric>.json`` (our own dir under the pod-shell user's
# home; doesn't touch other tenants -- consistent with the "never --prune on a
# shared pod" rule). The pod shell runs as unprivileged ``admin`` with bash +
# coreutils, so a printf-redirect write + ``cat`` read is all we need (no
# curl/python on the pod). ``$HOME`` is used UNQUOTED so bash expands it (a quoted
# ``~`` is literal → writes to a dir named ``~``); the filename is sanitized to
# ``[A-Za-z0-9_.-]`` so it needs no quoting either. Only the JSON blob is quoted.

_FLAG_DIR = "$HOME/.fsh_ops"
_FLAG_FILE = f"{_FLAG_DIR}/pod.json"   # ONE per pod (FS allows one fabric at a time)


def read_pod_flag(host: str, pod_user: str, pod_pass: str, fabric: str = "") -> dict[str, Any] | None:
    """Return the pod's operation-flag dict, or ``None`` if absent/unreadable.

    ``fabric`` is accepted for signature compatibility but IGNORED - the flag is
    per-pod (FS allows one fabric at a time, so a build on fabric A is destroyed
    by installing fabric B; the guard must see ANY running fabric). Best-effort:
    missing file or bad JSON -> ``None``. Stale detection is the caller's job."""
    from .pod_shell import run_on_pod
    rc, out = run_on_pod(host, pod_user, pod_pass,
                         f"cat {_FLAG_FILE} 2>/dev/null", timeout_s=15)
    if rc != 0 or not out.strip():
        return None
    try:
        return json.loads(out)
    except (ValueError, TypeError):
        return None


def write_pod_flag(host: str, pod_user: str, pod_pass: str, fabric: str,
                   payload: dict[str, Any]) -> None:
    """Set (overwrite) the pod's operation flag. ``fabric`` is recorded IN the
    payload (which fabric is running), not in the filename - one file per pod."""
    from .pod_shell import run_on_pod
    payload = {**payload, "fabric": fabric}
    blob = json.dumps(payload, separators=(",", ":"))
    # mkdir + atomic write via temp + mv (no partial reads mid-write). printf
    # '%s\n' (trailing newline) so `cat` emits one - else the FS-CLI exit-code
    # trailer glues onto the JSON and json.loads fails.
    cmd = (f"mkdir -p {_FLAG_DIR} && "
           f"printf '%s\n' {shlex.quote(blob)} > {_FLAG_FILE}.tmp && "
           f"mv {_FLAG_FILE}.tmp {_FLAG_FILE}")
    run_on_pod(host, pod_user, pod_pass, cmd, timeout_s=15)


def clear_pod_flag(host: str, pod_user: str, pod_pass: str, fabric: str = "") -> None:
    """Remove the pod's operation flag (idempotent - no-op if absent).

    ``fabric`` is ignored (signature compatibility) - the flag is per-pod. A
    session should only clear a flag it owns; clearing another fabric's flag
    unsafely un-blocks a destructive install. Callers that did not write the
    flag should leave it (the stale-TTL ages it out safely)."""
    from .pod_shell import run_on_pod
    run_on_pod(host, pod_user, pod_pass, f"rm -f {_FLAG_FILE}", timeout_s=15)


# ── VM lifecycle ─────────────────────────────────────────────────────────────

def list_fabric_vms(c: FabricStudioClient, fabric_id: int | str) -> list[dict[str, Any]]:
    data = _check(c.get(f"api/v1/model/fabric/{fabric_id}/vm"), "list_fabric_vms")
    return data.get("object") or []


def get_vm_by_name(c: FabricStudioClient, fabric_id: int | str, name: str) -> dict[str, Any] | None:
    for v in list_fabric_vms(c, fabric_id):
        if v.get("name") == name:
            return v
    return None


def create_vm(c: FabricStudioClient, fabric_id: int | str, vm_name: str,
              firmware_id: int | str, *,
              ipv4gateway: str | None = None,
              ipv4dns1: str | None = None,
              ipv4dns2: str | None = None,
              uuid: str | None = None) -> dict[str, Any]:
    """Create a model VM on a firmware. This FS requires the ``{"object": {...}}``
    body wrapper (a flat body 400s "Required parameter 'object' is missing"), and
    the create response ``object`` can be null, so we re-resolve by name and
    return the authoritative row.

    ``ipv4gateway``, ``ipv4dns1``, ``ipv4dns2`` are set at create time to avoid
    post-hoc PATCH round-trips (FS accepts them on create but the spec's "writable"
    claim is misleading -- no PATCH endpoint exists post-create).

    ``uuid`` pins the VM's SMBIOS UUID (``model.vm.uuid`` → qemu ``-uuid`` → guest
    DMI ``product_uuid`` → k8s node ``systemUUID``). FS bakes it into the qemu
    launch, so a later change (``set_vm_uuid``; ``""`` = FS generates a random
    one) only lands on a reinstall (``install_vm``). Use for a deterministic
    hardware identity (e.g. a UUID-locked appliance license)."""
    obj: dict[str, Any] = {"name": vm_name, "firmware": int(firmware_id), "if_exists": "abort"}
    if ipv4gateway is not None:
        obj["ipv4gateway"] = ipv4gateway
    if ipv4dns1 is not None:
        obj["ipv4dns1"] = ipv4dns1
    if ipv4dns2 is not None:
        obj["ipv4dns2"] = ipv4dns2
    if uuid is not None:
        obj["uuid"] = uuid
    body = {"object": obj}
    _check(c.post(f"api/v1/model/fabric/{fabric_id}/vm", json_data=body), "create_vm")
    vm = get_vm_by_name(c, fabric_id, vm_name)
    if not vm:
        raise FabricStudioAdminError(f"create_vm: VM {vm_name!r} missing after create")
    return vm


def get_vm_install_after(c: FabricStudioClient, vm_id: int | str) -> list[int]:
    """Return the VM ids FS's own install ordering (``model.installafter``,
    GUI: VM Advanced -> "Install after") currently requires ``vm_id`` to wait
    on. Enforced by FS at install time -- distinct from any controller-side
    ordering (e.g. this repo's ``NodeSpec.depends_on``, which only gates our
    provision-phase items, not the VM install itself)."""
    data = _check(c.get(f"api/v1/model/vm/{vm_id}/install/after"), "get_vm_install_after")
    obj = data.get("object") or {}
    after = obj.get("after")
    if after is None:
        return []
    return [int(v) for v in after] if isinstance(after, list) else [int(after)]


def set_vm_install_after(c: FabricStudioClient, vm_id: int | str,
                         after_vm_ids: list[int]) -> None:
    """Set FS's ``model.installafter`` for ``vm_id`` to exactly ``after_vm_ids``
    (replaces whatever was there -- FS has no partial-update semantics here).
    An empty list clears the constraint (equivalent to the DELETE endpoint,
    but idempotent to call either way)."""
    _patch(c, f"api/v1/model/vm/{vm_id}/install/after",
          {"after": [int(v) for v in after_vm_ids]}, "set_vm_install_after")


# ── Runtime control ──────────────────────────────────────────────────────────

def get_running_fabric(c: FabricStudioClient) -> dict[str, Any] | None:
    """Return the pod's currently-running fabric (``GET runtime/fabric``) or
    None if nothing is installed. Mirrors ``PodRuntime.get_running_fabric``
    for the fs_admin client path."""
    try:
        data = _check(c.get("api/v1/runtime/fabric"), "get_running_fabric")
    except Exception:
        return None
    return data.get("object") or None


def install_fabric(c: FabricStudioClient, fabric_id: int | str, *,
                   allow_running: bool = False) -> dict[str, Any]:
    """Install + power on the fabric (``POST runtime/fabric/{id}``, empty body =
    FS's *install-everything*). FS creates a background task; returns the task row.

    DESTRUCTIVE ON A RUNNING FABRIC. Despite older lore that this "no-ops on an
    already-installed fabric", an empty-body install **redeploys every VM in the
    fabric** -- it powers off and reinstalls running guests (data survives only via
    the persistent disk; there is downtime and a risk to a live appliance). This is
    the first-bring-up primitive ONLY: the reconciler calls it strictly behind an
    ``if not runtime_vms(fid):`` guard (see reconciler bring-up) and synchronizes --
    never installs -- an already-running fabric.

    So this refuses by default when the fabric already has running VMs. To publish
    a model change (a new port-redirect / expose, cabling, access) onto a running
    fabric, DO NOT call this -- use :func:`synchronize_device` on the affected device
    (the System Host for NAT/port-redirects), which converges without a reinstall.
    Pass ``allow_running=True`` only for a deliberate, authorized full redeploy.
    """
    if not allow_running:
        running = runtime_vms(c, fabric_id)
        if running:
            names = ", ".join(sorted(v.get("name", "?") for v in running)) or f"{len(running)} VM(s)"
            raise FabricStudioAdminError(
                f"install_fabric refused: fabric {fabric_id} already has running VMs "
                f"({names}); an empty-body install would REDEPLOY them all. For a model "
                f"change (port-redirect/expose/cabling) on a running fabric use "
                f"synchronize_device(System Host) -- it converges without a reinstall. "
                f"Pass allow_running=True only for an intentional full redeploy.")
    data = _check(c.post(f"api/v1/runtime/fabric/{fabric_id}", json_data={}), "install_fabric")
    return data.get("object") or {}


# ── Task tracking ────────────────────────────────────────────────────────────
# Every mutating FS call (VM install, power on/off, license install/uninstall,
# snapshot/backup) queues a background task. Track them uniformly via the plain
# task endpoints -- the ``model/protected_task.*`` URLs return 400 on FS and are
# NOT usable; use these instead:
#   * GET task/{id}                -> single task; returncode None ⇒ still running
#   * GET task?running=true        -> everything in flight on the pod
#   * GET task/device?device_id=N  -> recent tasks for a VM (find the one a
#                                     colon-less POST/DELETE just spawned)
# DONE  ⇔ returncode is not None (≡ returned_date set).
# OK    ⇔ returncode == 0 and no signal. signal/monitor_error explain failures.

def get_task(c: FabricStudioClient, task_id: int | str) -> dict[str, Any]:
    """Fetch one task by id via the working ``api/v1/task/{id}`` endpoint."""
    data = _check(c.get(f"api/v1/task/{task_id}"), "get_task")
    return data.get("object") or {}


def list_running_tasks(c: FabricStudioClient) -> list[dict[str, Any]]:
    """All tasks currently in flight on the pod."""
    data = _check(c.get("api/v1/task?running=true"), "list_running_tasks")
    return data.get("object") or []


def cancel_task(c: FabricStudioClient, task_id: int | str) -> None:
    """Cancel an in-flight task via ``DELETE api/v1/task/{id}`` (the FS verb the
    GUI's task-cancel button uses). Frees the queue so a stuck install no longer
    blocks ``destroy_vm`` / ``delete_fabric`` with a "task conflict"."""
    _check(c.delete(f"api/v1/task/{task_id}"), "cancel_task")


def latest_device_task(c: FabricStudioClient, vm_id: int | str,
                       limit: int = 1) -> dict[str, Any]:
    """Most recent task for a VM -- use when an FS call didn't return a task id
    you can poll (e.g. ``POST runtime/vm/{id}`` install)."""
    data = _check(
        c.get(f"api/v1/task/device?device_id={vm_id}&limit={limit}&order_by=-created_date"),
        "latest_device_task",
    )
    obj = data.get("object") or []
    return obj[0] if obj else {}


def task_done(t: dict[str, Any]) -> bool:
    return t.get("returncode") is not None or bool(t.get("returned_date"))


def wait_task(c: FabricStudioClient, task: dict[str, Any] | int | str,
              timeout_s: int = 1800, poll_s: int = 5,
              label: str | None = None, max_poll_errors: int = 10) -> dict[str, Any]:
    """Block until an FS task finishes. Accepts a task object or a bare id.
    Raises on non-zero returncode, signal, or timeout. Returns the final task.

    Tolerant of transient poll failures: the task runs server-side, so a dropped
    or 5xx ``get_task`` HTTP call (the pod's API briefly closing the connection
    under load -- common during a multi-minute ``install_fabric``) must NOT abort
    the wait. Such errors are retried after ``poll_s``; only ``max_poll_errors``
    *consecutive* failures (the pod genuinely gone) raise. A successful poll
    resets the counter, so isolated blips over a long install cost nothing."""
    tid = task.get("id") if isinstance(task, dict) else task
    name = label or (task.get("name") if isinstance(task, dict) else f"task {tid}")
    if tid is None:
        return task if isinstance(task, dict) else {}
    deadline = time.monotonic() + timeout_s
    poll_errors = 0
    while time.monotonic() < deadline:
        try:
            t = get_task(c, tid)
            poll_errors = 0
        except Exception as e:
            poll_errors += 1
            if poll_errors >= max_poll_errors:
                raise FabricStudioAdminError(
                    f"wait_task: task {tid} ({name}) -- {poll_errors} consecutive poll "
                    f"failures, giving up (last: {e})") from e
            time.sleep(poll_s)
            continue
        if task_done(t):
            rc, sig = t.get("returncode"), t.get("signal")
            if str(rc) != "0" or sig:
                raise FabricStudioAdminError(_task_failure_detail(c, tid,
                    f"task {tid} ({name}) failed: rc={rc} signal={sig} "
                    f"err={t.get('monitor_error')}"))
            return t
        time.sleep(poll_s)
    raise FabricStudioAdminError(f"wait_task: task {tid} ({name}) not finished within {timeout_s}s")


def runtime_vms(c: FabricStudioClient, fabric_id: int | str | None = None) -> list[dict[str, Any]]:
    """All runtime VMs on the pod (only one fabric runs at a time, so
    filtering client-side by ``fabric_id`` is sufficient)."""
    data = _check(c.get("api/v1/runtime/vm"), "runtime_vms")
    out = data.get("object") or []
    if fabric_id is not None:
        out = [v for v in out if str(v.get("fabric")) == str(fabric_id)]
    return out


def wait_running(c: FabricStudioClient, fabric_id: int | str, timeout_s: int = 600,
                 poll_s: int = 10) -> list[dict[str, Any]]:
    """Block until every VM in the fabric reports ``status.powered`` and
    ``status.post_boot_prepared``. Raises on timeout.

    NB: the ``runtime/vm`` *list* endpoint omits the ``status`` sub-object by
    default (the FS related-fields gotcha), so we re-read each VM's status via
    ``get_vm_runtime_state`` (which requests ``related-fields=status``) rather
    than trusting the list rows -- otherwise ``status`` is always null and this
    would hang to timeout even after the guests are fully booted."""
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        vms = runtime_vms(c, fabric_id)
        if vms:
            states = [get_vm_runtime_state(c, v["id"]).get("status") or {} for v in vms]
            if all(s.get("powered") and s.get("post_boot_prepared") for s in states):
                return vms
        time.sleep(poll_s)
    raise FabricStudioAdminError(f"wait_running: fabric {fabric_id} did not all reach 'ready' within {timeout_s}s")


def get_runtime_vm(c: FabricStudioClient, vm_id: int | str) -> dict[str, Any]:
    data = _check(
        c.get(f"api/v1/runtime/vm/{vm_id}?related-fields=license,status"),
        "get_runtime_vm",
    )
    return data.get("object") or {}


def install_vm(c: FabricStudioClient, vm_id: int | str) -> dict[str, Any]:
    """(Re)install + power on a single VM via ``POST /api/v1/runtime/vm/{id}``.

    FS returns a ``model.devicetask`` "Install '<name>' device" row immediately;
    actual provisioning takes ~30-60s. Use ``wait_vm_ready`` to block until
    it's done -- do NOT use ``wait_task`` (the protected_task model URL is
    broken in FS; poll the VM's ``task`` related-field instead).
    """
    data = _check(c.post(f"api/v1/runtime/vm/{vm_id}", json_data={}), "install_vm")
    return data.get("object") or {}


def reload_vm_license(c: FabricStudioClient, vm_id: int | str) -> dict[str, Any]:
    """Re-pull this VM's license WITHOUT destroying/reinstalling the guest, via
    ``POST /api/v1/runtime/vm/{id}/license`` with ``{reinstall, refresh}``.

    This is the light-weight cousin of ``install_vm`` (destroy+reinstall): it
    re-runs only the license assignment on the running VM, which is what the
    legacy CLI ``reload-license`` command did. FS returns a ``model.devicetask``
    row immediately; use ``wait_vm_licensed`` to confirm the flag flips."""
    data = _check(
        c.post(f"api/v1/runtime/vm/{vm_id}/license",
               json_data={"reinstall": True, "refresh": True}),
        "reload_vm_license",
    )
    return data.get("object") or {}


def destroy_vm(c: FabricStudioClient, vm_id: int | str) -> None:
    """Stop and remove the runtime VM (model row survives so install_vm can
    rebuild). FS returns HTTP 200 with ``errors.global`` non-empty when an
    install task is still in-flight -- _check raises in that case so callers
    learn to wait for ``wait_vm_ready`` before destroying."""
    _check(c.delete(f"api/v1/runtime/vm/{vm_id}"), "destroy_vm")


def get_vm_runtime_state(c: FabricStudioClient, vm_id: int | str) -> dict[str, Any]:
    """Returns ``{exists, task, status}`` for a VM. After destroy the runtime
    row vanishes and FS returns rcode=232 -- we report that as ``exists=False``.

    A transient HTTP error (read timeout while the pod is busy, e.g. right after
    a multi-GB disk export) is NOT a state signal -- report it as
    ``exists=True, task="pending"`` so the surrounding poll loop keeps retrying
    within its own deadline instead of crashing the whole scenario."""
    try:
        resp = c.get(f"api/v1/runtime/vm/{vm_id}?related-fields=status&related-fields=task")
    except Exception:
        return {"exists": True, "task": "pending", "status": {}}
    try:
        data = resp.json()
    except Exception:
        return {"exists": False, "task": None, "status": {}}
    if data.get("rcode") == 232 or data.get("status") == "error":
        return {"exists": False, "task": None, "status": {}}
    obj = data.get("object") or {}
    return {"exists": True, "task": obj.get("task"), "status": obj.get("status") or {}}


def wait_vm_gone(c: FabricStudioClient, vm_id: int | str, timeout_s: int = 120,
                 poll_s: int = 3) -> None:
    """Block until ``runtime/vm/{id}`` no longer exists (after destroy_vm)."""
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if not get_vm_runtime_state(c, vm_id)["exists"]:
            return
        time.sleep(poll_s)
    raise FabricStudioAdminError(f"wait_vm_gone: vm {vm_id} still present after {timeout_s}s")


def wait_vm_ready(c: FabricStudioClient, vm_id: int | str, timeout_s: int = 600,
                  poll_s: int = 5, task_id: int | str | None = None) -> dict[str, Any]:
    """Block until the VM's install task finishes AND it reports powered +
    post_boot_prepared. ``task`` is non-null while the install is running.

    ``task_id`` (the ``install_vm``/``install_device`` task) makes this gate on
    the install's *returncode*: a failed install (e.g. rc 254 -- a guest init that
    returned non-zero, or an FS teardown/nft error) destroys the runtime, so the
    VM never reaches powered+post_boot_prepared and a returncode-blind wait would
    only ever hit the timeout (or, worse, momentarily pass on a half-built VM).
    With the task id we fail FAST and LOUD with the actual rc the moment the task
    finishes non-zero, instead of silently reporting success. Pass it whenever you
    have it (callers that don't are unchanged -- model-status-only wait)."""
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if task_id is not None:
            t = get_task(c, task_id)
            if task_done(t):
                rc, sig = t.get("returncode"), t.get("signal")
                if str(rc) != "0" or sig:
                    raise FabricStudioAdminError(_task_failure_detail(c, task_id,
                        f"wait_vm_ready: vm {vm_id} install task {task_id} "
                        f"({t.get('name')}) failed: rc={rc} signal={sig} "
                        f"err={t.get('monitor_error')}"))
        s = get_vm_runtime_state(c, vm_id)
        if s["exists"] and s["task"] is None:
            st = s["status"] or {}
            if st.get("powered") and st.get("post_boot_prepared"):
                return st
        time.sleep(poll_s)
    raise FabricStudioAdminError(f"wait_vm_ready: vm {vm_id} not ready within {timeout_s}s")


def wait_device_idle(c: FabricStudioClient, vm_id: int | str,
                     timeout_s: int = 240, poll_s: int = 5) -> None:
    """Block until the VM has no in-flight device task (latest task ``returncode``
    is non-null). The FS "Install '<name>' device" task lingers as running for
    ~40s AFTER the guest reaches post_boot_prepared; issuing another device task
    (license uninstall/install, power-off, destroy) in that window is rejected
    with "Failed to queue task (task conflict)". Call this between a reinstall
    and any follow-on device action. Best-effort: returns after timeout rather
    than raising, so a genuinely-stuck task doesn't wedge the caller forever."""
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        t = latest_device_task(c, vm_id)
        if not t or task_done(t):
            return
        time.sleep(poll_s)


def wait_vm_licensed(c: FabricStudioClient, vm_id: int | str,
                     timeout_s: int = 300, poll_s: int = 5,
                     progress: Callable[[str], None] | None = None) -> dict[str, Any]:
    """Block until the VM's ``status.licensed`` flips true (or timeout).

    A VM reaches powered + post_boot_prepared BEFORE FS finishes *assigning* its
    license. For FortiFlex the assignment runs asynchronously as a pod-level task
    tied to the forticloud/fabric object (``related_obj`` ≠ the VM's device_id),
    so ``wait_device_idle`` (which queries ``task/device?device_id=…``) returns
    while that task is still in flight and ``status.licensed`` is still false.
    Confirmed live 2026-06-06: lic-to-flex served ``FSRVMOTM26000191`` but the
    flag hadn't flipped at post_boot_prepared, tripping a premature license
    retry. Returns the final status dict (``licensed`` may still be false on
    timeout -- the caller decides whether to retry).

    Fast path: ``POST runtime/vm/{id}/license:wait`` blocks server-side for up
    to ``timeout_s`` seconds -- confirmed live on FS. Falls back to the 5s poll
    loop if the endpoint returns a non-200/non-done response (unlicensed VMs or
    pods running older firmware that doesn't support the endpoint)."""
    # Fast path -- FS native blocking wait (eliminates polling round-trips).
    try:
        resp = c.post(f"api/v1/runtime/vm/{vm_id}/license:wait",
                      json_data={"timeout": timeout_s})
        data = resp.json() if resp.content else {}
        if resp.status_code == 200 and data.get("status") == "done":
            # Endpoint returned -- read the actual licensed flag to confirm.
            return get_vm_runtime_state(c, vm_id).get("status") or {}
    except Exception:
        pass  # fall through to poll loop

    # Fallback poll loop (older FS firmware or endpoint returned unexpected status).
    start = time.monotonic()
    deadline = start + timeout_s
    st: dict[str, Any] = {}
    last_note = 0.0
    while time.monotonic() < deadline:
        st = get_vm_runtime_state(c, vm_id).get("status") or {}
        if st.get("licensed"):
            return st
        # Emit a heartbeat ~every 20s so the wait isn't silent (FortiFlex
        # assignment can take minutes -- without this it looks frozen).
        if progress and (time.monotonic() - last_note) >= 20:
            last_note = time.monotonic()
            progress(f"still waiting for FS to assign license "
                     f"({time.monotonic() - start:.0f}/{timeout_s}s)")
        time.sleep(poll_s)
    return st


def install_device(c: FabricStudioClient, device_id: int | str) -> dict[str, Any]:
    """POST runtime/device/{id} (no colon-suffix) -- installs/(re)provisions a
    VM whose previous install task failed. Equivalent of install_vm but via
    the runtime/device endpoint; FS treats both as the same install op. Use
    this for fs-task-health failed_tasks where power-on/off won't help
    because the VM never finished installing in the first place.

    Switches go to ``runtime/switch/{id}`` instead: ``runtime/device/{id}`` on a
    switch queues a task that dies with ``Vm has no parameters`` (live-verified on
    2.2.35)."""
    obj = _check(c.get(f"api/v1/model/device/{device_id}"), "install_device").get("object") or {}
    kind = "switch" if obj.get("__model") == "model.switch" else "device"
    data = _check(c.post(f"api/v1/runtime/{kind}/{device_id}", json_data={}), "install_device")
    return data.get("object") or {}


def fabric_diff(c: FabricStudioClient, fabric_id: int | str) -> dict[str, Any]:
    """The fabric's model-vs-runtime diff (``GET model/object/diff?model=model.fabric
    &id={fid}``) -- the same data the GUI "Apply changes" panel renders. Returns the
    ``object`` dict; its ``diff.devices`` maps each device id with pending changes to
    the per-subsystem verb FS wants (e.g. ``{"64": {"dhcp_table": {"938": "install"}}}``
    means the System Host's DHCP reservation for vmport 938 needs an **install** to
    land in the running dnsmasq -- a synchronize does NOT apply dhcp_table changes)."""
    return _check(c.get(f"api/v1/model/object/diff?model=model.fabric&id={fabric_id}"),
                  "fabric_diff").get("object") or {}


def devices_needing_dhcp_install(c: FabricStudioClient, fabric_id: int | str) -> list[int]:
    """Device ids whose ``dhcp_table`` has a pending diff (verb ``install``) in the
    fabric diff -- i.e. native DHCP servers (System Host) that must be re-installed
    for a just-changed DHCP reservation to be served. Empty when already converged
    (so callers stay idempotent and don't reinstall the host on every apply)."""
    diff = fabric_diff(c, fabric_id).get("diff") or {}
    out = []
    for did, subs in (diff.get("devices") or {}).items():
        if (subs or {}).get("dhcp_table"):
            with contextlib.suppress(TypeError, ValueError):
                out.append(int(did))
    return out


def synchronize_device(c: FabricStudioClient, device_id: int | str) -> dict[str, Any]:
    """POST runtime/device/{id}:synchronize -- push MODEL changes (ports, access
    exposure, cabling) onto an already-installed, running VM WITHOUT a full
    reinstall/reboot. This is the cheap convergence path: use it when only the
    VM's model topology changed; reserve a full ``install_vm``/``install_fabric``
    for firmware swaps or first bring-up. Also exposed as ``runtime/vm/{id}:synchronize``.
    Returns the queued task object."""
    data = _check(c.post(f"api/v1/runtime/device/{device_id}:synchronize"), "synchronize_device")
    return data.get("object") or {}


def power_off_device(c: FabricStudioClient, device_id: int | str) -> dict[str, Any]:
    """POST runtime/device/{id}:power-off -- returns the queued task object."""
    data = _check(c.post(f"api/v1/runtime/device/{device_id}:power-off"), "power_off_device")
    return data.get("object") or {}


def power_on_device(c: FabricStudioClient, device_id: int | str) -> dict[str, Any]:
    """POST runtime/device/{id}:power-on -- returns the queued task object."""
    data = _check(c.post(f"api/v1/runtime/device/{device_id}:power-on"), "power_on_device")
    return data.get("object") or {}


def wait_powered(c: FabricStudioClient, vm_id: int | str, want: bool,
                 timeout_s: int = 180, poll_s: int = 3) -> bool:
    """Block until the VM's ``status.powered`` reaches ``want`` (True/False).
    Returns the final powered value; raises on timeout. Tolerant of the transient
    read-timeout that ``get_vm_runtime_state`` reports as ``task='pending'``."""
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        st = get_vm_runtime_state(c, vm_id)
        if bool((st.get("status") or {}).get("powered")) == want:
            return want
        time.sleep(poll_s)
    raise FabricStudioAdminError(
        f"wait_powered: vm {vm_id} did not reach powered={want} within {timeout_s}s")


def power_cycle(c: FabricStudioClient, vm_id: int | str,
                off_timeout_s: int = 180, ready_timeout_s: int = 300,
                progress: Any = None) -> dict[str, Any]:
    """Cleanly power a VM off then back on, blocking until it is fully ready
    (powered + post_boot_prepared). Returns the final vm status dict.

    Reusable resilience check: confirms a guest survives a reboot before you
    rely on a snapshot of it. FS-level readiness only -- it does NOT probe the
    guest's own app (a containerized product's pods may still be warming up
    after ``post_boot_prepared``); probe the app's port/URL separately.
    ``vm_id`` doubles as the device id (FS treats ``runtime/device/{vm_id}``
    as the same VM). ``progress`` is an optional ``print``-like callable."""
    _say = progress or (lambda *_: None)
    _say(f"power-off vm {vm_id} ...")
    wait_task(c, power_off_device(c, vm_id), timeout_s=off_timeout_s,
              label=f"power-off vm {vm_id}")
    wait_powered(c, vm_id, want=False, timeout_s=off_timeout_s)
    _say(f"vm {vm_id} off; power-on ...")
    wait_task(c, power_on_device(c, vm_id), timeout_s=off_timeout_s,
              label=f"power-on vm {vm_id}")
    _say(f"vm {vm_id} on; waiting for ready (powered+post_boot_prepared) ...")
    st = wait_vm_ready(c, vm_id, timeout_s=ready_timeout_s)
    _say(f"vm {vm_id} ready.")
    return st


def take_diff_snapshot(c: FabricStudioClient, vm_id: int | str, name: str,
                       link: bool = True, diff: bool = True, off_timeout_s: int = 240,
                       export_timeout_s: int = 900, ready_timeout_s: int = 300,
                       progress: Any = None) -> dict[str, Any]:
    """Power-off → diff-export → (optional) link-to-VM → boot back up.

    The one-call "take a diff snapshot of a running VM" helper. Every step queues
    an FS task that is tracked to completion by id:
      1. ``power_off_device`` (HARD, virsh destroy) + its task -- a synchronous
         stop, so the task completing MEANS the domain is really off. NOTE: the
         ACPI ``:shutdown`` verb is a no-op on appliance guests (FortiGate,
         FortiAIGate/k3s -- no ACPI power-button handler), and FS flips the model
         ``status.powered`` flag to False anyway, so neither ACPI nor the model
         flag is a reliable "off" gate. A hard power-off is. (For a *graceful*
         halt, ``shutdown -h now`` in-guest first, then this no-ops the off step.)
      2. ``export_vm_disks(diff=True, switch=link, overwrite=False)`` + its task --
         a DELTA against the **original standalone firmware**. The export
         re-validates the domain is off ("Can't export when the device is running")
         -- treated as the authoritative gate and retried through any residual
         settling / a power-off that didn't take.
      3. ``power_on_device`` + its task + ``wait_vm_ready``.

    ``diff=False`` takes a FULL snapshot instead: the disks are flattened into one standalone firmware
    (larger, no dependency on the original, a full install to restore).

    ``name`` MUST be unique (``overwrite=False`` -- a colliding name fails the
    export task rather than silently clobbering a prior snapshot). Returns the new
    snapshot firmware dict (id / path / is_diff / diff_from).

    **Diff lineage:** diffs never chain. Every diff is rebased onto the original
    standalone firmware, even when the VM is booting from an earlier diff: the
    export log says "as rebased firmware" and ``diff_from`` stays the standalone
    id. So with ``link=True`` (default; the VM's firmware pointer moves to THIS
    snapshot so a reinstall boots it) the next snapshot still holds everything
    since the standalone, and any diff can be deleted without breaking another.
    Each one does depend on its standalone: an install downloads the original
    first. Live-verified on 2.2.35 (two successive diffs, both ``diff_from`` the
    standalone; the second booted with both markers).

    App-level readiness (a containerized product's pods) warms up AFTER
    ``post_boot_prepared`` -- probe the app URL separately; see ``power_cycle``."""
    _say = progress or (lambda *_: None)
    if not name:
        raise FabricStudioAdminError("take_diff_snapshot: name must be non-empty and unique")
    _say(f"power-off vm {vm_id} (hard -- appliance guests ignore ACPI) ...")
    try:
        wait_task(c, power_off_device(c, vm_id), timeout_s=off_timeout_s,
                  label=f"power-off vm {vm_id}")
    except FabricStudioAdminError as e:
        _say(f"  power-off note: {str(e)[:120]} (may already be off)")
    _say(f"vm {vm_id} off; export diff snapshot {name!r} (link={link}) ...")
    tid = None
    for attempt in range(8):
        try:
            t = export_vm_disks(c, vm_id, name, diff=diff, overwrite=False, switch=link)
            tid = t.get("id")
            _say(f"export task id={tid}; waiting ...")
            wait_task(c, tid, timeout_s=export_timeout_s, label=f"export {name}")
            break
        except FabricStudioAdminError as e:
            if "is running" in str(e) and attempt < 7:
                _say(f"  domain still settling; re-issuing power-off + retry export "
                     f"({attempt + 1}/7)")
                with contextlib.suppress(FabricStudioAdminError):
                    power_off_device(c, vm_id)
                time.sleep(10)
                continue
            raise
    _say(f"snapshot {name!r} created (task {tid}); power-on vm {vm_id} ...")
    wait_task(c, power_on_device(c, vm_id), timeout_s=off_timeout_s,
              label=f"power-on vm {vm_id}")
    wait_vm_ready(c, vm_id, timeout_s=ready_timeout_s)
    _say(f"vm {vm_id} back up.")
    # resolve the freshly-created snapshot row by path for the caller
    snap = next((f for f in list_all_firmwares(c)
                 if str(f.get("path", "")).endswith(name)), {"name": name})
    return snap


def get_task_log(c: FabricStudioClient, task_id: int | str) -> str:
    """Fetch a task's execution log via ``api/v1/task/{id}:log``.

    This is where FS records the *reason* a device task failed (e.g. a
    synchronize that returns 254 because an attribute write hit a runtime-DB
    foreign-key constraint). Returns '' if the log endpoint is unavailable."""
    try:
        resp = c.get(f"api/v1/task/{task_id}:log")
        if resp.status_code == 200:
            # FS returns the log as raw text/plain (not the usual {object:...}
            # envelope). Try JSON first in case a build wraps it, else use text.
            try:
                obj = (resp.json() or {}).get("object")
                if isinstance(obj, str):
                    return obj
                if isinstance(obj, dict):
                    return obj.get("log") or obj.get("text") or ""
                if isinstance(obj, list):
                    return "\n".join(str(x) for x in obj)
            except ValueError:
                return resp.text or ""
    except Exception:
        pass
    return ""


def _task_failure_detail(c: FabricStudioClient, task_id: int | str,
                         head: str, max_lines: int = 15, max_chars: int = 1000) -> str:
    """``head`` plus only the **tail** of the task's FS log -- so a failed
    install/sync error carries the actual *reason* (e.g.
    ``No license for fgt000 (FLEX,LIC)``) instead of a bare ``rc=254``. The fatal
    line is always at the end, and some logs (a multi-hour build) are large, so we
    keep just the last ``max_lines`` lines, hard-capped at ``max_chars``. Best
    effort: returns just ``head`` if the log is unavailable."""
    log = get_task_log(c, task_id).strip()
    if not log:
        return head
    tail = "\n".join(log.splitlines()[-max_lines:])[-max_chars:]
    return f"{head}\n  --- FS task {task_id} log (tail) ---\n  " + tail.replace("\n", "\n  ")


def wait_device_task(c: FabricStudioClient, task_id: int | str,
                     timeout_s: int = 120, poll_s: int = 2,
                     raise_on_error: bool = True) -> dict[str, Any]:
    """Poll /api/v1/task/{id} until ``returncode`` is non-null (task finished).

    Used by power-cycle and synchronize: the protected_task model URL
    ``wait_task`` uses is broken for the short device tasks (returns 404), but
    the plain /api/v1/task/{id} endpoint works.

    A finished task can still have FAILED -- FS device tasks (synchronize,
    install, power) report failure as a non-zero ``returncode`` (e.g. 254) with
    the cause only in ``task/{id}:log``. By default we raise on a non-zero
    return and attach the log tail so the caller can't silently proceed on a
    half-applied sync. Pass ``raise_on_error=False`` to inspect the raw task."""
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        resp = c.get(f"api/v1/task/{task_id}")
        if resp.status_code == 200:
            obj = (resp.json() or {}).get("object") or {}
            if obj.get("returncode") is not None:
                rc = obj.get("returncode")
                if raise_on_error and (str(rc) != "0" or obj.get("signal")):
                    raise FabricStudioAdminError(_task_failure_detail(c, task_id,
                        f"device task {task_id} ({obj.get('name')}) failed: "
                        f"rc={rc} signal={obj.get('signal')}"))
                return obj
        time.sleep(poll_s)
    raise FabricStudioAdminError(f"wait_device_task: task {task_id} not finished within {timeout_s}s")


# ── Firmware / snapshots ─────────────────────────────────────────────────────
# "Snapshots" are firmware images in the pod's *home* repository (there is no
# snapshot REST resource). A model VM's ``firmware`` field is just a firmware id.

def list_home_firmwares(c: FabricStudioClient, vm_type: str | None = None) -> list[dict[str, Any]]:
    """Bootable images in the home repository, optionally filtered by VM type.
    A diff/snapshot image has ``is_diff: true`` and ``diff_from`` set."""
    ep = ("api/v1/system/repository/firmware"
          "?select=repository.name=home&exclude=status=unknown"
          "&related-fields=repository&related-fields=diff_from")
    obj = _check(c.get(ep), "list_home_firmwares").get("object") or []
    if vm_type:
        obj = [f for f in obj if f.get("vm_type") == vm_type]
    return obj


def list_all_firmwares(c: FabricStudioClient, vm_type: str | None = None) -> list[dict[str, Any]]:
    """Firmware rows across **all** repositories (home + ``fortinet``/``beta``/…),
    optionally filtered by VM type. Each carries ``repository`` (``{name}``),
    ``status`` (``ready``/``downloaded`` = local & deployable, ``remote`` = in the
    repo, auto-downloaded at install), ``size`` (0 = an unusable stub), and a
    versioned ``path``. Used to auto-select the latest usable image for a node."""
    ep = ("api/v1/system/repository/firmware?exclude=status=unknown"
          "&related-fields=repository&related-fields=diff_from")
    obj = _check(c.get(ep), "list_all_firmwares").get("object") or []
    if vm_type:
        obj = [f for f in obj if f.get("vm_type") == vm_type]
    return obj


def get_vm_firmware_id(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str) -> Any:
    """Current firmware id attached to a model VM (the source of truth for which
    snapshot is loaded -- the disk row keeps the base image's filename)."""
    vm = _check(c.get(f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}"), "get_vm_firmware_id")
    return (vm.get("object") or {}).get("firmware")


def set_vm_firmware(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str,
                    firmware_id: int | str) -> None:
    """Point a model VM at a different firmware/snapshot. Takes effect on the
    NEXT install (destroy_vm → install_vm → wait_vm_ready)."""
    _patch(c, f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}",
           {"object": {"firmware": int(firmware_id)}}, "set_vm_firmware")


def set_vm_console_password(c: FabricStudioClient, fabric_id: int | str,
                            vm_id: int | str, password: str) -> dict[str, Any]:
    """Set the VM's console password (``model.vm.console_password``).

    Required for a **VNC/SPICE** access to actually be exposed. FS accepts a
    ``mode: PUBLIC`` VNC access with no console password, then silently declines
    to allocate its forward at install time, logging::

        No valid password for VNC, public access not allowed

    and leaves the access sitting at ``fport_idx: 0``. The model therefore claims
    VNC is PUBLIC while nothing listens -- which reads as a broken forward rather
    than a missing credential. Model-only -- applies on (re)install."""
    return _patch(c, f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}",
                  {"object": {"console_password": password}},
                  "set_vm_console_password").get("object") or {}


def set_vm_password(c: FabricStudioClient, fabric_id: int | str,
                    vm_id: int | str, password: str) -> dict[str, Any]:
    """Set the VM's device admin password (``model.vm.password``). FS uses it to
    log in for post-boot prepare. Model-only -- applies on (re)install."""
    return _patch(c, f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}",
                  {"object": {"password": password}},
                  "set_vm_password").get("object") or {}


def set_vm_uuid(c: FabricStudioClient, fabric_id: int | str,
                vm_id: int | str, uuid: str) -> dict[str, Any]:
    """Set the VM's SMBIOS UUID (``model.vm.uuid``). ``""`` clears it so FS
    generates a fresh one on the next install. Model-only -- applies on
    (re)install (``install_vm``)."""
    return _patch(c, f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}",
                  {"object": {"uuid": uuid}},
                  "set_vm_uuid").get("object") or {}


# Pod hugepages are allocated in 1 GiB pages. Not exposed by any API (it comes
# from /proc/meminfo Hugepagesize, and the pod shell has no /proc mounted), but
# measured: a guest declaring 8192 MiB needed exactly 8 pages and failed to power
# on with 2 free.
HUGEPAGE_SIZE_MIB = 1024


def hugepages_available(c: FabricStudioClient) -> int:
    """Total hugepages configured on the pod (``GET system/kernel/hugepages:available``).
    Counted in PAGES, not bytes -- multiply by ``HUGEPAGE_SIZE_MIB`` for MiB."""
    return int(_check(c.get("api/v1/system/kernel/hugepages:available"),
                      "hugepages_available").get("object") or 0)


def hugepages_free(c: FabricStudioClient) -> int:
    """Hugepages still unclaimed on the pod (``GET system/kernel/hugepages:free``).

    A VM whose ``model.vmparameters.hugepages`` is true maps ALL its guest RAM out
    of this pool, and FS defaults that flag to true -- so a fabric can be perfectly
    modelled and still fail at power-on with ``unable to map backing store for
    guest RAM: Cannot allocate memory`` once the pool is exhausted. The VM is then
    left ``Shut Off`` while ``runtime device status`` still reports ``Running``,
    which is why this is worth checking BEFORE an install rather than diagnosing
    after one."""
    return int(_check(c.get("api/v1/system/kernel/hugepages:free"),
                      "hugepages_free").get("object") or 0)


def get_vm_parameters(c: FabricStudioClient, vm_id: int | str) -> dict[str, Any]:
    """The model VM's hypervisor parameters (``model.vmparameters``):
    ``GET model/vm/{vid}/parameters`` → ``{cpu_count, memory(MiB), cpu_mode,
    install_license, ...}``. These OVERRIDE the firmware ``.meta`` hypervisor
    block (memory/vcpu) per-VM; an unset override returns 0/"" defaults."""
    return _check(c.get(f"api/v1/model/vm/{vm_id}/parameters"),
                  "get_vm_parameters").get("object") or {}


def set_vm_parameters(c: FabricStudioClient, vm_id: int | str, *,
                      cpu_count: int | None = None, memory: int | None = None,
                      install_license: str = "FIRMWARE",
                      extra: dict[str, Any] | None = None) -> dict[str, Any]:
    """Set per-VM hypervisor parameter overrides (``PATCH model/vm/{vid}/parameters``).

    ``memory`` is MiB. Takes effect on the NEXT install (destroy_vm →
    install_vm). Idempotent -- re-setting the same values is a no-op to FS.
    ``install_license=FIRMWARE`` keeps the firmware's license behavior (the
    value the FS UI sends alongside a cpu/memory edit).

    ``extra`` passes arbitrary ``model.vmparameters`` fields (e.g. ``expert`` hooks,
    ``hugepages``, ``cpu_mode``). Keys are merged into the patch body alongside
    ``cpu_count`` / ``memory`` / ``install_license``."""
    obj: dict[str, Any] = {"install_license": install_license}
    if cpu_count is not None:
        obj["cpu_count"] = str(cpu_count)
    if memory is not None:
        obj["memory"] = str(memory)
    if extra:
        obj.update(extra)
    return _patch(
        c, f"api/v1/model/vm/{vm_id}/parameters", {"object": obj}, "set_vm_parameters",
    ).get("object") or {}


def patch_vm_params(c: FabricStudioClient, vm_id: int | str,
                    params: dict[str, Any]) -> dict[str, Any]:
    """Patch arbitrary ``model.vmparameters`` fields (e.g. ``expert``, ``hugepages``,
    ``cpu_model``). Skips common ``cpu_count``/``memory``/``install_license`` -- use
    ``set_vm_parameters`` instead for those values that need string coercion and the
    ``install_license`` sentinel. Takes effect on the NEXT install."""
    return _patch(
        c, f"api/v1/model/vm/{vm_id}/parameters", {"object": params},
        "patch_vm_params",
    ).get("object") or {}


def list_vm_disks(c: FabricStudioClient, vm_id: int | str) -> list[dict[str, Any]]:
    """The model VM's disks (``model.vmdisk``). The base firmware disk has
    ``extra=False``; data disks added via ``add_vm_disk`` have ``extra=True``
    and a ``capacity`` in MiB."""
    vm = _check(c.get(f"api/v1/model/vm/{vm_id}?related-fields=disks"),
                "list_vm_disks").get("object") or {}
    return vm.get("disks") or []


def add_vm_disk(c: FabricStudioClient, vm_id: int | str, capacity_mb: int) -> dict[str, Any]:
    """Attach an extra data disk to a model VM (``POST model/vm/{vid}/disk``).

    Body MUST set ``sizing: CUSTOM`` + ``declared`` (MiB) -- with the default
    ``sizing`` FS ignores the size and provisions a **0-byte** disk (so e.g.
    FMG/FAZ never get a usable data disk). The created row reports ``_order >= 1``
    (the base firmware disk is ``_order 0``). Takes effect on the NEXT install
    (the guest sees a new raw ``/dev/vdN``). NOT idempotent on its own -- callers
    must check ``list_vm_disks`` first; the reconciler does."""
    return _check(
        c.post(f"api/v1/model/vm/{vm_id}/disk", json_data={"capacity": int(capacity_mb)}),
        "add_vm_disk",
    ).get("object") or {}


def set_vm_disk_capacity(c: FabricStudioClient, disk_id: int | str,
                         capacity_mb: int) -> dict[str, Any]:
    """Extend a disk to ``capacity_mb`` via ``PATCH model/vm/disk/{disk_id}`` (note:
    the disk item route carries **no vm id** -- it's ``model/vm/disk/{id}``, not
    ``model/vm/{vid}/disk/{id}``).

    A firmware disk ships ``declared > 0`` (the size the image wants) but
    ``capacity 0`` -- FS provisions it **0-byte** until extended, so e.g. FMG/FAZ
    never get a usable data partition. Setting ``capacity >= declared`` (read back
    as ``sizing: CUSTOM``) makes FS honor the size on the next install."""
    return _patch(
        c, f"api/v1/model/vm/disk/{disk_id}",
        {"object": {"capacity": int(capacity_mb), "sizing": "CUSTOM"}},
        "set_vm_disk_capacity",
    ).get("object") or {}


def get_vm_license_mode(c: FabricStudioClient, fabric_id: int | str,
                        vm_id: int | str) -> dict[str, Any]:
    """The model VM's license assignment config (``model.vmlicense``):
    ``GET model/fabric/{fid}/vm/{vid}/license``. ``mode`` is how FS picks a
    license on install; ``served`` is the assigned ``system/license`` id."""
    return _check(c.get(f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}/license"),
                  "get_vm_license_mode").get("object") or {}


def set_vm_license_mode(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str,
                        mode: str = "NONE", served: int | None = None) -> dict[str, Any]:
    """Set how FS assigns a license to a model VM on install
    (``PATCH model/fabric/{fid}/vm/{vid}/license``).

    ``mode`` is a short free-form string (FS schema: maxLength 8, default
    ``AUTO``); ``NONE`` disables assignment so the VM installs with **no
    license** -- use this to build a clean, license-free base image. ``AUTO``
    pulls the best-matching license from the pool / FortiFlex. Takes effect on
    the NEXT install.

    NB: FS rejects PATCHing ``served`` directly ("Can not change 'served'",
    rcode 246) -- it's recomputed by FS from ``mode`` + the pool on install. So
    we only send ``mode`` by default; ``served`` is accepted only if FS allows
    it for the given mode (pass explicitly at your own risk)."""
    obj: dict[str, Any] = {"mode": mode}
    if served is not None:
        obj["served"] = int(served)
    return _patch(
        c, f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}/license",
        {"object": obj}, "set_vm_license_mode",
    ).get("object") or {}


# ── FortiCloud / FortiFlex account (pod-level license source) ────────────────
# Registering a FortiCloud/FortiFlex account on the pod lets FS auto-assign a
# license to a VM on install (model.vmlicense.mode=AUTO pulls from it). This is
# the FS-side license source: register it = "give FortiFlex a license"; delete
# it = "remove the license source" so installs come up unlicensed.

def get_forticloud_account(c: FabricStudioClient) -> dict[str, Any]:
    """Current FortiCloud account on the pod. ``object.flexvm.username`` is set
    when a FortiFlex account is registered (empty/absent when none)."""
    return _check(c.get("api/v1/system/forticloud/account"), "get_forticloud_account").get("object") or {}


def forticloud_registered(c: FabricStudioClient) -> bool:
    acct = get_forticloud_account(c)
    return bool((acct.get("flexvm") or {}).get("username"))


def get_pod_hostname(c: FabricStudioClient) -> str | None:
    """The pod's own device hostname via ``GET api/v1/system/hostname``
    (``object`` is the hostname string, e.g. ``fortisoar-80-beta``). Best-effort:
    returns ``None`` on any HTTP/parse error or non-200 -- callers (e.g. listing
    pods) use it as a label, not a health gate."""
    try:
        resp = c.get("api/v1/system/hostname")
        if resp.status_code == 200:
            obj = (resp.json() or {}).get("object")
            if isinstance(obj, str):
                return obj
    except Exception:
        pass
    return None


def _wait_forticloud(c: FabricStudioClient, want_registered: bool,
                     timeout_s: int = 90, poll_s: int = 3) -> None:
    """Block until the FortiCloud account reaches the desired state. Register
    and unregister are async tasks on FS -- acting again before they settle
    raises "Failed to queue task (task conflict)"."""
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if forticloud_registered(c) == want_registered:
            return
        time.sleep(poll_s)
    raise FabricStudioAdminError(
        f"forticloud account did not become {'registered' if want_registered else 'empty'} "
        f"within {timeout_s}s")


def wait_pod_idle(c: FabricStudioClient, timeout_s: int = 240, poll_s: int = 4,
                  match: str | None = None) -> None:
    """Block until the pod has no running tasks (optionally only those whose name
    contains ``match``, case-insensitive). The FortiCloud register/unregister
    flag flips BEFORE its "FortiCloud API registration" task finishes; issuing
    an install in that window fails with "task conflict". Best-effort: returns
    after timeout rather than raising."""
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        running = list_running_tasks(c)
        if match is not None:
            running = [t for t in running if match.lower() in str(t.get("name", "")).lower()]
        if not running:
            return
        time.sleep(poll_s)


def register_forticloud_account(c: FabricStudioClient, api_id: str, password: str,
                                wait: bool = True, timeout_s: int = 90) -> dict[str, Any]:
    """Register FortiFlex/FortiCloud creds so FS auto-licenses on install:
    ``POST system/forticloud/account {apiId, password}``. ``api_id``/``password``
    are the FortiFlex IAM API credentials (FORTIFLEX_USER / FORTIFLEX_PASS).
    Async on FS -- by default blocks until the account shows registered."""
    # If an unregister task is still settling, wait for it before posting.
    if wait:
        _wait_forticloud(c, want_registered=False, timeout_s=timeout_s)
    obj = _check(
        c.post("api/v1/system/forticloud/account",
               json_data={"apiId": api_id, "password": password}),
        "register_forticloud_account",
    ).get("object") or {}
    if wait:
        _wait_forticloud(c, want_registered=True, timeout_s=timeout_s)
        # The registered flag flips before the "FortiCloud API registration"
        # task closes; wait it out so a follow-on install won't task-conflict.
        wait_pod_idle(c, match="forticloud")
    return obj


def delete_forticloud_account(c: FabricStudioClient, wait: bool = True,
                              timeout_s: int = 90) -> None:
    """Remove the registered FortiCloud/FortiFlex account
    (``DELETE system/forticloud/account``) so FS has no license source.
    Async on FS -- by default blocks until the account shows empty."""
    if not forticloud_registered(c):
        return
    # A still-running registration task blocks the unregister with "task
    # conflict"; wait for FortiCloud tasks to clear first.
    wait_pod_idle(c, match="forticloud")
    _check(c.delete("api/v1/system/forticloud/account"), "delete_forticloud_account")
    if wait:
        _wait_forticloud(c, want_registered=False, timeout_s=timeout_s)
        wait_pod_idle(c, match="forticloud")


# ── Pod security preferences (public/custom port-forward gating) ──────────────
# Whether FS will expose a VM access externally is gated POD-WIDE by
# system/security/preferences. A PUBLIC vmaccess on a non-default (custom) guest
# port is silently refused unless ``custom_rules_allowed=yes``; the per-protocol
# ``{ssh,http,https,rdp}_public_allowed`` flags gate those well-known forwards.
# (Live-confirmed shape, PATCH api/v1/system/security/preferences.)

def get_security_preferences(c: FabricStudioClient) -> dict[str, Any]:
    """The pod's security preferences (``GET system/security/preferences``)."""
    return _check(c.get("api/v1/system/security/preferences"),
                  "get_security_preferences").get("object") or {}


def set_security_preferences(c: FabricStudioClient, **prefs: Any) -> dict[str, Any]:
    """PATCH ``system/security/preferences`` with the given flags (e.g.
    ``custom_rules_allowed="yes"``). Returns the updated object."""
    return _patch(c, "api/v1/system/security/preferences",
                  {"preferences": prefs}, "set_security_preferences").get("object") or {}


# The flags that must be "yes" for external port-forwards to be allocated: custom
# guest ports (e.g. an app on 8080) need custom_rules_allowed; the well-known
# protocols need their per-type flag. RDP/VNC/SPICE are left alone (security).
_PUBLIC_FORWARD_FLAGS = (
    "custom_rules_allowed", "http_public_allowed",
    "https_public_allowed", "ssh_public_allowed",
)


def ensure_public_forwards_allowed(c: FabricStudioClient,
                                   flags: tuple[str, ...] = _PUBLIC_FORWARD_FLAGS) -> list[str]:
    """Idempotently set the pod-wide port-forward gates to ``yes``. Returns the
    flags it had to change (empty when already permissive). Pod-level, so run it
    once before exposing any node's custom/public access."""
    cur = get_security_preferences(c)
    need = {f: "yes" for f in flags if cur.get(f) != "yes"}
    if not need:
        return []
    set_security_preferences(c, **need)
    return list(need)


# ── VM access (port-forward exposure) ────────────────────────────────────────

def list_vm_accesses(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str) -> list[dict[str, Any]]:
    vm = _check(c.get(f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}?related_fields=accesses"),
                "list_vm_accesses").get("object") or {}
    return vm.get("accesses") or []


def set_access_mode(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str,
                    access_id: int | str, mode: str = "PUBLIC") -> None:
    """PATCH a single access entry's mode (PUBLIC exposes an external
    port-forward; PRIVATE keeps it pod-internal)."""
    _patch(c, f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}/access/{access_id}",
           {"object": {"mode": mode}}, "set_access_mode")


# Default guest dport per access type -- used when CREATING a missing access entry
# (a freshly-uploaded BASIC qcow's .meta carries no SSH/HTTPS access, so there's
# nothing to flip; we create it on the VM model instead of editing the .meta).
# HTTPS2HTTP = FS's HTTPS-to-HTTP reverse proxy (external browser-trusted HTTPS in
# the 16000-16999 range → PLAIN-HTTP backend); backend dport is the guest's HTTP
# port (80). Use it for apps that serve plain HTTP; use HTTPS (13000-range,
# TLS→TLS) only when the guest itself terminates TLS on 443.
# RDP = the guest's xrdp/RDP port (3389); FS allocates its external forward in the
# 17000 range (ACCESS_FORWARD_BASE) once rdp_public_allowed=yes. Without an explicit
# dport FS leaves the access a stub (dport 0) and never allocates a forward.
_ACCESS_DPORT = {"SSH": 22, "HTTPS": 443, "HTTP": 80, "HTTPS2HTTP": 80, "RDP": 3389}


def create_vm_access(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str,
                     access_type: str, mode: str = "PUBLIC",
                     dport: int | None = None) -> dict[str, Any]:
    """Create a VM access entry (``POST model/fabric/{fid}/vm/{vid}/access``) so
    FS allocates an external port-forward for it. The model-level alternative to
    editing the firmware ``.meta`` access types -- and, unlike a ``.meta`` edit, a
    model change needs **no** ``refresh_home_repository``.

    ``model.vmaccess`` requires ``_order name type vm`` (FS model docs; ``vm`` comes
    from the URL, ``name`` is readonly after create). ``dport`` is the *destination*
    (guest-side) port "when not the default one" -- for SSH it equals the default 22,
    harmless to send; defaults from ``_ACCESS_DPORT`` by type."""
    obj: dict[str, Any] = {"type": access_type, "mode": mode, "name": access_type}
    dp = dport if dport is not None else _ACCESS_DPORT.get(access_type)
    if dp is not None:
        obj["dport"] = dp
    return _post_object(
        c, f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}/access", obj, "create_vm_access",
    ).get("object") or {}


def delete_vm_access(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str,
                     access_id: int | str) -> None:
    """Delete a single VM access entry (``DELETE model/fabric/{fid}/vm/{vid}/access/
    {aid}``). Used to drop a stray/wrong-dport access so ``ensure_public_access``
    re-creates it at the default dport for its type."""
    _check(
        c.request("DELETE", f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}/access/{access_id}"),
        "delete_vm_access",
    )


def ensure_public_access(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str,
                         types: tuple[str, ...] = ("HTTPS", "SSH")) -> list[str]:
    """Make the named access types PUBLIC on a VM so they get external
    port-forwards. Idempotent -- PATCHes entries not already PUBLIC, and **creates**
    a missing entry (a freshly-uploaded BASIC qcow has none to flip). Returns the
    types that were changed. The external port-forward is (re)allocated when the VM
    runtime is next applied/installed (model-only -- no home-repo refresh needed)."""
    by_type = {a.get("type"): a for a in list_vm_accesses(c, fabric_id, vm_id)}
    changed = []
    for t in types:
        a = by_type.get(t)
        want_dport = _ACCESS_DPORT.get(t)
        if a is None:
            create_vm_access(c, fabric_id, vm_id, t, "PUBLIC")
            changed.append(t)
        elif want_dport is not None and not a.get("dport"):
            # Stub entry: exists but has no guest dport (e.g. an RDP access created
            # at dport 0 before RDP had a default), so FS never allocated a forward.
            # Recreate at the correct dport -- a bare mode flip can't set dport. Only
            # falsy dports are repaired, so a working SSH/HTTPS forward is untouched.
            delete_vm_access(c, fabric_id, vm_id, a["id"])
            create_vm_access(c, fabric_id, vm_id, t, "PUBLIC")
            changed.append(t)
        elif a.get("mode") != "PUBLIC":
            set_access_mode(c, fabric_id, vm_id, a["id"], "PUBLIC")
            changed.append(t)
    return changed


# ── Live access-port validation ──────────────────────────────────────────────
# A deployed guest's PUBLIC access is reachable at pod_host:(base + port_idx).
# These bases mirror fabric_config._SSH_FORWARD_BASE / _WEB_FORWARD_BASE; keep
# them in sync. HTTP's external base is a fallback (rarely PUBLIC).
ACCESS_FORWARD_BASE = {"SSH": 11000, "HTTPS": 13000, "HTTPS2HTTP": 16000,
                       "HTTP": 18000, "RDP": 17000}


def probe_access_port(host: str, port: int, kind: str,
                      timeout: float = 6.0) -> tuple[bool, str]:
    """Live-probe one exposed listener: SSH = TCP connect + banner ('SSH-'),
    HTTPS/HTTPS2HTTP = TLS handshake, anything else = TCP connect. Returns
    ``(ok, detail)``. This is a *liveness* probe (does the listener answer), not
    an auth/trust check, so the TLS handshake intentionally does not verify the
    cert (FS guest certs behind the proxy are self-signed)."""
    import socket
    import ssl
    try:
        if kind in ("HTTPS", "HTTPS2HTTP"):
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            with (socket.create_connection((host, port), timeout=timeout) as raw,
                  ctx.wrap_socket(raw, server_hostname=host) as tls):
                return True, f"TLS {tls.version()}"
        with socket.create_connection((host, port), timeout=timeout) as s:
            if kind == "SSH":
                s.settimeout(timeout)
                banner = s.recv(64).decode("latin-1", "replace").strip()
                if banner.startswith("SSH-"):
                    return True, banner[:40]
                return False, f"no SSH banner (got {banner[:30]!r})"
            return True, "tcp connect ok"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def probe_vm_accesses(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str,
                      host: str, timeout: float = 6.0) -> list[dict[str, Any]]:
    """Live-probe every PUBLIC access on a VM at its external port-forward
    (``ACCESS_FORWARD_BASE[type] + port_idx``). Returns one
    ``{type, port, ok, detail}`` per probeable PUBLIC access (empty if the VM has
    no port_idx yet -- i.e. not installed)."""
    rv = get_runtime_vm(c, vm_id)
    port_idx = rv.get("port_idx")
    out: list[dict[str, Any]] = []
    if port_idx is None:
        return out
    seen: set[tuple[str, int]] = set()
    for a in list_vm_accesses(c, fabric_id, vm_id):
        atype = a.get("type")
        if a.get("mode") != "PUBLIC" or atype not in ACCESS_FORWARD_BASE:
            continue
        ext = ACCESS_FORWARD_BASE[atype] + int(port_idx)
        # FS may carry duplicate vmaccess rows of the same type (e.g. one per
        # guest interface); the external forward is base+port_idx (per-VM), so
        # they all map to the same listener -- probe it once.
        if (atype, ext) in seen:
            continue
        seen.add((atype, ext))
        ok, detail = probe_access_port(host, ext, atype, timeout)
        out.append({"type": atype, "port": ext, "ok": ok, "detail": detail})
    return out


# ── System Host custom port redirection (model.portredirect) ─────────────────
# A custom external port → guest:port forward is NOT a vmaccess -- it's a
# model.portredirect rule on the System Host (the fabric router/NAT). FS only
# accepts these when pod-wide custom_rules_allowed=yes (see
# ensure_public_forwards_allowed). Live-confirmed fields (PATCH/POST
# model/fabric/{fid}/host/port/redirect): device (the System Host's model.host
# id), name, from_port (external listener), to_addr (guest ip), to_port (guest
# port), socktype TCP|UDP, snat (use to_addr as source), enabled.

def list_port_redirects(c: FabricStudioClient, fabric_id: int | str) -> list[dict[str, Any]]:
    """The fabric's System Host custom port-redirect rules."""
    return _check(c.get(f"api/v1/model/fabric/{fabric_id}/host/port/redirect"),
                  "list_port_redirects").get("object") or []


def delete_port_redirect(c: FabricStudioClient, fabric_id: int | str,
                         redirect_id: int | str) -> None:
    """Delete a System Host custom port-redirect rule by id."""
    _check(
        c.request("DELETE", f"api/v1/model/fabric/{fabric_id}/host/port/redirect/{redirect_id}"),
        "delete_port_redirect",
    )


def create_port_redirect(c: FabricStudioClient, fabric_id: int | str, *, device: int | str,
                         name: str, from_port: int, to_addr: str, to_port: int,
                         socktype: str = "TCP", snat: bool = True,
                         description: str = "", enabled: bool = True) -> dict[str, Any]:
    """Create a System Host port-redirect (external ``from_port`` → ``to_addr``:
    ``to_port``). ``device`` is the System Host's model.host id
    (``get_system_host(...)['id']``)."""
    # POSTed to the HOST-scoped route, with the host in the path and NOT in the
    # body. The fabric-scoped route rejects the same object with
    # ``object.cast.device: readonly_fields`` -- ``device`` is derived from the
    # path there, so supplying it fails the cast and the whole create 400s with
    # "Unable to deserialize: model.portredirect", which reads as a malformed
    # rule rather than as one field too many. Live-verified on a pod with no
    # redirects, where there was no existing rule to copy the shape from.
    # Reads still use the fabric-scoped route, which is fine: it is the same
    # collection viewed through the fabric's System Host.
    obj = {"name": name, "from_port": int(from_port),
           "to_addr": to_addr, "to_port": int(to_port), "socktype": socktype,
           "snat": snat, "description": description, "enabled": enabled}
    return _post_object(
        c, f"api/v1/model/host/{device}/port/redirect", obj, "create_port_redirect",
    ).get("object") or {}


def ensure_port_redirect(c: FabricStudioClient, fabric_id: int | str, *, device: int | str,
                         name: str, from_port: int, to_addr: str, to_port: int,
                         socktype: str = "TCP") -> bool:
    """Idempotently ensure an external ``from_port``/``socktype`` redirects to
    ``to_addr``:``to_port`` on the System Host. Identity is (from_port, socktype)
    -- the unique external listener; a re-run with the same target is a no-op, a
    changed target is PATCHed. Returns True if it created/changed anything.

    Pod-wide ``custom_rules_allowed`` must be ``yes`` or FS rejects the rule."""
    for r in list_port_redirects(c, fabric_id):
        if int(r.get("from_port") or 0) == int(from_port) and \
                (r.get("socktype") or "TCP") == socktype:
            if r.get("to_addr") == to_addr and int(r.get("to_port") or 0) == int(to_port):
                return False
            _patch(
                c, f"api/v1/model/fabric/{fabric_id}/host/port/redirect/{r['id']}",
                {"object": {**r, "device": device, "name": name,
                            "to_addr": to_addr, "to_port": int(to_port)}},
                "update_port_redirect",
            )
            return True
    create_port_redirect(c, fabric_id, device=device, name=name, from_port=from_port,
                         to_addr=to_addr, to_port=to_port, socktype=socktype)
    return True


# ── Topology: networks / switches / cables / ports ───────────────────────────
# FS models a fabric's L2/L3 as: networks (ipv4 subnet + gateway), switches
# (each carrying an ``auto_address_network`` that AUTO-ASSIGNS a static IP to any
# VM port cabled to it), and cables (join two PORT ids via conn1/conn2). VM ports
# (model.vmport) and switch ports (model.switchport) share one id space; a cable
# connects a vmport id to a switchport id. This is the contract that gives a
# guest a reachable IP -- a VM with only the auto OOB port and no fabric switch
# never gets one. All creates need the {"object": {...}} body wrapper and return
# the created row in ``object`` (verified live on an 8.0.0 pod).

def delete_vm(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str) -> None:
    """Delete a model VM (``DELETE model/fabric/{fid}/vm/{vid}``). Tear down its
    runtime first (``destroy_vm``) if installed. Removes the model row entirely --
    contrast ``destroy_vm`` which only removes the runtime."""
    _check(c.delete(f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}"), "delete_vm")


def delete_switch(c: FabricStudioClient, fabric_id: int | str, switch_id: int | str) -> None:
    _check(c.delete(f"api/v1/model/fabric/{fabric_id}/switch/{switch_id}"), "delete_switch")


def delete_network(c: FabricStudioClient, fabric_id: int | str, network_id: int | str) -> None:
    _check(c.delete(f"api/v1/model/fabric/{fabric_id}/network/{network_id}"), "delete_network")


def list_networks(c: FabricStudioClient, fabric_id: int | str) -> list[dict[str, Any]]:
    return _check(c.get(f"api/v1/model/fabric/{fabric_id}/network"), "list_networks").get("object") or []


def create_network(c: FabricStudioClient, fabric_id: int | str, name: str,
                   ipv4network: str, ipv4netmask: str = "255.255.255.0",
                   ipv4gateway: str | None = None) -> dict[str, Any]:
    """Create an L3 network (subnet) in a fabric. ``ipv4gateway`` defaults to
    ``.254`` of the subnet if omitted is NOT done here -- pass it explicitly."""
    obj = {"name": name, "ipv4network": ipv4network, "ipv4netmask": ipv4netmask}
    if ipv4gateway:
        obj["ipv4gateway"] = ipv4gateway
    return _check(c.post(f"api/v1/model/fabric/{fabric_id}/network",
                         json_data={"object": obj}), "create_network").get("object") or {}


def ensure_network(c: FabricStudioClient, fabric_id: int | str, name: str,
                   ipv4network: str, ipv4netmask: str = "255.255.255.0",
                   ipv4gateway: str | None = None) -> dict[str, Any]:
    for n in list_networks(c, fabric_id):
        if n.get("name") == name:
            return n
    return create_network(c, fabric_id, name, ipv4network, ipv4netmask, ipv4gateway)


def update_network(c: FabricStudioClient, fabric_id: int | str, network_id: int | str,
                   **fields: Any) -> dict[str, Any]:
    """PATCH a network's L3 attributes (``ipv4network``/``ipv4netmask``/
    ``ipv4gateway``/``ipv4dns1``/``ipv4dns2``/``name``). Only the keyword fields
    you pass are sent. Takes effect on the next synchronize/install of attached
    VMs. Returns the updated row. NB: renumbering a live network is disruptive --
    the reconciler only emits this when an intent's cidr/gateway drifts."""
    obj = {k: v for k, v in fields.items() if v is not None}
    if not obj:
        return next((n for n in list_networks(c, fabric_id)
                     if str(n.get("id")) == str(network_id)), {})
    return _patch(
        c, f"api/v1/model/fabric/{fabric_id}/network/{network_id}",
        {"object": obj}, "update_network",
    ).get("object") or {}


def list_switches(c: FabricStudioClient, fabric_id: int | str) -> list[dict[str, Any]]:
    return _check(c.get(f"api/v1/model/fabric/{fabric_id}/switch"), "list_switches").get("object") or []


def create_switch(c: FabricStudioClient, fabric_id: int | str, name: str,
                  auto_address_network: int | str | None = None,
                  mgmt: bool = True) -> dict[str, Any]:
    """Create a switch. When ``auto_address_network`` is a network id, FS
    auto-assigns a static IP from that subnet to every VM port cabled to this
    switch (the mechanism behind a working VM's reachable mgmt IP). The switch is
    created with a pool of free switchports (``object.ports``) ready to cable."""
    obj: dict[str, Any] = {"name": name, "mgmt": mgmt}
    if auto_address_network is not None:
        obj["auto_address_network"] = int(auto_address_network)
    return _check(c.post(f"api/v1/model/fabric/{fabric_id}/switch",
                         json_data={"object": obj}), "create_switch").get("object") or {}


def ensure_switch(c: FabricStudioClient, fabric_id: int | str, name: str,
                  auto_address_network: int | str | None = None,
                  mgmt: bool = True) -> dict[str, Any]:
    for s in list_switches(c, fabric_id):
        if s.get("name") == name:
            return s
    return create_switch(c, fabric_id, name, auto_address_network, mgmt)


# Sentinel so ``update_switch`` can distinguish "leave auto_address_network
# alone" (default) from "clear it" (explicit None).
_UNSET = object()


def update_switch(c: FabricStudioClient, fabric_id: int | str, switch_id: int | str,
                  *, name: str | None = None,
                  auto_address_network: int | str | None = _UNSET,  # type: ignore[assignment]
                  mgmt: bool | None = None) -> dict[str, Any]:
    """Rewire / rename an existing switch (``PATCH model/fabric/{fid}/switch/{sid}``).

    The headline use is **switch ↔ network rewire**: pass
    ``auto_address_network`` to repoint which subnet a switch auto-addresses its
    cabled VM ports from (``None`` to clear it so the switch stops handing out
    IPs). Only the fields you pass are sent -- omitting ``auto_address_network``
    leaves it untouched (a real ``None`` clears it, hence the ``_UNSET``
    sentinel). Takes effect on the next ``synchronize_device`` of the attached
    VMs (model-only change -- no reinstall). Returns the updated switch row."""
    obj: dict[str, Any] = {}
    if name is not None:
        obj["name"] = name
    if mgmt is not None:
        obj["mgmt"] = bool(mgmt)
    if auto_address_network is not _UNSET:
        obj["auto_address_network"] = (
            int(auto_address_network) if auto_address_network is not None else None
        )
    if not obj:
        # Nothing to change -- return the current row so callers stay idempotent.
        return next((s for s in list_switches(c, fabric_id)
                     if str(s.get("id")) == str(switch_id)), {})
    return _patch(
        c, f"api/v1/model/fabric/{fabric_id}/switch/{switch_id}",
        {"object": obj}, "update_switch",
    ).get("object") or {}


def get_system_host(c: FabricStudioClient, fabric_id: int | str) -> dict[str, Any]:
    """The fabric's **System Host** (``GET model/fabric/{fid}/host``) -- the
    pod-provided router/NAT/DHCP that gives the fabric its egress.

    There is exactly one per fabric (singular endpoint, returns one object). Its
    ``ports`` are the fabric's uplinks: ``mgmt1`` is the external WAN port
    (``external=1, egress_nat=True`` -- the pod's real NAT), and each ``int``
    port is cabled to exactly one switch (``peer`` = that switch's port id),
    making that switch **host-uplinked** = routable. FS seeds two uplinked
    switches: "OOB Mgmt" (a management net -- no default gateway injected) and
    "Internet Access" (an egress net -- gateway injected → internet egress). A
    switch with NO host-port peer is a *floating segment*: IPs get assigned but
    there's no route off it (see ``read_fabric_state``'s ``host_uplinked``).

    ``?related_fields=ports`` is required or ``ports`` comes back as bare ids."""
    return _check(
        c.get(f"api/v1/model/fabric/{fabric_id}/host?related_fields=ports"),
        "get_system_host",
    ).get("object") or {}


def set_host_port_ipv4(c: FabricStudioClient, host_port_id: int | str,
                       ipv4addr: str, ipv4netmask: str = "255.255.255.0") -> dict[str, Any]:
    """Set a System Host port's address via ``PATCH model/host/port/{id}`` (item
    route carries **no host id** -- ``model/host/port/{id}``, like the disk route).

    A switch host-uplinks (routes outbound via the host's NAT) only when a
    forwarding System Host port OWNS its network's gateway IP and is cabled onto
    that switch. Repointing a host int port to a custom net's gateway is how you
    uplink a user-declared management network the pod didn't seed."""
    return _patch(
        c, f"api/v1/model/host/port/{host_port_id}",
        {"object": {"ipv4addr": ipv4addr, "ipv4netmask": ipv4netmask}},
        "set_host_port_ipv4",
    ).get("object") or {}


def list_switch_ports(c: FabricStudioClient, fabric_id: int | str,
                      switch_id: int | str) -> list[dict[str, Any]]:
    return _check(c.get(f"api/v1/model/fabric/{fabric_id}/switch/{switch_id}/port"),
                  "list_switch_ports").get("object") or []


def free_switch_port(c: FabricStudioClient, fabric_id: int | str,
                     switch_id: int | str) -> dict[str, Any] | None:
    """First switchport with no cable attached (``cable`` None), or None."""
    for p in list_switch_ports(c, fabric_id, switch_id):
        if not p.get("cable") and not p.get("peer"):
            return p
    return None


def add_switch_port(c: FabricStudioClient, fabric_id: int | str,
                    switch_id: int | str) -> dict[str, Any]:
    """Append a new port to a switch (``POST model/fabric/{fid}/switch/{sid}/port``).
    FS auto-assigns a name and index. Returns the new port row."""
    return _check(
        c.post(f"api/v1/model/fabric/{fabric_id}/switch/{switch_id}/port",
               json_data={"object": {}}),
        "add_switch_port",
    ).get("object") or {}


def set_switchport_vlan(c: FabricStudioClient, port_id: int | str, *,
                        mode: str | None = None, vlan: int | None = None,
                        trunk: str | None = None) -> dict[str, Any]:
    """Set a switchport's OVS VLAN fields (``PATCH model/switch/port/{id}``).

    ``mode`` is OVS ``vlan_mode`` -- ``"access"`` (untagged, frames land on
    ``vlan``) or ``"trunk"`` (tagged, ``trunk`` is the comma-separated allow
    list). Only the fields you pass are written.

    Two traps this wraps:
      * a NATIVE vlan alongside ``mode: trunk`` is silently ignored by OVS, so
        callers should send ``vlan=0`` with a trunk rather than a tag that looks
        honoured in the GUI and is not;
      * the API validates NOTHING here -- 4096, -1 and ``"not,a,vlan"`` are all
        accepted and stored. Validate before calling (see ``fs_topology``'s
        intent-level VLAN checks).

    The write alone does not change forwarding: OVS is only reprogrammed by
    ``install_switch`` (a device *synchronize* updates the runtime row and
    leaves the bridge on its old config)."""
    obj: dict[str, Any] = {}
    if mode is not None:
        obj["mode"] = mode
    if vlan is not None:
        obj["vlan"] = int(vlan)
    if trunk is not None:
        obj["trunk"] = trunk
    if not obj:
        return {}
    return _patch(c, f"api/v1/model/switch/port/{port_id}", {"object": obj},
                  "set_switchport_vlan")


def install_switch(c: FabricStudioClient, switch_id: int | str) -> dict[str, Any]:
    """Reinstall a switch's runtime (``POST runtime/switch/{id}``) so OVS picks
    up model-side VLAN changes.

    This is NOT interchangeable with ``synchronize_device``. Verified in both
    directions on a live pod: after narrowing a trunk, the removed VLAN still
    forwarded; after widening it back, the restored VLAN still did not -- until
    this call ran. ``GET runtime/switch/{id}/port`` reports the NEW value the
    whole time, so the runtime row reads correct while traffic follows the old
    config. Any VLAN edit must be followed by this."""
    return _check(c.post(f"api/v1/runtime/switch/{switch_id}", json_data={}),
                  "install_switch").get("object") or {}


def get_vm_ports(c: FabricStudioClient, fabric_id: int | str,
                 vm_id: int | str) -> list[dict[str, Any]]:
    vm = _check(c.get(f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}?related_fields=ports"),
                "get_vm_ports").get("object") or {}
    return vm.get("ports") or []


def list_routers(c: FabricStudioClient, fabric_id: int | str) -> list[dict[str, Any]]:
    """The fabric's FS-native **routers** (``GET model/fabric/{fid}/router``).

    Distinct from the System Host: a ``model.router`` is an in-fabric L3 hop that
    FS seeds into some fabric templates (e.g. an "ISP Router" fronting a seeded
    Internet/ISP pair). It owns real port IPs and answers ARP on whatever segment
    it is cabled to, but the topology framework has never modelled it -- there is
    no ``routers:`` intent key -- so before this existed it was invisible to
    ``plan``/``prune``/``verify``.

    That invisibility is not academic. A seeded router holding a segment's
    gateway address while its own upstream port is uncabled (and with no default
    route of its own) wins the ARP against the System Host port configured with
    the same address, and every guest on that segment black-holes. ``plan``
    reported the fabric clean throughout, because it could not see the device.
    Live-diagnosed on the fortiaigate_lab fabric.

    Returns the model rows; ``read_fabric_state`` attaches each router's ports.
    """
    return _check(c.get(f"api/v1/model/fabric/{fabric_id}/router"),
                  "list_routers").get("object") or []


def list_router_ports(c: FabricStudioClient, fabric_id: int | str,
                      router_id: int | str) -> list[dict[str, Any]]:
    """One router's ports (``GET model/fabric/{fid}/router/{id}/port``).

    Same shape as a vmport plus the NAT flags (``egress_nat``/``ingress_nat``).
    A port with ``cable: None`` is an unconnected leg -- which is what makes a
    seeded router a black hole when its *other* leg holds a live gateway IP."""
    return _check(c.get(f"api/v1/model/fabric/{fabric_id}/router/{router_id}/port"),
                  "list_router_ports").get("object") or []


def delete_router(c: FabricStudioClient, fabric_id: int | str,
                  router_id: int | str) -> dict[str, Any]:
    """Delete an FS-native router from a fabric.

    Uncable its ports first: a router still cabled into a switch may be refused,
    and an uncabled router is already inert (it can no longer answer ARP for a
    gateway address), so the uncable is the load-bearing half."""
    return _check(c.delete(f"api/v1/model/fabric/{fabric_id}/router/{router_id}"),
                  "delete_router").get("object") or {}


def list_cables(c: FabricStudioClient, fabric_id: int | str) -> list[dict[str, Any]]:
    return _check(c.get(f"api/v1/model/fabric/{fabric_id}/cable"), "list_cables").get("object") or []


def create_cable(c: FabricStudioClient, fabric_id: int | str,
                 device1: int | str, port1: int | str,
                 device2: int | str, port2: int | str) -> dict[str, Any]:
    """Cable two device ports together. Body is FLAT (not object-wrapped) with
    ``device1``/``device1port`` and ``device2``/``device2port`` -- device is the
    owning VM or switch id, the port is the vmport/switchport id. FS assigns the
    cable hwaddr and returns the row (``conn1``/``conn2`` = the two port ids)."""
    body = {"device1": int(device1), "device1port": int(port1),
            "device2": int(device2), "device2port": int(port2)}
    return _check(c.post(f"api/v1/model/fabric/{fabric_id}/cable", json_data=body),
                  "create_cable").get("object") or {}


def delete_cable(c: FabricStudioClient, fabric_id: int | str, cable_id: int | str) -> None:
    """Cables are item-addressed globally, not under the fabric (the fabric path
    is only for list/create): ``DELETE model/cable/{id}``."""
    _check(c.delete(f"api/v1/model/cable/{cable_id}"), "delete_cable")


def cable_vm_to_switch(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str,
                       switch_id: int | str, port_name: str = "eth0") -> dict[str, Any]:
    """Idempotently cable a VM's port (default eth0) to a free port on a switch.
    Removes any existing cable on that VM port first (e.g. the auto OOB cable),
    so the port moves onto the auto-address switch and picks up a reachable IP on
    the next install. Returns the new cable row."""
    ports = get_vm_ports(c, fabric_id, vm_id)
    vp = next((p for p in ports if p.get("name") == port_name), None)
    if not vp:
        raise FabricStudioAdminError(f"cable_vm_to_switch: VM {vm_id} has no port {port_name!r}")
    if vp.get("cable"):
        delete_cable(c, fabric_id, vp["cable"])
    sp = free_switch_port(c, fabric_id, switch_id)
    if not sp:
        sp = add_switch_port(c, fabric_id, switch_id)
    return create_cable(c, fabric_id, vp["device"], vp["id"], sp["device"], sp["id"])


def set_port_ipv4(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str,
                  port_id: int | str, ipv4addr: str | None,
                  ipv4netmask: str | None = None, addrmode: str = "STA",
                  dhcp_server: int | None = None, network: int | None = None) -> None:
    """Set a VM port's address. ``addrmode`` STA=static (set ipv4addr), or DHCP
    (FS/guest negotiates). PATCH model.vmport via the VM's port collection.

    ``dhcp_server`` (a native-device id, e.g. the System Host) turns the port into
    FS *static DHCP*: ``addrmode`` is forced to ``DHCP`` and FS leases the exact
    ``ipv4addr``/``ipv4netmask`` to a guest doing plain DHCP. A qcow guest can't
    take an FS-injected static address, so this is the way to give one a fixed,
    FS-owned IP. The lease carries the VM's Network Parameters DNS always, but its
    gateway ONLY when that gateway is inside this port's subnet -- else the guest
    gets an address and no default route (live-verified on 2.2.35).

    The change is model-only: the System Host serves it after a System Host
    **install** (see ``devices_needing_dhcp_install``); a sync of the host or the
    VM leaves the old lease.

    ``network`` (a ``model.network`` id) is **required** for static-DHCP to work:
    per the FS model docs it's what "configures gateway and nameserver served by
    the native DHCP service". Without it the System Host issues no lease (proven
    live -- port had ``network=None`` → no ``runtimedhcpentry`` → guest unreachable).
    Pass the network the port's switch auto-addresses."""
    if dhcp_server is not None:
        addrmode = "DHCP"
    obj: dict[str, Any] = {"addrmode": addrmode}
    if ipv4addr is not None:
        obj["ipv4addr"] = ipv4addr
    if ipv4netmask is not None:
        obj["ipv4netmask"] = ipv4netmask
    if dhcp_server is not None:
        obj["dhcp_server"] = dhcp_server
    if network is not None:
        obj["network"] = network
    _patch(c, f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}/port/{port_id}",
           {"object": obj}, "set_port_ipv4")


def set_port_mgmt(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str,
                  port_id: int | str, mgmt: bool) -> None:
    """Flag a VM port as the guest's **management port** (``model.vmport.mgmt``).

    FS points a VM's external access port-forwards (SSH ``11000+idx``, …) at its
    mgmt port. With no mgmt port the forward still LISTENS on the pod but has no
    target: the TCP connect succeeds and the session then hangs with no banner,
    which reads exactly like a perimeter firewall block. The carrying switch must
    also be a management switch (``model.switch.mgmt``) and the change only takes
    effect on a **full fabric install** -- a per-VM destroy+install_vm is not
    enough (proven live 07-16, pod B: fitng's SSH forward)."""
    _patch(c, f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}/port/{port_id}",
           {"object": {"mgmt": bool(mgmt)}}, "set_port_mgmt")


def clear_port_ipv4(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str,
                    port_id: int | str, network: int | None = None) -> None:
    """Explicitly NULL a VM port's static IP (``set_port_ipv4`` can't -- it skips a
    None ipv4addr to mean 'leave unchanged'). Use when a port was moved to a
    different auto_address switch and kept a stale out-of-subnet IP: clear it so
    FS auto-addresses a fresh in-subnet IP from the switch's network at the NEXT
    INSTALL (FS assigns auto_address at install, not synchronize -- proven live).
    Pass ``network`` (the switch's auto_address net id) so FS knows which subnet
    to draw from."""
    obj: dict[str, Any] = {"ipv4addr": None, "ipv4netmask": None, "addrmode": "STA"}
    if network is not None:
        obj["network"] = int(network)
    _patch(c, f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}/port/{port_id}",
           {"object": obj}, "clear_port_ipv4")


def set_port_auto_config(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str,
                         port_id: int | str, enabled: bool) -> None:
    """Turn FS address management on/off for a VM port (``model.vmport.auto_config``
    -- "Address is configured by the Fabric Studio", default true).

    Turn it OFF for a port that must NOT carry an untagged L3 address -- an
    802.1Q trunk being the case that matters. FS auto-addresses any cabled port
    with no IP from its switch's network AT INSTALL, so merely clearing the
    address is not enough: it comes back, sits untagged on a trunk, and is
    dropped at the uplink while the guest looks configured."""
    _patch(c, f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}/port/{port_id}",
           {"object": {"auto_config": bool(enabled)}}, "set_port_auto_config")


def set_port_link(c: FabricStudioClient, device_id: int | str, port_id: int | str,
                  up: bool) -> dict[str, Any]:
    """Per-port enable/disable on a RUNNING VM by breaking/repairing the cable
    attached to one port -- link down/up WITHOUT removing the model cable.

    FS has no model-level "port enabled" flag (confirmed against the OpenAPI:
    ``model.vmport`` carries no such field). The administrative on/off lever is
    the runtime cable break/repair pair, addressed by ``(device, port)``:
      * ``up=False`` → ``POST runtime/device/cable/{device}/{port}:break``
                       (the port goes link-down; the cable stays in the model)
      * ``up=True``  → ``POST runtime/device/cable/{device}/{port}:repair``

    Runtime-only: the VM must be installed (a model-only port can't break a
    cable that has no runtime). ``device_id`` is the owning VM's id, ``port_id``
    the ``model.vmport`` id. Returns the queued task object -- poll with
    ``wait_device_task``. Idempotent at FS level (re-breaking a broken cable /
    re-repairing a healthy one is accepted)."""
    verb = "repair" if up else "break"
    return _check(
        c.post(f"api/v1/runtime/device/cable/{device_id}/{port_id}:{verb}"),
        "set_port_link",
    ).get("object") or {}


def _port_ip_in_network(ip: str | None, network_row: dict[str, Any] | None) -> bool:
    """Return True if ``ip`` falls within the CIDR described by ``network_row``
    (fields: ``ipv4network``, ``ipv4netmask``). Returns True when either argument
    is absent so callers only flag genuine mismatches."""
    if not ip or not network_row:
        return True
    net_addr = network_row.get("ipv4network")
    net_mask = network_row.get("ipv4netmask")
    if not net_addr or not net_mask:
        return True
    try:
        network = ipaddress.IPv4Network(f"{net_addr}/{net_mask}", strict=False)
        return ipaddress.IPv4Address(ip) in network
    except ValueError:
        return True


def read_fabric_state(c: FabricStudioClient, fabric_id: int | str) -> dict[str, Any]:
    """Read a fabric's WHOLE model graph in one shot for the reconciler to diff.

    Returns a plain-dict snapshot (JSON-friendly, no live objects) of every
    resource type the topology framework manages, plus index maps that make
    diffing cheap:

      {
        "fabric":   {"id", "name", ...},
        "host":     {id,name,"ports":[...]},        # System Host (router/NAT/DHCP)
        "networks": [ {id,name,ipv4network,ipv4netmask,ipv4gateway,ipv4dns1,ipv4dns2} ],
        "switches": [ {id,name,auto_address_network,mgmt,vm_type,host_uplinked,
                       host_uplink_gateway,"ports":[ {id,name,device,cable,peer,vlan,...} ]} ],
        "vms":      [ {id,name,vm_type,firmware,
                       "ports":[ {id,name,device,ipv4addr,ipv4netmask,addrmode,
                                  network,cable,peer,mgmt} ]} ],
        "cables":   [ {id,conn1,conn2} ],
        "routers":  [ {id,name,vm_type,"ports":[ {id,name,ipv4addr,egress_nat,
                       ingress_nat,cable,peer} ]} ],   # FS-native in-fabric L3 hops
        # ---- derived indices (not FS rows) ----
        "ports_by_id":   {port_id: port_row},      # vm + switch ports unified
        "device_by_port":{port_id: owning_device_id},
        "links":         [ {"vm_id","vm_port","vm_port_name","switch_id",
                            "switch_port","cable_id"} ],  # resolved vm↔switch edges
        "router_links":  [ {"router_id","router_port","router_port_name",
                            "router_port_ip","switch_id","switch_port",
                            "cable_id"} ],                # router↔switch edges
        "switch_links":  [ {"switch_a","switch_a_port","switch_a_port_name",
                            "switch_b","switch_b_port","switch_b_port_name",
                            "cable_id"} ],                # switch↔switch trunks
      }

    A "link" is the reconciler's unit of cabling: it walks each cable, finds the
    vm-port end and the switch-port end, and records which VM port is attached to
    which switch -- exactly the shape an intent ``links:`` entry declares. Cables
    that don't join a vm-port to a switch-port (e.g. switch↔switch trunks) are
    left in ``cables`` but produce no link. All reads here are GETs -- safe to run
    concurrently against a busy pod."""
    fabric = next((f for f in list_fabrics(c) if str(f.get("id")) == str(fabric_id)), {})

    networks = list_networks(c, fabric_id)

    switches = list_switches(c, fabric_id)
    for s in switches:
        s["ports"] = list_switch_ports(c, fabric_id, s["id"])

    # System Host = the fabric router. A switch is **host-uplinked** (routable)
    # iff a forwarding System Host port OWNS the gateway IP of the network the
    # switch auto-addresses -- i.e. when FS hands a cabled VM port an IP from that
    # net with the net's gateway, a real router actually answers at that gateway.
    # This is the routing ground truth, independent of the cable/peer topology
    # (which can reach a switch via an indirect bridge hop and mislead a naive
    # port-adjacency check). A switch whose net's gateway no host port owns is a
    # *floating segment*: IPs get assigned but nothing routes off it (the matrix
    # bug -- and, in some seeded fabrics, the "Internet Access" switch itself).
    host = get_system_host(c, fabric_id)
    host_gateways = {
        hp.get("ipv4addr")
        for hp in (host.get("ports") or [])
        if isinstance(hp, dict) and hp.get("forwarding") and hp.get("ipv4addr")
    }
    nets_by_id = {n.get("id"): n for n in networks}
    for s in switches:
        net = nets_by_id.get(s.get("auto_address_network"))
        gw = net.get("ipv4gateway") if net else None
        s["host_uplinked"] = bool(gw) and gw in host_gateways
        s["host_uplink_gateway"] = gw if s["host_uplinked"] else None

    vms_raw = _check(
        c.get(f"api/v1/model/fabric/{fabric_id}/vm?related_fields=ports"),
        "read_fabric_state.vms",
    ).get("object") or []
    vms = []
    for v in vms_raw:
        vms.append({
            "id": v.get("id"), "name": v.get("name"), "vm_type": v.get("vm_type"),
            "firmware": v.get("firmware"), "config": v.get("config"),
            "auto_params_network": v.get("auto_params_network"),
            "ports": v.get("ports") or [],
        })

    cables = list_cables(c, fabric_id)

    # FS-native routers. Seeded into some fabric templates and never modelled by
    # the intent, so they used to be absent from this snapshot entirely -- which
    # made a router holding a segment's gateway IP undiagnosable from `plan`.
    routers = list_routers(c, fabric_id)
    for r in routers:
        r["ports"] = list_router_ports(c, fabric_id, r["id"])

    # ---- vmport IP-in-subnet validation -----------------------------------
    # Ports moved to a different switch retain their old IP; FS won't auto-
    # correct. Flag them now so callers surface the mismatch rather than
    # discovering it as "SSH dots" mid-install.
    # We need switch_id → network for each vm port, which requires cable
    # resolution -- defer to the links loop below; validation warnings are
    # collected into ``port_ip_warnings`` keyed by port id.
    port_ip_warnings: dict[Any, str] = {}

    # ---- derived indices --------------------------------------------------
    ports_by_id: dict[Any, dict[str, Any]] = {}
    device_by_port: dict[Any, Any] = {}
    switch_port_ids: set[Any] = set()
    vm_port_ids: set[Any] = set()
    for s in switches:
        for p in s["ports"]:
            ports_by_id[p["id"]] = p
            device_by_port[p["id"]] = s["id"]
            switch_port_ids.add(p["id"])
    for v in vms:
        for p in v["ports"]:
            ports_by_id[p["id"]] = p
            device_by_port[p["id"]] = v["id"]
            vm_port_ids.add(p["id"])
    router_port_ids: set[Any] = set()
    for r in routers:
        for p in r["ports"]:
            ports_by_id[p["id"]] = p
            device_by_port[p["id"]] = r["id"]
            router_port_ids.add(p["id"])

    links = []
    switch_links: list[dict[str, Any]] = []
    router_links: list[dict[str, Any]] = []
    for cab in cables:
        a, b = cab.get("conn1"), cab.get("conn2")
        # Orient so (vm_port, switch_port) regardless of conn order.
        if a in vm_port_ids and b in switch_port_ids:
            vm_p, sw_p = a, b
        elif b in vm_port_ids and a in switch_port_ids:
            vm_p, sw_p = b, a
        elif (a in router_port_ids and b in switch_port_ids) or \
             (b in router_port_ids and a in switch_port_ids):
            rt_p, sw_p2 = (a, b) if a in router_port_ids else (b, a)
            rt_port = ports_by_id.get(rt_p, {})
            router_links.append({
                "router_id": device_by_port.get(rt_p), "router_port": rt_p,
                "router_port_name": rt_port.get("name"),
                "router_port_ip": rt_port.get("ipv4addr"),
                "switch_id": device_by_port.get(sw_p2), "switch_port": sw_p2,
                "cable_id": cab.get("id"),
            })
            continue
        elif a in switch_port_ids and b in switch_port_ids:
            # Switch↔switch trunk. It used to be dropped here with everything
            # else, which made inter-switch trunks invisible to state -- a VLAN
            # could be missing from the uplink between two switches and nothing
            # in the snapshot could see it. Record it separately: it is not a
            # ``link`` (no VM end), but it IS topology.
            switch_links.append({
                "switch_a": device_by_port.get(a), "switch_a_port": a,
                "switch_a_port_name": ports_by_id.get(a, {}).get("name"),
                "switch_b": device_by_port.get(b), "switch_b_port": b,
                "switch_b_port_name": ports_by_id.get(b, {}).get("name"),
                "cable_id": cab.get("id"),
            })
            continue
        else:
            continue  # not a vm↔switch edge (host port, dangling)
        vm_port = ports_by_id.get(vm_p, {})
        link = {
            "vm_id": device_by_port.get(vm_p),
            "vm_port": vm_p,
            "vm_port_name": vm_port.get("name"),
            "switch_id": device_by_port.get(sw_p),
            "switch_port": sw_p,
            "cable_id": cab.get("id"),
        }
        links.append(link)

        # Validate that the vm port's static IP is within the switch's
        # auto-address network. Static-only check: DHCP ports are assigned
        # by the System Host so their IP is always correct.
        sw_id = link["switch_id"]
        sw_row = next((s for s in switches if s.get("id") == sw_id), None)
        if sw_row and vm_port.get("addrmode", "STA") == "STA":
            net_id = sw_row.get("auto_address_network")
            net_row = nets_by_id.get(net_id)
            port_ip = vm_port.get("ipv4addr")
            if port_ip and not _port_ip_in_network(port_ip, net_row):
                net_cidr = (
                    f"{net_row['ipv4network']}/{net_row['ipv4netmask']}"
                    if net_row else "unknown"
                )
                port_ip_warnings[vm_p] = (
                    f"port {vm_port.get('name')!r} on VM "
                    f"{device_by_port.get(vm_p)} has IP {port_ip} "
                    f"outside switch {sw_row.get('name')!r} network {net_cidr}"
                )

    return {
        "fabric": fabric,
        "host": host,
        "networks": networks,
        "switches": switches,
        "vms": vms,
        "cables": cables,
        "ports_by_id": ports_by_id,
        "device_by_port": device_by_port,
        "routers": routers,
        "links": links,
        "switch_links": switch_links,
        "router_links": router_links,
        "port_ip_warnings": port_ip_warnings,
    }


# ── Per-VM license control (FS-side) ─────────────────────────────────────────
# FS owns license attach/detach for a VM; the guest's csadm only has
# show/deploy/get-uuid + a hidden interactive --decouple-license. Prefer these.

def uninstall_license(c: FabricStudioClient, vm_id: int | str) -> dict[str, Any]:
    """Release/decouple the VM's license: ``DELETE runtime/vm/{id}/license``
    queues "Uninstall '<name>' device license". After it completes the guest
    reports "License not found on the system" -- run this before capturing a
    snapshot so the image is license-free. Returns the queued task."""
    return _check(c.delete(f"api/v1/runtime/vm/{vm_id}/license"), "uninstall_license").get("object") or {}


def install_license(c: FabricStudioClient, vm_id: int | str) -> dict[str, Any]:
    """(Re)deploy the VM's license: ``POST runtime/vm/{id}/license`` queues
    "Install '<name>' device license". Counterpart to uninstall_license.
    Returns the queued task."""
    return _check(c.post(f"api/v1/runtime/vm/{vm_id}/license", json_data={}), "install_license").get("object") or {}


# ── FS license pool (model-side) + guest match validation ────────────────────
# FS keeps a pool of licenses at ``system/license``; a model VM points at one
# via ``model/fabric/{fid}/vm/{vid}.license.served`` (the FS-assigned license
# id) once installed. The guest (csadm) reports the serial it actually booted
# with. validate_license_match closes the loop: the serial FS *assigned* must
# equal the serial the guest *runs* (step 8 of docs/archive/plans/LICENSE_SCENARIO_PLAN.md).

def list_fs_licenses(c: FabricStudioClient) -> list[dict[str, Any]]:
    """The pod's FS license pool (``GET system/license``)."""
    return _check(c.get("api/v1/system/license"), "list_fs_licenses").get("object") or []


def get_fs_license(c: FabricStudioClient, license_id: int | str) -> dict[str, Any]:
    """A single FS license row by id (``GET system/license/{id}``). The
    ``name`` field is the license serial (e.g. ``FSRVMPTM26000304``)."""
    return _check(c.get(f"api/v1/system/license/{license_id}"), "get_fs_license").get("object") or {}


def get_vm_served_license_id(c: FabricStudioClient, fabric_id: int | str,
                             vm_id: int | str) -> Any:
    """The FS license id assigned to a model VM, from
    ``model/fabric/{fid}/vm/{vid}.license.served``. None when unassigned. The
    ``license`` sub-object is omitted unless requested, so pull it explicitly."""
    vm = _check(
        c.get(f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}?related-fields=license"),
        "get_vm_served_license_id",
    ).get("object") or {}
    lic = vm.get("license") or {}
    if isinstance(lic, dict):
        served = lic.get("served")
        # ``served`` may itself be an id or an embedded row depending on expansion.
        return served.get("id") if isinstance(served, dict) else served
    return None


def validate_license_match(c: FabricStudioClient, fabric_id: int | str,
                           vm: dict[str, Any], csadm_lic: dict[str, Any]) -> dict[str, Any]:
    """Compare the license FS assigned the VM against what the guest is running.

    FS side: ``model/.../vm.license.served`` → ``system/license/{id}.name`` (the
    serial). Guest side: csadm ``serial_no``. They must be equal for the install
    to have honored the FS-assigned license. Returns a verdict dict; ``match``
    is the bottom line.
    """
    vid = vm.get("id")
    served_id = get_vm_served_license_id(c, fabric_id, vid)
    fs_serial = None
    if served_id is not None:
        fs_serial = (get_fs_license(c, served_id) or {}).get("name")
    guest_serial = csadm_lic.get("serial_no")

    def _norm(s: Any) -> str:
        return str(s).strip().upper() if s else ""

    match = bool(fs_serial) and bool(guest_serial) and _norm(fs_serial) == _norm(guest_serial)
    reason = None
    if served_id is None:
        reason = "FS assigned no license to the VM (license.served is null)"
    elif not fs_serial:
        reason = f"FS license id {served_id} has no serial (name)"
    elif not guest_serial:
        reason = "guest csadm reported no serial_no"
    elif not match:
        reason = f"serial mismatch: FS={fs_serial!r} guest={guest_serial!r}"
    return {
        "match": match,
        "served_license_id": served_id,
        "fs_serial": fs_serial,
        "guest_serial": guest_serial,
        "guest_uuid": csadm_lic.get("device_uuid"),
        "reason": reason,
    }


# ── Snapshot capture + license pool mutation (discovered live 2026-06-05) ─────
# Routes confirmed by the OPTIONS 405(exists)/400(absent) discriminator + task
# history mining. See docs/archive/plans/LICENSE_SCENARIO_PLAN.md gaps A/B/C.

def export_vm_disks(c: FabricStudioClient, vm_id: int | str, name: str,
                    diff: bool = True, overwrite: bool = True,
                    switch: bool = False) -> dict[str, Any]:
    """Capture a snapshot: export a VM's disks as a home-repo firmware
    (``POST runtime/vm/{id}:export``). Queues an "Export '<vm>' disks as firmware
    '<name>'" task; poll with ``wait_task``. ``name`` must be non-empty (empty
    fails the task rc=254). The VM must be powered off: the export refuses a
    running device ("Can't export when the device is running").

    Payload flags (confirmed live 2026-06-06):
      - ``diff``      : capture a DELTA against the original standalone firmware
                        (``is_diff:true``, ``diff_from`` the standalone, even when
                        the VM runs from an earlier diff -- diffs never chain) --
                        small + fast to restore; installing it downloads the
                        standalone too. **Default.** ``diff=False`` flattens to a
                        full standalone qcow (~2x size, full install to restore).
      - ``overwrite`` : replace an existing home firmware of the same name
                        (no pre-delete needed). Default True.
      - ``switch``    : repoint the model VM's ``firmware`` to the new snapshot
                        after export. Default False (leave the pointer alone).
    """
    if not name:
        raise FabricStudioAdminError("export_vm_disks: name must be non-empty")
    body = {"name": name, "diff": diff, "overwrite": overwrite, "switch": switch}
    return _check(c.post(f"api/v1/runtime/vm/{vm_id}:export", json_data=body),
                  "export_vm_disks").get("object") or {}


def delete_firmware(c: FabricStudioClient, firmware_id: int | str) -> None:
    """Delete a home-repo firmware/snapshot (``DELETE system/repository/firmware/{id}``).
    Use to clean up snapshots created by ``export_vm_disks``."""
    _check(c.delete(f"api/v1/system/repository/firmware/{firmware_id}"), "delete_firmware")


def upload_firmware(c: FabricStudioClient, image_path: str,
                    field: str = "input", dest_name: str | None = None) -> dict[str, Any]:
    """Upload an external image (e.g. an lxc-builder ``LXC_*.zip``) into the pod's
    **home** repository (``POST system/repository/home/firmware:import``).

    Repos are keyed by NAME ("home"), not id -- the ``firmware:import`` action only
    exists under the name-keyed path (cracked live 2026-06-09 via the OPTIONS
    405=exists / 400=invalid-URL discriminator). Multipart/form-data, the file
    under field ``input`` (mirrors ``import_fs_license``). FS recognizes an
    lxc-builder zip as ``vm_type: LXC`` automatically (the existing fw 598 is one).

    Returns the import response object. The new firmware row often resolves more
    reliably by diffing ``list_home_firmwares`` before/after than from this body --
    callers should snapshot ids first. Large images: bump ``c.timeout_s``.
    """
    return _post_multipart(c, "api/v1/system/repository/home/firmware:import",
                           image_path, field, "upload_firmware",
                           dest_name=dest_name).get("object") or {}


# ── Device config (provision-time config FS restores during install) ──────────
# FS stores an uploaded device config as a ``model.deviceconfig`` (REST segment
# ``model/device/config``) and applies it to the device during provisioning when
# ``model.vm.config`` points at it. ``method=RESTORE`` = full-config restore.
# Routes cracked from the FS UI (2026-06-11): import is a global multipart action
# (fabric passed in the body), not fabric-prefixed.

def import_device_config(c: FabricStudioClient, config_path: str, *, name: str,
                         fabric_id: int | str, vm_type: str, method: str = "RESTORE",
                         overwrite: bool = True) -> dict[str, Any]:
    """Upload a device config into FS as a ``model.deviceconfig``
    (``POST model/device/config:import``). Multipart: the file under ``input``
    plus ``object.{name,fabric,vm_type,method}`` and ``overwrite``. Returns the
    created deviceconfig row (carries its ``id`` -- set ``model.vm.config`` to it
    so FS restores it at install). ``vm_type`` must match the target device
    (e.g. ``FGT``); ``method=RESTORE`` restores the whole config."""
    data = {
        "object.name": name,
        "object.fabric": str(fabric_id),
        "object.vm_type": vm_type,
        "object.method": method,
        "overwrite": "true" if overwrite else "false",
    }
    return _post_multipart(c, "api/v1/model/device/config:import",
                           config_path, "input", "import_device_config",
                           data=data, dest_name=name).get("object") or {}


def get_device_config(c: FabricStudioClient, config_id: int | str) -> dict[str, Any]:
    """A ``model.deviceconfig`` by id (``GET model/device/config/{id}``)."""
    return _check(c.get(f"api/v1/model/device/config/{config_id}"),
                  "get_device_config").get("object") or {}


def list_device_configs(c: FabricStudioClient,
                        fabric_id: int | str | None = None) -> list[dict[str, Any]]:
    """All device configs (``GET model/device/config``), optionally filtered to a
    fabric. Used to find an existing config by name for idempotent re-upload."""
    rows = _check(c.get("api/v1/model/device/config"), "list_device_configs").get("object") or []
    if not isinstance(rows, list):
        rows = []
    if fabric_id is not None:
        rows = [r for r in rows if str(r.get("fabric")) == str(fabric_id)]
    return rows


def delete_device_config(c: FabricStudioClient, config_id: int | str) -> None:
    """Delete a device config (``DELETE model/device/config/{id}``)."""
    _check(c.delete(f"api/v1/model/device/config/{config_id}"), "delete_device_config")


def export_device_config(c: FabricStudioClient, config_id: int | str) -> bytes:
    """Download a device config's bytes (``GET model/device/config/{id}:export``)."""
    resp = c.get(f"api/v1/model/device/config/{config_id}:export")
    return resp.content


def set_vm_config(c: FabricStudioClient, fabric_id: int | str, vm_id: int | str,
                  config_id: int | str | None) -> dict[str, Any]:
    """Point a VM's provision-time config at a deviceconfig id (or clear with
    None): ``PATCH model/fabric/{fid}/vm/{vid} {object:{config: id}}``. FS
    restores it during the VM's install. Model-only -- applies on (re)install."""
    return _patch(c, f"api/v1/model/fabric/{fabric_id}/vm/{vm_id}",
                  {"object": {"config": config_id}},
                  "set_vm_config").get("object") or {}


def upload_firmware_versioned(c: FabricStudioClient, image_path: str,
                              base_name: str | None = None,
                              field: str = "input") -> dict[str, Any]:
    """Upload an image into the home repo under a name that can't collide with an
    existing firmware. FS refuses to overwrite a same-named firmware on import
    (``upload_firmware`` has no overwrite), so this picks the first free
    ``<stem>-vN<ext>`` (``-v2``, ``-v3``, …) by checking the current home-repo
    filenames first, uploads under it, then resolves the created row by diffing
    ``list_home_firmwares`` before/after (the import body's row is unreliable).

    ``base_name`` overrides the on-disk filename as the versioning stem (e.g.
    pass ``"rocky96.zip"`` to version a generically-named build artifact).
    Returns ``{"firmware": <row>, "name": <uploaded filename>}``."""
    import os
    stem_src = base_name or os.path.basename(image_path)
    root, ext = os.path.splitext(stem_src)
    existing = {f.get("name") for f in list_home_firmwares(c)}
    candidate = stem_src
    n = 1
    while candidate in existing:
        n += 1
        candidate = f"{root}-v{n}{ext}"
    before = {f["id"] for f in list_home_firmwares(c)}
    upload_firmware(c, image_path, field=field, dest_name=candidate)
    after = list_home_firmwares(c)
    new = [f for f in after if f["id"] not in before]
    created = max(new, key=lambda f: f["id"]) if new else \
        next((f for f in after if f.get("name") == candidate), {})
    return {"firmware": created, "name": candidate}


def refresh_home_repository(c: FabricStudioClient) -> dict[str, Any]:
    """Re-scan the home repository so files dropped into its dir are ingested as
    firmware rows (``POST system/repository/home:refresh`` -- the "Home repository
    refresh" task). Use after staging an image on the pod out-of-band (SCP); the
    multipart ``upload_firmware`` above doesn't need this."""
    return _check(c.post("api/v1/system/repository/home:refresh", json_data={}),
                  "refresh_home_repository").get("object") or {}


def build_clean_base_snapshot(
    c: FabricStudioClient, fabric_id: int | str, vm_id: int | str,
    base_firmware_id: int | str, snapshot_name: str, vm_type: str | None = None,
    boot_timeout_s: int = 1800, export_timeout_s: int = 900,
    progress: Callable[[str], None] | None = None,
    guest_ready: Callable[[], bool] | None = None,
    guest_ready_timeout_s: int = 1800, guest_ready_poll_s: int = 20,
) -> dict[str, Any]:
    """Build a clean, **license-free** base snapshot from a base firmware -- the
    reusable "known-good clean start point" for license-scenario testing.

    Steps (all idempotent / safe to re-run):
      1. destroy any running runtime VM (waits for it to be ready + pod idle
         first, so a lingering install/forticloud task can't task-conflict);
      2. point the model VM at ``base_firmware_id`` -- use the ORIGINAL qcow
         (``is_diff: false``), not a diff/shutdown snapshot;
      3. set license mode = ``NONE`` so the VM installs with NO license;
      4. install and wait until powered + post_boot_prepared (+ device idle);
      4b. if ``guest_ready`` is given, poll it until the GUEST's own first-boot
         config wizard has finished -- FS ``post_boot_prepared`` fires minutes
         BEFORE FortiSOAR's ``config-vm.sh`` writes ``.vm_configured``; powering
         off in between captures a half-provisioned image (the bug this guards);
      5. power the guest OFF (FS exports a consistent image only from a
         shut-down guest -- matches the existing ``…-shutdown-only`` snapshots);
      6. export the disks as a new home-repo firmware named ``snapshot_name``.

    Returns the newly-created firmware dict (the snapshot). ``progress`` is an
    optional callback for human-readable status lines. ``guest_ready`` is an
    optional zero-arg predicate (see ``tools/fs_soar_license._guest_config_complete``)
    returning True once the guest reports config-complete; it should RAISE if the
    guest reports config-FAILED. Polled every ``guest_ready_poll_s`` up to
    ``guest_ready_timeout_s`` before raising on timeout."""
    def _say(m: str) -> None:
        if progress:
            progress(m)

    # 1. Tear down any existing runtime so the install is from a clean slate.
    st = get_vm_runtime_state(c, vm_id)
    if st["exists"]:
        _say(f"destroying existing runtime vm {vm_id} ...")
        wait_vm_ready(c, vm_id, timeout_s=boot_timeout_s)
        wait_pod_idle(c)
        destroy_vm(c, vm_id)
        wait_vm_gone(c, vm_id)

    # 2-3. Base firmware + no-license mode (both take effect on next install).
    _say(f"pointing vm {vm_id} at base firmware {base_firmware_id}")
    set_vm_firmware(c, fabric_id, vm_id, base_firmware_id)
    _say("setting license mode = NONE (install with no license)")
    set_vm_license_mode(c, fabric_id, vm_id, mode="NONE")

    # 4. Install and wait for the guest to finish booting.
    _say(f"installing vm {vm_id} (no license) ...")
    install_vm(c, vm_id)
    itask = latest_device_task(c, vm_id)
    if itask:
        _say(f"  install task {itask.get('id')}: {itask.get('name')}")
    wait_vm_ready(c, vm_id, timeout_s=boot_timeout_s)
    wait_device_idle(c, vm_id)
    _say("vm booted: powered + post_boot_prepared")

    # 4b. Wait for the GUEST'S OWN first-boot config wizard to finish. FS's
    #     post_boot_prepared is a host-side signal that fires while FortiSOAR's
    #     config-vm.sh is still running (package sync, content-hub, cert/UUID
    #     gen). Powering off here captures a half-provisioned image: no
    #     .vm_configured flag, leftover summary.conf/config-vm.response, and the
    #     csadmin .bash_profile still trying to re-run the wizard. Gate on the
    #     guest predicate so we only export a fully-configured image.
    if guest_ready is not None:
        _say("waiting for guest config wizard to finish (.vm_configured) ...")
        deadline = time.monotonic() + guest_ready_timeout_s
        while True:
            if guest_ready():               # may raise on config-FAILED
                _say("guest config wizard complete (.vm_configured present)")
                break
            if time.monotonic() >= deadline:
                raise FabricStudioAdminError(
                    f"guest config wizard did not finish within "
                    f"{guest_ready_timeout_s}s -- refusing to snapshot a "
                    f"half-provisioned image")
            time.sleep(guest_ready_poll_s)

    # 5. Clean shutdown so the exported image has no running-state drift.
    _say("powering guest off for a clean image ...")
    t = power_off_device(c, vm_id)
    if t.get("id"):
        wait_device_task(c, t["id"], timeout_s=300)
    wait_device_idle(c, vm_id)

    # 6. Export the disks as a new firmware; resolve the created row by diffing
    #    the home-repo firmware list (the export task's name field is unreliable).
    before = {f["id"] for f in list_home_firmwares(c, vm_type)}
    _say(f"exporting vm {vm_id} disks as firmware {snapshot_name!r} ...")
    task = export_vm_disks(c, vm_id, snapshot_name)
    wait_task(c, task, timeout_s=export_timeout_s)
    new = [f for f in list_home_firmwares(c, vm_type) if f["id"] not in before]
    created = max(new, key=lambda f: f["id"]) if new else {}
    _say(f"snapshot {snapshot_name!r} created: firmware id {created.get('id')}")
    return created


def import_fs_license(c: FabricStudioClient, lic_path: str) -> dict[str, Any]:
    """Upload a license file into the FS pool (``POST system/license:import``).

    The endpoint takes **multipart/form-data** with the file under field
    ``input`` (the server reads ``input.suffix``, so it must be an uploaded file,
    not a JSON string). Confirmed live 2026-06-05 with a real FortiSOAR ``.lic``
    (JWT-format token) → new ``system/license`` row, ``name`` = the serial,
    ``vm_type`` SOAR. Returns the created license object (id, name=serial, …).
    """
    return _post_multipart(c, "api/v1/system/license:import",
                           lic_path, "input", "import_fs_license").get("object") or {}


def delete_fs_license(c: FabricStudioClient, license_id: int | str) -> None:
    """**Remove** a license from the FS pool entirely (``DELETE
    system/license/{id}``) -- the license is gone and can't be reassigned on a
    later install. Confirmed live 2026-06-06 (returns the deleted row). Use this
    for "delete the license the snapshot was built with" so a reinstall must pick
    a DIFFERENT pool license. Contrast ``release_fs_license`` (decouple, keep)."""
    _check(c.delete(f"api/v1/system/license/{license_id}"), "delete_fs_license")


def release_fs_license(c: FabricStudioClient, license_id: int | str,
                       force: bool = True) -> None:
    """**Release** (decouple/unassign) a pool license without deleting it
    (``POST system/license/{id}:release`` body ``{"force": true}``). The license
    stays in the pool and can be reassigned later; only the current VM binding is
    freed. Confirmed live 2026-06-06 (rcode 0, status done). Use when you want to
    free a license but keep it available; use ``delete_fs_license`` to remove it
    outright."""
    _check(c.post(f"api/v1/system/license/{license_id}:release",
                  json_data={"force": force}), "release_fs_license")


# ── FortiFlex pool (fp-type → FortiFlex config mapping) ──────────────────────
# Registering a FortiCloud/FortiFlex account (above) syncs configs but
# provisions nothing on its own. To make FS actually draw a flex license for a
# VM type on install, that fp-type must be mapped to a FortiFlex config via the
# flex POOL. Without a SOAR pool entry, a SOAR install aborts
# "No license for soar00 (FLEX,LIC)" (task rc=254). Cracked + verified live
# 2026-06-06 against the OpenAPI spec (system/license/flex/pool).

def list_flex_pool(c: FabricStudioClient) -> list[dict[str, Any]]:
    """List the FortiFlex pool entries (fp-type → config mappings).
    ``GET system/license/flex/pool``."""
    obj = _check(c.get("api/v1/system/license/flex/pool"), "list_flex_pool").get("object")
    if isinstance(obj, list):
        return obj
    # Some FS builds wrap the rows under a key; fall back to any list value.
    if isinstance(obj, dict):
        for v in obj.values():
            if isinstance(v, list):
                return v
    return []


def set_flex_pool(c: FabricStudioClient, fp_type: str, config: int | str) -> dict[str, Any]:
    """Map a VM fp-type to a FortiFlex config so FS will auto-provision a flex
    license for it on install. ``POST system/license/flex/pool {type, config}``.
    Verified live 2026-06-06: ``type=SOAR, config=29529`` enabled SOAR flex
    provisioning (FS then auto-created ``FSRVMOTM…`` and assigned it on install).
    Idempotent on FS -- re-setting the same mapping is accepted."""
    return _check(
        c.post("api/v1/system/license/flex/pool",
               json_data={"type": fp_type, "config": int(config)}),
        "set_flex_pool",
    ).get("object") or {}


def delete_flex_pool(c: FabricStudioClient, fp_type: str) -> None:
    """Remove a FortiFlex pool mapping for an fp-type
    (``DELETE system/license/flex/pool {type}``)."""
    _check(
        c.request("DELETE", "api/v1/system/license/flex/pool",
                  json_data={"type": fp_type},
                  headers={"Content-Type": "application/json"}),
        "delete_flex_pool",
    )


def firmware_version(vm: dict[str, Any]) -> str:
    """Best-effort extract -- used to stamp verification entries with the
    firmware version we tested against. Falls back to empty string when
    the field isn't present."""
    fw = vm.get("firmware") or {}
    if isinstance(fw, dict):
        return fw.get("version") or fw.get("name") or ""
    return str(fw) if fw else ""
