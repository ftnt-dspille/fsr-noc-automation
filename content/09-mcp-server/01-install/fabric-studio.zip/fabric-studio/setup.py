"""Packaging hook: the agent skill lives in skills/fabric-studio, outside the package, so a checkout, the lab
repository and the Install page's manual copy all read one source. The wheel carries a copy of it, which is what lets
`fabric-studio-mcp connect` install the skill from an installed program."""
import shutil
from pathlib import Path

from setuptools import setup
from setuptools.command.build_py import build_py

SKILL_FILES = ("SKILL.md", "api-index.md")


class BuildPy(build_py):
    def run(self):
        super().run()
        src = Path(__file__).parent / "skills" / "fabric-studio"
        dst = Path(self.build_lib) / "fabric_studio" / "_skill"
        dst.mkdir(parents=True, exist_ok=True)
        for name in SKILL_FILES:
            shutil.copy2(src / name, dst / name)


setup(cmdclass={"build_py": BuildPy})
