---
name: fabric-studio
description: Operate Fortinet Fabric Studio pods (the lab platform that succeeds FortiPoC) with the fabric-studio Python library or its MCP server. Use when writing, running or debugging code that builds, inspects, installs, powers, licenses, snapshots or troubleshoots fabrics and VMs on a Fabric Studio pod, or when deciding whether to use the MCP tools or the library.
ftnt-ai-agent:
  format: 3
  requires:
    mcpServers: [fabric-studio]
  tags: [fabric-studio, lab]
---

# Fabric Studio

Fabric Studio runs **fabrics** on a **pod**: a fabric is a set of VMs (FortiGate, FortiManager,
FortiAnalyzer, FortiSOAR, Linux and others) joined by switches, networks and cables. This skill covers
the `fabric-studio` library and the `fabric-studio-mcp` server built on it.

## Set up the MCP server

If the Fabric Studio tools are not available, the person sets the server up once; you cannot do it
for them. Point them at the
[Install page](https://tec.myfortinet.com/fndn/fabric-studio/09-mcp-server/01-install/) (Fortinet
sign-in) for the download zip, then:

1. Unzip it and run `uv tool install "./fabric-studio[mcp]"` in the folder that holds `fabric-studio/`.
2. Run `fabric-studio-mcp setup` in a terminal: it asks for the pod, a name, the user and the
   password, which goes into the OS keychain. Never ask for the password in chat.
3. Add the server to the assistant. In FortiAgent: **Settings → MCP servers → Add an MCP server**,
   **Local command**, Name `Fabric Studio`, Command the full path from `which fabric-studio-mcp`,
   no arguments, then **Reload to apply changes**
   ([step by step](https://tec.myfortinet.com/fndn/fabric-studio/09-mcp-server/11-connect-fortiagent/)).
   In Claude Code: `claude mcp add fabric-studio --scope user -- fabric-studio-mcp`.

## Pick a surface

- **The MCP server** (`fabric-studio-mcp`): ask in plain language. It has a few broad tools: `pods`
  (views of pods, health, licenses, firmware), `fabric`, `vm`, `tasks`, `diagnose` (start here when
  something fails) and, for changes, `set_vm_access_public`, `install_system_host`, `set_vm_port_dhcp`,
  `set_vm_port_auto`, `snapshot_vm`, `vm_lifecycle` (on, off, restart, reinstall, cancel a task),
  `set_vm_license` (`NONE` or `AUTO`), `build` (make a whole fabric from a topology; see below) and `device` (look at
  and configure what is inside a FortiGate; see below) `run` (a command over SSH or an API call on any device) and `register` (connect a FortiGate to a
  FortiManager or FortiAnalyzer). Every change shows a plan first and then asks the person to
  approve it; you cannot approve for them. Prefer it for questions and small changes.
- **The library**: scripts, bulk work, anything the tools do not cover. The rest of this skill is
  about it.

## Build a fabric

Use the `build` tool to create a fabric with its devices, networks and cables in one go. Do not make the
VMs one by one with the library: the topology does that in dependency order and can be re-run safely.

1. `build` with `action=topologies`: what can be built. Each row has the devices, and the `variables` it
   accepts. Pick the one that matches the request (`fgt_single` is one FortiGate; `fgt_fmg_faz` is a
   FortiGate, FortiManager and FortiAnalyzer on one management network). If none fits, say so; do not invent a name.
   To write or change a topology (add a client behind a gate, license a device, a VLAN port), first call
   `action=examples`: it lists patterns and which topologies use them; with a `pattern` it returns their YAML.
   Copy the shape, not the addresses. A Linux guest's base image accepts only SSH keys, so a client you need to
   log in to must inject an authorized key (pattern `lxc_key_access`).
2. `action=validate` with the `topology`: checks it with no pod. `ok: false` lists what is wrong.
3. `action=plan` with the `host`: what applying it would create, reinstall or delete. Read these before you go on:
   `errors` / `blocked` (apply refuses; the text says why), `would_stop` (the fabric running there now: a pod
   runs one fabric, so a build stops it), `reinstalls` (their in-guest state is lost) and `deletes`.
   Tell the person what will be stopped and what will be created.
4. `action=apply`, `confirm=true`: shows the person the plan and asks them to approve. You cannot approve for them.
   If they decline, stop. It returns a `run_id` at once, because a build takes minutes.
5. `action=status` with the `run_id`: `state` is `running` or `finished`; `succeeded` is true only when the
   fabric converged. Check it again after a while rather than in a tight loop, and use `tasks` for the
   installs in flight. When `succeeded` is true, use `fabric` or `vm` to confirm the devices are powered on and ready.

**Firmware.** Left alone, each device uses the newest usable image on the pod. To pick one, pass a version
prefix through `variables`, for example `{"fgt_image": "7.4"}`. A firmware that the pod does not have fails the
plan and names the versions it does have: choose one of those and plan again.

**When it fails.** Read the `errors` or the `log_tail` and say what they mean. For a failed or stuck build call
`diagnose` for that pod and fabric, and read the task log it points at (`tasks`) before you try anything. Then
fix the cause (a variable, a firmware choice, a lockout the owner has to lift) and run `plan` again; the apply is
safe to repeat and only does what is still missing. Do not retry the same failing apply unchanged, do not lift a
lockout, and do not destroy a fabric to get unstuck.

**Prune.** Fabric Studio seeds an `ISP Router` into every fabric. If the plan is blocked with "black hole",
`prune=true` removes it, together with anything else the topology does not declare in that fabric, so read the
`deletes` list and tell the person first.

## Configure a FortiGate

Use the `device` tool for anything inside a FortiGate of a built fabric. Name the device, say what you want, and
leave how to the tool.

- Look first: `action=status` (firmware, license, HA) and `action=config` with a `section` (an alias such as
  `interfaces`, `routes`, `policies`, `addresses`, `dns`, or a path such as `system/interface`). With no `section`
  it lists the names. Reading never asks the person and never changes anything.
- Change with `action=set` (give an object these `values`; it is created when `name` does not exist) or
  `action=delete`. Call it directly to get the plan, a real before and after read from the device. Show the person
  what will change, then call again with `confirm=true`; they are asked to approve, and you cannot approve for them.
- Use FortiOS field names and say values the natural way: `{"allowaccess": ["https", "ssh"]}`, `true` for enable,
  a list of names for a table such as `srcaddr`.
- Check `verified` in the result. If it is false, the device did not keep what was asked: say so, do not report
  success.
- When the tool refuses or fails it says why and what to do (for example the device needs a license, or is
  powered off). Report that; do not look for another way around it.

## Run something on a device

Use `run` when you need the device's own output or an endpoint `device` does not cover, on any device type: give the
device name and either `command` (what you would type at its prompt) or `api` (such as `GET /api/v2/monitor/...`).
The tool signs in with the login Fabric Studio holds for the device; never ask for or pass a password. It uses the
device's public access, or goes through the pod when that is not public (`through` in the result says so), so do
not make access public just to run something.

- Reads run at once: `get`, `show`, `ls`, `df`, `ps`, a pipe into grep, any GET. Do not pass `confirm` for a read.
- Anything else returns a plan with the exact command or request. Show it to the person, then call again with
  `confirm=true`; they are asked to approve, and you cannot approve for them.
- Prefer `device` to configure a FortiGate (a real before and after, read back), and `run` for everything else.
- On a FortiManager or FortiAnalyzer, `api` is a JSON-RPC call: `get /dvmdb/adom/root/device`, or another verb
  (`set`, `add`, `exec`) with a `body`. If it is refused for permission, the error names the setting to enable.

## Linux guests, containers and web apps

- `LXC` is a Linux container and `BASIC` is a generic VM from a qcow2 or ISO. Fabric Studio sets up neither:
  their login is the image's own (from the firmware's metadata), and `run` uses it for you.
- A `BASIC` VM gets no address unless its link takes `dhcp: System Host` (pattern `generic_vm`).
- To run an app in a container, use a Docker-enabled LXC image and a payload that starts Docker and the app
  (pattern `docker_app`). The guest needs a way out to pull the image.
- To give someone a page to log in to, make the access public and read the `vm` tool's `access` view: each
  public access has an `open` link. `HTTPS` is a device's own web UI; `HTTPS2HTTP` puts TLS in front of a guest's
  plain-HTTP app (pattern `web_login_page`). Say which user to sign in as; never put a password in an answer.

## Register a FortiGate with a FortiManager or FortiAnalyzer

An image the pod lacks: put the file in the lab workspace and call `firmware` `upload` (`path`, and `name`
if it should be named differently; an LXC rootfs needs an `LXC_*.zip` name). It refreshes the home repository
and returns the image line to use; put that in the node's `image:` and plan as usual. Check `pods` view `firmwares` first: an
image already on the pod needs no upload.

Use `register` with the `gate` and the `manager`; do not configure both sides by hand. It reads what is already
in place and plans only what is missing, including authorizing the gate with its admin login, which the tool
passes from Fabric Studio and you never see. Call it to get the plan, show it to the person, then call again with
`confirm=true`. Check `verified`. Already registered is a no-op; for logs to a FortiAnalyzer, register with it too.
- If a command or request is refused or fails, report what the tool says; do not look for a way around it.

## Connect

```python
from fabric_studio import admin
from fabric_studio.resolve import pod_creds, resolve_fabric_id
from fabric_studio.client import FabricStudioClient

host = "pod.example.com"
user, password = pod_creds(host, None, None)   # Keychain, then env; exits with a message if none
c = FabricStudioClient(host, user, password)   # verify_ssl=False by default: pods use self-signed certs
c.login()
fid = resolve_fabric_id(c, None)               # None = the running fabric; or pass an id or a name
for vm in admin.list_fabric_vms(c, fid):
    state = admin.get_vm_runtime_state(c, vm["id"])
    print(vm["name"], vm["vm_type"], state["status"].get("powered"))
```

- Never put a password in code, a command line or chat. Credentials come from the OS keychain, the
  environment (`POD_PASSWORD`) or a gitignored env file.
- The client caches its session in `~/.fsh/sessions` and serializes new logins per pod. A pod
  rate-limits logins and then stops answering. A `LoginCooldown` error ("retry in Ns") means wait:
  do not loop.
- `urllib3` warns about the unverified certificate on every request. Silence it with
  `urllib3.disable_warnings()` in scripts.

## Model versus runtime

Fabric Studio keeps two views. The **model** is what you declared (a fabric's VMs, ports, access,
license mode): `list_fabrics`, `list_fabric_vms`, `list_networks`. The **runtime** is what is running:
`get_running_fabric`, `runtime_vms`, `get_vm_runtime_state`. They can disagree, and a change to the
model reaches a running VM only when you push it.

**A pod runs one fabric at a time.** Installing fabric B powers off fabric A's VMs. Its model stays, so
it still looks fine on paper. Check `get_running_fabric` before you install anything.

## Tasks

Most calls that change something return a **task** and do not wait. Pass it to `wait_task(c, task,
timeout_s=...)`, which raises on failure. A failed task's return code (often a bare `254`) says little:
**the reason is in `get_task_log(c, task_id)`**. Read it before guessing.

```python
t = admin.install_vm(c, vm_id)
admin.wait_task(c, t, timeout_s=900)
```

Errors from this API raise `FabricStudioAdminError` with the HTTP status. Lookups such as
`get_fabric_by_name` return `None` for "not found" and do not raise.

## Which function for which job

`api-index.md` next to this file lists every public function with its first docstring line. The common
ones:

| Job | Functions |
|---|---|
| See what exists | `list_fabrics`, `list_fabric_vms`, `list_all_firmwares`, `list_networks`, `list_switches` |
| What is running | `get_running_fabric`, `runtime_vms`, `get_vm_runtime_state`, `list_running_tasks` |
| Build | `ensure_fabric`, `create_vm`, `ensure_network`, `ensure_switch`, `cable_vm_to_switch`, `set_port_ipv4` |
| Bring up | `install_fabric` (first bring-up only), `install_vm`, `wait_vm_ready`, `wait_running` |
| Change a running VM | `synchronize_device`, `set_vm_firmware`, `set_vm_license_mode`, `power_cycle` |
| Power | `power_off_device`, `power_on_device`, `wait_powered` |
| Snapshots | `take_diff_snapshot` (`diff=True` or `False` for a full one), `export_vm_disks`, `delete_firmware` |
| Licenses | `get_vm_license_mode`, `set_vm_license_mode`, `list_fs_licenses`, `get_forticloud_account`, `validate_license_match` |
| Reach a VM | `list_vm_accesses`, `ensure_public_access`, `probe_vm_accesses`, `ACCESS_FORWARD_BASE` |
| Why did it fail | `get_task_log`, `latest_device_task`, `fabric_diff` |

## Things that cost people real runs

- **Do not call `install_fabric` on a fabric that is already running.** An empty install redeploys
  every VM and the library refuses unless you pass `allow_running=True`. To publish a model change to
  a running VM use `synchronize_device`.
- **A 0-byte firmware row is a stub.** Installing it fails with rc 254 ("reach remote file code for
  local file"). Check `list_all_firmwares`: a row is usable when it has a size. A `remote` row is fine;
  Fabric Studio downloads it on first install, which is slower and needs the pod's internet access.
- **Licensing.** `license mode NONE` installs the device unlicensed (eval): the API, CLI and GUI work.
  `AUTO` takes a license from the pod's pool or FortiFlex, which uses it up. A bare `AUTO` behaves
  differently per pod: it can stop and ask you to choose among several FortiFlex configurations, take a
  pooled license, or fail with `No license for <node> (LIC,FLEX)`. A device sized above the eval limit
  with no activation boots in limited mode.
- **Power-off is hard.** Appliance guests ignore the ACPI shutdown, so `power_off_device` cuts power.
  Shut a guest down from inside first when its state matters.
- **Diff snapshots never chain.** Each diff records the original firmware as its base, so any one can
  be deleted without breaking another, and installing one downloads the original too.
- **A new access entry is not a forward.** `ensure_public_access` makes the access PUBLIC; the external
  port is `ACCESS_FORWARD_BASE[type] + port_idx` (SSH 11000, HTTPS 13000, ...). A fresh guest answers
  "network unreachable" on its forward until it has booted.
- **Do not hand-write `ssh` to FortiOS devices.** Repeated wrong password attempts arm the admin
  lockout. Use key or API-key access.

## Safe working

- Reads are free. Everything that installs, powers, relicenses, deletes or snapshots changes a pod
  others may share: say what you will do, and to which fabric, before you do it.
- Look at a target before you delete or overwrite it. `delete_fabric`, `delete_vm`, `delete_firmware`,
  `delete_fs_license` are not reversible.
- Respect a lockout. A freeze on a pod is deliberate; do not work around it. Ask whoever set it.
- Wait on tasks with `wait_task`, not `sleep` loops and not by checking for a process.

## Where to look next

- `api-index.md`: every function, one line each.
- The repository README: install, MCP configuration, the tool list.
- `src/fabric_studio/mcp/diagnose.py`: the checks `diagnose` runs, if you need to reproduce one in code.
