"""``analyse`` is pure, so every diagnosis rule is tested without a pod."""
from __future__ import annotations

import copy

from fabric_studio.mcp.diagnose import analyse

OK_VM = {"id": 1, "name": "fgt", "vm_type": "FGT", "firmware_id": 7,
         "firmware": {"status": "ready", "size": 100, "path": "p"}, "runtime_exists": True, "task": None,
         "status": {"powered": True, "post_boot_prepared": True, "licensed": False},
         "license_mode": {"mode": "NONE", "served": None}, "tasks": [{"id": 5, "name": "Install", "returncode": 0}],
         "access": [{"type": "SSH", "ok": True, "detail": "open"}]}
FACTS = {"host": "h", "fabric_id": 1, "fabric": "f", "running_fabric_id": 1, "running_fabric": "f",
         "running_tasks": [], "lockouts": [], "vms": [OK_VM], "notes": []}


def facts(**vm):
    f = copy.deepcopy(FACTS)
    f["vms"][0].update(vm)
    return f


def codes(f):
    return {x["code"] for x in analyse(f)["findings"]}


def test_healthy_fabric_has_no_findings():
    r = analyse(FACTS)
    assert r["verdict"] == "healthy" and r["findings"] == []


def test_failed_install_names_the_license_cause():
    f = facts(tasks=[{"id": 9, "name": "Install", "returncode": 254,
                      "log": "boom\nNo license for faz000 (FLEX,LIC), fsm000 (LIC)\n"}])
    r = analyse(f)
    top = r["findings"][0]
    assert r["verdict"] == "problems found" and top["code"] == "license-missing"
    assert "faz000" in top["message"] and top["evidence"]["task_id"] == 9


def test_failure_followed_by_a_success_is_history():
    f = facts(tasks=[{"id": 10, "returncode": 0}, {"id": 9, "returncode": 254, "log": "x"}])
    assert analyse(f)["findings"] == []


def test_unknown_failure_quotes_the_last_log_line():
    f = facts(tasks=[{"id": 9, "name": "Install", "returncode": 1, "log": "a\nthe disk exploded\n"}])
    top = analyse(f)["findings"][0]
    assert top["code"] == "task-failed" and "the disk exploded" in top["message"]


def test_stub_missing_and_remote_firmware():
    assert "firmware-stub" in codes(facts(firmware={"status": "ready", "size": 0, "path": "p"}))
    assert "firmware-missing" in codes(facts(firmware=None))
    assert "firmware-remote" in codes(facts(firmware={"status": "remote", "size": 5, "path": "p"}))


def test_vm_state_rules():
    assert "not-installed" in codes(facts(runtime_exists=False))
    assert "powered-off" in codes(facts(status={"powered": False}))
    f = facts(status={"powered": True, "post_boot_prepared": False})
    assert "not-ready" in codes(f)
    assert analyse(f)["findings"][0]["severity"] == "warn"


def test_booting_during_an_install_is_only_info():
    f = facts(status={"powered": True, "post_boot_prepared": False}, task="installing")
    assert analyse(f)["findings"][0]["severity"] == "info"


def test_unserved_license_and_eval_mode():
    assert "license-unserved" in codes(facts(license_mode={"mode": "AUTO", "served": None}))
    assert "license-unserved" not in codes(facts(license_mode={"mode": "NONE", "served": None}))


def test_unreachable_forward_is_a_warning_unless_busy():
    bad = [{"type": "SSH", "ok": False, "detail": "refused"}]
    assert "access-unreachable" in codes(facts(access=bad))
    f = facts(access=bad)
    f["running_tasks"] = [{"id": 1, "name": "x"}]
    assert "access-unreachable" not in codes(f)


def test_other_fabric_running_lockout_and_ranking():
    f = facts(firmware=None)
    f["running_fabric_id"], f["running_fabric"] = 2, "other"
    f["lockouts"] = [{"fabric": "*", "reason": "r"}]
    r = analyse(f)
    assert {"fabric-not-running", "locked", "firmware-missing"} <= codes(f)
    assert [x["severity"] for x in r["findings"]] == sorted((x["severity"] for x in r["findings"]),
                                                            key={"error": 0, "warn": 1, "info": 2}.get)
    assert not any(x["code"] == "not-installed" for x in r["findings"])  # a stopped fabric is not "broken"


def test_deep_adds_plugged_in_checks_and_reranks(monkeypatch):
    from fabric_studio.mcp import diagnose as d

    monkeypatch.setattr(d, "EXTENSIONS", [])
    r = d.deep(FACTS, analyse(FACTS), None)
    assert r["verdict"] == "healthy" and r["findings"][0]["code"] == "deep-unavailable"

    seen = {}

    def check(**kw):
        seen.update(kw)
        return [{"severity": "error", "vm": "fgt", "code": "verify-x", "message": "m"}]

    monkeypatch.setattr(d, "EXTENSIONS", [check, lambda **kw: 1 / 0])
    r = d.deep(FACTS, analyse(FACTS), "topo")
    assert r["verdict"] == "problems found" and r["findings"][0]["code"] == "verify-x"
    assert seen["topology"] == "topo" and seen["fabric"] == "f"
    assert any(f["code"] == "deep-partial" for f in r["findings"])  # a crashing check does not hide the rest


def test_one_cause_seen_twice_is_reported_once_with_both_proofs():
    f = facts(firmware={"status": "ready", "size": 0, "path": "p"},
              tasks=[{"id": 9, "name": "Install", "returncode": 254,
                      "log": "Internal error, reach remote file code for local file"}])
    stubs = [x for x in analyse(f)["findings"] if x["code"] == "firmware-stub"]
    assert len(stubs) == 1
    assert stubs[0]["evidence"]["size"] == 0 and stubs[0]["also"]["task_id"] == 9
