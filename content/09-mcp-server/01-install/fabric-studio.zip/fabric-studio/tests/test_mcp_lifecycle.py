"""vm_lifecycle and set_vm_license: previews, lockout refusal, and the calls each action makes."""
from __future__ import annotations

import asyncio

import pytest
from conftest import import_server
from mcp.server.mcpserver.exceptions import ToolError


class FakeAdmin:
    """Records the calls the tools make; the VM starts powered on."""

    def __init__(self):
        self.calls, self.powered = [], True

    def get_vm_runtime_state(self, c, vid):
        return {"status": {"powered": self.powered, "post_boot_prepared": self.powered}}

    def power_off_device(self, c, vid):
        self.calls.append("off")
        self.powered = False
        return {"id": 1}

    def power_on_device(self, c, vid):
        self.calls.append("on")
        self.powered = True
        return {"id": 2}

    def wait_task(self, *a, **k):
        self.calls.append("wait_task")

    def wait_powered(self, *a, **k):
        self.calls.append("wait_powered")

    def wait_vm_ready(self, c, vid, **k):
        self.calls.append(("ready", k.get("task_id")))

    def power_cycle(self, c, vid, **k):
        self.calls.append("cycle")

    def install_vm(self, c, vid):
        self.calls.append("install")
        return {"id": 9}

    def get_task(self, c, tid):
        return {"id": tid, "name": "Install", "returncode": None}

    def cancel_task(self, c, tid):
        self.calls.append(("cancel", tid))

    def get_vm_license_mode(self, c, fid, vid):
        return {"mode": "AUTO", "served": 5}

    def get_fs_license(self, c, lid):
        return {"name": "SERIAL-1"}

    def set_vm_license_mode(self, c, fid, vid, mode="NONE", served=None):
        self.calls.append(("mode", mode))
        return {}

    def list_fs_licenses(self, c):
        return [{"id": 5, "vm_type": "FMG"}, {"id": 6, "vm_type": "FGT"}]

    def forticloud_registered(self, c):
        return True


@pytest.fixture
def s(monkeypatch):
    m = import_server()
    fake = FakeAdmin()
    monkeypatch.setattr(m, "fs_admin", fake)
    monkeypatch.setattr(m, "_resolve", lambda *a, **k: (object(), 1, {"id": 7, "name": "fmg", "vm_type": "FMG"}))
    monkeypatch.setattr(m, "_client", lambda host: object())
    monkeypatch.setattr(m.inst, "lockouts", lambda: {})
    m.fake = fake
    return m


def test_preview_changes_nothing(s):
    out = s.vm_lifecycle("h", "restart", vm="fmg")
    assert out["dry_run"] is True and out["powered_now"] is True and s.fake.calls == []


@pytest.mark.parametrize("action,expected", [("off", ["off", "wait_task", "wait_powered"]),
                                             ("restart", ["cycle"]),
                                             ("reinstall", ["install", ("ready", 9)])])
def test_each_action_calls_the_right_steps(s, action, expected):
    out = s.vm_lifecycle("h", action, vm="fmg", confirm=True)
    assert out["executed"] is True and s.fake.calls == expected


def test_on_when_already_on_is_a_no_op(s):
    out = s.vm_lifecycle("h", "on", vm="fmg", confirm=True)
    assert out["executed"] is False and "already on" in out["reason"] and s.fake.calls == []


def test_cancel_task_needs_an_id_and_cancels_it(s):
    with pytest.raises(ToolError, match="needs task_id"):
        s.vm_lifecycle("h", "cancel_task")
    assert s.vm_lifecycle("h", "cancel_task", task_id=3, confirm=True)["executed"] is True
    assert s.fake.calls == [("cancel", 3)]


def test_unknown_action_is_rejected(s):
    with pytest.raises(ToolError, match="action must be"):
        s.vm_lifecycle("h", "explode")


def test_a_locked_pod_is_refused_for_both_tools(s, monkeypatch):
    monkeypatch.setattr(s.inst, "lockouts", lambda: {"h": [{"fabric": "*", "reason": "demo Thursday"}]})
    with pytest.raises(ToolError, match="demo Thursday"):
        s.vm_lifecycle("h", "off", confirm=True)
    with pytest.raises(ToolError, match="locked"):
        s.set_vm_license("h", "NONE", confirm=True)
    assert s.fake.calls == []


def test_license_preview_reports_the_pool_and_warns_on_auto(s):
    out = s.set_vm_license("h", "auto")
    assert out["dry_run"] is True and out["mode_now"] == "AUTO" and out["served_now"] == "SERIAL-1"
    assert out["pooled_licenses_matching"] == 1 and "uses up" in out["warning"] and s.fake.calls == []


def test_license_applies_the_mode_then_reinstalls(s):
    out = s.set_vm_license("h", "none", confirm=True)
    assert out["executed"] is True and s.fake.calls == [("mode", "NONE"), "install", ("ready", 9)]
    assert "warning" not in out


def test_license_without_reinstall_only_changes_the_setting(s):
    s.set_vm_license("h", "NONE", reinstall=False, confirm=True)
    assert s.fake.calls == [("mode", "NONE")]


def test_license_rejects_a_bad_mode(s):
    with pytest.raises(ToolError, match="mode must be"):
        s.set_vm_license("h", "FLEX")


def test_both_tools_are_registered_as_mutating_without_a_visible_ctx(s):
    tools = {t.name: t for t in asyncio.run(s.mcp.list_tools())}
    for name in ("vm_lifecycle", "set_vm_license"):
        assert tools[name].annotations.destructive_hint is True
        assert "ctx" not in tools[name].input_schema["properties"]


def test_resources_and_prompts_are_registered(s):
    assert [str(r.uri) for r in asyncio.run(s.mcp.list_resources())] == ["fabric-studio://pods"]
    assert len(asyncio.run(s.mcp.list_resource_templates())) == 2
    assert {p.name for p in asyncio.run(s.mcp.list_prompts())} == {
        "troubleshoot-failed-install", "snapshot-before-change", "pod-health-check"}
    assert "diagnose" in s.troubleshoot_failed_install("pod-a")
