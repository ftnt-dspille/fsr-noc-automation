"""``when:`` -- pod-conditional ``networks:`` / ``switches:`` / ``links:`` entries.

One intent, several pods whose physical shape genuinely differs. The motivating
case is a pooled-license segment that only some pods serve: on a pod without one
the segment is a floating switch nothing routes to, and cabling it costs a
reinstall to buy nothing, so the intent has to be able to drop it.
"""
from __future__ import annotations

import pytest

from fabric_studio.topology.reconciler import parse_intent


def _doc(*, net_when=None, sw_when=None, link_when=None) -> dict:
    net = {"name": "lic", "cidr": "10.100.55.0/24"}
    sw = {"name": "licsw", "auto_address": "lic"}
    link = {"port": "port3", "switch": "mgmtsw"}
    for entry, val in ((net, net_when), (sw, sw_when), (link, link_when)):
        if val is not None:
            entry["when"] = val
    return {
        "fabric": "wf",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}, net],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}, sw],
        "nodes": [{"name": "fmg", "type": "FMG", "firmware": 817,
                   "links": [{"port": "port1", "switch": "mgmtsw"}, link]}],
    }


def _ports(intent):
    return [lk.port for lk in intent.nodes[0].links]


def test_absent_when_is_unconditional():
    """Every pre-existing intent must be unaffected: no ``when:`` == present."""
    it = parse_intent(_doc())
    assert [n.name for n in it.networks] == ["mgmt", "lic"]
    assert [s.name for s in it.switches] == ["mgmtsw", "licsw"]
    assert _ports(it) == ["port1", "port3"]


def test_when_true_keeps_everything():
    it = parse_intent(_doc(net_when=True, sw_when=True, link_when=True))
    assert [n.name for n in it.networks] == ["mgmt", "lic"]
    assert [s.name for s in it.switches] == ["mgmtsw", "licsw"]
    assert _ports(it) == ["port1", "port3"]


def test_when_false_drops_network_switch_and_link_together():
    """The whole segment disappears -- and dropping the switch does NOT trip the
    link's declared-switch check, because the link that used it is gone too."""
    it = parse_intent(_doc(net_when=False, sw_when=False, link_when=False))
    assert [n.name for n in it.networks] == ["mgmt"]
    assert [s.name for s in it.switches] == ["mgmtsw"]
    assert _ports(it) == ["port1"]


@pytest.mark.parametrize("falsey", ["false", "False", "no", "off", "0", "", "  ", "null", "none"])
def test_string_falsey_spellings_drop(falsey):
    """A ``-var`` always arrives as a STRING, so the string spellings must behave
    like a typed ``bool`` variable rather than being truthy non-empty text."""
    assert _ports(parse_intent(_doc(link_when=falsey))) == ["port1"]


@pytest.mark.parametrize("truthy", ["true", "TRUE", "yes", "on", "1"])
def test_string_truthy_spellings_keep(truthy):
    assert _ports(parse_intent(_doc(link_when=truthy))) == ["port1", "port3"]


def test_non_boolean_string_is_an_error_not_silently_true():
    """A typo'd or unresolved ``when:`` must fail loudly. Silently treating it as
    true would keep a segment the pod can't support; silently false would delete
    one it needs."""
    with pytest.raises(ValueError, match="when="):
        parse_intent(_doc(link_when="maybe"))


def test_unless_is_the_negation_of_when():
    assert _ports(parse_intent(_doc(link_when=True))) == ["port1", "port3"]
    doc = _doc()
    doc["nodes"][0]["links"][1] = {"port": "port3", "switch": "mgmtsw", "unless": True}
    assert _ports(parse_intent(doc)) == ["port1"]
    doc["nodes"][0]["links"][1]["unless"] = False
    assert _ports(parse_intent(doc)) == ["port1", "port3"]


def test_when_and_unless_together_is_an_error():
    doc = _doc()
    doc["nodes"][0]["links"][1].update({"when": True, "unless": True})
    with pytest.raises(ValueError, match="not both"):
        parse_intent(doc)


def test_one_flag_drives_both_halves_of_an_either_or():
    """The pooled-license shape: port1 lands on the license segment WHEN the pod
    serves one, on egress UNLESS it does -- from a single variable, so the two
    spellings cannot drift into declaring the same port twice or not at all."""
    def build(serves_license: bool):
        return {
            "fabric": "wf",
            "networks": [{"name": "e", "cidr": "203.0.113.0/24"},
                         {"name": "lic", "cidr": "10.100.55.0/24",
                          "when": serves_license}],
            "switches": [{"name": "egress", "auto_address": "e"},
                         {"name": "licsw", "auto_address": "lic",
                          "when": serves_license}],
            "nodes": [{"name": "fmg", "type": "FMG", "firmware": 817, "links": [
                {"port": "port1", "switch": "licsw", "ip": "10.100.55.12",
                 "when": serves_license},
                {"port": "port1", "switch": "egress", "ip": "203.0.113.4",
                 "unless": serves_license},
                {"port": "port3", "switch": "egress", "when": serves_license},
            ]}],
        }

    on = parse_intent(build(True))
    assert [(l.port, l.switch) for l in on.nodes[0].links] == [
        ("port1", "licsw"), ("port3", "egress")]

    off = parse_intent(build(False))
    assert [(l.port, l.switch) for l in off.nodes[0].links] == [("port1", "egress")]
    assert [s.name for s in off.switches] == ["egress"]
    # Exactly one port1 either way -- never zero, never a duplicate.
    for it in (on, off):
        assert [l.port for l in it.nodes[0].links].count("port1") == 1


def test_unresolved_var_falls_back_to_its_declared_default():
    """The golden-snapshot test parses raw docs, so a ``when:`` may still be an
    unsubstituted ${var.x}. Resolving it to the declared default is what a pod
    with no .fabricvars overlay gets -- not a guess."""
    doc = _doc(link_when="${var.seg}")
    doc["variables"] = {"seg": {"default": False, "type": "bool"}}
    assert _ports(parse_intent(doc)) == ["port1"]
    doc["variables"]["seg"]["default"] = True
    assert _ports(parse_intent(doc)) == ["port1", "port3"]


def test_unresolved_var_with_no_default_is_an_error():
    doc = _doc(link_when="${var.undeclared}")
    with pytest.raises(ValueError, match="when="):
        parse_intent(doc)


def test_dropped_link_does_not_renumber_the_others():
    """``port:`` auto-numbering keys off the DECLARATION index, so disabling a
    link must not shift a later port onto the wrong NIC."""
    doc = {
        "fabric": "wf",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}],
        "nodes": [{"name": "fgt", "type": "FGT", "firmware": 814, "links": [
            {"switch": "mgmtsw"},                      # -> port1
            {"switch": "mgmtsw", "when": False},       # -> port2, dropped
            {"switch": "mgmtsw"},                      # -> port3, NOT port2
        ]}],
    }
    assert _ports(parse_intent(doc)) == ["port1", "port3"]
