"""The agent skill must not drift from the code it describes."""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parents[1] / "skills" / "fabric-studio"
TEXT = (SKILL_DIR / "SKILL.md").read_text()

# snake_case words in the skill that are not library functions
NOT_FUNCTIONS = {"verify_ssl", "timeout_s", "allow_running", "task_id", "vm_id", "api_index", "wait_task_",
                 "post_boot_prepared", "pod_password", "vm_type", "get_task_log_", "run_id", "fgt_single", "fgt_fmg_faz", "fgt_image", "would_stop", "log_tail"}


def test_frontmatter_names_the_skill_and_says_when_to_use_it():
    head = TEXT.split("---")[1]
    assert re.search(r"^name: fabric-studio$", head, re.M)
    desc = re.search(r"^description: (.+)$", head, re.M).group(1)
    assert len(desc) > 80 and "Use when" in desc


def test_every_function_the_skill_names_exists():
    from conftest import import_server

    from fabric_studio import admin as fs_admin
    from fabric_studio import keychain
    from fabric_studio import resolve as fs_resolve
    from fabric_studio.client import FabricStudioClient
    server = import_server()
    tools = {n for n in dir(server) if not n.startswith("_")}
    known = set(dir(fs_admin)) | set(dir(fs_resolve)) | set(dir(keychain)) | set(dir(FabricStudioClient)) | tools
    tokens = set(re.findall(r"`([a-z][a-z0-9]*(?:_[a-z0-9]+)+)(?:\(.*?\))?`", TEXT))
    missing = sorted(t for t in tokens if t not in known and t not in NOT_FUNCTIONS)
    assert not missing, f"the skill names things that do not exist: {missing}"


def test_the_connect_example_compiles_and_only_uses_real_imports():
    code = re.search(r"```python\n(.*?)```", TEXT, re.S).group(1)
    compile(code, "SKILL.md", "exec")
    for line in code.splitlines():
        if line.startswith(("from ", "import ")):
            exec(line, {})


def test_the_api_index_is_current():
    r = subprocess.run([sys.executable, str(SKILL_DIR / "gen_api_index.py"), "--check"], capture_output=True)
    assert r.returncode == 0, "api-index.md is stale: run python skills/fabric-studio/gen_api_index.py"


def test_the_skill_ships_no_lab_details():
    for f in SKILL_DIR.glob("*"):
        if f.suffix in {".md", ".py"}:
            body = f.read_text()
            assert not re.search(r"\b10\.\d+\.\d+\.\d+\b|fortidemo|svl-devops|password\s*=\s*['\"]\w", body), f.name


def test_the_build_workflow_uses_only_actions_and_fields_the_tool_has():
    import fabric_studio.mcp.build as build
    section = TEXT.split("## Build a fabric")[1].split("\n## ")[0]
    actions = set(re.findall(r"`action=([a-z]+)`", section))
    assert actions == set(build.ACTIONS)
    for field in ("errors", "blocked", "would_stop", "reinstalls", "deletes", "run_id", "state", "succeeded", "log_tail"):
        assert f"`{field}`" in section
