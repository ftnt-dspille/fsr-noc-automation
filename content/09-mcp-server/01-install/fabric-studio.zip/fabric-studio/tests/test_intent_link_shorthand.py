"""Semantics of the backward-compatible link shorthands in ``parse_intent``.

Each shorthand must expand to the *exact same* ``Intent`` as its verbose form —
we assert equality against the canonical spelling, not merely "it parses".
"""
from __future__ import annotations

import dataclasses

import pytest

from fabric_studio.topology.reconciler import _default_port_name, parse_intent


def _base(nodes: list[dict]) -> dict:
    return {
        "fabric": "sh",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}],
        "nodes": nodes,
    }


def _links(intent, node="host1"):
    nd = next(n for n in intent.nodes if n.name == node)
    return [dataclasses.asdict(lk) for lk in nd.links]


def test_node_switch_shorthand_equals_verbose():
    short = parse_intent(_base([
        {"name": "host1", "type": "LXC", "firmware": 865, "switch": "mgmtsw"}]))
    verbose = parse_intent(_base([
        {"name": "host1", "type": "LXC", "firmware": 865,
         "links": [{"port": "eth0", "switch": "mgmtsw"}]}]))
    assert _links(short) == _links(verbose)


def test_bare_string_link_equals_verbose():
    short = parse_intent(_base([
        {"name": "host1", "type": "LXC", "firmware": 865, "links": ["mgmtsw"]}]))
    verbose = parse_intent(_base([
        {"name": "host1", "type": "LXC", "firmware": 865,
         "links": [{"port": "eth0", "switch": "mgmtsw"}]}]))
    assert _links(short) == _links(verbose)


def test_auto_port_numbers_by_order():
    intent = parse_intent(_base([
        {"name": "host1", "type": "LXC", "firmware": 865,
         "links": ["mgmtsw", "mgmtsw"]}]))
    assert [lk["port"] for lk in _links(intent)] == ["eth0", "eth1"]


def test_fortinet_type_defaults_to_port_style():
    intent = parse_intent(_base([
        {"name": "host1", "type": "FGT", "firmware": 100,
         "links": ["mgmtsw", "mgmtsw"]}]))
    assert [lk["port"] for lk in _links(intent)] == ["port1", "port2"]


def test_explicit_port_still_wins_over_default():
    intent = parse_intent(_base([
        {"name": "host1", "type": "FGT", "firmware": 100,
         "links": [{"port": "mgmt", "switch": "mgmtsw"}]}]))
    assert _links(intent)[0]["port"] == "mgmt"


def test_switch_and_links_together_is_error():
    with pytest.raises(ValueError, match="not both"):
        parse_intent(_base([
            {"name": "host1", "type": "LXC", "firmware": 865, "switch": "mgmtsw",
             "links": [{"port": "eth0", "switch": "mgmtsw"}]}]))


def test_undeclared_switch_still_rejected_via_shorthand():
    with pytest.raises(ValueError, match="undeclared switch"):
        parse_intent(_base([
            {"name": "host1", "type": "LXC", "firmware": 865, "switch": "nope"}]))


@pytest.mark.parametrize("nt,idx,expected", [
    ("LXC", 0, "eth0"), ("BASIC", 1, "eth1"), ("SOAR", 0, "eth0"),
    ("FGT", 0, "port1"), ("fmg", 2, "port3"), ("", 0, "eth0"),
])
def test_default_port_name(nt, idx, expected):
    assert _default_port_name(nt, idx) == expected
