"""Offline tests for managed Fabric Studio instances (``tools/fs_mcp/instances``): env-file
discovery, the registry, registration (login stubbed), and that no password is ever returned."""
from __future__ import annotations

import json
import stat
from unittest.mock import MagicMock

import pytest

from fabric_studio.mcp import instances as inst

SECRET = "s3cret-pw-do-not-leak"


@pytest.fixture
def env_dir(tmp_path, monkeypatch):
    d = tmp_path / "envs"
    d.mkdir()
    (d / ".env.alpha").write_text(f"FS_POD_HOST=alpha.example.com\nPOD_USERNAME=admin\nPOD_PASSWORD={SECRET}\n")
    (d / ".env.beta").write_text(f"# beta.pods.example.com\nPOD_PASSWORD='{SECRET}'\n")
    (d / ".env.nopw").write_text("FS_POD_HOST=nopw.example.com\n")
    monkeypatch.setenv("FS_ENV_DIRS", str(d))
    monkeypatch.setenv("FSH_INSTANCES_FILE", str(tmp_path / "instances.json"))
    return d


def _ok_connect(monkeypatch):
    monkeypatch.setattr("fabric_studio.admin.get_pod_hostname", lambda c: "alpha-host")
    return lambda h, u, p: object()


def _by_host(rows):
    return {r["host"]: r for r in rows}


def test_discover_reads_env_files_without_secrets(env_dir):
    rows = _by_host(inst.discover())
    assert rows["alpha.example.com"]["has_password"] is True
    assert rows["alpha.example.com"]["user"] == "admin"
    assert rows["beta.pods.example.com"]["has_password"] is True  # host from the header comment
    assert rows["nopw.example.com"]["has_password"] is False
    assert SECRET not in json.dumps(rows)


def test_register_env_file_and_creds_roundtrip(env_dir, monkeypatch):
    out = inst.register(env_file=str(env_dir / ".env.alpha"), connect=_ok_connect(monkeypatch))
    assert out["ok"] and out["verified"] and out["host"] == "alpha.example.com"
    assert SECRET not in json.dumps(out)
    assert inst.creds_for("alpha.example.com") == ("admin", SECRET)
    path = inst.registry_path()
    assert stat.S_IMODE(path.stat().st_mode) == 0o600
    assert SECRET not in path.read_text()
    status = _by_host(inst.instances_status(inst.discover(), inst.load_registry()))
    assert status["alpha.example.com"]["registered"] is True


def test_dry_run_changes_nothing(env_dir, monkeypatch):
    out = inst.register(env_file=str(env_dir / ".env.alpha"), dry_run=True, connect=_ok_connect(monkeypatch))
    assert out["ok"] and out["dry_run"]
    assert inst.load_registry() == {}


def test_failed_login_is_refused(env_dir):
    def bad(h, u, p):
        raise RuntimeError("401")
    out = inst.register(env_file=str(env_dir / ".env.alpha"), connect=bad)
    assert not out["ok"] and "login" in out["error"]
    assert inst.load_registry() == {}


def test_env_file_outside_allowed_roots_is_refused(env_dir, tmp_path):
    other = tmp_path / "elsewhere"
    other.mkdir()
    (other / ".env").write_text("FS_POD_HOST=x.example.com\nPOD_PASSWORD=x\n")
    out = inst.register(env_file=str(other / ".env"), verify=False)
    assert not out["ok"] and "outside" in out["error"]
    bad_name = env_dir / "notes.txt"
    bad_name.write_text("x")
    assert not inst.register(env_file=str(bad_name), verify=False)["ok"]


def test_keychain_store_copies_password_to_keychain_only(env_dir, monkeypatch):
    saved = {}
    out = inst.register(env_file=str(env_dir / ".env.alpha"), store="keychain", verify=False,
                        set_secret=lambda h, p: saved.update({h: p}))
    assert out["ok"] and saved == {"alpha.example.com": SECRET}
    entry = inst.load_registry()["alpha.example.com"]
    assert "env_file" not in entry and SECRET not in json.dumps(entry)


def test_unregister(env_dir, monkeypatch):
    inst.register(env_file=str(env_dir / ".env.alpha"), verify=False)
    assert inst.unregister("alpha.example.com")["ok"]
    assert inst.load_registry() == {}
    assert not inst.unregister("alpha.example.com")["ok"]


def test_server_tools(env_dir, monkeypatch):
    import importlib

    from conftest import import_server


    s = import_server()
    assert s.add_instance(env_file=str(env_dir / ".env.alpha"), verify=False)["ok"]
    rows = s.list_instances(probe=False)
    assert [r["host"] for r in rows] == ["alpha.example.com"] and rows[0]["password_in"] == "env file"
    monkeypatch.setattr(s, "_pod_overview", lambda h, only: {"host": h, "online": True, "fabrics": []})
    assert s.instances_overview()[0]["host"] == "alpha.example.com"
    monkeypatch.setattr(s, "_probe", lambda h: {"online": False, "error": "down"})
    disc = _by_host(s.discover_instances(probe=True))
    assert disc["alpha.example.com"]["registered"] and disc["alpha.example.com"]["online"] is False
    assert s.remove_instance("alpha.example.com")["ok"]
    assert SECRET not in json.dumps(disc)


def test_lockouts_read_and_scope(tmp_path, monkeypatch):
    monkeypatch.setattr(inst.Path, "home", classmethod(lambda cls: tmp_path))
    d = tmp_path / ".fsh" / "lockouts"
    d.mkdir(parents=True)
    (d / "a__.lockout").write_text(json.dumps(
        {"pod_host": "a.example.com", "fabric": "*", "reason": "live", "by": "me", "created": 1.0}))
    (d / "b_f.lockout").write_text(json.dumps(
        {"pod_host": "b.example.com", "fabric": "f1", "reason": "", "by": "me", "created": 1.0}))
    (d / "junk.lockout").write_text("not json")
    locks = inst.lockouts()
    assert set(locks) == {"a.example.com", "b.example.com"}
    assert inst.is_locked(locks["a.example.com"], "anything")
    assert inst.is_locked(locks["b.example.com"], "f1") and not inst.is_locked(locks["b.example.com"], "f2")
    assert not inst.is_locked(locks["b.example.com"])


def test_whats_up_filters_and_lock_flags(env_dir, monkeypatch):
    import importlib

    from conftest import import_server


    s = import_server()
    s.add_instance(env_file=str(env_dir / ".env.alpha"), verify=False, name="alpha")
    monkeypatch.setattr(inst, "lockouts", lambda: {"alpha.example.com": [
        {"fabric": "f1", "reason": "x", "by": "me", "since": None}]})
    def dev(n, t, up=True):
        return {"id": n, "name": n, "vm_type": t, "up": up, "ready": True}
    ov = {"online": True, "devices_up": 3, "locked": False, "lockouts": inst.lockouts()["alpha.example.com"],
          "fabrics": [{"id": 1, "name": "f1", "locked": True, "devices": [dev("fgt1", "FGT"), dev("fmg", "FMG"), dev("fgt2", "FGT", False)]}]}
    monkeypatch.setattr(s, "_pod_overview", lambda h, only, creds=None: ov)
    all_up = s.whats_up(include_unmanaged=False)
    assert [d["name"] for d in all_up["pods"][0]["fabrics"][0]["devices"]] == ["fgt1", "fmg"]
    assert all_up["pods"][0]["fabrics"][0]["locked"] is True
    fgt = s.whats_up(include_unmanaged=False, vm_type="fgt")
    assert [d["name"] for d in fgt["pods"][0]["fabrics"][0]["devices"]] == ["fgt1"]
    assert s.whats_up(include_unmanaged=False, vm_type="FWB")["pods"] == []
    assert s.whats_up(include_unmanaged=False, name_contains="FM")["pods"][0]["devices_up"] == 1


def test_env_file_password_only_goes_to_the_host_it_names(env_dir, monkeypatch):
    sent = []
    out = inst.register(host="evil.example.com", env_file=str(env_dir / ".env.alpha"),
                        connect=lambda h, u, p: sent.append((h, p)))
    assert not out["ok"] and "alpha.example.com" in out["error"] and sent == []
    (env_dir / ".env.nohost").write_text(f"POD_PASSWORD={SECRET}\n")
    out = inst.register(host="evil.example.com", env_file=str(env_dir / ".env.nohost"),
                        connect=lambda h, u, p: sent.append((h, p)))
    assert not out["ok"] and sent == []
    # an entry whose file now names another host yields no credentials
    inst.register(env_file=str(env_dir / ".env.alpha"), verify=False)
    (env_dir / ".env.alpha").write_text(f"FS_POD_HOST=other.example.com\nPOD_PASSWORD={SECRET}\n")
    assert inst.creds_for("alpha.example.com") is None


def _patch_keychain(monkeypatch, get_secret):
    """conftest drops fabric_studio.keychain from sys.modules per test, so patch the live module object."""
    import importlib

    monkeypatch.setattr(importlib.import_module("fabric_studio.keychain"), "get_secret", get_secret)


# ── add_instance must not send a shared credential to a host nobody chose ──────────

def test_register_without_an_env_file_never_uses_the_shared_login(env_dir, monkeypatch):
    monkeypatch.setenv("POD_USERNAME", "admin")
    monkeypatch.setenv("POD_PASSWORD", SECRET)          # the shared fallback
    _patch_keychain(monkeypatch, lambda account: None)  # nothing stored for this host
    sent = []
    out = inst.register(host="evil.example.com", verify=True, connect=lambda h, u, p: sent.append((h, u, p)))
    assert not out["ok"] and "no login stored" in out["error"] and sent == []


def test_register_without_an_env_file_uses_a_password_stored_for_that_host(env_dir, monkeypatch):
    _patch_keychain(monkeypatch, lambda account: SECRET if account == "stored.example.com" else None)
    sent = []
    ok = _ok_connect(monkeypatch)
    out = inst.register(host="stored.example.com", verify=True, dry_run=True,
                        connect=lambda h, u, p: sent.append((h, u, p)) or ok(h, u, p))
    assert out["ok"] and sent == [("stored.example.com", "admin", SECRET)]
