"""The build tool: listing, validating and planning a topology, the apply that starts a detached run, and its status."""
from __future__ import annotations

import json
import os
from typing import ClassVar

import pytest
from conftest import import_server
from mcp.server.mcpserver.exceptions import ToolError

from fabric_studio.topology import reconciler as rec


@pytest.fixture
def b(monkeypatch, tmp_path):
    import fabric_studio.mcp.build as mod
    import_server()  # a fresh server reloads the tool module onto its own mcp
    import importlib
    mod = importlib.import_module("fabric_studio.mcp.build")
    monkeypatch.setattr(mod, "_known_host", lambda h: True)
    monkeypatch.setattr(mod, "_client", lambda h: object())
    monkeypatch.setattr(mod, "_login", lambda h: ("admin", "pw-from-keychain"))
    monkeypatch.setattr(mod.inst, "lockouts", lambda: {})
    monkeypatch.setattr(mod.fs_admin, "get_running_fabric", lambda c: {"name": "other-fabric"})
    monkeypatch.setattr(mod.topo, "check_firmware", lambda c, i: ({"fgt": {"id": 814, "name": "FGT-7.6.6.zip"}}, []))
    mod.call = mod.build.__wrapped__
    return mod


def _plan(*changes, errors=()):
    return rec.Plan(changes=list(changes), errors=list(errors), fabric="fgt-single")


CREATE = rec.Change("create", "node", "fgt")


class FakePopen:
    calls: ClassVar[list] = []

    def __init__(self, cmd, **kw):
        FakePopen.calls.append((cmd, kw))
        self.pid = 4242


def test_it_lists_the_bundled_topologies_with_their_variables(b):
    rows = {r["name"]: r for r in b.call("topologies")["topologies"]}
    assert {"fgt_single", "fgt_fmg_faz"} <= set(rows)
    assert rows["fgt_fmg_faz"]["devices"] == ["FAZ", "FGT", "FMG"]
    assert "fgt_image" in rows["fgt_fmg_faz"]["variables"] and rows["fgt_fmg_faz"]["source"] == "bundled"


def test_a_bundled_topology_validates_with_no_pod(b):
    out = b.call("validate", topology="fgt_fmg_faz")
    assert out["ok"] is True and [n["type"] for n in out["nodes"]] == ["FGT", "FMG", "FAZ"] and out["errors"] == []


def test_a_broken_topology_is_reported_not_raised(b, tmp_path, monkeypatch):
    bad = tmp_path / "ws" / "topologies" / "bad"
    bad.mkdir(parents=True)
    (bad / "intent.yaml").write_text("fabric: bad\nnodes:\n  - {name: x, type: FGT, links: [{port: port1, switch: nowhere}]}\n")
    monkeypatch.setattr(b.inst, "workspace_dirs", lambda: [tmp_path / "ws"])
    out = b.call("validate", topology="bad")
    assert out["ok"] is False and out["errors"]


@pytest.mark.parametrize("bad", ["../etc/passwd", "/etc/passwd", "a/../../b", "", "nope-not-listed", "fgt single"])
def test_a_topology_that_is_not_a_listed_name_is_refused(b, bad):
    with pytest.raises(ToolError, match="topology"):
        b.call("validate", topology=bad)


@pytest.mark.parametrize("variables", [{"x": "${file:/etc/passwd}"}, {"x": "../../a"}, {"bad name": "1"}, {"x": "a;b"}])
def test_variables_must_be_plain_text(b, variables):
    with pytest.raises(ToolError, match="variable"):
        b.call("validate", topology="fgt_single", variables=variables)


def test_a_plan_says_what_it_creates_and_what_it_would_stop(b, monkeypatch):
    monkeypatch.setattr(b.topo.rec, "plan", lambda c, i, prune=False: _plan(CREATE))
    out = b.call("plan", host="h", topology="fgt_single")
    assert out["ok"] and out["nodes_to_create"] == ["fgt"] and out["would_stop"] == "other-fabric"
    assert out["changes"] == {"create": 1} and out["blocked"] is False


def test_a_plan_failure_is_returned_with_its_reason(b, monkeypatch):
    def boom(c, i, prune=False):
        raise b.fs_admin.FabricStudioAdminError("no firmware for FGT")
    monkeypatch.setattr(b.topo.rec, "plan", boom)
    out = b.call("plan", host="h", topology="fgt_single")
    assert out["ok"] is False and "no firmware" in out["error"]


def test_plan_and_apply_need_a_host(b):
    for action in ("plan", "apply"):
        with pytest.raises(ToolError, match="needs host"):
            b.call(action, topology="fgt_single")


def test_apply_without_confirm_only_previews(b, monkeypatch):
    monkeypatch.setattr(b.topo.rec, "plan", lambda c, i, prune=False: _plan(CREATE))
    monkeypatch.setattr(b.subprocess, "Popen", FakePopen)
    FakePopen.calls.clear()
    out = b.call("apply", host="h", topology="fgt_single")
    assert out["dry_run"] is True and out["started"] is False and FakePopen.calls == []


def test_apply_with_confirm_starts_a_detached_run_without_the_password_in_argv(b, monkeypatch):
    monkeypatch.setattr(b.topo.rec, "plan", lambda c, i, prune=False: _plan(CREATE))
    monkeypatch.setattr(b.subprocess, "Popen", FakePopen)
    FakePopen.calls.clear()
    out = b.call("apply", host="h", topology="fgt_single", variables={"fgt_image": "7.4"}, prune=True, confirm=True)
    assert out["started"] is True and out["would_stop"] == "other-fabric"
    cmd, kw = FakePopen.calls[0]
    assert "pw-from-keychain" not in " ".join(cmd) and kw["env"]["FS_POD_PASS"] == "pw-from-keychain"
    assert "--prune" in cmd and "fgt_image=7.4" in cmd and kw["start_new_session"] is True
    meta = json.loads(next(b._runs_dir().glob("*.json")).read_text())
    assert "pw-from-keychain" not in json.dumps(meta) and meta["host"] == "h"


def test_apply_is_refused_on_a_locked_pod_a_blocked_plan_and_a_running_build(b, monkeypatch):
    monkeypatch.setattr(b.subprocess, "Popen", FakePopen)
    FakePopen.calls.clear()
    monkeypatch.setattr(b.topo.rec, "plan", lambda c, i, prune=False: _plan(CREATE, errors=["black hole"]))
    out = b.call("apply", host="h", topology="fgt_single", confirm=True)
    assert out["started"] is False and out["blocked"] is True
    monkeypatch.setattr(b.topo.rec, "plan", lambda c, i, prune=False: _plan(CREATE))
    monkeypatch.setattr(b.inst, "lockouts", lambda: {"h": [{"fabric": "*", "reason": "demo Thursday"}]})
    with pytest.raises(ToolError, match="demo Thursday"):
        b.call("apply", host="h", topology="fgt_single", confirm=True)
    monkeypatch.setattr(b.inst, "lockouts", lambda: {})
    b._runs_dir().mkdir(parents=True, exist_ok=True)
    (b._runs_dir() / "20260101-000000-abcd.json").write_text(json.dumps({"run_id": "20260101-000000-abcd", "host": "h", "pid": os.getpid(), "fabric": "f", "started": "t"}))
    out = b.call("apply", host="h", topology="fgt_single", confirm=True)
    assert out["started"] is False and "still going" in out["error"] and FakePopen.calls == []


def test_apply_on_a_converged_fabric_is_a_no_op(b, monkeypatch):
    monkeypatch.setattr(b.topo.rec, "plan", lambda c, i, prune=False: _plan(rec.Change("noop", "node", "fgt")))
    out = b.call("apply", host="h", topology="fgt_single", confirm=True)
    assert out["started"] is False and out["noop"] is True


def test_status_reads_a_finished_run_and_points_at_diagnose_on_failure(b):
    d = b._runs_dir()
    d.mkdir(parents=True, exist_ok=True)
    rid = "20260101-000000-abcd"
    (d / f"{rid}.json").write_text(json.dumps({"run_id": rid, "host": "h", "pid": 1, "fabric": "f", "started": "t"}))
    (d / f"{rid}.log").write_text("[00:00:01] creating\napply FAILED: no firmware\n")
    (d / f"{rid}.rc").write_text("1\n")
    out = b.call("status", run_id=rid)
    assert out["state"] == "finished" and out["succeeded"] is False and "diagnose" in out["next"]
    (d / f"{rid}.log").write_text("converged ✓\n")
    (d / f"{rid}.rc").write_text("0\n")
    assert b.call("status", run_id=rid)["succeeded"] is True
    assert b.call("status")["runs"][0]["run_id"] == rid
    with pytest.raises(ToolError, match="bad run_id"):
        b.call("status", run_id="../../x")


def test_an_unknown_action_is_rejected(b):
    with pytest.raises(ToolError, match="action must be"):
        b.call("explode")


def test_the_tool_is_registered_as_mutating_without_a_visible_ctx(b):
    import asyncio

    import fabric_studio.mcp.server as s
    tools = {t.name: t for t in asyncio.run(s.mcp.list_tools())}
    assert tools["build"].annotations.destructive_hint is True
    assert "ctx" not in tools["build"].input_schema["properties"] and "approval" not in tools["build"].input_schema["properties"]


def test_a_firmware_the_pod_lacks_blocks_the_plan_and_names_what_it_has(b, monkeypatch):
    monkeypatch.setattr(b.topo.rec, "plan", lambda c, i, prune=False: _plan(CREATE))
    monkeypatch.setattr(b.topo, "check_firmware", lambda c, i: ({}, ["node 'fgt': firmware '9.9' not found (have: 7.4.9, 7.6.6M)"]))
    monkeypatch.setattr(b.subprocess, "Popen", FakePopen)
    FakePopen.calls.clear()
    plan = b.call("plan", host="h", topology="fgt_single", variables={"fgt_image": "9.9"})
    assert plan["blocked"] is True and "7.6.6M" in plan["errors"][0]
    out = b.call("apply", host="h", topology="fgt_single", variables={"fgt_image": "9.9"}, confirm=True)
    assert out["started"] is False and FakePopen.calls == []


def test_the_plan_reports_which_firmware_each_device_will_use(b, monkeypatch):
    monkeypatch.setattr(b.topo.rec, "plan", lambda c, i, prune=False: _plan(CREATE))
    assert b.call("plan", host="h", topology="fgt_single")["firmware"] == {"fgt": {"id": 814, "name": "FGT-7.6.6.zip"}}


def test_a_topology_can_be_built_under_another_fabric_name(b):
    rows = {r["name"]: r for r in b.call("topologies")["topologies"]}
    assert rows["fgt_single"]["fabric"] == "fgt-single" and "fabric_name" in rows["fgt_single"]["variables"]
    assert b.call("validate", topology="fgt_single", variables={"fabric_name": "second-copy"})["fabric"] == "second-copy"
    assert b.call("validate", topology="fgt_fmg_faz")["fabric"] == "fgt-fmg-faz"


def test_fabric_name_rejects_path_separators():
    import pytest
    from mcp.server.mcpserver.exceptions import ToolError

    from fabric_studio.mcp import build
    for bad in ("../x", "/etc", "a/b", "a b", "-x"):
        with pytest.raises(ToolError):
            build._check_variables({"fabric_name": bad})
    assert build._check_variables({"fabric_name": "docs-demo.1"}) == {"fabric_name": "docs-demo.1"}


def test_bundled_topologies_plan_without_a_checkout(tmp_path, monkeypatch):
    """An installed copy has no .git/devices/pyproject above its topologies: validate must still work."""
    from fabric_studio.mcp import build
    from fabric_studio.topology import payload, run

    def no_root(*a, **k):
        raise FileNotFoundError("no repository root")
    monkeypatch.setattr(payload, "repo_root", no_root)
    for name in ("fgt_single", "fgt_fmg_faz"):
        intent = run.load(str(build._resolve_topology(name)))
        assert intent.nodes
