"""``fabric-studio-mcp connect``: which agents it finds, the exact commands it runs, and that it never replaces silently."""
from __future__ import annotations

import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

from fabric_studio.mcp import cli, connect, skill

CMD = "/opt/tools/bin/fabric-studio-mcp"


@pytest.fixture(autouse=True)
def isolated(tmp_path, monkeypatch):
    """No test here may write into the developer's real home (their agents' skill folders live there)."""
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: home))
    src = tmp_path / "skill-source"
    src.mkdir()
    (src / "SKILL.md").write_text("the skill")
    (src / "api-index.md").write_text("the index")
    monkeypatch.setattr(skill, "source", lambda: src)
    return home


class FakeAgents:
    """A runner that behaves like the four agents' `mcp` commands, and records what was run."""

    def __init__(self, present: set[str] = frozenset(), fail: str | None = None, list_down: set[str] = frozenset()):
        self.calls: list[list[str]] = []
        self.present, self.fail, self.list_down = set(present), fail, set(list_down)

    def __call__(self, argv):
        argv = list(argv)
        self.calls.append(argv)
        prog = argv[0].rsplit("/", 1)[-1]
        sub = argv[2] if len(argv) > 2 else ""
        if self.fail and sub == self.fail:
            return 1, "boom"
        if sub in ("show", "get"):
            if prog in self.present:
                return 0, ""
            # FortiAgent's own wording for an unknown server; claude and codex just exit 1
            return 1, ("fortiagent mcp: No MCP server is named x. List them with mcp list." if prog == "fortiagent" else "not found")
        if sub == "add":
            self.present.add(prog)
            return 0, ""
        if sub == "remove":
            self.present.discard(prog)
            return 0, ""
        if sub == "update":
            return 0, ""
        if sub == "list" and prog in self.list_down:
            return 1, "Error: Server process exited with code 1"
        if sub == "list":
            name = "Fabric Studio" if prog == "fortiagent" else "fabric-studio"
            return 0, (f"✓ {name}  connected\n" if prog in self.present else "")
        return 1, "?"


def which_all(prog):
    return f"/usr/bin/{prog}"


def which_only(*progs):
    return lambda prog: f"/usr/bin/{prog}" if prog in progs else None


def run(argv, runner, *, which=which_all, ask=lambda _: "y", env=None):
    lines: list[str] = []
    rc = connect.connect(cli.build_parser().parse_args(["connect", *argv]), run=runner, which=which, ask=ask,
                         out=lines.append, env=env or {}, command=CMD, exists=lambda _: False)
    return rc, "\n".join(lines)


def adds(runner):
    return [c for c in runner.calls if "add" in c[:3]]


def test_connects_every_agent_it_finds_with_each_agents_own_command():
    r = FakeAgents()
    rc, text = run([], r)
    assert rc == 0, text
    by = {c[0].rsplit("/", 1)[-1]: c for c in adds(r)}
    assert by["fortiagent"][1:] == ["mcp", "add", "Fabric Studio", "--", CMD]
    assert by["claude"][1:] == ["mcp", "add", "fabric-studio", "--scope", "user", "--", CMD]
    assert by["codex"][1:] == ["mcp", "add", "fabric-studio", "--", CMD]
    assert by["opencode"][1:] == ["mcp", "add", "--global", "fabric-studio", "--", CMD]
    assert "Next: ask the agent" in text


def test_only_the_named_agent_is_touched():
    r = FakeAgents()
    rc, _ = run(["claude"], r)
    assert rc == 0 and [c[0].rsplit("/", 1)[-1] for c in adds(r)] == ["claude"]


def test_agents_that_are_not_installed_are_skipped_not_failed():
    r = FakeAgents()
    rc, text = run([], r, which=which_only("codex"))
    assert rc == 0 and [c[0].rsplit("/", 1)[-1] for c in adds(r)] == ["codex"]
    rc, text = run(["claude"], FakeAgents(), which=which_only("codex"))
    assert rc == 1 and "not installed here" in text


def test_nothing_installed_says_how_to_add_it_by_hand():
    rc, text = run([], FakeAgents(), which=which_only())
    assert rc == 1 and CMD in text and "by hand" in text


def test_dry_run_prints_the_commands_and_changes_nothing():
    r = FakeAgents()
    rc, text = run(["--dry-run"], r)
    assert rc == 0 and adds(r) == [] and "Dry run" in text and "mcp add" in text and CMD in text


def test_declining_changes_nothing():
    r = FakeAgents()
    rc, text = run([], r, ask=lambda _: "n")
    assert rc == 1 and adds(r) == [] and "Left as it was" in text


def test_yes_does_not_ask():
    def boom(_):
        raise AssertionError("asked")
    rc, _ = run(["--yes", "codex"], FakeAgents(), ask=boom)
    assert rc == 0


def test_an_existing_entry_is_left_alone_unless_replace():
    r = FakeAgents(present={"claude"})
    rc, text = run(["claude"], r)
    assert rc == 0 and adds(r) == [] and "already connected" in text and "--replace" in text


def test_replace_swaps_the_entry_with_each_agents_own_commands():
    r = FakeAgents(present={"claude", "fortiagent", "codex"})
    rc, text = run(["--replace", "claude", "fortiagent", "codex"], r)
    assert rc == 0, text
    subs = [(c[0].rsplit("/", 1)[-1], c[2]) for c in r.calls if c[2] in ("remove", "add", "update")]
    assert ("claude", "remove") in subs and ("claude", "add") in subs
    assert ("fortiagent", "update") in subs and ("fortiagent", "add") not in subs
    assert subs.index(("claude", "remove")) < subs.index(("claude", "add"))


def test_opencode_cannot_be_replaced_from_the_command_line_and_says_so():
    r = FakeAgents(present={"opencode"})
    rc, text = run(["--replace", "opencode"], r)
    assert rc == 1 and adds(r) == [] and "cannot replace" in text


def test_a_failing_agent_command_is_reported_and_exits_nonzero():
    rc, text = run(["claude"], FakeAgents(fail="add"))
    assert rc == 1 and "failed" in text and "boom" in text


def test_an_unknown_agent_is_refused_before_anything_runs():
    r = FakeAgents()
    rc, text = run(["emacs"], r)
    assert rc == 2 and "emacs" in text and r.calls == []


def test_a_path_with_spaces_is_quoted_in_the_printed_command():
    lines: list[str] = []
    args = cli.build_parser().parse_args(["connect", "--dry-run", "codex", "--command", "/my tools/fabric-studio-mcp"])
    connect.connect(args, run=FakeAgents(), which=which_all, out=lines.append, env={}, exists=lambda _: False)
    assert '"/my tools/fabric-studio-mcp"' in "\n".join(lines)


def test_fortiagent_is_found_inside_the_app_bundle_when_it_is_not_on_path(tmp_path):
    exe = tmp_path / "fortiagent"
    exe.write_text("")
    assert connect.AGENTS["fortiagent"].find(which_only(), {"FORTIAGENT_BIN": str(exe)}) == str(exe)
    assert connect.AGENTS["fortiagent"].find(which_only(), {}, lambda p: p == connect._FORTIAGENT_APP) == connect._FORTIAGENT_APP


def test_self_command_is_absolute_whether_run_by_name_or_path(tmp_path):
    exe = tmp_path / "fabric-studio-mcp"
    exe.write_text("")
    assert connect.self_command(str(exe)) == str(exe)
    assert connect.self_command("fabric-studio-mcp", which=lambda _: "/x/bin/fabric-studio-mcp") == "/x/bin/fabric-studio-mcp"


def test_the_pod_commands_do_not_import_the_mcp_package():
    """`pods`, `setup` and `connect` must not pay for importing the MCP SDK (over a second); only the server does."""
    code = ("import sys; from fabric_studio.mcp import entry, cli, connect; "
            "print('mcp' in sys.modules, 'fabric_studio.mcp.server' in sys.modules)")
    out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, check=True).stdout.strip()
    assert out == "False False", out


def test_the_command_option_does_not_replace_the_subcommand(monkeypatch):
    """`--command` and the subcommand name once shared one argparse destination: main() then looked up the path."""
    seen = {}
    monkeypatch.setattr(connect, "connect", lambda args: seen.update(vars(args)) or 0)
    assert cli.main(["connect", "--dry-run", "--command", "/x/fabric-studio-mcp", "codex"]) == 0
    assert seen["agent_command"] == "/x/fabric-studio-mcp" and seen["agent"] == ["codex"]


def test_a_failed_check_is_unknown_not_absent_so_nothing_is_added():
    r = FakeAgents(list_down={"opencode"})
    rc, text = run(["opencode"], r)
    assert rc == 1 and adds(r) == [] and "could not check" in text


def test_an_add_that_worked_is_not_a_failure_when_the_agent_cannot_list_afterwards():
    """opencode's `mcp list` needs its local service; a busy port must not turn a good add into a failure."""
    class ListFailsAfterAdd(FakeAgents):
        def __call__(self, argv):
            if list(argv)[2:3] == ["list"] and any(c[2:3] == ["add"] for c in self.calls):
                self.calls.append(list(argv))
                return 1, "Error: port in use"
            return super().__call__(argv)
    r = ListFailsAfterAdd()
    rc, text = run(["codex"], r)
    assert rc == 0 and "added as" in text and "could not confirm" in text


def test_the_printed_command_names_the_program_not_its_full_path():
    _, text = run(["--dry-run", "codex"], FakeAgents())
    assert "\n  codex mcp add fabric-studio -- " in text and "/usr/bin/codex mcp add" not in text


def test_the_pod_commands_silence_the_self_signed_certificate_warning(tmp_path):
    """`setup` talks to pods with self-signed certificates; it once printed four multi-line warnings because the
    commands stopped importing the server, whose imports used to silence them."""
    code = ("import warnings, sys; from fabric_studio.mcp import cli; cli.main(['pods']); "
            "from urllib3.exceptions import InsecureRequestWarning as W; "
            "print(any(f[0] == 'ignore' and f[2] is W for f in warnings.filters), 'fabric_studio.pod.runtime_factory' in sys.modules)")
    env = {**__import__("os").environ, "FSH_INSTANCES_FILE": str(tmp_path / "i.json")}
    out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, check=True, env=env).stdout.split()
    assert out[-2:] == ["True", "False"], out


# ── the skill ────────────────────────────────────────────────────────────────

def installed(home, rel):
    return (home / rel / "SKILL.md").is_file() and (home / rel / "api-index.md").is_file()


def test_the_skill_is_copied_for_claude_and_codex_after_the_mcp_add(isolated):
    rc, text = run(["claude", "codex"], FakeAgents())
    assert rc == 0, text
    assert installed(isolated, ".claude/skills/fabric-studio") and installed(isolated, ".codex/skills/fabric-studio")
    assert "Claude Code: skill installed in ~/.claude/skills/fabric-studio." in text


def test_the_skill_follows_the_agents_own_config_folder_variables(isolated, tmp_path):
    env = {"CLAUDE_CONFIG_DIR": str(tmp_path / "cc"), "CODEX_HOME": str(tmp_path / "cx")}
    rc, _ = run(["claude", "codex"], FakeAgents(), env=env)
    assert rc == 0
    assert (tmp_path / "cc/skills/fabric-studio/SKILL.md").is_file() and (tmp_path / "cx/skills/fabric-studio/SKILL.md").is_file()
    assert not (isolated / ".claude").exists() and not (isolated / ".codex").exists()


def test_dry_run_names_the_skill_folder_and_writes_nothing(isolated):
    rc, text = run(["--dry-run", "claude"], FakeAgents())
    assert rc == 0 and "copy the skill to ~/.claude/skills/fabric-studio" in text
    assert not (isolated / ".claude").exists()


def test_declining_copies_no_skill(isolated):
    rc, _ = run(["claude"], FakeAgents(), ask=lambda _: "n")
    assert rc == 1 and not (isolated / ".claude").exists()


def test_no_skill_skips_it(isolated):
    rc, text = run(["--no-skill", "claude"], FakeAgents())
    assert rc == 0 and "skill" not in text and not (isolated / ".claude").exists()


def test_an_agent_that_already_has_the_server_still_gets_the_skill(isolated):
    rc, text = run(["claude"], FakeAgents(present={"claude"}))
    assert rc == 0 and "already connected" in text and installed(isolated, ".claude/skills/fabric-studio")


def test_a_current_copy_is_left_alone_and_said_so(isolated):
    skill.install(skill.source(), isolated / ".claude/skills/fabric-studio")
    rc, text = run(["claude"], FakeAgents())
    assert rc == 0 and "skill already installed in ~/.claude/skills/fabric-studio" in text and "skill installed in" not in text


def test_a_different_copy_is_not_overwritten_without_replace(isolated):
    dst = isolated / ".claude/skills/fabric-studio"
    dst.mkdir(parents=True)
    (dst / "SKILL.md").write_text("someone's edited copy")
    rc, text = run(["claude"], FakeAgents())
    assert "different copy of the skill" in text and "--replace" in text
    assert (dst / "SKILL.md").read_text() == "someone's edited copy"
    rc, text = run(["--replace", "claude"], FakeAgents(present={"claude"}))
    assert rc == 0 and (dst / "SKILL.md").read_text() == "the skill"


def test_opencode_alone_gets_its_own_folder_but_shares_claudes_when_claude_is_connected(isolated):
    rc, text = run(["opencode"], FakeAgents())
    assert rc == 0 and installed(isolated, ".config/opencode/skills/fabric-studio")
    rc, text = run(["claude", "opencode"], FakeAgents(), which=which_all)
    assert "opencode: reads Claude Code's skills folder" in text


def test_fortiagent_is_told_to_import_it_in_the_app_and_nothing_is_copied(isolated):
    rc, text = run(["fortiagent"], FakeAgents())
    assert rc == 0 and "FortiAgent: import the skill in the app" in text and str(skill.source()) in text
    assert not any(isolated.rglob("SKILL.md"))


def test_a_missing_skill_source_is_reported_not_fatal(isolated, monkeypatch):
    monkeypatch.setattr(skill, "source", lambda: None)
    rc, text = run(["claude"], FakeAgents())
    assert rc == 0 and "skill is not part of this install" in text and not (isolated / ".claude").exists()


@pytest.mark.skipif(not shutil.which("uv"), reason="needs uv to build in an isolated environment, as an install does")
def test_a_built_wheel_carries_the_skill(tmp_path):
    """`uv tool install` builds a wheel: the build hook must put the skill inside the package. `uv build` makes the
    sdist first and the wheel from it, so this also proves MANIFEST.in ships the skill files."""
    root = Path(__file__).resolve().parent.parent
    subprocess.run(["uv", "build", "--out-dir", str(tmp_path), "-q", str(root)], check=True, capture_output=True)
    with zipfile.ZipFile(next(tmp_path.glob("*.whl"))) as z:
        for name in skill.FILES:
            assert z.read(f"fabric_studio/_skill/{name}") == (root / "skills" / "fabric-studio" / name).read_bytes()
