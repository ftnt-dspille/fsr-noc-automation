"""Dry run: every tool annotated destructive does NOTHING when called without ``confirm``.

The docubot approval policy lets previews through without asking the person, because it relies on this contract:
a change tool without ``confirm`` (or with ``confirm=false``) never acts. This test calls each destructive-annotated
tool with ``confirm`` absent and proves that no write reached the network or the pod. Every write path is a tripwire:
any non-GET HTTP request, any SSH execution, and any non-read call on the FortiOS client is recorded, and the test fails
if one is recorded. A destructive tool with no case here fails the test until it gets one.
"""
from __future__ import annotations

import asyncio
import inspect
from unittest.mock import MagicMock

import pytest
import requests
from conftest import import_server
from mcp.server.mcpserver.exceptions import ToolError

# One minimal call per destructive tool, WITHOUT confirm. Every action named here is one the tool accepts.
CASES: dict[str, dict] = {
    "set_vm_access_public": dict(host="pod", vm="fsr", fabric="f"),
    "install_system_host": dict(host="pod", fabric="f"),
    "set_vm_port_dhcp": dict(host="pod", vm="fsr", fabric="f"),
    "set_vm_port_auto": dict(host="pod", vm="fsr", fabric="f"),
    "snapshot_vm": dict(host="pod", action="full", name="snap", vm="fsr", fabric="f"),
    "vm_lifecycle": dict(host="pod", action="restart", vm="fsr", fabric="f"),
    "set_vm_license": dict(host="pod", mode="flex", vm="fsr", fabric="f"),
    "build": dict(host="pod", action="apply", topology="t"),
    "device": dict(host="pod", device="fgt", fabric="f", action="set", section="interfaces", name="port1",
                   values={"status": "up"}),
    "run": dict(host="pod", device="fgt", fabric="f", command="execute reboot"),
    "register": dict(host="pod", gate="gate", manager="mgr"),
    "firmware": dict(host="pod", action="import", name="fw"),
}

# Any of these on a client object is a write.
WRITE_METHODS = {"post", "put", "patch", "delete", "request_write"}


# Tools defined outside server.py, looked up in the module that registers them.
MODULE_OF = {"build": "build", "device": "device", "firmware": "firmware", "register": "register", "run": "rawexec"}


def _tool_fn(s, name):
    import importlib
    return getattr(importlib.import_module(f"fabric_studio.mcp.{MODULE_OF[name]}") if name in MODULE_OF else s, name)


@pytest.fixture
def tripwire(monkeypatch):
    s = import_server()
    writes: list[str] = []
    real_session_request = requests.sessions.Session.request

    def guarded_request(self, method, url, *a, **k):
        if str(method).upper() != "GET":
            writes.append(f"HTTP {method} {url}")
            raise AssertionError(f"dry run wrote over HTTP: {method} {url}")
        raise requests.ConnectionError("dry-run test: no network")

    monkeypatch.setattr(requests.sessions.Session, "request", guarded_request)

    def guarded_ssh(*a, **k):
        writes.append(f"SSH {a[:2]!r}")
        raise AssertionError("dry run ran a command over SSH")

    import fabric_studio.channels.ssh as ssh_mod
    monkeypatch.setattr(ssh_mod, "_jump_exec", guarded_ssh, raising=False)

    # The FS client: every GET answers an empty 200, so a tool reads "nothing there" and goes on to the change it
    # would make. Any write it then attempts is recorded on this mock, and the test fails.
    client = MagicMock()
    reply = MagicMock(status_code=200, text="{}")
    reply.json.return_value = {"results": [], "data": [], "items": []}
    client.get.return_value = reply
    monkeypatch.setattr(s, "_client", lambda host: client)
    # One fabric (id 10) with one VM, so the name lookups resolve and the tool reaches its change step.
    vm = {"id": 78, "name": "fsr", "vm_type": "FGT", "fabric_id": 10}
    monkeypatch.setattr(s, "_resolve", lambda host, v, fab, vt=None: (client, 10, vm))
    monkeypatch.setattr(s, "resolve_fabric_id", lambda c, fab: 10)
    return s, writes, client


def _destructive_names(s) -> set[str]:
    return {t.name for t in asyncio.run(s.mcp.list_tools()) if t.annotations and t.annotations.destructive_hint}


def test_every_destructive_tool_has_a_dry_run_case(tripwire):
    s, _, _ = tripwire
    names = _destructive_names(s)
    assert names, "no destructive tools found: the annotations changed"
    missing = sorted(names - set(CASES))
    assert not missing, f"destructive tools with no dry-run case (add one to CASES): {missing}"
    stale = sorted(set(CASES) - names)
    assert not stale, f"CASES names tools that are no longer destructive: {stale}"


@pytest.mark.parametrize("name", sorted(CASES))
def test_destructive_tool_without_confirm_changes_nothing(name, tripwire):
    s, writes, client = tripwire
    fn = _tool_fn(s, name)
    out = None
    try:
        out = fn(**CASES[name])
        if inspect.isawaitable(out):
            out = asyncio.run(out)
    except ToolError:
        pass   # the tool refused the call in words: fine, as long as nothing was written
    except Exception as e:
        # a bug in the case (a wrong argument, a missing mock) must not pass for a dry run
        raise AssertionError(f"{name} did not reach its preview path: {type(e).__name__}: {e}") from e
    assert writes == [], f"{name} wrote without confirm: {writes}"
    client_writes = [c for c in client.method_calls if c[0].split(".")[-1] in WRITE_METHODS]
    assert client_writes == [], f"{name} called a write on the FS client: {client_writes}"
    if isinstance(out, dict):   # a preview says so; it never reports that it ran
        assert out.get("executed") is not True, f"{name} reported executed without confirm: {out}"


def test_the_tripwire_itself_catches_a_write(tripwire):
    """Proof the detector works: a write made through the fake client or HTTP is seen, so a silent pass means nothing."""
    s, writes, client = tripwire
    client.post("/api/x", json={})
    assert [c[0] for c in client.method_calls if c[0].split(".")[-1] in WRITE_METHODS] == ["post"]
    with pytest.raises(AssertionError):
        requests.Session().request("DELETE", "https://pod.invalid/api")
    assert writes == ["HTTP DELETE https://pod.invalid/api"]


# The read actions the docubot approval policy allows WITHOUT asking the person (docubot src/approval/policy.ts,
# FABRIC_STUDIO_READ_ACTIONS). Each one must be a read here, or the policy is allowing a change.
DOCUBOT_READ_COMMANDS = {"FGT": "get system status", "SOAR": "df -h"}   # run: exact command text -> device type
DOCUBOT_DEVICE_READ_ACTIONS = ("status", "config")                       # device: action


def test_docubot_run_read_commands_classify_as_reads():
    from fabric_studio.mcp.rawexec import classify_command
    for vm_type, command in DOCUBOT_READ_COMMANDS.items():
        read, why = classify_command(command, vm_type)
        assert read is True, f"{command!r} on {vm_type} is not a read ({why}); docubot would allow a change"


@pytest.mark.parametrize("action", DOCUBOT_DEVICE_READ_ACTIONS)
def test_docubot_device_read_actions_write_nothing(action, tripwire, monkeypatch):
    s, writes, client = tripwire
    from fabric_studio.mcp import device as device_mod
    fn = _tool_fn(s, "device")
    try:
        out = fn(host="pod", device="fgt", fabric="f", action=action)
        if inspect.isawaitable(out):
            out = asyncio.run(out)
    except ToolError:
        out = None
    assert writes == [], f"device {action} wrote: {writes}"
    assert not (isinstance(out, dict) and out.get("executed") is True)
    assert device_mod.ACTIONS.__contains__(action)
