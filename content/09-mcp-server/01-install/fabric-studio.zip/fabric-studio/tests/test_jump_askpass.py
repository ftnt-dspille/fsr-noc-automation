"""The askpass helper the pod runs prints the password and never evaluates it."""
import subprocess

from fabric_studio.channels import jump


def test_hostile_password_is_printed_not_run(tmp_path):
    pw = "a$(touch PWNED)`id`'\"b"
    payload = jump.build_password_payload("192.0.2.1", "root", pw, "true")
    assert pw not in payload and "PWNED" not in payload
    # run only the helper-making steps, then the helper itself, in a scratch dir
    steps = payload.split("; ")
    make = "; ".join(s for s in steps if not s.startswith(("SSH_ASKPASS", "rm -f", "exit", "_rc")) and jump.JUMP_MARKER not in s)
    script = f'cd {tmp_path}; {make.replace("/tmp/", str(tmp_path) + "/")}; "$_askpass"'
    out = subprocess.run(["bash", "-c", script], capture_output=True, text=True)
    assert out.stdout.splitlines()[-1] == pw
    assert not (tmp_path / "PWNED").exists()
