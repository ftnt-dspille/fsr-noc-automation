"""Tests for backend.fabric.payload -- repo-root discovery and .conf packing."""
from __future__ import annotations

import os
import tarfile
from pathlib import Path

import pytest

from fabric_studio.topology import payload as pl

# ── repo_root ────────────────────────────────────────────────────────────────

def test_repo_root_finds_marker_from_a_deep_path(tmp_path):
    """The regression this module exists for: a fixed number of dirname() calls
    overshoots the root as soon as a caller moves one level deeper."""
    root = tmp_path / "checkout"
    (root / ".git").mkdir(parents=True)
    deep = root / "topologies" / "some_stack" / "nested"
    deep.mkdir(parents=True)
    assert pl.repo_root(str(deep)) == str(root)


def test_repo_root_accepts_a_git_less_tree(tmp_path):
    """An exported tree (release tarball, container build context) has no .git;
    devices/_base still identifies it."""
    root = tmp_path / "export"
    (root / "devices" / "_base").mkdir(parents=True)
    assert pl.repo_root(str(root / "devices")) == str(root)


def test_repo_root_raises_rather_than_guessing(tmp_path):
    """A silently wrong root is what produced the misleading 'missing payload
    dir' pointing outside the repository -- fail instead."""
    with pytest.raises(FileNotFoundError):
        pl.repo_root(str(tmp_path))




# ── collect_payload ──────────────────────────────────────────────────────────

def _make_tree(tmp_path):
    base = tmp_path / "devices" / "_base"
    (base / "setup.d").mkdir(parents=True)
    (base / "init").write_text("#!/bin/sh\nbase init\n")
    (base / "setup.d" / "10-docker-up").write_text("base docker\n")
    (base / "setup.d" / "20-run-app").write_text("base run\n")
    tool = tmp_path / "devices" / "demo" / "payload"
    (tool / "app").mkdir(parents=True)
    (tool / "app" / "compose.yaml").write_text("services: {}\n")
    return base, tool


def test_overlay_wins_on_collision(tmp_path):
    base, tool = _make_tree(tmp_path)
    (tool / "setup.d").mkdir()
    (tool / "setup.d" / "20-run-app").write_text("tool run\n")
    members = pl.collect_payload(str(base), str(tool))
    assert Path(members["fabric/setup.d/20-run-app"]) == tool / "setup.d" / "20-run-app"
    # A file the tool does NOT override still comes from the base lifecycle.
    assert Path(members["fabric/setup.d/10-docker-up"]) == base / "setup.d" / "10-docker-up"


def test_macos_metadata_never_reaches_a_guest(tmp_path):
    base, tool = _make_tree(tmp_path)
    (tool / "app" / ".DS_Store").write_text("junk")
    (tool / "app" / "._compose.yaml").write_text("resource fork")
    members = pl.collect_payload(str(base), str(tool))
    assert not any(".DS_Store" in k or "/._" in k for k in members)


# ── write_conf ───────────────────────────────────────────────────────────────

def test_conf_is_deterministic_and_sets_exec_bits(tmp_path):
    base, tool = _make_tree(tmp_path)
    members = pl.collect_payload(str(base), str(tool))
    first = tmp_path / "a.conf"
    second = tmp_path / "b.conf"
    pl.write_conf(members, str(first), quiet=True)
    pl.write_conf(members, str(second), quiet=True)
    # Byte-identical: re-running must not look like a change in git.
    assert first.read_bytes() == second.read_bytes()

    with tarfile.open(first, "r:gz") as tf:
        modes = {m.name: m.mode for m in tf.getmembers()}
        owners = {(m.uid, m.gid, m.mtime) for m in tf.getmembers()}
    assert modes["fabric/init"] == 0o755
    assert modes["fabric/setup.d/10-docker-up"] == 0o755
    assert modes["fabric/app/compose.yaml"] == 0o644
    assert owners == {(0, 0, 0)}


def test_missing_init_is_rejected(tmp_path):
    """Without fabric/init the guest has no lifecycle entrypoint, and the
    failure would otherwise surface much later as a guest that never runs."""
    with pytest.raises(SystemExit):
        pl.write_conf({"fabric/app/compose.yaml": __file__},
                      str(tmp_path / "x.conf"), quiet=True)


# ── build_confs ──────────────────────────────────────────────────────────────

def test_build_confs_reports_the_missing_tool_by_path(tmp_path):
    root = tmp_path / "checkout"
    (root / "devices" / "_base" / "setup.d").mkdir(parents=True)
    (root / "devices" / "_base" / "init").write_text("x\n")
    topo = root / "topologies" / "t"
    topo.mkdir(parents=True)
    with pytest.raises(SystemExit) as err:
        pl.build_confs(str(topo), ["nosuchtool"], quiet=True)
    assert "nosuchtool" in str(err.value)


def test_build_confs_writes_one_conf_per_tool(tmp_path):
    root = tmp_path / "checkout"
    base = root / "devices" / "_base"
    (base / "setup.d").mkdir(parents=True)
    (base / "init").write_text("#!/bin/sh\n")
    for tool in ("alpha", "beta"):
        d = root / "devices" / tool / "payload" / "app"
        d.mkdir(parents=True)
        (d / "compose.yaml").write_text(f"# {tool}\n")
    topo = root / "topologies" / "t"
    topo.mkdir(parents=True)

    written = pl.build_confs(str(topo), ["alpha", "beta"], quiet=True)

    assert set(written) == {"alpha", "beta"}
    for tool, path in written.items():
        assert os.path.isfile(path)
        with tarfile.open(path, "r:gz") as tf:
            names = tf.getnames()
        assert "fabric/init" in names
        assert "fabric/app/compose.yaml" in names


def test_inject_resolves_a_file_ref_embedded_in_a_script(tmp_path):
    """``${file:...}`` must resolve ANYWHERE in an inject value, not only when
    the whole value is one reference.

    The anchored version left an embedded reference as literal text, and nothing
    reported it: a setup script that heredocs a public key into
    ``authorized_keys`` shipped the string ``${file:...}`` as the key, so the
    guest booted with an authorized_keys file containing no key and key-only SSH
    refused every login. Live-verified on the VLAN lab."""
    from fabric_studio.topology.payload import _resolve_inject

    (tmp_path / "lab_key.pub").write_text("ssh-ed25519 AAAAKEY vlanlab\n")
    out = _resolve_inject({
        "fabric/setup.d/06-authorized-key": (
            "#!/bin/sh\ncat > /root/.ssh/authorized_keys <<'KEY'\n"
            "${file:lab_key.pub}\nKEY\nchmod 600 /root/.ssh/authorized_keys\n"),
        "whole": "${file:lab_key.pub}",
    }, str(tmp_path))
    assert "ssh-ed25519 AAAAKEY vlanlab" in out["fabric/setup.d/06-authorized-key"]
    assert "${file:" not in out["fabric/setup.d/06-authorized-key"]
    assert out["fabric/setup.d/06-authorized-key"].startswith("#!/bin/sh")
    # a value that is exactly one reference keeps the old whole-value semantics
    assert out["whole"] == "ssh-ed25519 AAAAKEY vlanlab"


def test_exclude_drops_matching_payload_members(tmp_path):
    """``exclude`` globs match the path under /fabric and keep those files out
    of the .conf. A 240 MB gitignored image bundle in a device payload timed out
    the pod's import endpoint for a node that never loads it."""
    root = tmp_path / "repo"
    (root / "devices" / "_base").mkdir(parents=True)
    (root / "devices" / "_base" / "init").write_text("#!/bin/sh\n")
    pay = root / "devices" / "dev" / "payload"
    (pay / "agent-images").mkdir(parents=True)
    (pay / "agent-images" / "big.tar.gz").write_bytes(b"x" * 64)
    (pay / "app").mkdir()
    (pay / "app" / "run.py").write_text("print(1)\n")
    out = root / "out"
    out.mkdir()

    def names(spec):
        with tarfile.open(pl.build_deviceconfig(spec, str(out))) as tf:
            return set(tf.getnames())

    full = names({"device": "dev", "base": ["init"]})
    assert any("agent-images/big.tar.gz" in n for n in full)
    kept = names({"device": "dev", "base": ["init"], "exclude": ["agent-images/*"]})
    assert not any("agent-images" in n for n in kept)
    assert any("app/run.py" in n for n in kept)
    assert any(n.endswith("init") for n in kept)


def test_a_device_name_that_climbs_out_is_refused(tmp_path):
    with pytest.raises(ValueError, match="one path segment"):
        pl.build_deviceconfig({"device": "../../etc"}, str(tmp_path))
    with pytest.raises(ValueError, match="one path segment"):
        pl.build_deviceconfig({"device": "ok"}, str(tmp_path), name="../x")


def test_an_injected_file_must_stay_under_fabric():
    for bad in ("etc/passwd", "fabric/../../x", "/abs", "fabric"):
        with pytest.raises(ValueError, match="under fabric/"):
            pl._safe_arcname(bad)
    assert pl._safe_arcname("fabric/app/branch.env") == "fabric/app/branch.env"


def test_a_file_reference_cannot_read_outside_the_workspace(tmp_path):
    outside = tmp_path / "secret.txt"
    outside.write_text("s3cret")
    root = tmp_path / "ws"
    root.mkdir()
    (root / "ok.txt").write_text("fine")
    assert pl._resolve_inject({"fabric/a": "${file:ok.txt}"}, str(root)) == {"fabric/a": "fine"}
    for ref in ("../secret.txt", str(outside)):
        with pytest.raises(ValueError, match="inside the workspace"):
            pl._resolve_inject({"fabric/a": "${file:" + ref + "}"}, str(root))


def test_a_key_is_not_generated_through_a_symlink(tmp_path):
    root = tmp_path / "ws"
    root.mkdir()
    target = tmp_path / "elsewhere"
    try:
        (root / "k").symlink_to(target)
    except OSError:
        pytest.skip("this account may not create symlinks (Windows without developer mode)")
    with pytest.raises(ValueError, match="will not generate a key"):
        pl._resolve_inject({"fabric/a": "${file:k.pub}"}, str(root))
    assert not target.exists()
