"""The apply runner must start without pyfortiflex, and a FortiFlex node must say what to install."""
import importlib
import sys

import pytest


@pytest.fixture
def no_pyfortiflex(monkeypatch):
    """pyfortiflex cannot be imported, as on an install that left the optional extra out."""
    for name in [m for m in sys.modules if m == "pyfortiflex" or m.startswith("pyfortiflex.")]:
        monkeypatch.delitem(sys.modules, name)
    monkeypatch.setitem(sys.modules, "pyfortiflex", None)
    monkeypatch.delitem(sys.modules, "fabric_studio.topology.flex", raising=False)


def test_runner_starts_without_pyfortiflex(no_pyfortiflex, monkeypatch, capsys):
    from fabric_studio.topology import run

    monkeypatch.delenv("FS_POD_USER", raising=False)
    monkeypatch.delenv("FS_POD_PASS", raising=False)
    # Past the imports and into the credentials check: it used to die on the FortiFlex import before this.
    assert run.main(["apply", "intent.yaml", "--host", "pod.example.com"]) == 2
    assert "FS_POD_USER" in capsys.readouterr().err


def test_flex_module_says_what_to_install(no_pyfortiflex):
    with pytest.raises(ImportError, match=r"fabric-studio\[flex\]"):
        importlib.import_module("fabric_studio.topology.flex")
