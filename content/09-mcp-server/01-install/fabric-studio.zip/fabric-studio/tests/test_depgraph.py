"""Dependency graph tests (Phase 5): cycle detection, topological order, DOT.

All tests are offline -- no pod. They build an ``Intent`` via ``parse_intent``
and exercise ``DependencyGraph`` directly.
"""
import pytest

from fabric_studio.topology import reconciler as rec
from fabric_studio.topology.depgraph import DependencyGraph


def _intent(nodes=None, config=None, **over):
    doc = {
        "fabric": "dep-test",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24",
                       "gateway": "198.51.100.254"}],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}],
        "nodes": nodes or [
            {"name": "host1", "type": "LXC",
             "links": [{"port": "eth0", "switch": "mgmtsw"}]},
        ],
    }
    if config:
        doc["config"] = config
    doc.update(over)
    return rec.parse_intent(doc)


def _ci(label, node="host1", depends_on=None):
    ci = {"label": label, "node": node, "commands": ["echo ok"]}
    if depends_on:
        ci["depends_on"] = depends_on
    return ci


# ── cycle detection (fires at parse time via parse_intent) ─────────────────

def test_no_cycle_single_node():
    intent = _intent()
    assert DependencyGraph(intent).detect_cycles() is None


def test_node_cycle_detected():
    with pytest.raises(ValueError, match="dependency cycle"):
        _intent(nodes=[
            {"name": "a", "type": "LXC", "depends_on": ["b"],
             "links": [{"port": "eth0", "switch": "mgmtsw"}]},
            {"name": "b", "type": "LXC", "depends_on": ["a"],
             "links": [{"port": "eth0", "switch": "mgmtsw"}]},
        ])


def test_node_cycle_in_parse_intent():
    doc = {
        "fabric": "cycle-test",
        "nodes": [
            {"name": "a", "type": "LXC", "depends_on": ["b"]},
            {"name": "b", "type": "LXC", "depends_on": ["a"]},
        ],
    }
    with pytest.raises(ValueError, match="dependency cycle"):
        rec.parse_intent(doc)


def test_provision_item_cycle_detected():
    with pytest.raises(ValueError, match="dependency cycle"):
        _intent(config=[
            _ci("enroll", depends_on=["verify"]),
            _ci("verify", depends_on=["enroll"]),
        ])


def test_cross_cycle_node_to_provision():
    """A node depends on a provision item, which targets that node -- cycle."""
    with pytest.raises(ValueError, match="dependency cycle"):
        _intent(
            nodes=[{"name": "a", "type": "LXC", "depends_on": ["setup"],
                    "links": [{"port": "eth0", "switch": "mgmtsw"}]}],
            config=[_ci("setup", node="a")],
        )


# ── unknown deps (fire at parse time via parse_intent) ─────────────────────

def test_unknown_node_dep_raises():
    with pytest.raises(ValueError, match="no such node"):
        _intent(nodes=[
            {"name": "a", "type": "LXC", "depends_on": ["ghost"],
             "links": [{"port": "eth0", "switch": "mgmtsw"}]},
        ])


def test_unknown_provision_dep_raises():
    with pytest.raises(ValueError, match="no such provision label or node"):
        _intent(config=[_ci("enroll", depends_on=["ghost"])])


# ── topological order ──────────────────────────────────────────────────────

def test_provision_order_no_deps_preserves_list_order():
    """With no explicit deps, items run in their declared list order."""
    intent = _intent(config=[
        _ci("first"), _ci("second"), _ci("third"),
    ])
    order = [c.label for c in DependencyGraph(intent).provision_order()]
    assert order == ["first", "second", "third"]


def test_provision_order_with_explicit_deps():
    """A depends_on B reorders B before A even if A is declared first."""
    intent = _intent(config=[
        _ci("a", depends_on=["b"]),
        _ci("b"),
    ])
    order = [c.label for c in DependencyGraph(intent).provision_order()]
    assert order == ["b", "a"]


def test_provision_order_chain():
    """a → b → c (a depends on b depends on c) reorders to [c, b, a]."""
    intent = _intent(config=[
        _ci("a", depends_on=["b"]),
        _ci("b", depends_on=["c"]),
        _ci("c"),
    ])
    order = [c.label for c in DependencyGraph(intent).provision_order()]
    assert order == ["c", "b", "a"]


def test_provision_order_node_dep():
    """An item implicitly depends on its target node being booted first."""
    intent = _intent(nodes=[
        {"name": "n1", "type": "LXC",
         "links": [{"port": "eth0", "switch": "mgmtsw"}]},
        {"name": "n2", "type": "LXC",
         "links": [{"port": "eth0", "switch": "mgmtsw"}]},
    ], config=[
        _ci("on-n2", node="n2"),
        _ci("on-n1", node="n1"),
    ])
    full = DependencyGraph(intent).topological_order()
    refs = [d.name for d in full]
    # n1 and n2 come before their provision items.
    assert refs.index("n1") < refs.index("on-n1")
    assert refs.index("n2") < refs.index("on-n2")


def test_provision_order_item_depends_on_node():
    """An item can depends_on a node name (cross-graph edge)."""
    intent = _intent(nodes=[
        {"name": "n1", "type": "LXC",
         "links": [{"port": "eth0", "switch": "mgmtsw"}]},
        {"name": "n2", "type": "LXC",
         "links": [{"port": "eth0", "switch": "mgmtsw"}]},
    ], config=[
        _ci("on-n1", node="n1", depends_on=["n2"]),
    ])
    full = DependencyGraph(intent).topological_order()
    refs = [d.name for d in full]
    assert refs.index("n2") < refs.index("on-n1")


def test_provision_order_excludes_nodes():
    """provision_order() returns only ConfigSpec items, not NodeSpec."""
    intent = _intent(config=[_ci("enroll")])
    order = DependencyGraph(intent).provision_order()
    assert all(isinstance(s, rec.ConfigSpec) for s in order)
    assert len(order) == 1


# ── DOT output ─────────────────────────────────────────────────────────────

def test_to_dot_basic():
    intent = _intent()
    dot = DependencyGraph(intent).to_dot()
    assert dot.startswith("digraph fabric {")
    assert dot.endswith("}")
    assert 'node:host1' in dot
    assert "shape=ellipse" in dot


def test_to_dot_with_provision_item():
    intent = _intent(config=[_ci("enroll")])
    dot = DependencyGraph(intent).to_dot()
    assert "provision:enroll" in dot
    assert "shape=box" in dot
    # Edge: node:host1 -> provision:enroll (node must be up before item runs)
    assert '"node:host1" -> "provision:enroll"' in dot


def test_to_dot_with_explicit_dep_edge():
    intent = _intent(config=[
        _ci("a", depends_on=["b"]),
        _ci("b"),
    ])
    dot = DependencyGraph(intent).to_dot()
    assert '"provision:b" -> "provision:a"' in dot
