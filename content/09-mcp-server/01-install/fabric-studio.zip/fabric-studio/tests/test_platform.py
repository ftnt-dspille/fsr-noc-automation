"""Windows and POSIX differences live in ``fabric_studio._platform``. The Windows branches are exercised here with
stand-ins, so a change that breaks them fails on any machine; CI also runs the real thing on Windows."""
from __future__ import annotations

import subprocess
import sys
import types

import pytest

from fabric_studio import _platform
from fabric_studio.mcp import _runner


def test_pid_alive_for_this_process_and_a_finished_one():
    import os
    assert _platform.pid_alive(os.getpid())
    done = subprocess.Popen([sys.executable, "-c", "pass"])
    done.wait()
    assert not _platform.pid_alive(done.pid)


@pytest.mark.parametrize("pid", [0, -1])
def test_pid_alive_rejects_nonsense(pid):
    assert not _platform.pid_alive(pid)


def test_pid_alive_never_signals_on_windows(monkeypatch):
    """os.kill(pid, 0) terminates the process on Windows: the Windows branch must not call it."""
    calls = []
    monkeypatch.setattr(_platform, "IS_WINDOWS", True)
    monkeypatch.setattr(_platform, "_pid_alive_windows", lambda pid: calls.append(pid) or True)
    monkeypatch.setattr("os.kill", lambda *a: pytest.fail("os.kill must not be used on Windows"))
    assert _platform.pid_alive(1234) and calls == [1234]


def test_detached_kwargs_per_platform(monkeypatch):
    monkeypatch.setattr(_platform, "IS_WINDOWS", False)
    assert _platform.detached_popen_kwargs() == {"start_new_session": True}
    monkeypatch.setattr(_platform, "IS_WINDOWS", True)
    assert _platform.detached_popen_kwargs() == {"creationflags": 0x8 | 0x200}


def test_posix_lock_is_exclusive(tmp_path):
    a, b = (open(tmp_path / "x.lock", "w") for _ in range(2))
    try:
        _platform.try_lock(a)
        with pytest.raises(OSError):
            _platform.try_lock(b)
        _platform.unlock(a)
        _platform.try_lock(b)
        _platform.unlock(b)
    finally:
        a.close()
        b.close()


def test_windows_lock_uses_msvcrt_from_the_start_of_the_file(monkeypatch, tmp_path):
    seen = []
    fake = types.SimpleNamespace(LK_NBLCK=2, LK_UNLCK=0,
                                 locking=lambda fd, mode, n: seen.append((mode, n)))
    monkeypatch.setattr(_platform, "IS_WINDOWS", True)
    monkeypatch.setitem(sys.modules, "msvcrt", fake)
    with open(tmp_path / "w.lock", "w") as fh:
        fh.write("xx")   # the position is not 0: the lock must still start at byte 0
        _platform.try_lock(fh)
        assert fh.tell() == 0
        _platform.unlock(fh)
    assert seen == [(2, 1), (0, 1)]


def test_runner_records_the_exit_code(tmp_path):
    rc = tmp_path / "run.rc"
    assert _runner.main([str(rc), sys.executable, "-c", "raise SystemExit(7)"]) == 7
    assert rc.read_text(encoding="utf-8").strip() == "7"


def test_runner_records_127_for_a_missing_program(tmp_path):
    rc = tmp_path / "run.rc"
    assert _runner.main([str(rc), str(tmp_path / "no-such-program")]) == 127
    assert rc.read_text(encoding="utf-8").strip() == "127"


def test_runner_output_survives_a_non_utf8_default_encoding(tmp_path):
    """The build prints 'converged ✓' into a log: with PYTHONUTF8 (set for the child) it is UTF-8 on every platform."""
    import os
    log = tmp_path / "out.log"
    env = {**os.environ, "PYTHONUTF8": "1"}
    with open(log, "wb") as fh:
        subprocess.run([sys.executable, "-c", "print('converged ✓')"], env=env, stdout=fh, check=True)
    assert "converged ✓" in log.read_text(encoding="utf-8")
