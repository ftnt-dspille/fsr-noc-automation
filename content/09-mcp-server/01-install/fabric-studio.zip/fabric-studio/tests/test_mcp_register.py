"""register: plan only the missing steps, never show the gate's login, read the manager back."""
import pytest

from fabric_studio.mcp import fortios as f
from fabric_studio.mcp import register as rg


def _t(name, password="gate-pw"):
    return f.Target(host="pod.example.com", name=name, fabric="lab", https_port=13000, ssh_port=11000,
                    user="admin", password=password)


@pytest.fixture
def lab(monkeypatch):
    s = {"rows": [], "pointed": False, "allow_vm": False, "rpc_ok": True, "cli": [], "rpc": []}
    g, m = _t("fgt1"), _t("fmg", password="mgr-pw")

    def resolve(host, device, fabric, types=None, need=()):
        if device == "fgt1":
            return g, {"name": "fgt1", "fabric": "lab", "vm_type": "FGT", "fabric_id": 1, "id": 10}
        return m, {"name": "fmg", "fabric": "lab", "vm_type": "FMG", "fabric_id": 1, "id": 11}

    def ssh(t, script, timeout):
        s["cli"].append((t.name, script))
        if script == "get system status":
            return {"output": "Version: FortiGate-VM64 v7.6.6\nSerial-Number: FGVM000001\n"}
        if script.startswith("show system central-management"):
            return {"output": 'set type fortimanager\nset fmg "10.0.0.40"' if s["pointed"] else "set type none"}
        if script == "show system global":
            return {"output": "set fgfm-allow-vm enable" if s["allow_vm"] else "set hostname fmg"}
        if "central-management" in script:
            s["pointed"] = True
            s["rows"] = [{"name": "FGVM000001", "sn": "FGVM000001", "mgmt_mode": 0}]
        if "fgfm-allow-vm" in script:
            s["allow_vm"] = True
        return {"output": ""}

    def rpc(t, verb, url, body=None):
        s["rpc"].append((verb, url, body))
        if not s["rpc_ok"]:
            raise f.DeviceError("refused the JSON-RPC login (code -11)")
        if url.endswith("/device") and verb == "get":
            return {"status": 0, "message": "OK", "data": s["rows"]}
        if url == "/dvm/cmd/add/device":
            s["rows"] = [{**s["rows"][0], "mgmt_mode": 3, "conn_status": 1}]
            return {"status": 0, "message": "OK", "data": {"taskid": 7}}
        if url.startswith("/task/task/"):
            return {"status": 0, "message": "OK", "data": {"state": 4}}
        return {"status": 0, "message": "OK", "data": None}

    monkeypatch.setattr(rg.dev, "resolve", resolve)
    monkeypatch.setattr(rg, "_mgmt_ip", lambda host, row: "10.0.0.40")
    monkeypatch.setattr(rg.rx, "_ssh_fortios", ssh)
    monkeypatch.setattr(rg.rx, "_jsonrpc", rpc)
    monkeypatch.setattr(rg, "_refuse_if_locked", lambda h: None)
    monkeypatch.setattr(rg.time, "sleep", lambda s: None)
    return s


def call(**kw):
    return rg.register.__wrapped__(host="pod", gate="fgt1", manager="fmg", fabric="lab", **kw)


def test_plan_lists_only_missing_steps_and_changes_nothing(lab):
    out = call()
    assert out["dry_run"] and len(out["steps"]) == 3
    assert not any("set " in script for _, script in lab["cli"])   # reads only


def test_apply_points_waits_authorizes_and_verifies(lab):
    out = call(confirm=True)
    assert out["verified"] and out["done"] == ["fgfm-allow-vm", "gate pointed at manager", "authorized"]
    add = next(b for v, u, b in lab["rpc"] if u == "/dvm/cmd/add/device")
    assert add["data"]["device"]["adm_pass"] == "gate-pw"   # the gate's login goes to the manager...
    assert "gate-pw" not in str(out)                          # ...and never into the result


def test_already_managed_is_a_noop(lab):
    lab["rows"] = [{"name": "fgt1", "sn": "FGVM000001", "mgmt_mode": 3}]
    out = call(confirm=True)
    assert out["noop"] and out["executed"] is False and lab["rpc"][-1][0] == "get"


def test_rpc_not_permitted_is_planned_first(lab):
    lab["rpc_ok"] = False
    out = call()
    assert out["steps"][0].startswith("fmg: allow JSON-RPC")


def test_bad_adom_is_refused(lab):
    with pytest.raises(Exception, match="ADOM name"):
        call(adom="root; rm")
