"""Topology reconciler -- offline unit tests (intent parsing + diff logic).

No pod needed: ``plan``/``apply`` are exercised against a fake provider that
serves a canned ``read_fabric_state`` graph, so the diff (create/update/noop/
delete) is validated without touching Fabric Studio. The live apply-test lives
in the apply-test section of docs/reference/FS_TOPOLOGY_FRAMEWORK.md (needs an exclusive pod).
"""
import os

import pytest

from fabric_studio.topology import reconciler as rec

# Not a real config in anyone's account -- if it ever reaches the live API the
# error names it, which is a faster diagnosis than a plausible-looking id.
_FAKE_FLEX_CONFIG_ID = 99999


@pytest.fixture(autouse=True)
def _no_live_fortiflex(monkeypatch, _isolated_data_dir):
    """Keep this file offline, as its docstring promises.

    `_ensure_license` on an AUTO node with no explicit flex_config calls
    `flex.autodetect_config_for_vm_type`, which AUTHENTICATES TO FORTIFLEX and
    lists the account's real configs. Three tests here did exactly that, so
    their result depended on somebody's live FortiFlex inventory: they went red
    the day the account grew a seventh ACTIVE FortiGate-* config and autodetect
    started (correctly) refusing to guess. A unit test must not have an opinion
    about that account.

    Depends on `_isolated_data_dir` EXPLICITLY so ordering is guaranteed rather
    than assumed -- that conftest fixture must have finished purging before this
    one imports, and autouse-vs-autouse ordering is not something to rely on.

    IMPORT THE MODULE HERE, not at file scope. `tests/conftest.py`'s
    `_isolated_data_dir` deletes every `backend.*` entry from `sys.modules`
    before each test, so a module object bound when this FILE was imported is a
    stale object that nothing under test will ever look at again: patching it
    silently does nothing, and the live API call goes out anyway. Importing
    inside the fixture -- which runs after that purge -- gets the module the
    code under test will actually import.

    Tests that want autodetect's own behaviour monkeypatch over this stub --
    and the real thing is covered offline in test_fabric_flex.py.
    """
    from fabric_studio.topology import flex

    monkeypatch.setattr(flex, "autodetect_config_for_vm_type",
                        lambda vm_type, **kw: _FAKE_FLEX_CONFIG_ID)
    # Everything else on the FortiFlex leg of `_ensure_license` is live too:
    # `resolve_config_id` re-lists the account, and `assert_config_matches_vm_type`
    # looks the id up in it. Stubbing only the first one moves the live call one
    # line down rather than removing it.
    monkeypatch.setattr(flex, "resolve_config_id", lambda ref, **kw: int(ref))
    monkeypatch.setattr(flex, "assert_config_matches_vm_type",
                        lambda cid, vm_type: None)
    monkeypatch.setattr(rec.fa, "set_flex_pool", lambda c, vm_type, cid: None)
    # An empty pod pool: AUTO falls through to autodetect (stubbed above).
    monkeypatch.setattr(rec.fa, "list_flex_pool", lambda c: [])

# ── Intent parsing ───────────────────────────────────────────────────────────

def test_parse_intent_minimal():
    intent = rec.parse_intent({
        "fabric": "topo-test",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24", "gateway": "198.51.100.254"}],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}],
        "nodes": [{"name": "h1", "type": "LXC", "firmware": 865,
                   "links": [{"port": "eth0", "switch": "mgmtsw"}]}],
    })
    assert intent.fabric == "topo-test"
    assert intent.networks[0].ipv4network == "198.51.100.0"
    assert intent.networks[0].ipv4netmask == "255.255.255.0"
    assert intent.switches[0].auto_address == "mgmt"
    assert intent.nodes[0].links[0].switch == "mgmtsw"


def test_parse_intent_link_dhcp_field():
    intent = rec.parse_intent({
        "fabric": "f",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "s", "auto_address": "mgmt"}],
        "nodes": [{"name": "n", "type": "BASIC", "firmware": 1,
                   "links": [{"port": "eth0", "switch": "s", "dhcp": "System Host"}]}],
    })
    assert intent.nodes[0].links[0].dhcp == "System Host"


def test_parse_intent_node_uuid_valid_absent_invalid():
    """A node's optional ``uuid`` pins the SMBIOS UUID: canonical hex parses,
    omission is None, and a malformed value is rejected at parse time."""
    base = {
        "fabric": "f",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "s", "auto_address": "mgmt"}],
    }
    ok = rec.parse_intent({**base, "nodes": [
        {"name": "n", "type": "BASIC", "firmware": 1,
         "uuid": "464F5254-4950-44F4-833F-56070DA0A5FA",
         "links": [{"port": "eth0", "switch": "s"}]}]})
    assert ok.nodes[0].uuid == "464F5254-4950-44F4-833F-56070DA0A5FA"

    absent = rec.parse_intent({**base, "nodes": [
        {"name": "n", "type": "BASIC", "firmware": 1,
         "links": [{"port": "eth0", "switch": "s"}]}]})
    assert absent.nodes[0].uuid is None

    with pytest.raises(ValueError, match="uuid must be canonical"):
        rec.parse_intent({**base, "nodes": [
            {"name": "n", "type": "BASIC", "firmware": 1, "uuid": "nope",
             "links": [{"port": "eth0", "switch": "s"}]}]})


def test_parse_intent_expose_normalizes():
    """expose: accepts a bare int and a {port, from_port, proto, name} dict;
    both normalize to {from_port, to_port, socktype, name}."""
    intent = rec.parse_intent({
        "fabric": "f",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "s", "auto_address": "mgmt"}],
        "nodes": [{"name": "n", "type": "LXC", "firmware": 1,
                   "links": [{"port": "eth0", "switch": "s"}],
                   "expose": [8080,
                              {"port": 22, "from_port": 9122, "name": "ssh"},
                              {"port": 53, "proto": "udp"}]}],
    })
    ex = intent.nodes[0].expose
    assert ex[0] == {"from_port": 8080, "to_port": 8080, "socktype": "TCP", "name": None}
    assert ex[1] == {"from_port": 9122, "to_port": 22, "socktype": "TCP", "name": "ssh"}
    assert ex[2] == {"from_port": 53, "to_port": 53, "socktype": "UDP", "name": None}


def test_parse_intent_expose_rejects_bad_proto():
    import pytest
    with pytest.raises(ValueError):
        rec.parse_intent({
            "fabric": "f",
            "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
            "switches": [{"name": "s", "auto_address": "mgmt"}],
            "nodes": [{"name": "n", "type": "LXC", "firmware": 1,
                       "links": [{"port": "eth0", "switch": "s"}],
                       "expose": [{"port": 8080, "proto": "sctp"}]}],
        })


def _cfg_intent(**ci):
    """Minimal one-node intent carrying a single config item."""
    item = {"node": "n", **ci}
    return {
        "fabric": "f",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "s", "auto_address": "mgmt"}],
        "nodes": [{"name": "n", "type": "LXC", "firmware": 1,
                   "links": [{"port": "eth0", "switch": "s"}]}],
        "config": [item],
    }


def _p(posix_path):
    """A POSIX-style expected path in this platform's spelling (resolved paths use os.sep)."""
    return os.path.normpath(posix_path)


def test_parse_intent_resolves_relative_config_paths_against_base_dir():
    intent = rec.parse_intent(
        _cfg_intent(script="setup.sh", ssh_key="keys/id", commands=None),
        base_dir="/intents/demo")
    # exactly-one-action lint: a script item can't also carry commands.
    spec = intent.config[0]
    assert spec.script == _p("/intents/demo/setup.sh")
    assert spec.ssh_key == _p("/intents/demo/keys/id")


def test_parse_intent_resolves_repository_paths_from_repo_root():
    intent = rec.parse_intent(
        _cfg_intent(script="topologies/windows_builder/build.sh"),
        base_dir="/intents/demo")
    assert intent.config[0].script.endswith(_p("/topologies/windows_builder/build.sh"))


def test_parse_intent_supports_explicit_intent_relative_paths():
    intent = rec.parse_intent(
        _cfg_intent(script="intent://setup.sh"), base_dir="/intents/demo")
    assert intent.config[0].script == _p("/intents/demo/setup.sh")


def test_parse_intent_resolves_relative_playbook_and_upload_and_detached():
    doc = _cfg_intent(playbook="plays/seed.yml")
    intent = rec.parse_intent(doc, base_dir="/intents/demo")
    assert intent.config[0].playbook == _p("/intents/demo/plays/seed.yml")

    up = rec.parse_intent(
        _cfg_intent(upload={"src": "files/a.txt", "dest": "/tmp/a.txt"}),
        base_dir="/intents/demo")
    assert up.config[0].upload["src"] == _p("/intents/demo/files/a.txt")

    det = rec.parse_intent(
        _cfg_intent(detached={"script": "build.sh", "sentinel": "/tmp/done"}),
        base_dir="/intents/demo")
    assert det.config[0].detached["script"] == _p("/intents/demo/build.sh")


def test_parse_intent_leaves_absolute_paths_and_no_base_dir_untouched():
    # Absolute path passes through even with a base_dir.
    absolute = os.path.abspath(_p("/opt/x/setup.sh"))   # "/opt/..." is only absolute on POSIX; C:\\opt\\... on Windows
    abs_intent = rec.parse_intent(
        _cfg_intent(script=absolute), base_dir="/intents/demo")
    assert abs_intent.config[0].script == absolute
    # No base_dir → relative path preserved (only ~ expansion happens).
    rel_intent = rec.parse_intent(_cfg_intent(script="setup.sh"))
    assert rel_intent.config[0].script == "setup.sh"


def test_parse_intent_resolves_config_defaults_ssh_key():
    doc = _cfg_intent(commands="echo hi")
    doc["config_defaults"] = {"ssh_key": "keys/shared", "ssh_user": "root"}
    intent = rec.parse_intent(doc, base_dir="/intents/demo")
    assert intent.config_defaults["ssh_key"] == _p("/intents/demo/keys/shared")
    assert intent.config_defaults["ssh_user"] == "root"


# ── T5: input variables + overlays ───────────────────────────────────────────

def _var_intent(**extra):
    doc = {
        "fabric": "f",
        "variables": {
            "cidr": {"default": "198.51.100.0/24", "type": "string"},
            "cpu": {"default": 2, "type": "number"},
        },
        "networks": [{"name": "mgmt", "cidr": "${var.cidr}"}],
        "switches": [{"name": "s", "auto_address": "mgmt"}],
        "nodes": [{"name": "n", "type": "LXC", "firmware": 1, "cpu": "${var.cpu}",
                   "links": [{"port": "eth0", "switch": "s"}]}],
    }
    doc.update(extra)
    return doc


def test_variables_default_substitution_and_type_preserved():
    doc = _var_intent()
    vals = rec.resolve_variables(doc)
    intent = rec.parse_intent(rec.substitute_variables(doc, vals))
    assert intent.networks[0].cidr == "198.51.100.0/24"
    # a string that is *exactly* one ${var.X} keeps the var's native type.
    assert intent.nodes[0].cpu == 2 and isinstance(intent.nodes[0].cpu, int)


def test_variables_bare_scalar_shorthand_is_the_default():
    doc = _var_intent(variables={"cidr": "203.0.113.0/24", "cpu": 4})
    vals = rec.resolve_variables(doc)
    assert vals == {"cidr": "203.0.113.0/24", "cpu": 4}


def test_variable_override_precedence_and_coercion():
    doc = _var_intent()
    vals = rec.resolve_variables(doc, var_overrides=("cidr=203.0.113.0/24", "cpu=8"))
    assert vals["cidr"] == "203.0.113.0/24"
    assert vals["cpu"] == 8 and isinstance(vals["cpu"], int)  # number coercion


def test_required_variable_with_no_value_errors():
    doc = _var_intent(variables={"pod_id": {"required": True}})
    with pytest.raises(ValueError, match="pod_id"):
        rec.resolve_variables(doc)


def test_optional_unset_variable_is_allowed():
    doc = {"fabric": "f", "variables": {"opt": {"required": False}}}
    assert rec.resolve_variables(doc) == {}


def test_override_of_undeclared_variable_errors():
    doc = _var_intent()
    with pytest.raises(ValueError, match="not declared"):
        rec.resolve_variables(doc, var_overrides=("ghost=1",))


def test_reference_to_undeclared_variable_errors():
    doc = {"fabric": "f", "networks": [{"name": "m", "cidr": "${var.nope}"}]}
    # no variables: block, yet a ${var.X} ref -- substitute_variables with empty
    # values must reject the dangling reference.
    with pytest.raises(ValueError, match="nope"):
        rec.substitute_variables(doc, {})


def test_var_without_variables_block_errors():
    doc = {"fabric": "f"}
    with pytest.raises(ValueError, match="no variables: block"):
        rec.resolve_variables(doc, var_overrides=("x=1",))


def test_varfile_and_pod_overlay_precedence(tmp_path):
    intent = tmp_path / "intent.yaml"
    intent.write_text(
        "fabric: f\n"
        "variables:\n  who: {default: base}\n"
        "networks: [{name: mgmt, cidr: 198.51.100.0/24}]\n"
        "switches: [{name: s, auto_address: mgmt}]\n"
        "nodes: [{name: \"n-${var.who}\", type: LXC, firmware: 1,"
        " links: [{port: eth0, switch: s}]}]\n")
    (tmp_path / "defaults.fabricvars").write_text("who: defaults\n")
    (tmp_path / "10.0.0.9.fabricvars").write_text("who: podspecific\n")

    assert rec.load_intent(str(intent)).nodes[0].name == "n-defaults"
    assert rec.load_intent(str(intent), pod_host="10.0.0.9").nodes[0].name == "n-podspecific"
    assert rec.load_intent(str(intent), pod_host="10.0.0.9",
                           var_overrides=("who=cli",)).nodes[0].name == "n-cli"


def test_invalid_number_variable_errors():
    doc = _var_intent()
    with pytest.raises(ValueError, match="not a valid number"):
        rec.resolve_variables(doc, var_overrides=("cpu=notanumber",))


def test_resolve_firmware_id_matches_name_or_path_basename(monkeypatch):
    """image: resolves against the home-repo firmware NAME (uploaded artifacts)
    OR the firmware filename = basename(path) (built-in appliance firmwares have
    no name). Mirrors what export emits."""
    # Patch through rec.fa (the exact module object the resolver calls) -- under
    # pytest the bare ``fabric_studio.admin`` import can resolve to a separate
    # module instance, so patching that wouldn't take.
    monkeypatch.setattr(rec.fa, "list_home_firmwares", lambda c: [
        {"id": 999, "name": "rocky9-base.qcow2", "path": "firmwares/rocky9-base.qcow2",
         "size": 1048576},
        {"id": 1134, "name": None,
         "path": "firmwares/FGT_VM64_KVM-v7.6.5.M-build3651-FORTINET.out.kvm.zip",
         "size": 2097152},
    ])
    by_name = rec.NodeSpec(name="h", type="BASIC", image="rocky9-base.qcow2")
    by_path = rec.NodeSpec(name="fgt", type="FGT",
                           image="FGT_VM64_KVM-v7.6.5.M-build3651-FORTINET.out.kvm.zip")
    assert rec._resolve_firmware_id(object(), by_name) == 999
    assert rec._resolve_firmware_id(object(), by_path) == 1134


def test_ensure_port_redirect_creates_when_absent(monkeypatch):
    from fabric_studio import admin as fs_admin
    posts = []
    monkeypatch.setattr(fs_admin, "list_port_redirects", lambda c, fid: [])

    class _C:
        def request(self, method, path, json_data=None, headers=None):
            posts.append((method, path, json_data["object"]))
            return {"object": {"id": 9}}
    monkeypatch.setattr(fs_admin, "_check", lambda resp, label: resp)
    changed = fs_admin.ensure_port_redirect(_C(), 6, device=31, name="app",
                                            from_port=8080, to_addr="10.254.254.10",
                                            to_port=8080)
    assert changed is True
    assert posts[0][0] == "POST"
    # HOST-scoped route, with the host in the path. The fabric-scoped route
    # 400s the same body with `object.cast.device: readonly_fields` -- device is
    # derived from the path there, so sending it fails the cast and the create
    # reports "Unable to deserialize: model.portredirect", which reads as a
    # malformed rule rather than as one field too many. Live-verified.
    assert posts[0][1] == "api/v1/model/host/31/port/redirect"
    assert "device" not in posts[0][2]
    assert posts[0][2]["from_port"] == 8080 and posts[0][2]["to_addr"] == "10.254.254.10"
    assert posts[0][2]["socktype"] == "TCP" and posts[0][2]["snat"] is True


def test_ensure_port_redirect_noop_when_target_matches(monkeypatch):
    from fabric_studio import admin as fs_admin
    existing = [{"id": 3, "from_port": 8080, "socktype": "TCP",
                 "to_addr": "10.254.254.10", "to_port": 8080}]
    monkeypatch.setattr(fs_admin, "list_port_redirects", lambda c, fid: existing)

    class _C:
        def request(self, *a, **k):
            raise AssertionError("should not PATCH/POST on an exact match")
    monkeypatch.setattr(fs_admin, "_check", lambda resp, label: resp)
    assert fs_admin.ensure_port_redirect(_C(), 6, device=31, name="app",
                                         from_port=8080, to_addr="10.254.254.10",
                                         to_port=8080) is False


def test_ensure_port_redirect_patches_changed_target(monkeypatch):
    from fabric_studio import admin as fs_admin
    existing = [{"id": 3, "from_port": 8080, "socktype": "TCP",
                 "to_addr": "10.0.0.9", "to_port": 8080}]
    monkeypatch.setattr(fs_admin, "list_port_redirects", lambda c, fid: existing)
    calls = []

    class _C:
        def request(self, method, path, json_data=None, headers=None):
            calls.append((method, path, json_data["object"]))
            return {"object": {}}
    monkeypatch.setattr(fs_admin, "_check", lambda resp, label: resp)
    assert fs_admin.ensure_port_redirect(_C(), 6, device=31, name="app",
                                         from_port=8080, to_addr="10.254.254.10",
                                         to_port=8080) is True
    assert calls[0][0] == "PATCH"
    assert calls[0][1].endswith("/host/port/redirect/3")
    assert calls[0][2]["to_addr"] == "10.254.254.10"


def test_ensure_public_forwards_allowed_flips_only_missing(monkeypatch):
    from fabric_studio import admin as fs_admin
    monkeypatch.setattr(fs_admin, "get_security_preferences",
                        lambda c: {"custom_rules_allowed": "no", "ssh_public_allowed": "yes"})
    sent = {}
    monkeypatch.setattr(fs_admin, "set_security_preferences",
                        lambda c, **prefs: sent.update(prefs) or {})
    changed = fs_admin.ensure_public_forwards_allowed(
        None, ("custom_rules_allowed", "ssh_public_allowed"))
    assert changed == ["custom_rules_allowed"]
    assert sent == {"custom_rules_allowed": "yes"}


def test_apply_dhcp_link_patches_addrmode_and_dhcp_server(monkeypatch):
    """A link with ``dhcp: System Host`` resolves the System Host id and PATCHes
    the port to static DHCP (addrmode forced to DHCP + dhcp_server)."""
    calls = []
    fid = 6
    monkeypatch.setattr(rec.fa, "wait_pod_idle", lambda c: None)
    from fabric_studio.topology import images
    monkeypatch.setattr(images, "ensure_images", lambda c, intent, say: {})
    monkeypatch.setattr(rec.fa, "ensure_fabric", lambda c, name, desc=None: {"id": fid})
    monkeypatch.setattr(rec.fa, "ensure_network",
                        lambda c, fid, *a, **k: {"id": 23, "ipv4network": "198.51.100.0",
                                                 "ipv4netmask": "255.255.255.0",
                                                 "ipv4gateway": None})
    monkeypatch.setattr(rec, "_cidr_of", lambda row: "198.51.100.0/24")
    monkeypatch.setattr(rec.fa, "ensure_switch",
                        lambda c, fid, name, aa, mgmt: {"id": 85,
                                                        "auto_address_network": aa, "mgmt": mgmt})
    monkeypatch.setattr(rec.fa, "get_vm_by_name",
                        lambda c, fid, name: {"id": 86, "firmware": 1})
    monkeypatch.setattr(rec, "_resolve_firmware_id",
                        lambda c, nd, image_ids=None, declared_images=None: 1)
    monkeypatch.setattr(rec, "_apply_node_resources", lambda *a, **k: False)
    monkeypatch.setattr(rec, "_ensure_provision_config", lambda *a, **k: False)
    monkeypatch.setattr(rec.fa, "read_fabric_state",
                        lambda c, fid: {"links": [{"vm_id": 86, "vm_port_name": "eth0",
                                                   "switch_id": 85}]})
    monkeypatch.setattr(rec.fa, "get_vm_ports",
                        lambda c, fid, vid: [{"id": 938, "name": "eth0",
                                              "ipv4addr": "10.254.254.2",
                                              "ipv4netmask": "255.255.255.0"}])
    monkeypatch.setattr(rec.fa, "get_system_host", lambda c, fid: {"id": 64})
    monkeypatch.setattr(rec.fa, "get_vm_install_after", lambda c, vid: [])
    monkeypatch.setattr(rec.fa, "set_vm_install_after", lambda c, vid, after: None)

    def _spy(c, fid, vid, pid, ip, mask=None, addrmode="STA", dhcp_server=None, network=None):
        calls.append({"ip": ip, "mask": mask, "addrmode": addrmode,
                      "dhcp_server": dhcp_server, "network": network})
    monkeypatch.setattr(rec.fa, "set_port_ipv4", _spy)
    monkeypatch.setattr(rec, "assert_converged", lambda *a, **k: {})

    intent = rec.parse_intent({
        "fabric": "topo-test",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}],
        "nodes": [{"name": "b1", "type": "BASIC", "firmware": 1,
                   "links": [{"port": "eth0", "switch": "mgmtsw", "dhcp": "System Host"}]}],
    })
    rec.apply(FakeClient(), intent, boot=False)
    # The port's FS-default address (10.254.254.2) is OUTSIDE the link's subnet
    # (198.51.100.0/24), so the reconciler reallocates a real in-subnet host
    # (first free = .1) -- leasing an out-of-subnet addr would yield no DHCP
    # reservation. set_port_ipv4 itself forces addrmode=DHCP from dhcp_server.
    assert len(calls) == 1
    assert calls[0]["ip"] == "198.51.100.1"
    assert calls[0]["mask"] == "255.255.255.0"
    assert calls[0]["dhcp_server"] == 64
    # network resolves to the switch's auto_address net (mgmt → id 23) so the
    # native DHCP actually serves the lease.
    assert calls[0]["network"] == 23


def test_set_port_ipv4_dhcp_server_forces_dhcp_addrmode(monkeypatch):
    """fs_admin.set_port_ipv4 with a dhcp_server forces addrmode=DHCP and adds
    dhcp_server to the PATCH body (the live-validated static-DHCP shape)."""
    from fabric_studio import admin as fs_admin
    captured = {}

    class _C:
        def request(self, method, path, json_data=None, headers=None):
            captured["method"] = method
            captured["path"] = path
            captured["obj"] = json_data["object"]
            return {"object": {}}
    monkeypatch.setattr(fs_admin, "_check", lambda resp, label: resp)
    fs_admin.set_port_ipv4(_C(), 6, 123, 938, "10.254.254.2",
                           "255.255.255.0", addrmode="STA", dhcp_server=64)
    assert captured["obj"]["addrmode"] == "DHCP"
    assert captured["obj"]["dhcp_server"] == 64
    assert captured["obj"]["ipv4addr"] == "10.254.254.2"


def test_ensure_public_access_creates_missing_entry(monkeypatch):
    """A freshly-uploaded BASIC qcow has no SSH access entry to flip, so
    ensure_public_access CREATES one (model-level, no .meta edit / repo refresh)."""
    from fabric_studio import admin as fs_admin
    posts = []
    monkeypatch.setattr(fs_admin, "list_vm_accesses",
                        lambda c, fid, vid: [{"id": 1, "type": "VNC", "mode": "PRIVATE"}])

    class _C:
        def request(self, method, path, json_data=None, headers=None):
            posts.append((method, path, json_data["object"]))
            return {"object": {"id": 9}}
    monkeypatch.setattr(fs_admin, "_check", lambda resp, label: resp)
    changed = fs_admin.ensure_public_access(_C(), 6, 123, types=("SSH",))
    assert changed == ["SSH"]
    assert posts == [("POST", "api/v1/model/fabric/6/vm/123/access",
                      {"type": "SSH", "mode": "PUBLIC", "name": "SSH", "dport": 22})]


def test_ensure_public_access_flips_existing_entry(monkeypatch):
    """When the access entry already exists but is PRIVATE, flip it (PATCH) rather
    than create a duplicate."""
    from fabric_studio import admin as fs_admin
    calls = []
    monkeypatch.setattr(fs_admin, "list_vm_accesses",
                        lambda c, fid, vid: [{"id": 5, "type": "SSH", "mode": "PRIVATE", "dport": 22}])

    class _C:
        def request(self, method, path, json_data=None, headers=None):
            calls.append((method, path, json_data["object"] if json_data else None))
            return {"object": {}}
    monkeypatch.setattr(fs_admin, "_check", lambda resp, label: resp)
    changed = fs_admin.ensure_public_access(_C(), 6, 123, types=("SSH",))
    assert changed == ["SSH"]
    assert calls == [("PATCH", "api/v1/model/fabric/6/vm/123/access/5", {"mode": "PUBLIC"})]


def test_ensure_public_access_repairs_stub_dport(monkeypatch):
    """An existing PUBLIC access with a falsy dport (e.g. an RDP stub at dport 0)
    gets deleted + recreated at the type's default dport, so FS allocates a
    forward. A working forward (nonzero dport) is left untouched."""
    from fabric_studio import admin as fs_admin
    calls = []
    monkeypatch.setattr(fs_admin, "list_vm_accesses",
                        lambda c, fid, vid: [{"id": 9, "type": "RDP", "mode": "PUBLIC", "dport": 0}])

    class _C:
        def request(self, method, path, json_data=None, headers=None):
            calls.append((method, path, json_data["object"] if json_data else None))
            return {"object": {}}
    monkeypatch.setattr(fs_admin, "_check", lambda resp, label: resp)
    changed = fs_admin.ensure_public_access(_C(), 6, 123, types=("RDP",))
    assert changed == ["RDP"]
    # delete the stub, then recreate at dport 3389
    assert calls[0] == ("DELETE", "api/v1/model/fabric/6/vm/123/access/9", None)
    assert calls[1][0] == "POST" and calls[1][2]["dport"] == 3389


def test_parse_intent_requires_fabric():
    with pytest.raises(ValueError):
        rec.parse_intent({"networks": []})


def test_parse_intent_rejects_switch_on_undeclared_network():
    with pytest.raises(ValueError):
        rec.parse_intent({"fabric": "f", "switches": [{"name": "s", "auto_address": "ghost"}]})


def test_parse_intent_rejects_link_to_undeclared_switch():
    with pytest.raises(ValueError):
        rec.parse_intent({"fabric": "f",
                          "nodes": [{"name": "n", "links": [{"port": "p", "switch": "ghost"}]}]})


def test_norm_cidr_matches_quad_dotted_and_prefix():
    assert rec._norm_cidr("198.51.100.0", "255.255.255.0") == "198.51.100.0/24"
    assert rec._norm_intent_cidr("198.51.100.0/24") == "198.51.100.0/24"


# ── Diff logic against a fake provider ───────────────────────────────────────

class FakeClient:
    pass


@pytest.fixture
def fake_state(monkeypatch):
    """Install a canned read_fabric_state + fabric lookup so plan() can diff
    without a pod. The graph: fabric exists, has network 'mgmt' (correct cidr),
    switch 'mgmtsw' auto-addressing it, and one node 'h1' cabled eth0→mgmtsw.
    A second node 'h2' from the intent is absent (→ create)."""
    state = {
        "fabric": {"id": 6, "name": "topo-test"},
        "networks": [{"id": 23, "name": "mgmt", "ipv4network": "198.51.100.0",
                      "ipv4netmask": "255.255.255.0", "ipv4gateway": "198.51.100.254"}],
        "switches": [{"id": 85, "name": "mgmtsw", "auto_address_network": 23,
                      "mgmt": True, "vm_type": "SW", "host_uplinked": True, "ports": []}],
        "vms": [{"id": 86, "name": "h1", "vm_type": "LXC", "firmware": 865, "ports": []}],
        "cables": [],
        "ports_by_id": {}, "device_by_port": {},
        "links": [{"vm_id": 86, "vm_port": 1, "vm_port_name": "eth0",
                   "switch_id": 85, "switch_port": 2, "cable_id": 9}],
    }
    monkeypatch.setattr(rec.fa, "get_fabric_by_name",
                        lambda c, name: state["fabric"] if name == "topo-test" else None)
    monkeypatch.setattr(rec.fa, "read_fabric_state", lambda c, fid: state)
    monkeypatch.setattr(rec.fa, "runtime_vms", lambda c, fid: [])
    monkeypatch.setattr(rec.fa, "devices_needing_dhcp_install", lambda c, fid: [])
    monkeypatch.setattr(rec, "_resolve_firmware_id",
                        lambda c, nd, image_ids=None, declared_images=None: nd.firmware)
    monkeypatch.setattr(rec.fa, "list_home_firmwares", lambda c, vm_type=None: [])
    monkeypatch.setattr(rec.fa, "get_vm_install_after", lambda c, vid: [])
    monkeypatch.setattr(rec.fa, "set_vm_install_after", lambda c, vid, after: None)
    return state


def _intent_two_nodes():
    return rec.parse_intent({
        "fabric": "topo-test",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24", "gateway": "198.51.100.254"}],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}],
        "nodes": [
            {"name": "h1", "type": "LXC", "firmware": 865,
             "links": [{"port": "eth0", "switch": "mgmtsw"}]},
            {"name": "h2", "type": "LXC", "firmware": 865,
             "links": [{"port": "eth0", "switch": "mgmtsw"}]},
        ],
    })


def test_plan_diff_creates_only_missing_node(fake_state):
    plan = rec.plan(FakeClient(), _intent_two_nodes())
    kinds = {(c.op, c.kind, c.name) for c in plan.changes}
    # mgmt network + mgmtsw switch + h1 + its link already exist → noop.
    assert ("noop", "network", "mgmt") in kinds
    assert ("noop", "switch", "mgmtsw") in kinds
    assert ("noop", "node", "h1") in kinds
    assert ("noop", "link", "h1.eth0→mgmtsw") in kinds
    # h2 and its link are new.
    assert ("create", "node", "h2") in kinds
    assert ("create", "link", "h2.eth0→mgmtsw") in kinds


def test_plan_detects_switch_rewire(fake_state):
    intent = rec.parse_intent({
        "fabric": "topo-test",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24", "gateway": "198.51.100.254"},
                     {"name": "lan", "cidr": "203.0.113.0/24", "gateway": "203.0.113.1"}],
        "switches": [{"name": "mgmtsw", "auto_address": "lan"}],   # was mgmt(23) → rewire
    })
    plan = rec.plan(FakeClient(), intent)
    rewire = [c for c in plan.changes if c.kind == "switch" and c.op == "update"]
    assert rewire and "lan" in rewire[0].detail
    # lan network is new.
    assert any(c.op == "create" and c.kind == "network" and c.name == "lan"
               for c in plan.changes)


def test_plan_detects_dns_drift(fake_state):
    """plan() must surface dns1/dns2 drift -- apply() PATCHes it, so a noop plan
    that hides a DNS mismatch would let apply silently mutate (and a FortiFlex
    guest needs dns1 to resolve FortiCare for activation)."""
    intent = rec.parse_intent({
        "fabric": "topo-test",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24",
                      "gateway": "198.51.100.254", "dns1": "8.8.8.8"}],
    })
    plan = rec.plan(FakeClient(), intent)
    net_changes = [c for c in plan.changes if c.kind == "network" and c.name == "mgmt"]
    assert net_changes and net_changes[0].op == "update"


def test_plan_prune_flags_undeclared(fake_state):
    intent = rec.parse_intent({"fabric": "topo-test"})  # declares nothing
    plan = rec.plan(FakeClient(), intent, prune=True)
    deletes = {(c.kind, c.name) for c in plan.changes if c.op == "delete"}
    assert ("switch", "mgmtsw") in deletes
    assert ("node", "h1") in deletes
    # The fixture's network is literally named "mgmt", which is an FS-seeded
    # shared NETWORK name -- `_prune` refuses to delete it, so plan must not
    # promise the deletion either. Plan previously emitted it anyway, which read
    # as "this run will remove shared infra" when apply would silently keep it.
    assert ("network", "mgmt") not in deletes


def test_plan_no_delete_without_prune(fake_state):
    """Nodes present in live state but absent from the intent must NOT appear as
    deletes when prune=False (the default). Deletes are opt-in only."""
    intent = rec.parse_intent({"fabric": "topo-test"})  # declares no nodes
    plan = rec.plan(FakeClient(), intent, prune=False)
    deletes = [c for c in plan.changes if c.op == "delete"]
    assert deletes == [], (
        f"plan emitted delete(s) without --prune: {deletes}"
    )


def test_plan_rename_detected_as_delete_plus_create(fake_state):
    """Renaming h1→h1-renamed in the intent: plan must surface a create for the
    new name and -- with prune=True -- a delete for the old name.  Without prune
    the old node is silently ignored (no data-loss protection yet), but the new
    name must always emit a create so apply doesn't silently skip it."""
    intent = rec.parse_intent({
        "fabric": "topo-test",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24", "gateway": "198.51.100.254"}],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}],
        "nodes": [{"name": "h1-renamed", "type": "LXC", "firmware": 865,
                   "links": [{"port": "eth0", "switch": "mgmtsw"}]}],
    })
    plan_no_prune = rec.plan(FakeClient(), intent, prune=False)
    plan_prune    = rec.plan(FakeClient(), intent, prune=True)

    creates = {c.name for c in plan_no_prune.changes if c.op == "create" and c.kind == "node"}
    assert "h1-renamed" in creates, "renamed node not surfaced as create"

    deletes = {c.name for c in plan_prune.changes if c.op == "delete" and c.kind == "node"}
    assert "h1" in deletes, "old name not surfaced as delete under --prune"


def test_plan_detects_link_on_existing_node(fake_state):
    """Adding a second link (eth1→mgmtsw) to h1, which already exists in live
    state with only eth0 cabled, must emit a create-link for eth1."""
    intent = rec.parse_intent({
        "fabric": "topo-test",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24", "gateway": "198.51.100.254"}],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}],
        "nodes": [{"name": "h1", "type": "LXC", "firmware": 865,
                   "links": [{"port": "eth0", "switch": "mgmtsw"},
                              {"port": "eth1", "switch": "mgmtsw"}]}],
    })
    plan = rec.plan(FakeClient(), intent)
    link_ops = {(c.op, c.name) for c in plan.changes if c.kind == "link"}
    assert ("noop", "h1.eth0→mgmtsw") in link_ops, "existing eth0 link should be noop"
    assert ("create", "h1.eth1→mgmtsw") in link_ops, "new eth1 link not detected as create"


def test_plan_detects_link_rewire_to_different_switch(fake_state, monkeypatch):
    """Rewiring h1.eth0 from mgmtsw→lansw must emit create-link (not noop).
    The old cable is left for apply to clean up (prune_undeclared_cables)."""
    # Add a second switch to state and intent.
    fake_state["switches"].append({
        "id": 90, "name": "lansw", "auto_address_network": 24,
        "mgmt": False, "vm_type": "SW", "host_uplinked": False, "ports": [],
    })
    fake_state["networks"].append({
        "id": 24, "name": "lan", "ipv4network": "203.0.113.0",
        "ipv4netmask": "255.255.255.0", "ipv4gateway": "203.0.113.1",
    })
    intent = rec.parse_intent({
        "fabric": "topo-test",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24", "gateway": "198.51.100.254"},
                     {"name": "lan",  "cidr": "203.0.113.0/24",  "gateway": "203.0.113.1"}],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"},
                     {"name": "lansw",  "auto_address": "lan"}],
        "nodes": [{"name": "h1", "type": "LXC", "firmware": 865,
                   "links": [{"port": "eth0", "switch": "lansw"}]}],  # moved off mgmtsw
    })
    plan = rec.plan(FakeClient(), intent)
    link_ops = {(c.op, c.name) for c in plan.changes if c.kind == "link"}
    assert ("create", "h1.eth0→lansw") in link_ops, "rewired link not detected as create"
    assert ("noop", "h1.eth0→mgmtsw") not in link_ops, "old link should not be noop"


def test_apply_raises_when_no_firmware_for_new_node(monkeypatch):
    """Creating a node with no firmware/image set must raise FabricStudioAdminError
    immediately -- not silently create a VM with null firmware."""
    from fabric_studio import admin as fs_admin
    from fabric_studio.topology import images
    monkeypatch.setattr(rec.fa, "wait_pod_idle", lambda c: None)
    monkeypatch.setattr(images, "ensure_images", lambda c, intent, say: {})
    monkeypatch.setattr(rec.fa, "ensure_fabric", lambda c, name, desc=None: {"id": 6})
    monkeypatch.setattr(rec.fa, "ensure_network",
                        lambda c, fid, *a, **k: {"id": 23, "ipv4network": "198.51.100.0",
                                                 "ipv4netmask": "255.255.255.0",
                                                 "ipv4gateway": None})
    monkeypatch.setattr(rec, "_cidr_of", lambda row: "198.51.100.0/24")
    monkeypatch.setattr(rec.fa, "ensure_switch",
                        lambda c, fid, name, aa, mgmt: {"id": 85, "auto_address_network": aa,
                                                        "mgmt": mgmt})
    monkeypatch.setattr(rec.fa, "get_vm_by_name", lambda c, fid, name: None)  # node absent
    monkeypatch.setattr(rec, "_resolve_firmware_id",
                        lambda c, nd, image_ids=None, declared_images=None: None)  # no fw
    monkeypatch.setattr(rec.fa, "read_fabric_state",
                        lambda c, fid: {"links": [], "vms": [], "networks": [],
                                        "switches": [], "cables": [],
                                        "ports_by_id": {}, "device_by_port": {}})

    intent = rec.parse_intent({
        "fabric": "topo-test",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}],
        "nodes": [{"name": "h1", "type": "LXC",
                   "links": [{"port": "eth0", "switch": "mgmtsw"}]}],
    })
    # conftest wipes backend.* modules between tests, so the FabricStudioAdminError
    # class raised inside apply() may be a fresh instance that doesn't match the
    # pre-test import. Catch by name to stay robust across the module wipe.
    try:
        rec.apply(FakeClient(), intent, boot=False)
        raise AssertionError("expected FabricStudioAdminError was not raised")
    except Exception as e:
        assert type(e).__name__ == "FabricStudioAdminError", f"wrong exception: {type(e)}"
        assert "firmware/image required" in str(e), f"unexpected error: {e}"


def _cabling_intent() -> rec.Intent:
    return rec.Intent(fabric="f", nodes=[rec.NodeSpec(
        name="h1", type="LXC",
        links=[rec.LinkSpec(port="eth0", switch="mgmtsw")])])


def test_cabling_flags_a_newly_created_node_switch_for_reinstall(monkeypatch):
    """A node created in THIS apply carries its links out of create_vm, so the
    cable already reads correct in the post-create state -- but the running
    switch has never seen the port. The switch must still be flagged for
    reinstall, and the existing cable must not be re-cabled. Live evidence: an
    apply added a node to a running fabric, synchronized the switch, skipped
    the reinstall, and the guest answered nothing, not even ARP."""
    calls = []
    monkeypatch.setattr(rec.fa, "cable_vm_to_switch", lambda *a, **k: calls.append(a))
    switches = rec._reconcile_cabling(
        None, 6, _cabling_intent(), vm_id={"h1": 86}, sw_id={"mgmtsw": 85},
        created_nodes={"h1"}, cur_link_switch={(86, "eth0"): 85},
        _say=lambda m: None)
    assert switches == {85}
    assert calls == [], "the cable row already exists; re-cabling would duplicate it"


def test_cabling_leaves_an_existing_correct_cable_alone(monkeypatch):
    """Pre-existing behavior: an old node whose link already sits on the wanted
    switch is noop -- no cable call, no reinstall flag."""
    calls = []
    monkeypatch.setattr(rec.fa, "cable_vm_to_switch", lambda *a, **k: calls.append(a))
    switches = rec._reconcile_cabling(
        None, 6, _cabling_intent(), vm_id={"h1": 86}, sw_id={"mgmtsw": 85},
        created_nodes=set(), cur_link_switch={(86, "eth0"): 85},
        _say=lambda m: None)
    assert switches == set()
    assert calls == []


def test_cabling_cables_a_missing_link_and_flags_the_switch(monkeypatch):
    """A link whose cable is missing (or moved) gets cabled, and its switch is
    flagged for reinstall so OVS learns the port."""
    calls = []
    monkeypatch.setattr(rec.fa, "cable_vm_to_switch", lambda *a, **k: calls.append(a))
    switches = rec._reconcile_cabling(
        None, 6, _cabling_intent(), vm_id={"h1": 86}, sw_id={"mgmtsw": 85},
        created_nodes=set(), cur_link_switch={},
        _say=lambda m: None)
    assert switches == {85}
    assert len(calls) == 1


def test_cable_vm_to_switch_auto_expands_when_no_free_port(monkeypatch):
    """When all switch ports are occupied, cable_vm_to_switch must add a new port
    and cable to it -- not raise. FS supports POST switch/{id}/port."""
    from fabric_studio import admin as fs_admin
    added = []
    cables = []
    monkeypatch.setattr(fs_admin, "free_switch_port", lambda c, fid, sid: None)
    monkeypatch.setattr(fs_admin, "get_vm_ports",
                        lambda c, fid, vid: [{"id": 1, "name": "eth0",
                                              "device": 99, "cable": None}])
    monkeypatch.setattr(fs_admin, "add_switch_port",
                        lambda c, fid, sid: added.append(sid) or {"id": 200, "device": sid})
    monkeypatch.setattr(fs_admin, "create_cable",
                        lambda c, fid, d1, p1, d2, p2: cables.append((p1, p2)) or {"id": 77})
    monkeypatch.setattr(fs_admin, "_check", lambda resp, label: resp)

    fs_admin.cable_vm_to_switch(object(), fabric_id=6, vm_id=99, switch_id=85, port_name="eth0")
    assert added == [85], "add_switch_port should have been called for switch 85"
    assert cables == [(1, 200)], "cable should connect vm port 1 to new switch port 200"


def _intent_one_node():
    """Single-node intent that fully matches the fake_state graph (h1), so the
    only thing that can vary in plan() is the runtime/bring-up gate."""
    return rec.parse_intent({
        "fabric": "topo-test",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24", "gateway": "198.51.100.254"}],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}],
        "nodes": [{"name": "h1", "type": "LXC", "firmware": 865,
                   "links": [{"port": "eth0", "switch": "mgmtsw"}]}],
    })


def test_plan_boot_noop_when_runtime_present(fake_state, monkeypatch):
    # Fabric running, h1's runtime row present, nothing else drifted → clean no-op.
    monkeypatch.setattr(rec.fa, "runtime_vms", lambda c, fid: [{"id": 86}])
    plan = rec.plan(FakeClient(), _intent_one_node())
    names = {(c.op, c.kind, c.name) for c in plan.changes}
    assert ("noop", "boot", "topo-test") in names
    assert not plan.mutating          # CLI would short-circuit ("Nothing to apply")


def test_plan_recovers_node_with_missing_runtime(fake_state, monkeypatch):
    # Fabric is running (some other VM powered) but h1's runtime row is GONE -- a
    # crashed / out-of-band-destroyed node. The model graph is unchanged, so this
    # is invisible to the model diff; plan() must still surface it as a recover so
    # a plain `apply` (no --force) re-installs it. Regression guard for the
    # gate-recovery finding (Pod B 2026-06-12).
    monkeypatch.setattr(rec.fa, "runtime_vms", lambda c, fid: [{"id": 999}])
    plan = rec.plan(FakeClient(), _intent_one_node())
    names = {(c.op, c.kind, c.name) for c in plan.changes}
    assert ("create", "boot", "h1") in names      # per-node recover surfaced
    assert plan.mutating                          # so cmd_apply will NOT skip apply
    # infra otherwise unchanged → no spurious whole-fabric synchronize.
    assert ("update", "boot", "topo-test") not in names


def test_plan_surfaces_standing_system_host_dhcp_diff(fake_state, monkeypatch):
    # Fabric running, h1's runtime present, no model drift -- but the System Host
    # carries a STANDING dhcp_table diff (e.g. an orphan reservation left after a
    # VM was deleted out-of-band). plan() must surface it as a mutating boot change
    # so `apply` heals it (host install + rebuild forwards) instead of the CLI
    # short-circuiting on "no changes" and leaving a destructive GUI-sync landmine.
    monkeypatch.setattr(rec.fa, "runtime_vms", lambda c, fid: [{"id": 86}])
    monkeypatch.setattr(rec.fa, "devices_needing_dhcp_install", lambda c, fid: [64])
    plan = rec.plan(FakeClient(), _intent_one_node())
    names = {(c.op, c.kind, c.name) for c in plan.changes}
    assert ("update", "boot", "topo-test") in names   # host DHCP heal surfaced
    assert ("noop", "boot", "topo-test") not in names  # not a silent no-op
    assert plan.mutating


# ── Switch role sugar ────────────────────────────────────────────────────────

def test_effective_resource_floors_and_bumps():
    # explicit value wins but is floored to the minimum
    assert rec._effective_resource(8, 4, 2) == 8        # spec above min → spec
    assert rec._effective_resource(2, 4, 2) == 4        # spec below min → floored up
    assert rec._effective_resource(4, 4, 4) is None     # already at target → no change
    # no spec: only bump UP to the minimum, never downsize the firmware default
    assert rec._effective_resource(None, 4, 2) == 4     # below min → bump to min
    assert rec._effective_resource(None, 4, 8) is None  # above min → leave firmware default
    assert rec._effective_resource(None, None, 1) is None  # no min, no spec → untouched


def test_plan_floors_fmg_faz_resources_without_explicit_spec(monkeypatch):
    # an FMG node with no cpu/memory in the intent still gets floored to the
    # vm-type minimum (4/8192) so a minimally-declared node can't boot broken.
    monkeypatch.setattr(rec.fa, "get_vm_parameters",
                        lambda c, vid: {"cpu_count": 1, "memory": 2048})
    monkeypatch.setattr(rec.fa, "list_vm_disks", lambda c, vid: [])
    p = rec.Plan()
    nd = rec.NodeSpec(name="fmg", type="FMG")
    rec._plan_node_resources(None, p, nd, {"id": 1}, fid=1)
    descs = [c.detail for c in p.changes]
    assert any("cpu 1→4" in d for d in descs)
    assert any("memory 2048→8192" in d for d in descs)


def test_parse_switch_host_uplink_flag():
    intent = rec.parse_intent({"fabric": "f", "networks": [{"name": "m", "cidr": "10.0.0.0/24", "gateway": "10.0.0.254"}],
                               "switches": [{"name": "m", "auto_address": "m", "host_uplink": True}]})
    assert intent.switches[0].host_uplink is True


def test_ensure_host_uplink_repoints_and_cables(monkeypatch):
    calls = {"set_ip": None, "cable": None}
    host = {"id": 86, "ports": [
        {"id": 676, "name": "mgmt1", "ipv4addr": None, "forwarding": True, "cable": None},
        {"id": 677, "name": "int1", "ipv4addr": "10.254.254.254", "forwarding": True, "cable": 91},
    ]}
    monkeypatch.setattr(rec.fa, "get_system_host", lambda c, fid: host)
    monkeypatch.setattr(rec.fa, "set_host_port_ipv4",
                        lambda c, pid, ip, mask: calls.__setitem__("set_ip", (pid, ip)))
    monkeypatch.setattr(rec.fa, "list_switch_ports", lambda c, fid, sid: [{"id": 500, "cable": None}])
    monkeypatch.setattr(rec.fa, "delete_cable", lambda c, fid, cid: calls.__setitem__("del", cid))
    monkeypatch.setattr(rec.fa, "free_switch_port", lambda c, fid, sid: {"id": 500, "device": sid})
    monkeypatch.setattr(rec.fa, "create_cable",
                        lambda c, fid, d1, p1, d2, p2: calls.__setitem__("cable", (d1, p1, d2, p2)))
    net = rec.NetworkSpec(name="Management", cidr="10.100.55.0/24", gateway="10.100.55.254")
    rec._ensure_host_uplink(None, 1, 48, net, say=lambda m: None)
    # repointed the spare int port (not mgmt1) to the gateway, then cabled it to the switch
    assert calls["set_ip"] == (677, "10.100.55.254")
    assert calls["del"] == 91                         # removed its old (OOB) cable
    assert calls["cable"] == (86, 677, 48, 500)       # host:int1 → switch 48 free port


def test_ensure_host_uplink_idempotent_when_owned_and_cabled(monkeypatch):
    host = {"id": 86, "ports": [
        {"id": 677, "name": "int1", "ipv4addr": "10.100.55.254", "forwarding": True, "cable": 200},
    ]}
    monkeypatch.setattr(rec.fa, "get_system_host", lambda c, fid: host)
    monkeypatch.setattr(rec.fa, "list_switch_ports", lambda c, fid, sid: [{"id": 500, "cable": 200}])
    # set_host_port_ipv4 / create_cable must NOT be called
    monkeypatch.setattr(rec.fa, "set_host_port_ipv4", lambda *a: (_ for _ in ()).throw(AssertionError("repointed")))
    monkeypatch.setattr(rec.fa, "create_cable", lambda *a: (_ for _ in ()).throw(AssertionError("recabled")))
    net = rec.NetworkSpec(name="Management", cidr="10.100.55.0/24", gateway="10.100.55.254")
    rec._ensure_host_uplink(None, 1, 48, net, say=lambda m: None)  # no exception = idempotent


def test_ensure_host_uplink_prefers_free_port_over_stealing(monkeypatch):
    """Two host-uplinked nets must each get their OWN int port: the second uplink
    must pick a FREE port, not steal the first's (proven-live regression -- two
    host_uplink:true switches collapsed to one because the candidate selector
    always returned the first int port)."""
    calls = {"set_ip": None, "del": None, "cable": None}
    # int1 already owns Internet Access's gateway + is cabled (the first uplink);
    # int2 is FREE. The Management uplink must take int2, leaving int1 alone.
    host = {"id": 86, "ports": [
        {"id": 676, "name": "mgmt1", "ipv4addr": None, "forwarding": True, "cable": None},
        {"id": 677, "name": "int1", "ipv4addr": "203.0.113.254", "forwarding": True, "cable": 91},
        {"id": 678, "name": "int2", "ipv4addr": None, "forwarding": True, "cable": None},
    ]}
    monkeypatch.setattr(rec.fa, "get_system_host", lambda c, fid: host)
    monkeypatch.setattr(rec.fa, "set_host_port_ipv4",
                        lambda c, pid, ip, mask: calls.__setitem__("set_ip", (pid, ip)))
    # int1's cable (91) lands on declared sibling switch 99 -> int1 is NOT free.
    monkeypatch.setattr(rec.fa, "list_switch_ports",
                        lambda c, fid, sid: [{"id": 500, "cable": 91}] if sid == 99 else [{"id": 500, "cable": None}])
    monkeypatch.setattr(rec.fa, "delete_cable", lambda c, fid, cid: calls.__setitem__("del", cid))
    monkeypatch.setattr(rec.fa, "free_switch_port", lambda c, fid, sid: {"id": 500, "device": sid})
    monkeypatch.setattr(rec.fa, "create_cable",
                        lambda c, fid, d1, p1, d2, p2: calls.__setitem__("cable", (d1, p1, d2, p2)))
    net = rec.NetworkSpec(name="Management", cidr="10.100.55.0/24", gateway="10.100.55.254")
    # switch 48 is the one being uplinked; switch 99 is a declared sibling int1 is
    # cabled to -- int1 must be left alone, int2 (uncabled) taken instead.
    rec._ensure_host_uplink(None, 1, 48, net, say=lambda m: None,
                           declared_switch_ids={48, 99})
    # repointed the FREE int2 (not int1) -- and did NOT delete int1's Internet cable
    assert calls["set_ip"] == (678, "10.100.55.254")
    assert calls["del"] is None
    assert calls["cable"] == (86, 678, 48, 500)


def test_role_egress_maps_to_mgmt_false():
    intent = rec.parse_intent({"fabric": "f",
                               "switches": [{"name": "inet", "role": "egress"}]})
    assert intent.switches[0].mgmt is False
    assert intent.switches[0].role == "egress"


def test_role_mgmt_maps_to_mgmt_true():
    intent = rec.parse_intent({"fabric": "f",
                               "switches": [{"name": "oob", "role": "mgmt"}]})
    assert intent.switches[0].mgmt is True


def test_role_default_is_mgmt_true():
    intent = rec.parse_intent({"fabric": "f", "switches": [{"name": "s"}]})
    assert intent.switches[0].mgmt is True
    assert intent.switches[0].role is None


def test_role_rejects_bad_value():
    with pytest.raises(ValueError):
        rec.parse_intent({"fabric": "f", "switches": [{"name": "s", "role": "wan"}]})


def test_role_contradicting_mgmt_flag_rejected():
    with pytest.raises(ValueError):
        rec.parse_intent({"fabric": "f",
                          "switches": [{"name": "s", "role": "egress", "mgmt": True}]})


# ── Floating-switch guard ────────────────────────────────────────────────────

def test_floating_warning_when_switch_not_host_uplinked():
    intent = rec.parse_intent({
        "fabric": "f",
        "switches": [{"name": "lonely", "role": "egress"}],
        "nodes": [{"name": "n", "links": [{"port": "eth1", "switch": "lonely"}]}],
    })
    warns = rec._floating_switch_warnings(intent, [{"name": "lonely", "host_uplinked": False}])
    assert warns and "lonely" in warns[0] and "floating" in warns[0]


def test_no_floating_warning_for_uplinked_switch():
    intent = rec.parse_intent({
        "fabric": "f",
        "switches": [{"name": "Internet Access", "role": "egress"}],
        "nodes": [{"name": "n", "links": [{"port": "eth1", "switch": "Internet Access"}]}],
    })
    warns = rec._floating_switch_warnings(
        intent, [{"name": "Internet Access", "host_uplinked": True}])
    assert warns == []


def test_no_floating_warning_for_switch_without_nodes():
    intent = rec.parse_intent({"fabric": "f",
                               "switches": [{"name": "spare", "role": "egress"}]})
    assert rec._floating_switch_warnings(intent, []) == []


# ── image addressing contract ────────────────────────────────────────────────

def _addr_intent(link):
    return rec.parse_intent({
        "fabric": "f",
        "images": [{"name": "win2022-golden", "home_repo": "w.qcow2",
                    "addressing": "dhcp"}],
        "switches": [{"name": "s", "role": "egress"}],
        "nodes": [{"name": "win2022", "type": "WINDOWS", "image": "win2022-golden",
                   "links": [{"port": "eth0", "switch": "s", **link}]}],
    })


def test_dhcp_only_image_rejects_a_static_link():
    v = rec._image_addressing_violations(_addr_intent({"ip": "192.168.0.150"}))
    assert len(v) == 1
    assert "192.168.0.150" in v[0] and "dhcp: System Host" in v[0]


def test_dhcp_only_image_rejects_a_link_with_no_addressing():
    v = rec._image_addressing_violations(_addr_intent({}))
    assert len(v) == 1 and "no dhcp: and no ip:" in v[0]


def test_dhcp_only_image_accepts_a_dhcp_link():
    assert rec._image_addressing_violations(
        _addr_intent({"dhcp": "System Host"})) == []


def test_image_without_addressing_constrains_nothing():
    intent = rec.parse_intent({
        "fabric": "f",
        "images": [{"name": "img", "home_repo": "w.qcow2"}],
        "switches": [{"name": "s", "role": "egress"}],
        "nodes": [{"name": "n", "image": "img",
                   "links": [{"port": "eth0", "switch": "s", "ip": "10.0.0.5"}]}],
    })
    assert rec._image_addressing_violations(intent) == []


# ── hugepage capacity guard ──────────────────────────────────────────────────

def _hp_intent(**node_kw):
    return rec.parse_intent({
        "fabric": "f",
        "switches": [{"name": "s", "role": "egress"}],
        "nodes": [{"name": "win2022", "type": "WINDOWS",
                   "links": [{"port": "eth0", "switch": "s"}], **node_kw}],
    })


def _patch_hp(monkeypatch, *, free, mem, hugepages, available=56):
    monkeypatch.setattr(rec.fa, "hugepages_free", lambda c: free)
    monkeypatch.setattr(rec.fa, "hugepages_available", lambda c: available)
    monkeypatch.setattr(rec.fa, "get_vm_parameters",
                        lambda c, vid: {"memory": mem, "hugepages": hugepages})


def test_hugepage_shortfall_blocks_when_pool_too_small(monkeypatch):
    # The ad_dc failure: 8192 MiB of pool-backed RAM against 2 free pages.
    _patch_hp(monkeypatch, free=2, mem=8192, hugepages=True)
    msg = rec._hugepage_shortfall(None, _hp_intent(), ["win2022"], {"win2022": 42})
    assert msg and "8 page" in msg and "only 2 are free" in msg
    assert "power-on" in msg.lower()  # names the failure mode, not just the arithmetic


def test_no_hugepage_shortfall_when_pool_fits(monkeypatch):
    _patch_hp(monkeypatch, free=16, mem=8192, hugepages=True)
    assert rec._hugepage_shortfall(None, _hp_intent(), ["win2022"], {"win2022": 42}) is None


def test_hugepages_false_needs_no_pages(monkeypatch):
    # Declaring hugepages:false maps from ordinary RAM -- the pool is irrelevant.
    _patch_hp(monkeypatch, free=0, mem=8192, hugepages=True)
    assert rec._hugepage_shortfall(
        None, _hp_intent(hugepages=False), ["win2022"], {"win2022": 42}) is None


def test_hugepage_check_skips_guests_already_off_the_pool(monkeypatch):
    # Undeclared + FS already has it false → not pool-backed, don't count it.
    _patch_hp(monkeypatch, free=0, mem=8192, hugepages=False)
    assert rec._hugepage_shortfall(None, _hp_intent(), ["win2022"], {"win2022": 42}) is None


def test_hugepage_check_is_silent_on_pods_without_the_endpoint(monkeypatch):
    # Older pod: the guard must never block an apply it cannot evaluate.
    def _boom(c):
        raise RuntimeError("404")
    monkeypatch.setattr(rec.fa, "hugepages_free", _boom)
    assert rec._hugepage_shortfall(None, _hp_intent(), ["win2022"], {"win2022": 42}) is None


def test_hugepages_declared_true_counts_even_if_model_says_false(monkeypatch):
    # Explicit true is a request to move ONTO the pool -- check capacity for it.
    _patch_hp(monkeypatch, free=1, mem=4096, hugepages=False)
    msg = rec._hugepage_shortfall(
        None, _hp_intent(hugepages=True), ["win2022"], {"win2022": 42})
    assert msg and "4 page" in msg


# ── dhcp_service guard ───────────────────────────────────────────────────────

def _dhcp_state(dhcp_service: bool, *, host_cabled: bool = True):
    """Fabric state with one switch ('Internet Access', port 10) and a System Host
    int port cabled to it whose DHCP server is on/off."""
    host_ports = []
    if host_cabled:
        host_ports = [{"name": "int2", "peer": 10, "dhcp_service": dhcp_service}]
    return {
        "host": {"ports": host_ports},
        "switches": [{"name": "Internet Access", "id": 3,
                      "ports": [{"id": 10, "name": "port1"}]}],
    }


def _dhcp_intent():
    return rec.parse_intent({
        "fabric": "f",
        "switches": [{"name": "Internet Access", "role": "egress"}],
        "nodes": [{"name": "win2022", "links": [
            {"port": "eth0", "switch": "Internet Access", "dhcp": "System Host"}]}],
    })


def test_dhcp_warns_when_host_port_serves_no_dhcp():
    warns = rec._dhcp_switches_without_service(_dhcp_intent(), _dhcp_state(False))
    assert len(warns) == 1
    assert "Internet Access" in warns[0]
    assert "win2022.eth0" in warns[0]
    assert "int2" in warns[0]


def test_no_dhcp_warning_when_service_enabled():
    assert rec._dhcp_switches_without_service(_dhcp_intent(), _dhcp_state(True)) == []


def test_no_dhcp_warning_for_floating_switch():
    # No System Host port on the segment at all -- _floating_switch_warnings owns
    # that case, and it names a better fix. Don't double-report.
    assert rec._dhcp_switches_without_service(
        _dhcp_intent(), _dhcp_state(False, host_cabled=False)) == []


def test_no_dhcp_warning_without_a_dhcp_link():
    # Same dead segment, but the link is static -- nothing asks for a lease.
    intent = rec.parse_intent({
        "fabric": "f",
        "switches": [{"name": "Internet Access", "role": "egress"}],
        "nodes": [{"name": "win2022", "links": [
            {"port": "eth0", "switch": "Internet Access", "ip": "203.0.113.10"}]}],
    })
    assert rec._dhcp_switches_without_service(intent, _dhcp_state(False)) == []


def test_plan_surfaces_floating_warning_in_render(fake_state):
    # h1 cabled to a NEW switch 'float' that won't be host-uplinked.
    intent = rec.parse_intent({
        "fabric": "topo-test",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"},
                     {"name": "float", "role": "egress"}],
        "nodes": [{"name": "h1", "type": "LXC", "firmware": 865,
                   "links": [{"port": "eth0", "switch": "mgmtsw"},
                             {"port": "eth1", "switch": "float"}]}],
    })
    plan = rec.plan(FakeClient(), intent)
    assert any("float" in w for w in plan.warnings)
    assert "! switch 'float'" in plan.render()


# ── Reachability report (pure, over a read_fabric_state snapshot) ────────────

def _two_node_state(host2_ip="198.51.100.2", routable=True):
    """host1 + host2 on one mgmt switch. ``routable`` toggles host-uplink;
    ``host2_ip=None`` makes host2's port IP-less (the MISS path)."""
    return {
        "fabric": {"id": 6, "name": "topo-test"},
        "networks": [{"id": 23, "name": "mgmt", "ipv4network": "198.51.100.0",
                      "ipv4netmask": "255.255.255.0", "ipv4gateway": "198.51.100.254"}],
        "switches": [{"id": 85, "name": "mgmtsw", "auto_address_network": 23,
                      "mgmt": False, "vm_type": "SW",
                      "host_uplinked": routable, "ports": []}],
        "vms": [
            {"id": 86, "name": "host1", "vm_type": "LXC", "firmware": 865,
             "ports": [{"id": 1, "name": "eth0", "ipv4addr": "198.51.100.1",
                        "network": 23, "cable": 124}]},
            {"id": 87, "name": "host2", "vm_type": "LXC", "firmware": 865,
             "ports": [{"id": 2, "name": "eth0", "ipv4addr": host2_ip,
                        "network": 23 if host2_ip else None, "cable": 125}]},
        ],
        "cables": [{"id": 124, "conn1": 1, "conn2": 3},
                   {"id": 125, "conn1": 2, "conn2": 4}],
        "ports_by_id": {}, "device_by_port": {},
        "links": [
            {"vm_id": 86, "vm_port": 1, "vm_port_name": "eth0", "switch_id": 85,
             "switch_port": 3, "cable_id": 124},
            {"vm_id": 87, "vm_port": 2, "vm_port_name": "eth0", "switch_id": 85,
             "switch_port": 4, "cable_id": 125},
        ],
    }


def test_reachability_rows_ok_and_egress():
    rows = {r.node: r for r in rec.reachability_report(_two_node_state(), None)["rows"]}
    assert rows["host1"].ok and rows["host1"].ip == "198.51.100.1"
    assert rows["host1"].network == "mgmt"
    assert rows["host1"].routable and rows["host1"].egress   # mgmt=False + uplinked


def test_reachability_flags_ipless_port_as_miss():
    rows = rec.reachability_report(_two_node_state(host2_ip=None), None)["rows"]
    h2 = next(r for r in rows if r.node == "host2")
    assert not h2.ok and h2.ip is None


def test_reachability_isolated_when_not_uplinked():
    rows = rec.reachability_report(_two_node_state(routable=False), None)["rows"]
    h1 = next(r for r in rows if r.node == "host1")
    assert not h1.routable and not h1.egress


def test_reachability_pairs_same_l2_reachable():
    pairs = rec.reachability_report(_two_node_state(), None)["pairs"]
    p = next(p for p in pairs if p["src"] == "host1" and p["dst"] == "host2")
    assert p["reachable"] and "same L2" in p["why"]


# ── Manageability gate (_unmanageable_nodes -- Run-2 matrix rule #1) ───────────

def _matrix_state():
    """uplinked switch (id 85) + floating switch (id 90); three nodes:
    n_ok (port1→uplinked), n_float (port1→floating only),
    n_data (port1→uplinked + port2→floating). Matches the Run-2 matrix cells."""
    return {
        "fabric": {"id": 7, "name": "m"},
        "networks": [{"id": 23, "name": "up", "ipv4network": "198.51.100.0",
                      "ipv4netmask": "255.255.255.0", "ipv4gateway": "198.51.100.254"},
                     {"id": 24, "name": "fl", "ipv4network": "192.0.2.0",
                      "ipv4netmask": "255.255.255.0", "ipv4gateway": "192.0.2.254"}],
        "switches": [{"id": 85, "name": "upsw", "auto_address_network": 23,
                      "mgmt": False, "host_uplinked": True, "ports": []},
                     {"id": 90, "name": "flsw", "auto_address_network": 24,
                      "mgmt": True, "host_uplinked": False, "ports": []}],
        "vms": [
            {"id": 86, "name": "n_ok", "vm_type": "FGT",
             "ports": [{"id": 1, "name": "port1", "ipv4addr": "198.51.100.1",
                        "network": 23, "cable": 1}]},
            {"id": 87, "name": "n_float", "vm_type": "FGT",
             "ports": [{"id": 2, "name": "port1", "ipv4addr": "192.0.2.1",
                        "network": 24, "cable": 2}]},
            {"id": 88, "name": "n_data", "vm_type": "FGT",
             "ports": [{"id": 3, "name": "port1", "ipv4addr": "198.51.100.2",
                        "network": 23, "cable": 3},
                       {"id": 4, "name": "port2", "ipv4addr": "192.0.2.2",
                        "network": 24, "cable": 4}]},
        ],
        "cables": [], "ports_by_id": {}, "device_by_port": {},
        "links": [
            {"vm_id": 86, "vm_port_name": "port1", "switch_id": 85},
            {"vm_id": 87, "vm_port_name": "port1", "switch_id": 90},
            {"vm_id": 88, "vm_port_name": "port1", "switch_id": 85},
            {"vm_id": 88, "vm_port_name": "port2", "switch_id": 90},
        ],
    }


def _matrix_intent():
    return rec.parse_intent({
        "fabric": "m",
        "networks": [{"name": "up", "cidr": "198.51.100.0/24", "gateway": "198.51.100.254"},
                     {"name": "fl", "cidr": "192.0.2.0/24", "gateway": "192.0.2.254"}],
        "switches": [{"name": "upsw", "auto_address": "up", "role": "egress", "host_uplink": True},
                     {"name": "flsw", "auto_address": "fl", "role": "mgmt"}],
        "nodes": [
            {"name": "n_ok", "type": "FGT", "firmware": 814,
             "links": [{"port": "port1", "switch": "upsw"}]},
            {"name": "n_float", "type": "FGT", "firmware": 814,
             "links": [{"port": "port1", "switch": "flsw"}]},
            {"name": "n_data", "type": "FGT", "firmware": 814,
             "links": [{"port": "port1", "switch": "upsw"},
                       {"port": "port2", "switch": "flsw"}]},
        ],
    })


def test_unmanageable_only_flags_floating_only_node():
    """Floating-only node is unmanageable; a host-uplinked port (even alongside a
    floating data port) is fine -- matrix cells C/D fail, A and G pass."""
    bad = rec._unmanageable_nodes(_matrix_intent(), _matrix_state())
    assert bad == ["n_float"]            # NOT n_ok, NOT n_data (has a routable port)


def test_unmanageable_ignores_switch_mgmt_flag():
    """The switch `mgmt` flag is irrelevant: n_float is on a mgmt=True floating
    switch yet still unmanageable; n_ok is on a mgmt=False uplinked switch and is
    fine. Uplink decides, not the mgmt flag (matrix rule #2)."""
    bad = rec._unmanageable_nodes(_matrix_intent(), _matrix_state())
    assert "n_ok" not in bad and "n_float" in bad


# ── FortiFlex DNS gate (_flex_nodes_without_dns -- soc-demo flex root cause) ───

def _flex_state(dns1):
    """One FGT on a host-uplinked egress switch; ``dns1`` sets the egress net's
    resolver (None = no DNS → flex won't activate)."""
    return {
        "fabric": {"id": 9, "name": "f"},
        "networks": [{"id": 30, "name": "egress", "ipv4network": "203.0.113.0",
                      "ipv4netmask": "255.255.255.0", "ipv4gateway": "203.0.113.254",
                      "ipv4dns1": dns1}],
        "switches": [{"id": 95, "name": "egsw", "auto_address_network": 30,
                      "mgmt": False, "host_uplinked": True, "ports": []}],
        "vms": [{"id": 96, "name": "fgt", "vm_type": "FGT",
                 "ports": [{"id": 1, "name": "port1", "ipv4addr": "203.0.113.5",
                            "network": 30, "cable": 1}]}],
        "cables": [], "ports_by_id": {}, "device_by_port": {},
        "links": [{"vm_id": 96, "vm_port_name": "port1", "switch_id": 95}],
    }


def _flex_intent():
    return rec.parse_intent({
        "fabric": "f",
        "networks": [{"name": "egress", "cidr": "203.0.113.0/24", "gateway": "203.0.113.254"}],
        "switches": [{"name": "egsw", "auto_address": "egress", "role": "egress", "host_uplink": True}],
        "nodes": [{"name": "fgt", "type": "FGT", "firmware": 814,
                   "license": {"mode": "auto", "flex_config": "13796"},
                   "links": [{"port": "port1", "switch": "egsw"}]}],
    })


def test_flex_without_dns_flagged_when_net_has_no_dns():
    assert rec._flex_nodes_without_dns(_flex_intent(), _flex_state(None)) == ["fgt"]


def test_flex_with_dns_not_flagged():
    assert rec._flex_nodes_without_dns(_flex_intent(), _flex_state("8.8.8.8")) == []


# ── Install-status gating (wait_vm_ready returncode check) ────────────────────

def test_wait_vm_ready_raises_on_failed_install_task(monkeypatch):
    """A failed install (rc 254) must raise immediately, not spin to timeout --
    a failed install destroys the runtime so the VM never reaches ready."""
    from fabric_studio import admin as fs_admin
    monkeypatch.setattr(fs_admin, "get_task", lambda c, tid: {
        "id": tid, "name": "Install 'docker1' device",
        "returncode": 254, "signal": None, "monitor_error": "nft delete chain"})
    monkeypatch.setattr(fs_admin, "get_vm_runtime_state",
                        lambda c, vid: {"exists": False, "task": None, "status": {}})
    monkeypatch.setattr(fs_admin.time, "sleep", lambda s: None)
    with pytest.raises(fs_admin.FabricStudioAdminError) as e:
        fs_admin.wait_vm_ready(FakeClient(), 135, timeout_s=30, task_id=695)
    assert "254" in str(e.value)


def test_wait_vm_ready_passes_on_successful_install(monkeypatch):
    """rc 0 install + powered/post_boot_prepared → returns the status dict."""
    from fabric_studio import admin as fs_admin
    monkeypatch.setattr(fs_admin, "get_task",
                        lambda c, tid: {"id": tid, "returncode": 0, "signal": None})
    monkeypatch.setattr(fs_admin, "get_vm_runtime_state",
                        lambda c, vid: {"exists": True, "task": None,
                                        "status": {"powered": True, "post_boot_prepared": True}})
    monkeypatch.setattr(fs_admin.time, "sleep", lambda s: None)
    st = fs_admin.wait_vm_ready(FakeClient(), 135, timeout_s=30, task_id=693)
    assert st["powered"] is True


# ── Stray-cable pruning ──────────────────────────────────────────────────────

def _one_node_intent():
    return rec.parse_intent({
        "fabric": "lxc-docker",
        "networks": [{"name": "Internet Access", "cidr": "203.0.113.0/24"}],
        "switches": [{"name": "Internet Access", "auto_address": "Internet Access"}],
        "nodes": [{"name": "docker1", "type": "LXC", "firmware": 1,
                   "links": [{"port": "eth0", "switch": "Internet Access"}]}],
    })


def test_prune_undeclared_cables_removes_stray_on_managed_switch(monkeypatch):
    """eth1 cabled to the SAME managed switch but not declared → pruned;
    the node is returned for reinstall."""
    deleted = []
    monkeypatch.setattr(rec.fa, "read_fabric_state", lambda c, fid: {"links": [
        {"vm_id": 135, "vm_port_name": "eth0", "switch_id": 133, "cable_id": 11},
        {"vm_id": 135, "vm_port_name": "eth1", "switch_id": 133, "cable_id": 22},
    ]})
    monkeypatch.setattr(rec.fa, "delete_cable", lambda c, fid, cid: deleted.append(cid))
    changed = rec._prune_undeclared_cables(
        FakeClient(), 17, _one_node_intent(), {"docker1": 135},
        {"Internet Access": 133}, lambda m: None)
    assert deleted == [22]
    assert changed == {"docker1"}


def test_prune_undeclared_cables_keeps_unmanaged_switch(monkeypatch):
    """A cable to an UNMANAGED switch (FS-auto OOB mgmt) is left alone."""
    deleted = []
    monkeypatch.setattr(rec.fa, "read_fabric_state", lambda c, fid: {"links": [
        {"vm_id": 135, "vm_port_name": "eth0", "switch_id": 133, "cable_id": 11},
        {"vm_id": 135, "vm_port_name": "eth1", "switch_id": 999, "cable_id": 22},
    ]})
    monkeypatch.setattr(rec.fa, "delete_cable", lambda c, fid, cid: deleted.append(cid))
    changed = rec._prune_undeclared_cables(
        FakeClient(), 17, _one_node_intent(), {"docker1": 135},
        {"Internet Access": 133}, lambda m: None)
    assert deleted == []
    assert changed == set()


def test_apply_dhcp_link_keeps_valid_in_subnet_address(monkeypatch):
    """When the port already has a usable in-subnet address, the static-DHCP
    path keeps it (idempotent -- no churn on re-apply)."""
    calls = []
    fid = 6
    monkeypatch.setattr(rec.fa, "wait_pod_idle", lambda c: None)
    from fabric_studio.topology import images
    monkeypatch.setattr(images, "ensure_images", lambda c, intent, say: {})
    monkeypatch.setattr(rec.fa, "ensure_fabric", lambda c, name, desc=None: {"id": fid})
    monkeypatch.setattr(rec.fa, "ensure_network",
                        lambda c, fid, *a, **k: {"id": 23, "ipv4network": "198.51.100.0",
                                                 "ipv4netmask": "255.255.255.0",
                                                 "ipv4gateway": "198.51.100.254"})
    monkeypatch.setattr(rec, "_cidr_of", lambda row: "198.51.100.0/24")
    monkeypatch.setattr(rec.fa, "ensure_switch",
                        lambda c, fid, name, aa, mgmt: {"id": 85,
                                                        "auto_address_network": aa, "mgmt": mgmt})
    monkeypatch.setattr(rec.fa, "get_vm_by_name",
                        lambda c, fid, name: {"id": 86, "firmware": 1})
    monkeypatch.setattr(rec, "_resolve_firmware_id",
                        lambda c, nd, image_ids=None, declared_images=None: 1)
    monkeypatch.setattr(rec, "_apply_node_resources", lambda *a, **k: False)
    monkeypatch.setattr(rec, "_ensure_provision_config", lambda *a, **k: False)
    monkeypatch.setattr(rec, "_prune_undeclared_cables", lambda *a, **k: set())
    monkeypatch.setattr(rec.fa, "read_fabric_state",
                        lambda c, fid: {"links": [{"vm_id": 86, "vm_port_name": "eth0",
                                                   "switch_id": 85}]})
    monkeypatch.setattr(rec.fa, "get_vm_ports",
                        lambda c, fid, vid: [{"id": 938, "name": "eth0",
                                              "ipv4addr": "198.51.100.50",
                                              "ipv4netmask": "255.255.255.0"}])
    monkeypatch.setattr(rec.fa, "get_system_host", lambda c, fid: {"id": 64})
    monkeypatch.setattr(rec.fa, "get_vm_install_after", lambda c, vid: [])
    monkeypatch.setattr(rec.fa, "set_vm_install_after", lambda c, vid, after: None)
    monkeypatch.setattr(rec.fa, "set_port_ipv4",
                        lambda c, fid, vid, pid, ip, mask=None, addrmode="STA",
                        dhcp_server=None, network=None: calls.append({"ip": ip}))
    monkeypatch.setattr(rec, "assert_converged", lambda *a, **k: {})
    intent = rec.parse_intent({
        "fabric": "topo-test",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24", "gateway": "198.51.100.254"}],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}],
        "nodes": [{"name": "b1", "type": "BASIC", "firmware": 1,
                   "links": [{"port": "eth0", "switch": "mgmtsw", "dhcp": "System Host"}]}],
    })
    rec.apply(FakeClient(), intent, boot=False)
    assert calls == [{"ip": "198.51.100.50"}]  # kept (already in-subnet, not the gw)


# ── License ──────────────────────────────────────────────────────────────────

def test_parse_license_forms():
    assert rec._parse_license(None) is None
    assert rec._parse_license("auto") == rec.LicenseSpec(mode="AUTO")
    assert rec._parse_license("none") == rec.LicenseSpec(mode="NONE")
    d = rec._parse_license({"mode": "auto", "file": "x.lic", "flex_config": 29529})
    assert d == rec.LicenseSpec(mode="AUTO", file="x.lic", flex_config=29529)


def test_parse_license_rejects_bad_type():
    with pytest.raises(ValueError):
        rec._parse_license(["auto"])


def test_node_license_parsed_on_intent():
    intent = rec.parse_intent({
        "fabric": "f",
        "networks": [{"name": "n", "cidr": "198.51.100.0/24", "gateway": "198.51.100.254"}],
        "switches": [{"name": "s", "auto_address": "n"}],
        "nodes": [{"name": "fgt", "type": "FGT", "firmware": 850, "license": "auto",
                   "links": [{"port": "port1", "switch": "s"}]}],
    })
    assert intent.nodes[0].license.mode == "AUTO"


def test_ensure_license_sets_mode_and_flags_reinstall(monkeypatch):
    calls = {}
    monkeypatch.setattr(rec.fa, "get_vm_license_mode", lambda c, fid, vid: {"mode": "NONE"})
    monkeypatch.setattr(rec.fa, "set_vm_license_mode",
                        lambda c, fid, vid, mode: calls.setdefault("mode", mode))
    nd = rec.NodeSpec(name="fgt", type="FGT", license=rec.LicenseSpec(mode="AUTO"))
    changed = rec._ensure_license(None, 1, nd, 50, lambda m: None)
    assert changed is True and calls["mode"] == "AUTO"


def test_ensure_license_noop_when_mode_matches(monkeypatch):
    monkeypatch.setattr(rec.fa, "get_vm_license_mode", lambda c, fid, vid: {"mode": "AUTO"})
    monkeypatch.setattr(rec.fa, "set_vm_license_mode",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("set when unchanged")))
    nd = rec.NodeSpec(name="fgt", type="FGT", license=rec.LicenseSpec(mode="AUTO"))
    assert rec._ensure_license(None, 1, nd, 50, lambda m: None) is False


def test_ensure_license_none_node_is_noop(monkeypatch):
    monkeypatch.setattr(rec.fa, "get_vm_license_mode",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("queried license")))
    nd = rec.NodeSpec(name="lxc", type="LXC")          # no license declared
    assert rec._ensure_license(None, 1, nd, 50, lambda m: None) is False


def test_ensure_license_imports_file_then_sets_mode(monkeypatch, tmp_path):
    lic = tmp_path / "fgt.lic"; lic.write_text("LICENSE")
    imported = {}
    monkeypatch.setattr(rec.fa, "list_fs_licenses", lambda c: [])
    def _imp(c, p):
        imported["path"] = p
        return {"name": "FGVM999", "id": 9}
    monkeypatch.setattr(rec.fa, "import_fs_license", _imp)
    monkeypatch.setattr(rec.fa, "get_vm_license_mode", lambda c, fid, vid: {"mode": "NONE"})
    monkeypatch.setattr(rec.fa, "set_vm_license_mode", lambda c, fid, vid, mode: None)
    nd = rec.NodeSpec(name="fgt", type="FGT",
                      license=rec.LicenseSpec(mode="AUTO", file=str(lic)))
    changed = rec._ensure_license(None, 1, nd, 50, lambda m: None)
    assert changed is True and imported["path"] == str(lic)


def test_parse_license_flex_guest_valid():
    """Parse valid FLEX-GUEST license."""
    lic = rec._parse_license({
        "mode": "flex-guest",
        "flex_config": 29529,
        "redeem": {"api": "soar"},
    })
    assert lic.is_guest_redeem() is True
    assert lic.fs_mode() == "NONE"
    assert lic.redeem.api == "soar"


def test_parse_license_flex_guest_requires_flex_config():
    """FLEX-GUEST requires flex_config."""
    with pytest.raises(ValueError, match="requires flex_config"):
        rec._parse_license({
            "mode": "flex-guest",
            "redeem": {"api": "soar"},
        })


def test_parse_license_flex_guest_requires_redeem():
    """FLEX-GUEST requires redeem block."""
    with pytest.raises(ValueError, match="requires redeem"):
        rec._parse_license({
            "mode": "flex-guest",
            "flex_config": 29529,
        })




def test_license_spec_is_guest_redeem():
    """LicenseSpec.is_guest_redeem() checks for FLEX-GUEST mode."""
    guest = rec.LicenseSpec(mode="FLEX-GUEST", flex_config=29529,
                            redeem={"api": "soar"})
    assert guest.is_guest_redeem() is True

    auto = rec.LicenseSpec(mode="AUTO")
    assert auto.is_guest_redeem() is False


def test_license_spec_fs_mode():
    """LicenseSpec.fs_mode() converts FLEX-GUEST → NONE."""
    guest = rec.LicenseSpec(mode="FLEX-GUEST", flex_config=29529,
                            redeem={"api": "soar"})
    assert guest.fs_mode() == "NONE"

    auto = rec.LicenseSpec(mode="AUTO")
    assert auto.fs_mode() == "AUTO"

    none = rec.LicenseSpec(mode="NONE")
    assert none.fs_mode() == "NONE"


def test_ensure_license_flex_guest_sets_fs_mode_none(monkeypatch):
    """_ensure_license for FLEX-GUEST sets FS mode to NONE (no pool seeding)."""
    # Start with AUTO mode so we'll detect the change to NONE.
    monkeypatch.setattr(rec.fa, "get_vm_license_mode", lambda c, fid, vid: {"mode": "AUTO"})
    calls = {}
    def mock_set_vm_license_mode(c, fid, vid, mode):
        calls["mode"] = mode
    monkeypatch.setattr(rec.fa, "set_vm_license_mode", mock_set_vm_license_mode)
    # Mock that flex pool isn't called (the big one for FLEX-GUEST skipping).
    monkeypatch.setattr(rec.fa, "set_flex_pool",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("pool set for guest-redeem")))
    nd = rec.NodeSpec(name="soar", type="SOAR",
                      license=rec.LicenseSpec(mode="FLEX-GUEST", flex_config=29529,
                                              redeem={"api": "soar"}))
    changed = rec._ensure_license(None, 1, nd, 50, lambda m: None)
    assert changed is True and calls.get("mode") == "NONE"


def test_parse_ready_minimal():
    """Parse minimal ready: block (product defaults to node type)."""
    spec = rec._parse_ready({}, "SOAR")
    assert spec is not None
    assert spec.product == "soar"
    assert spec.timeout_s == 600


def test_parse_ready_with_overrides():
    """Parse ready: block with explicit product and timeout."""
    spec = rec._parse_ready(
        {"product": "fgt", "https": "https://localhost:8443/", "timeout_s": 300},
        "FGT",
    )
    assert spec.product == "fgt"
    assert spec.https == "https://localhost:8443/"
    assert spec.timeout_s == 300


def test_parse_ready_none_returns_none():
    """Parse None ready: returns None."""
    spec = rec._parse_ready(None, "SOAR")
    assert spec is None


def test_node_ready_parsed_on_intent():
    """ready: field is parsed on node intent."""
    intent = rec.parse_intent({
        "fabric": "f",
        "networks": [{"name": "n", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "s", "auto_address": "n"}],
        "nodes": [{
            "name": "soar", "type": "SOAR", "firmware": 858,
            "ready": {"timeout_s": 300},
            "links": [{"port": "eth0", "switch": "s"}],
        }],
    })
    assert intent.nodes[0].ready is not None
    assert intent.nodes[0].ready.product == "soar"
    assert intent.nodes[0].ready.timeout_s == 300


# ── Firmware auto-selection (no firmware/image → latest usable) ───────────────

def _fw(id, path, repo, size, status="ready", vm_type="FGT", is_diff=False):
    return {"id": id, "path": path, "size": size, "status": status,
            "vm_type": vm_type, "is_diff": is_diff, "repository": {"name": repo}}


def test_firmware_sort_key_orders_version_build_and_ga():
    latest = _fw(1, "FGT_VM64_KVM-v7.6.6.M-build3652-FORTINET.out.kvm.zip", "fortinet", 1)
    older = _fw(2, "FGT_VM64_KVM-v7.6.4.F-build3596-FORTINET.out.kvm.zip", "fortinet", 1)
    beta = _fw(3, "FGT_VM64_KVM-v7.6.6Beta1-build3600-FORTINET.out.kvm.zip", "beta", 1)
    ranked = sorted([older, beta, latest], key=rec._firmware_sort_key)
    assert ranked[-1]["id"] == 1            # 7.6.6 GA is latest
    assert ranked[0]["id"] == 3            # Beta sorts below GA


def test_auto_select_prefers_usable_home_over_remote(monkeypatch):
    rows = [
        _fw(850, "FGT_VM64_KVM-v7.6.4.F-build3596.zip", "home", 0),          # 0-byte stub (skip)
        _fw(800, "FGT_VM64_KVM-v7.6.2.F-build3462.zip", "home", 5000),       # usable home (older)
        _fw(814, "FGT_VM64_KVM-v7.6.6.M-build3652.zip", "fortinet", 9000),   # newer, but remote
    ]
    monkeypatch.setattr(rec.fa, "list_all_firmwares", lambda c, vm_type=None: rows)
    assert rec._auto_select_firmware(None, "FGT") == 800    # home wins even though older


def test_auto_select_falls_back_to_latest_remote(monkeypatch):
    rows = [
        _fw(850, "FGT_VM64_KVM-v7.6.4.F-build3596.zip", "home", 0),          # only home entry is a stub
        _fw(234, "FGT_VM64_KVM-v7.6.4.F-build3596.zip", "fortinet", 8000),
        _fw(814, "FGT_VM64_KVM-v7.6.6.M-build3652.zip", "fortinet", 9000),   # latest
    ]
    monkeypatch.setattr(rec.fa, "list_all_firmwares", lambda c, vm_type=None: rows)
    assert rec._auto_select_firmware(None, "FGT") == 814    # latest across repos


def test_auto_select_none_when_no_usable(monkeypatch):
    monkeypatch.setattr(rec.fa, "list_all_firmwares",
                        lambda c, vm_type=None: [_fw(850, "x.zip", "home", 0)])
    assert rec._auto_select_firmware(None, "FGT") is None   # only a 0-byte stub


def test_resolve_firmware_id_auto_selects_when_unset(monkeypatch):
    monkeypatch.setattr(rec.fa, "list_all_firmwares",
                        lambda c, vm_type=None: [_fw(814, "FGT-v7.6.6-build3652.zip", "fortinet", 9000)])
    nd = rec.NodeSpec(name="fgt", type="FGT")               # no firmware, no image
    assert rec._resolve_firmware_id(None, nd) == 814


def test_auto_select_picks_real_newest_soar_despite_bogus_patch(monkeypatch):
    # Real FS SOAR rows (live-observed): every row reports patch=1 regardless of
    # the true version, and the path has no ``v`` or ``build`` token, so the old
    # path-only sort key parsed them all to (0,0,0,0) and ``max`` picked an
    # arbitrary one. The real newest here is the 7.6.6 image (1250), not the
    # first-listed 7.6.5 (1245).
    rows = [
        {"id": 1245, "vm_type": "SOAR", "is_diff": False, "size": 1,
         "version_s": "fortisoar-7-6-5-Jan-15-26-ztp-updated", "build": 5275,
         "path": "firmwares/fortisoar-7-6-5-Jan-15-26-ztp-updated",
         "repository": {"name": "home"}},
        {"id": 1250, "vm_type": "SOAR", "is_diff": False, "size": 1,
         "version_s": "FSR-7.6.6-decouple-may21-26", "build": 5275,
         "path": "firmwares/FSR-7.6.6-decouple-may21-26",
         "repository": {"name": "home"}},
    ]
    monkeypatch.setattr(rec.fa, "list_all_firmwares", lambda c, vm_type=None: rows)
    assert rec._auto_select_firmware(None, "SOAR") == 1250


def test_auto_select_raises_on_tie(monkeypatch):
    """Two firmwares with the same version → tie → raise, not arbitrary pick."""
    rows = [
        {"id": 100, "vm_type": "LXC", "is_diff": False, "size": 1,
         "name": "rocky9-7.6.qcow2", "version_s": "",
         "path": "firmwares/rocky9-7.6.qcow2",
         "repository": {"name": "home"}},
        {"id": 200, "vm_type": "LXC", "is_diff": False, "size": 1,
         "name": "rocky9-7.6-alt.qcow2", "version_s": "",
         "path": "firmwares/rocky9-7.6-alt.qcow2",
         "repository": {"name": "home"}},
    ]
    monkeypatch.setattr(rec.fa, "list_all_firmwares", lambda c, vm_type=None: rows)
    import pytest as _pytest
    with _pytest.raises(rec.fa.FabricStudioAdminError, match="tie at the same version"):
        rec._auto_select_firmware(None, "LXC")


def test_auto_select_tie_message_suggests_filename(monkeypatch):
    """The tie error message should show filenames and suggest pinning by name."""
    rows = [
        {"id": 100, "vm_type": "LXC", "is_diff": False, "size": 1,
         "name": "rocky9-7.6.qcow2", "version_s": "",
         "path": "firmwares/rocky9-7.6.qcow2",
         "repository": {"name": "home"}},
        {"id": 200, "vm_type": "LXC", "is_diff": False, "size": 1,
         "name": "rocky9-7.6-alt.qcow2", "version_s": "",
         "path": "firmwares/rocky9-7.6-alt.qcow2",
         "repository": {"name": "home"}},
    ]
    monkeypatch.setattr(rec.fa, "list_all_firmwares", lambda c, vm_type=None: rows)
    import pytest as _pytest
    with _pytest.raises(rec.fa.FabricStudioAdminError) as exc_info:
        rec._auto_select_firmware(None, "LXC")
    msg = str(exc_info.value)
    assert "rocky9-7.6.qcow2" in msg
    assert "image:" in msg
    assert "avoid numeric IDs" in msg


def test_resolve_firmware_id_warns_on_zero_byte_stub(monkeypatch):
    """Pinning image: to a 0-byte stub firmware → raise at plan time, not rc 254
    at install."""
    monkeypatch.setattr(rec.fa, "list_home_firmwares", lambda c: [
        {"id": 999, "name": "rocky9-base.qcow2", "path": "firmwares/rocky9-base.qcow2",
         "size": 0},
    ])
    nd = rec.NodeSpec(name="h", type="LXC", image="rocky9-base.qcow2")
    import pytest as _pytest
    with _pytest.raises(rec.fa.FabricStudioAdminError, match="0-byte stub"):
        rec._resolve_firmware_id(object(), nd)


def test_resolve_firmware_id_warns_on_zero_byte_numeric_id(monkeypatch):
    """Pinning image: <numeric_id> to a 0-byte stub → same warning."""
    monkeypatch.setattr(rec.fa, "list_home_firmwares", lambda c: [
        {"id": 42, "name": "stub.qcow2", "path": "firmwares/stub.qcow2", "size": 0},
    ])
    nd = rec.NodeSpec(name="h", type="LXC", image=42)
    import pytest as _pytest
    with _pytest.raises(rec.fa.FabricStudioAdminError, match="0-byte stub"):
        rec._resolve_firmware_id(object(), nd)


# ── provision_config plan drift ───────────────────────────────────────────────
#
# These tests verify that _plan_node_resources emits a (reinstall) Change iff
# something is actually out of sync, and does NOT emit one when bytes+link match.
# They drive _plan_node_resources directly with monkeypatched fs_admin calls so no
# live pod is needed.

def _make_plan_node_resources_harness(monkeypatch, tmp_path,
                                      conf_bytes: bytes,
                                      remote_bytes: bytes | None,
                                      vm_config_id: int | None,
                                      config_id: int = 42,
                                      vm_type: str = "LXC"):
    """Build the monkeypatched environment for _plan_node_resources provision_config tests.

    Returns (plan, nd, cur) ready to pass to rec._plan_node_resources(c, plan, nd, cur, fid=1).
    """
    conf_file = tmp_path / "soc_netbox.conf"
    conf_file.write_bytes(conf_bytes)

    monkeypatch.setattr(rec.fa, "get_vm_parameters", lambda c, vid: {"cpu_count": 2, "memory": 2048})
    monkeypatch.setattr(rec.fa, "list_vm_disks", lambda c, vid: [])
    monkeypatch.setattr(rec.fa, "list_vm_accesses", lambda c, fid, vid: [])
    monkeypatch.setattr(rec.fa, "list_port_redirects", lambda c, fid: [])
    monkeypatch.setattr(rec.fa, "list_device_configs", lambda c, fid: (
        [{"id": config_id, "name": "soc_netbox.conf", "vm_type": vm_type}]
        if remote_bytes is not None else []
    ))
    if remote_bytes is not None:
        monkeypatch.setattr(rec.fa, "export_device_config",
                            lambda c, cid: remote_bytes if str(cid) == str(config_id) else b"")
    monkeypatch.setattr(rec.fa, "get_vm_license_mode", lambda c, fid, vid: None)

    nd = rec.NodeSpec(name="netbox", type=vm_type, firmware=865,
                      provision_config=str(conf_file))
    cur = {"id": 99, "name": "netbox", "config": vm_config_id}
    p = rec.Plan()
    return p, nd, cur


def test_provision_config_noop_when_bytes_match_and_vm_linked(monkeypatch, tmp_path):
    """Bytes match + VM config points at the right id → no reinstall."""
    payload = b"set hostname netbox\n"
    p, nd, cur = _make_plan_node_resources_harness(
        monkeypatch, tmp_path,
        conf_bytes=payload, remote_bytes=payload,
        vm_config_id=42,
    )
    rec._plan_node_resources(object(), p, nd, cur, fid=1)
    reinstalls = [c for c in p.changes if c.reinstall]
    assert reinstalls == [], f"unexpected reinstall: {reinstalls}"


def test_provision_config_flags_reinstall_when_bytes_differ(monkeypatch, tmp_path):
    """Local file changed → bytes differ → (reinstall) emitted."""
    p, nd, cur = _make_plan_node_resources_harness(
        monkeypatch, tmp_path,
        conf_bytes=b"set hostname netbox-new\n",
        remote_bytes=b"set hostname netbox-old\n",
        vm_config_id=42,
    )
    rec._plan_node_resources(object(), p, nd, cur, fid=1)
    reinstalls = [c for c in p.changes if c.reinstall]
    assert len(reinstalls) == 1


def test_provision_config_relink_only_when_vm_not_linked(monkeypatch, tmp_path):
    """Bytes match but FS cleared vm.config after install → re-link only, no reinstall."""
    payload = b"set hostname netbox\n"
    p, nd, cur = _make_plan_node_resources_harness(
        monkeypatch, tmp_path,
        conf_bytes=payload, remote_bytes=payload,
        vm_config_id=None,  # FS cleared the link post-install
    )
    rec._plan_node_resources(object(), p, nd, cur, fid=1)
    reinstalls = [c for c in p.changes if c.reinstall]
    relinks = [c for c in p.changes if c.kind == "config_link"]
    assert len(reinstalls) == 0, "content correct -- no reinstall expected"
    assert len(relinks) == 1, "broken link should produce a re-link change"


def test_provision_config_flags_reinstall_when_no_remote_config(monkeypatch, tmp_path):
    """No deviceconfig in FS at all → (reinstall) emitted."""
    p, nd, cur = _make_plan_node_resources_harness(
        monkeypatch, tmp_path,
        conf_bytes=b"set hostname netbox\n",
        remote_bytes=None,  # no deviceconfig in FS
        vm_config_id=None,
    )
    rec._plan_node_resources(object(), p, nd, cur, fid=1)
    reinstalls = [c for c in p.changes if c.reinstall]
    assert len(reinstalls) == 1


# ── Prune protection (Terraform prevent_destroy) ─────────────────────────────

def _prune_harness(monkeypatch):
    """Canned live state with: one undeclared normal net/switch/vm (should
    prune), a seeded shared 'OOB Mgmt' net (protected by name), and an
    intent-declared 'keepme' net marked protected: true. Returns the captured
    delete calls."""
    deleted = {"nets": [], "switches": [], "vms": []}
    state = {
        "vms": [
            {"id": 1, "name": "stray-vm"},         # undeclared → prune
            {"id": 2, "name": "keep-vm"},          # intent protected: true → keep
        ],
        "switches": [
            {"id": 10, "name": "Internet", "vm_type": "SW"},      # seeded → keep
            {"id": 11, "name": "stray-sw", "vm_type": "SW"},      # undeclared → prune
        ],
        "networks": [
            {"id": 20, "name": "OOB Mgmt"},   # seeded shared → keep
            {"id": 21, "name": "keepme"},     # intent protected: true → keep
            {"id": 22, "name": "stray-net"},  # undeclared → prune
        ],
    }
    monkeypatch.setattr(rec.fa, "read_fabric_state", lambda c, fid: state)
    monkeypatch.setattr(rec.fa, "get_vm_runtime_state",
                        lambda c, vid: {"exists": False})
    monkeypatch.setattr(rec.fa, "delete_network",
                        lambda c, fid, nid: deleted["nets"].append(nid))
    monkeypatch.setattr(rec.fa, "delete_switch",
                        lambda c, fid, sid: deleted["switches"].append(sid))
    monkeypatch.setattr(rec.fa, "delete_vm",
                        lambda c, fid, vid: deleted["vms"].append(vid))
    return deleted


def test_prune_keeps_seeded_and_protected_deletes_undeclared(monkeypatch):
    deleted = _prune_harness(monkeypatch)
    intent = rec.parse_intent({
        "fabric": "topo-x",
        "networks": [{"name": "keepme", "cidr": "10.0.0.0/24", "protected": True}],
        "nodes": [{"name": "keep-vm", "type": "BASIC", "protected": True}],
    })
    rec._prune(object(), 1, intent, vm_id={}, sw_id={}, net_id={}, _say=lambda m: None)
    # seeded 'Internet' switch + 'OOB Mgmt' net kept; intent-protected 'keepme' +
    # 'keep-vm' kept. Only stray-sw, stray-net, stray-vm pruned.
    assert deleted["switches"] == [11]          # only stray-sw
    assert deleted["nets"] == [22]              # only stray-net
    assert deleted["vms"] == [1]               # only stray-vm


def test_prune_vm_error_tolerant(monkeypatch):
    """A stuck VM destroy logs and continues -- doesn't abort before switches/nets."""
    deleted = _prune_harness(monkeypatch)
    # Make the first VM's runtime destroy blow up.
    monkeypatch.setattr(rec.fa, "get_vm_runtime_state",
                        lambda c, vid: {"exists": True})
    monkeypatch.setattr(rec.fa, "destroy_vm",
                        lambda c, vid: (_ for _ in ()).throw(RuntimeError("stuck")))
    intent = rec.parse_intent({"fabric": "topo-x"})
    rec._prune(object(), 1, intent, vm_id={}, sw_id={}, net_id={}, _say=lambda m: None)
    # VM 1 failed (not in deleted), but switches + nets still pruned.
    assert deleted["vms"] == []
    assert deleted["switches"] == [11]
    assert deleted["nets"] == [21, 22]  # both non-seeded nets (no intent protection)


def test_parse_intent_protected_fields():
    intent = rec.parse_intent({
        "fabric": "t",
        "networks": [{"name": "n1", "cidr": "10.0.0.0/24", "protected": True}],
        "switches": [{"name": "s1", "protected": True}],
        "nodes": [{"name": "v1", "type": "BASIC", "protected": True}],
    })
    assert intent.networks[0].protected is True
    assert intent.switches[0].protected is True
    assert intent.nodes[0].protected is True


def test_is_protected_name_collapses_internal_whitespace():
    # 'OOB  Mgmt' (double space) must still match the 'oob mgmt' allowlist --
    # else a seeded shared net could be pruned on a multi-tenant pod.
    assert rec._is_protected_name("OOB  Mgmt", set()) is True
    assert rec._is_protected_name("  Internet  Access  ", set()) is True
    assert rec._is_protected_name("my-net", set()) is False
    assert rec._is_protected_name("Keep  Me", {"keep me"}) is True


# ── use: presets ─────────────────────────────────────────────────────────────

def test_use_preset_injects_protected_seeded_blocks():
    i = rec.parse_intent({"fabric": "t", "use": ["oob-mgmt", "internet-egress"]})
    by_name = {n.name: n for n in i.networks}
    # The NETWORK is "Internet" and the SWITCH is "Internet Access" -- FS's own
    # asymmetric seeding (see PRESETS). The preset used to mint a *second*
    # network named "Internet Access" on the seeded net's subnet, which is what
    # black-holed fortiaigate_lab's egress segment; `_lint_topology` now refuses
    # that shape, so the preset must not reintroduce it.
    assert set(by_name) == {"OOB Mgmt", "Internet"}
    assert all(n.protected for n in i.networks)
    egress = next(s for s in i.switches if s.name == "Internet Access")
    assert egress.auto_address == "Internet"
    assert egress.role == "egress" and egress.host_uplink is True and egress.protected
    # The egress preset MUST carry DNS: a FortiFlex guest needs to resolve
    # FortiCare to activate, else it boots eval/limited (flex-activation gate).
    assert by_name["Internet"].dns1, "internet-egress preset needs dns1 for flex activation"


def test_use_preset_explicit_declaration_wins():
    i = rec.parse_intent({
        "fabric": "t", "use": ["oob-mgmt"],
        "networks": [{"name": "OOB Mgmt", "cidr": "10.0.0.0/24", "gateway": "10.0.0.1"}],
        "switches": [{"name": "OOB Mgmt", "auto_address": "OOB Mgmt"}],
    })
    assert len(i.networks) == 1
    assert i.networks[0].cidr == "10.0.0.0/24"   # explicit value preserved


def test_use_unknown_preset_raises():
    with pytest.raises(ValueError, match="unknown preset"):
        rec.parse_intent({"fabric": "t", "use": ["nope"]})


def test_use_string_form_accepted():
    i = rec.parse_intent({"fabric": "t", "use": "oob-mgmt"})
    assert [n.name for n in i.networks] == ["OOB Mgmt"]


# ── T8: count / for_each node fan-out ────────────────────────────────────────

def _fan_out_intent(**node_opts):
    """Minimal intent with a node that can carry count/for_each options."""
    return {
        "fabric": "f",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "s", "auto_address": "mgmt"}],
        "nodes": [{"name": "h", "type": "LXC", "firmware": 1,
                   "links": [{"port": "eth0", "switch": "s"}],
                   **node_opts}],
    }


def test_count_expansion_creates_n_copies_with_index_substitution():
    """count: 3 → 3 nodes with 0-based indices substituted into ${count.index}."""
    intent = rec.parse_intent(_fan_out_intent(count=3, name="h-${count.index}"))
    assert len(intent.nodes) == 3
    assert [n.name for n in intent.nodes] == ["h-0", "h-1", "h-2"]
    # Verify count/for_each are cleared after expansion.
    assert all(n.count is None and n.for_each is None for n in intent.nodes)


def test_count_expansion_substitutes_into_links_access_expose():
    """count substitution reaches into links, access, and expose."""
    intent = rec.parse_intent(_fan_out_intent(
        count=2,
        name="h-${count.index}",
        links=[{"port": "eth${count.index}", "switch": "s"}],
        access=["SSH", "HTTP-${count.index}"],
        expose=[{"port": 8080, "from_port": 8000 + 10}],  # expose.from_port stays fixed
    ))
    assert intent.nodes[0].links[0].port == "eth0"
    assert intent.nodes[1].links[0].port == "eth1"
    assert intent.nodes[0].access == ["SSH", "HTTP-0"]
    assert intent.nodes[1].access == ["SSH", "HTTP-1"]


def test_count_validation_rejects_non_integer():
    """count: must be an integer."""
    with pytest.raises(ValueError, match="count must be an integer"):
        rec.parse_intent(_fan_out_intent(count="three"))


def test_count_validation_rejects_zero_and_negative():
    """count: must be positive."""
    with pytest.raises(ValueError, match="count must be a positive integer"):
        rec.parse_intent(_fan_out_intent(count=0))
    with pytest.raises(ValueError, match="count must be a positive integer"):
        rec.parse_intent(_fan_out_intent(count=-1))


def test_for_each_expansion_creates_one_copy_per_dict_entry():
    """for_each: {key1: val1, key2: val2} → 2 nodes with key/value substituted."""
    intent = rec.parse_intent(_fan_out_intent(
        for_each={"prod": "production", "dev": "development"},
        name="h-${each.key}"
    ))
    assert len(intent.nodes) == 2
    # Dict order depends on insertion order (Python 3.7+).
    names = [n.name for n in intent.nodes]
    assert set(names) == {"h-prod", "h-dev"}


def test_for_each_substitutes_into_all_fields():
    """for_each substitutes ${each.key} and ${each.value} into all fields."""
    intent = rec.parse_intent(_fan_out_intent(
        for_each={"a": "apple", "b": "banana"},
        name="h-${each.key}",
        links=[{"port": "eth${each.key}", "switch": "s"}],
        access=["SSH-${each.value}"],
    ))
    a_node = next(n for n in intent.nodes if "a" in n.name)
    b_node = next(n for n in intent.nodes if "b" in n.name)
    assert a_node.links[0].port == "etha"
    assert b_node.links[0].port == "ethb"
    assert a_node.access == ["SSH-apple"]
    assert b_node.access == ["SSH-banana"]


def test_for_each_validation_rejects_non_dict():
    """for_each: must be a dict."""
    with pytest.raises(ValueError, match="for_each must be a dict"):
        rec.parse_intent(_fan_out_intent(for_each=["item1", "item2"]))


def test_count_and_for_each_mutually_exclusive():
    """A node cannot have both count and for_each."""
    with pytest.raises(ValueError, match="count and for_each are mutually exclusive"):
        rec.parse_intent(_fan_out_intent(count=2, for_each={"a": 1}))


def test_expanded_nodes_have_count_for_each_cleared():
    """After expansion, count and for_each are None."""
    intent = rec.parse_intent(_fan_out_intent(count=2))
    for node in intent.nodes:
        assert node.count is None
        assert node.for_each is None


def test_node_without_count_for_each_passes_unchanged():
    """A node with neither count nor for_each is not expanded."""
    intent = rec.parse_intent(_fan_out_intent(name="lonely"))
    assert len(intent.nodes) == 1
    assert intent.nodes[0].name == "lonely"


def test_count_expansion_with_empty_name_still_interpolates():
    """Even an empty name is interpolated (${count.index} alone becomes a digit)."""
    intent = rec.parse_intent(_fan_out_intent(
        count=3,
        name="${count.index}",  # name is just the index
    ))
    assert [n.name for n in intent.nodes] == ["0", "1", "2"]


def test_for_each_with_numeric_values_converts_to_string():
    """for_each values are converted to strings for substitution."""
    intent = rec.parse_intent(_fan_out_intent(
        for_each={"port_8080": 8080, "port_9090": 9090},
        name="server-${each.key}",
    ))
    # Verify the name substitution worked (keys were properly substituted).
    names = sorted(n.name for n in intent.nodes)
    assert names == ["server-port_8080", "server-port_9090"]


def test_config_references_base_node_name_before_expansion():
    """Config items reference the base (pre-expansion) node name."""
    intent = rec.parse_intent({
        "fabric": "f",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "s", "auto_address": "mgmt"}],
        "nodes": [{"name": "h", "type": "LXC", "firmware": 1, "count": 2,
                   "links": [{"port": "eth0", "switch": "s"}]}],
        "config": [{"node": "h", "commands": ["echo hi"]}],
    })
    # The config item references "h", which is the base name (before expansion).
    # After expansion, we have h-0 and h-1, but the config references the base "h".
    # This test verifies that no error is raised during parsing.
    # (The config application logic would need to handle matching "h" to ["h-0", "h-1"].)
    assert len(intent.nodes) == 2
    assert intent.config[0].node == "h"


def test_healthchecks_reference_base_node_name():
    """Healthcheck items reference base node names (pre-expansion)."""
    intent = rec.parse_intent({
        "fabric": "f",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "s", "auto_address": "mgmt"}],
        "nodes": [{"name": "h", "type": "FGT", "firmware": 1, "count": 2,
                   "links": [{"port": "eth0", "switch": "s"}]}],
        "healthchecks": [{"node": "h", "checks": ["ping"]}],
    })
    # Similar to config: the healthcheck references the base name.
    assert len(intent.nodes) == 2
    assert intent.healthchecks[0].node == "h"


# ── ignore_changes (T10) ─────────────────────────────────────────────────────

def test_parse_intent_ignore_changes_empty_default():
    """ignore_changes defaults to an empty list."""
    intent = rec.parse_intent({
        "fabric": "f",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "s", "auto_address": "mgmt"}],
        "nodes": [{"name": "n", "type": "LXC", "firmware": 1,
                   "links": [{"port": "eth0", "switch": "s"}]}],
    })
    assert intent.nodes[0].ignore_changes == []


def test_parse_intent_ignore_changes_list_of_strings():
    """ignore_changes accepts a list of field names."""
    intent = rec.parse_intent({
        "fabric": "f",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "s", "auto_address": "mgmt"}],
        "nodes": [{"name": "n", "type": "LXC", "firmware": 1,
                   "links": [{"port": "eth0", "switch": "s"}],
                   "ignore_changes": ["cpu", "memory", "disk"]}],
    })
    assert intent.nodes[0].ignore_changes == ["cpu", "memory", "disk"]


def test_parse_intent_ignore_changes_unknown_fields_tolerated():
    """ignore_changes allows unknown field names (future-proofing)."""
    intent = rec.parse_intent({
        "fabric": "f",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "s", "auto_address": "mgmt"}],
        "nodes": [{"name": "n", "type": "LXC", "firmware": 1,
                   "links": [{"port": "eth0", "switch": "s"}],
                   "ignore_changes": ["cpu", "future_field", "memory"]}],
    })
    assert intent.nodes[0].ignore_changes == ["cpu", "future_field", "memory"]


def test_parse_intent_ignore_changes_rejects_non_string_items():
    """ignore_changes must contain only strings."""
    import pytest
    with pytest.raises(ValueError) as exc_info:
        rec.parse_intent({
            "fabric": "f",
            "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
            "switches": [{"name": "s", "auto_address": "mgmt"}],
            "nodes": [{"name": "n", "type": "LXC", "firmware": 1,
                       "links": [{"port": "eth0", "switch": "s"}],
                       "ignore_changes": ["cpu", 123, "memory"]}],
        })
    assert "ignore_changes must be a list of strings" in str(exc_info.value)


def test_parse_intent_ignore_changes_all_valid_field_names():
    """ignore_changes accepts all documented resource field names."""
    # Test with all known resource fields that can be ignored.
    intent = rec.parse_intent({
        "fabric": "f",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24"}],
        "switches": [{"name": "s", "auto_address": "mgmt"}],
        "nodes": [{"name": "n", "type": "FGT", "firmware": 1,
                   "links": [{"port": "eth0", "switch": "s"}],
                   "ignore_changes": ["cpu", "memory", "disk", "access", "expose",
                                    "provision_config", "license"]}],
    })
    assert set(intent.nodes[0].ignore_changes) == {
        "cpu", "memory", "disk", "access", "expose", "provision_config", "license"
    }


def test_plan_node_resources_ignores_cpu_when_listed(monkeypatch):
    """plan_node_resources skips cpu drift when cpu is in ignore_changes."""
    from unittest.mock import MagicMock

    # Mock FS client and its methods
    c = MagicMock()
    p = rec.Plan()

    # Mock VM parameters: current=4, target would be 8, but cpu is ignored
    monkeypatch.setattr(rec.fa, "get_vm_parameters",
                       lambda *a, **k: {"cpu_count": "4", "memory": "4096"})
    monkeypatch.setattr(rec.fa, "list_vm_disks", lambda *a, **k: [])
    monkeypatch.setattr(rec.fa, "list_vm_accesses", lambda *a, **k: [])

    nd = rec.NodeSpec(
        name="test-vm", type="FGT", firmware=1,
        cpu=8,  # wants 8, but will be ignored
        ignore_changes=["cpu"]
    )
    cur = {"id": 123}

    rec._plan_node_resources(c, p, nd, cur, fid=456)

    # No cpu Change should be appended
    cpu_changes = [ch for ch in p.changes if "cpu" in ch.detail]
    assert len(cpu_changes) == 0


def test_plan_node_resources_ignores_memory_when_listed(monkeypatch):
    """plan_node_resources skips memory drift when memory is in ignore_changes."""
    from unittest.mock import MagicMock

    c = MagicMock()
    p = rec.Plan()

    monkeypatch.setattr(rec.fa, "get_vm_parameters",
                       lambda *a, **k: {"cpu_count": "4", "memory": "2048"})
    monkeypatch.setattr(rec.fa, "list_vm_disks", lambda *a, **k: [])
    monkeypatch.setattr(rec.fa, "list_vm_accesses", lambda *a, **k: [])

    nd = rec.NodeSpec(
        name="test-vm", type="FGT", firmware=1,
        memory=8192,  # wants 8192, but will be ignored
        ignore_changes=["memory"]
    )
    cur = {"id": 123}

    rec._plan_node_resources(c, p, nd, cur, fid=456)

    # No memory Change should be appended
    mem_changes = [ch for ch in p.changes if "memory" in ch.detail]
    assert len(mem_changes) == 0


def test_plan_node_resources_ignores_disk_when_listed(monkeypatch):
    """plan_node_resources skips disk drift when disk is in ignore_changes."""
    from unittest.mock import MagicMock

    c = MagicMock()
    p = rec.Plan()

    # Mock disks: firmware disk with declared=2048 but only capacity=1024
    disk_row = {"id": 1, "name": "data", "declared": "2048", "capacity": "1024", "extra": False}

    monkeypatch.setattr(rec.fa, "get_vm_parameters",
                       lambda *a, **k: {"cpu_count": "4", "memory": "4096"})
    monkeypatch.setattr(rec.fa, "list_vm_disks", lambda *a, **k: [disk_row])
    monkeypatch.setattr(rec.fa, "list_vm_accesses", lambda *a, **k: [])

    nd = rec.NodeSpec(
        name="test-vm", type="FGT", firmware=1,
        ignore_changes=["disk"]
    )
    cur = {"id": 123}

    rec._plan_node_resources(c, p, nd, cur, fid=456)

    # No disk Changes should be appended
    disk_changes = [ch for ch in p.changes if ch.kind == "disk"]
    assert len(disk_changes) == 0


def test_plan_node_resources_ignores_access_when_listed(monkeypatch):
    """plan_node_resources skips access drift when access is in ignore_changes."""
    from unittest.mock import MagicMock

    c = MagicMock()
    p = rec.Plan()

    monkeypatch.setattr(rec.fa, "get_vm_parameters",
                       lambda *a, **k: {"cpu_count": "4", "memory": "4096"})
    monkeypatch.setattr(rec.fa, "list_vm_disks", lambda *a, **k: [])
    # No SSH access currently, but SSH is declared
    monkeypatch.setattr(rec.fa, "list_vm_accesses", lambda *a, **k: [])

    nd = rec.NodeSpec(
        name="test-vm", type="FGT", firmware=1,
        access=["SSH"],  # wants SSH, but will be ignored
        ignore_changes=["access"]
    )
    cur = {"id": 123}

    rec._plan_node_resources(c, p, nd, cur, fid=456)

    # No access Changes should be appended
    access_changes = [ch for ch in p.changes if ch.kind == "access"]
    assert len(access_changes) == 0


def test_plan_node_resources_respects_cpu_without_ignore_changes(monkeypatch):
    """plan_node_resources emits cpu drift when cpu is NOT in ignore_changes."""
    from unittest.mock import MagicMock

    c = MagicMock()
    p = rec.Plan()

    monkeypatch.setattr(rec.fa, "get_vm_parameters",
                       lambda *a, **k: {"cpu_count": "4", "memory": "4096"})
    monkeypatch.setattr(rec.fa, "list_vm_disks", lambda *a, **k: [])
    monkeypatch.setattr(rec.fa, "list_vm_accesses", lambda *a, **k: [])

    nd = rec.NodeSpec(
        name="test-vm", type="FGT", firmware=1,
        cpu=8,  # wants 8, and cpu NOT in ignore_changes
        ignore_changes=[]
    )
    cur = {"id": 123}

    rec._plan_node_resources(c, p, nd, cur, fid=456)

    # cpu Change SHOULD be appended
    cpu_changes = [ch for ch in p.changes if "cpu" in ch.detail]
    assert len(cpu_changes) == 1
    assert "4→8" in cpu_changes[0].detail


# ── Plan serialization (T3) ──────────────────────────────────────────────────

def test_change_to_dict():
    """Change.to_dict() produces a JSON-serializable dict."""
    c = rec.Change(op="create", kind="network", name="mgmt", detail="10.0.0.0/24")
    d = c.to_dict()
    assert d == {
        "op": "create",
        "kind": "network",
        "name": "mgmt",
        "detail": "10.0.0.0/24",
        "reinstall": False,
    }


def test_change_from_dict():
    """Change.from_dict() round-trips with to_dict()."""
    original = rec.Change(op="update", kind="node", name="n1", detail="cpu 2→4")
    d = original.to_dict()
    restored = rec.Change.from_dict(d)
    assert restored.op == original.op
    assert restored.kind == original.kind
    assert restored.name == original.name
    assert restored.detail == original.detail


def test_change_from_dict_missing_detail():
    """Change.from_dict() handles missing detail gracefully."""
    d = {"op": "noop", "kind": "fabric", "name": "f"}
    c = rec.Change.from_dict(d)
    assert c.detail == ""


def test_plan_to_dict():
    """Plan.to_dict() includes timestamp, fabric, changes, and warnings."""
    c1 = rec.Change("create", "network", "mgmt", "10.0.0.0/24")
    c2 = rec.Change("noop", "fabric", "test-fabric")
    plan = rec.Plan(
        changes=[c1, c2],
        warnings=["floating switch"],
        fabric="test-fabric",
        timestamp="2026-06-24T12:00:00Z",
    )
    d = plan.to_dict()
    assert d["fabric"] == "test-fabric"
    assert d["timestamp"] == "2026-06-24T12:00:00Z"
    assert len(d["changes"]) == 2
    assert d["warnings"] == ["floating switch"]


def test_plan_from_dict_round_trip():
    """Plan.from_dict() round-trips with to_dict()."""
    original = rec.Plan(
        changes=[
            rec.Change("create", "network", "mgmt"),
            rec.Change("update", "node", "n1", "mem 2048→4096"),
        ],
        warnings=["warning 1", "warning 2"],
        fabric="my-fabric",
        timestamp="2026-06-24T13:00:00Z",
    )
    d = original.to_dict()
    restored = rec.Plan.from_dict(d)
    assert restored.fabric == original.fabric
    assert restored.timestamp == original.timestamp
    assert len(restored.changes) == len(original.changes)
    assert restored.warnings == original.warnings
    # Check first change
    assert restored.changes[0].op == "create"
    assert restored.changes[0].kind == "network"
    assert restored.changes[0].name == "mgmt"


def test_plan_auto_populates_timestamp():
    """Plan.__post_init__() auto-populates timestamp if not provided."""
    plan = rec.Plan()
    assert plan.timestamp is not None
    assert plan.timestamp.endswith("Z")
    assert "T" in plan.timestamp  # ISO format


def test_plan_from_dict_preserves_timestamp():
    """Plan.from_dict() preserves the saved timestamp (doesn't overwrite)."""
    saved_ts = "2026-01-15T10:30:45Z"
    d = {
        "timestamp": saved_ts,
        "fabric": "f",
        "changes": [],
        "warnings": [],
    }
    plan = rec.Plan.from_dict(d)
    assert plan.timestamp == saved_ts


def test_plan_changes_are_change_objects_after_from_dict():
    """Plan.from_dict() converts change dicts to Change objects."""
    d = {
        "timestamp": "2026-06-24T12:00:00Z",
        "fabric": "f",
        "changes": [
            {"op": "create", "kind": "network", "name": "mgmt", "detail": "10.0.0.0/24"},
            {"op": "noop", "kind": "fabric", "name": "f", "detail": ""},
        ],
        "warnings": [],
    }
    plan = rec.Plan.from_dict(d)
    assert len(plan.changes) == 2
    assert isinstance(plan.changes[0], rec.Change)
    assert plan.changes[0].kind == "network"
    assert isinstance(plan.changes[1], rec.Change)
    assert plan.changes[1].op == "noop"


# ── expose: integration tests ────────────────────────────────────────────────

def _expose_intent(expose_rules, node_name="n1"):
    """Build a minimal intent with one node that has expose: rules."""
    return rec.parse_intent({
        "fabric": "expose-test",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24",
                       "gateway": "198.51.100.254"}],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}],
        "nodes": [{"name": node_name, "type": "LXC", "image": 865,
                    "links": [{"port": "eth0", "switch": "mgmtsw"}],
                    "expose": expose_rules}],
    })


def _expose_apply_mocks(monkeypatch, fid=6, vid=86, port_ip="198.51.100.10",
                        existing_redirects=None):
    """Mock everything `apply()` touches so only the expose loop runs.

    Returns a list that captures every `ensure_port_redirect` call."""
    from fabric_studio.topology import images
    redirect_calls = []

    monkeypatch.setattr(rec.fa, "wait_pod_idle", lambda c: None)
    monkeypatch.setattr(images, "ensure_images", lambda c, intent, say: {})
    monkeypatch.setattr(rec.fa, "ensure_fabric",
                        lambda c, name, desc=None: {"id": fid})
    monkeypatch.setattr(rec.fa, "ensure_network",
                        lambda c, fid, *a, **k: {"id": 23, "ipv4network": "198.51.100.0",
                                                 "ipv4netmask": "255.255.255.0",
                                                 "ipv4gateway": "198.51.100.254"})
    monkeypatch.setattr(rec.fa, "update_network",
                        lambda c, fid, nid, **k: {"id": nid, **k})
    monkeypatch.setattr(rec, "_cidr_of", lambda row: "198.51.100.0/24")
    monkeypatch.setattr(rec.fa, "ensure_switch",
                        lambda c, fid, name, aa, mgmt: {"id": 85, "mgmt": mgmt,
                                                        "auto_address_network": aa})
    monkeypatch.setattr(rec.fa, "update_switch",
                        lambda c, fid, sid, **k: {"id": sid, **k})
    monkeypatch.setattr(rec.fa, "get_vm_by_name",
                        lambda c, fid, name: {"id": vid, "firmware": 1})
    monkeypatch.setattr(rec, "_resolve_firmware_id",
                        lambda c, nd, image_ids=None, declared_images=None: 1)
    monkeypatch.setattr(rec, "_apply_node_resources", lambda *a, **k: False)
    monkeypatch.setattr(rec, "_ensure_provision_config", lambda *a, **k: False)
    monkeypatch.setattr(rec.fa, "read_fabric_state",
                        lambda c, fid: {"links": [], "vms": [], "switches": [],
                                        "networks": [], "cables": [],
                                        "ports_by_id": {}, "device_by_port": {}})
    monkeypatch.setattr(rec.fa, "get_vm_ports",
                        lambda c, fid, vid: [{"id": 938, "name": "eth0",
                                              "ipv4addr": port_ip}])
    monkeypatch.setattr(rec.fa, "get_system_host", lambda c, fid: {"id": 64})
    monkeypatch.setattr(rec.fa, "ensure_public_forwards_allowed",
                        lambda c, flags: {"custom_rules_allowed": True})
    monkeypatch.setattr(rec.fa, "cable_vm_to_switch", lambda *a, **k: None)
    monkeypatch.setattr(rec.fa, "set_port_ipv4", lambda *a, **k: None)
    monkeypatch.setattr(rec.fa, "clear_port_ipv4", lambda *a, **k: None)
    monkeypatch.setattr(rec.fa, "set_port_mgmt", lambda *a, **k: None)
    monkeypatch.setattr(rec.fa, "set_vm_firmware", lambda *a, **k: None)
    monkeypatch.setattr(rec.fa, "get_vm_install_after", lambda c, vid: [])
    monkeypatch.setattr(rec.fa, "set_vm_install_after", lambda c, vid, after: None)

    def _ensure_redirect(c, fid, *, device, name, from_port, to_addr, to_port, socktype):
        redirect_calls.append({"device": device, "name": name,
                               "from_port": from_port, "to_addr": to_addr,
                               "to_port": to_port, "socktype": socktype})
        return True

    monkeypatch.setattr(rec.fa, "ensure_port_redirect", _ensure_redirect)
    monkeypatch.setattr(rec.fa, "list_port_redirects",
                        lambda c, fid: existing_redirects or [])
    monkeypatch.setattr(rec, "assert_converged", lambda *a, **k: {})

    return redirect_calls


class TestExposeApply:
    """Integration tests for the expose: apply loop in apply() (reconciler.py:2801-2837)."""

    def test_apply_creates_port_redirects_for_expose(self, monkeypatch):
        """apply() walks nd.expose and calls ensure_port_redirect for each rule."""
        calls = _expose_apply_mocks(monkeypatch)
        intent = _expose_intent([
            {"port": 8080},
            {"port": 22, "from_port": 9122, "name": "ssh"},
        ])
        rec.apply(FakeClient(), intent, boot=False)
        assert len(calls) == 2
        # First rule: bare port → from_port == to_port == 8080
        assert calls[0]["from_port"] == 8080
        assert calls[0]["to_port"] == 8080
        assert calls[0]["to_addr"] == "198.51.100.10"
        assert calls[0]["socktype"] == "TCP"
        # Second rule: custom from_port → 9122 → 22
        assert calls[1]["from_port"] == 9122
        assert calls[1]["to_port"] == 22
        assert calls[1]["name"] == "ssh"

    def test_apply_uses_correct_host_device_id(self, monkeypatch):
        """Port redirects target the System Host, not the VM's device."""
        calls = _expose_apply_mocks(monkeypatch)
        intent = _expose_intent([{"port": 8080}])
        rec.apply(FakeClient(), intent, boot=False)
        assert calls[0]["device"] == 64  # System Host id from get_system_host

    def test_apply_auto_names_redirect_when_no_name(self, monkeypatch):
        """An expose rule without a name gets an auto-generated name."""
        calls = _expose_apply_mocks(monkeypatch)
        intent = _expose_intent([{"port": 53, "proto": "UDP"}])
        rec.apply(FakeClient(), intent, boot=False)
        # Name pattern: <node>-<socktype>-<from_port>
        assert calls[0]["name"] == "n1-udp-53"

    def test_apply_skips_expose_when_no_port_ip(self, monkeypatch):
        """A node with no resolved port IP is skipped, not crashed."""
        calls = _expose_apply_mocks(monkeypatch, port_ip=None)
        intent = _expose_intent([{"port": 8080}])
        rec.apply(FakeClient(), intent, boot=False)
        assert calls == []  # no redirect created

    def test_apply_skips_nodes_without_expose(self, monkeypatch):
        """Nodes without expose: don't trigger redirect creation."""
        calls = _expose_apply_mocks(monkeypatch)
        intent = rec.parse_intent({
            "fabric": "expose-test",
            "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24",
                           "gateway": "198.51.100.254"}],
            "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}],
            "nodes": [
                {"name": "n1", "type": "LXC", "image": 865,
                 "links": [{"port": "eth0", "switch": "mgmtsw"}],
                 "expose": [{"port": 8080}]},
                {"name": "n2", "type": "LXC", "image": 865,
                 "links": [{"port": "eth0", "switch": "mgmtsw"}]},
            ],
        })
        rec.apply(FakeClient(), intent, boot=False)
        assert len(calls) == 1  # only n1, not n2

    def test_apply_enables_custom_rules_allowed(self, monkeypatch):
        """apply() flips the pod's custom_rules_allowed security flag before redirects."""
        flag_calls = []
        calls = _expose_apply_mocks(monkeypatch)
        # Override to spy on the flag call
        monkeypatch.setattr(rec.fa, "ensure_public_forwards_allowed",
                            lambda c, flags: flag_calls.append(flags) or
                            {"custom_rules_allowed": True})
        intent = _expose_intent([{"port": 8080}])
        rec.apply(FakeClient(), intent, boot=False)
        assert len(flag_calls) >= 1
        assert "custom_rules_allowed" in flag_calls[-1]

    def test_apply_prefers_declared_link_port_ip(self, monkeypatch):
        """to_addr prefers the IP of the port named in the node's first link."""
        calls = _expose_apply_mocks(monkeypatch)
        # Override get_vm_ports to return two ports with different IPs
        monkeypatch.setattr(rec.fa, "get_vm_ports",
                            lambda c, fid, vid: [
                                {"id": 1, "name": "eth0", "ipv4addr": "198.51.100.10"},
                                {"id": 2, "name": "eth1", "ipv4addr": "198.51.100.20"},
                            ])
        intent = rec.parse_intent({
            "fabric": "expose-test",
            "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24",
                           "gateway": "198.51.100.254"}],
            "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}],
            "nodes": [{"name": "n1", "type": "LXC", "image": 865,
                       "links": [{"port": "eth1", "switch": "mgmtsw"}],
                       "expose": [{"port": 8080}]}],
        })
        rec.apply(FakeClient(), intent, boot=False)
        # Should use eth1's IP (the declared link), not eth0's
        assert calls[0]["to_addr"] == "198.51.100.20"


class TestStaleOverlappingPorts:
    """A port the intent stopped declaring must not keep an address in a subnet a
    declared port still holds.

    The live failure this fixes: an FGT's AI-Users link moved port3 → port2, both
    kept 10.128.0.1, and the install died in the guest on
    ``Subnets overlap between 'port3' with primary IP of 'port2'`` / ``Command
    fail. Return code -54`` -- after the FortiGate had booted and licensed, naming
    a port the intent no longer mentions."""

    @staticmethod
    def _node(links, vm_type="FGT"):
        return rec.parse_intent({
            "fabric": "renumber-test",
            "networks": [{"name": "users", "cidr": "10.128.0.0/24",
                          "gateway": "10.128.0.254"}],
            "switches": [{"name": "userssw", "auto_address": "users"}],
            "nodes": [{"name": "n1", "type": vm_type, "firmware": 1,
                       "links": links}],
        }).nodes[0]

    def test_clears_undeclared_port_overlapping_a_declared_subnet(self):
        nd = self._node([{"port": "port2", "switch": "userssw",
                          "ip": "10.128.0.1", "netmask": "255.255.255.0"}])
        ports = {
            "port2": {"id": 497, "name": "port2", "ipv4addr": "10.128.0.1",
                      "ipv4netmask": "255.255.255.0"},
            "port3": {"id": 498, "name": "port3", "ipv4addr": "10.128.0.1",
                      "ipv4netmask": "255.255.255.0"},
        }
        assert [n for n, _ in rec._stale_overlapping_ports(nd, ports)] == ["port3"]

    def test_overlap_is_by_subnet_not_exact_address(self):
        """A different address in the same subnet overlaps too -- that is what
        FortiOS rejects, not just an exact duplicate."""
        nd = self._node([{"port": "port2", "switch": "userssw",
                          "ip": "10.128.0.1", "netmask": "255.255.255.0"}])
        ports = {
            "port2": {"id": 497, "name": "port2", "ipv4addr": "10.128.0.1",
                      "ipv4netmask": "255.255.255.0"},
            "port3": {"id": 498, "name": "port3", "ipv4addr": "10.128.0.9",
                      "ipv4netmask": "255.255.255.0"},
        }
        assert [n for n, _ in rec._stale_overlapping_ports(nd, ports)] == ["port3"]

    def test_undeclared_port_on_an_unrelated_subnet_is_left_alone(self):
        """FS auto-addresses ports at VM create, so an undeclared port that does
        not overlap is normal -- clearing it would strip a working address."""
        nd = self._node([{"port": "port2", "switch": "userssw",
                          "ip": "10.128.0.1", "netmask": "255.255.255.0"}])
        ports = {
            "port2": {"id": 497, "name": "port2", "ipv4addr": "10.128.0.1",
                      "ipv4netmask": "255.255.255.0"},
            "port1": {"id": 496, "name": "port1", "ipv4addr": "10.254.254.30",
                      "ipv4netmask": "255.255.255.0"},
        }
        assert rec._stale_overlapping_ports(nd, ports) == []

    def test_declared_ports_are_never_cleared(self):
        nd = self._node([
            {"port": "port2", "switch": "userssw", "ip": "10.128.0.1",
             "netmask": "255.255.255.0"},
            {"port": "port3", "switch": "userssw", "ip": "10.128.0.2",
             "netmask": "255.255.255.0"},
        ])
        ports = {
            "port2": {"id": 497, "name": "port2", "ipv4addr": "10.128.0.1",
                      "ipv4netmask": "255.255.255.0"},
            "port3": {"id": 498, "name": "port3", "ipv4addr": "10.128.0.2",
                      "ipv4netmask": "255.255.255.0"},
        }
        assert rec._stale_overlapping_ports(nd, ports) == []

    def test_applies_to_linux_guests_too(self):
        """Two addresses in one subnet on one host is wrong everywhere -- it just
        fails loudly on an appliance and quietly on Linux."""
        nd = self._node([{"port": "eth1", "switch": "userssw",
                          "ip": "10.128.0.1", "netmask": "255.255.255.0"}],
                        vm_type="LXC")
        ports = {
            "eth1": {"id": 2, "name": "eth1", "ipv4addr": "10.128.0.1",
                     "ipv4netmask": "255.255.255.0"},
            "eth0": {"id": 1, "name": "eth0", "ipv4addr": "10.128.0.5",
                     "ipv4netmask": "255.255.255.0"},
        }
        assert [n for n, _ in rec._stale_overlapping_ports(nd, ports)] == ["eth0"]

    def test_undeclared_port_with_no_address_is_ignored(self):
        nd = self._node([{"port": "port2", "switch": "userssw",
                          "ip": "10.128.0.1", "netmask": "255.255.255.0"}])
        ports = {
            "port2": {"id": 497, "name": "port2", "ipv4addr": "10.128.0.1",
                      "ipv4netmask": "255.255.255.0"},
            "port4": {"id": 499, "name": "port4", "ipv4addr": None,
                      "ipv4netmask": None},
        }
        assert rec._stale_overlapping_ports(nd, ports) == []


class TestExposeLint:
    """Tests for the duplicate from_port lint in _lint_intent."""




# ── egress scoring: the OOB segment, not the mgmt flag ────────────────────────
#
# Probed live (tools/probe_mgmt_egress.py, FS 2.0.8): a host-uplinked switch
# gives its guests an injected default gateway and working internet egress
# whether or not `mgmt` is set -- the ONE segment that never does is the seeded
# out-of-band management switch. The old rule (`egress = routable and not
# switch.mgmt`) failed the FortiFlex pre-flight on a topology that worked.

def _one_port_state(sw, vm_type="LXC"):
    """One guest on one switch -- the switch and the guest type are the variables."""
    return {
        "fabric": {"id": 1, "name": "probe"},
        "networks": [{"id": 23, "name": "n", "ipv4network": "198.51.100.0",
                      "ipv4netmask": "255.255.255.0", "ipv4gateway": "198.51.100.254"}],
        "switches": [{**sw, "auto_address_network": 23, "vm_type": "SW", "ports": []}],
        "vms": [{"id": 86, "name": "v", "vm_type": vm_type, "firmware": 865,
                 "ports": [{"id": 1, "name": "p", "ipv4addr": "198.51.100.1",
                            "network": 23, "cable": 124}]}],
        "cables": [{"id": 124, "conn1": 1, "conn2": 3}],
        "ports_by_id": {}, "device_by_port": {},
        "links": [{"vm_id": 86, "vm_port": 1, "vm_port_name": "p",
                   "switch_id": sw["id"], "switch_port": 3, "cable_id": 124}],
    }


def _egress_of(sw, vm_type="LXC"):
    return rec.reachability_report(_one_port_state(sw, vm_type), None)["rows"][0].egress


_USER_SW = {"id": 1, "nameid": "sw000", "name": "probe-egress", "host_uplinked": True}
_OOB_SW = {"id": 1, "nameid": "oobsw", "name": "OOB Mgmt", "host_uplinked": True}
_INT_SW = {"id": 1, "nameid": "intsw", "name": "Internet Access", "host_uplinked": True}


def test_mgmt_flag_does_not_suppress_egress():
    """The refutation, pinned: mgmt=True on a normal host-uplinked switch is
    still egress (probe cell `pd` -- gateway injected, ping 0%, curl 301)."""
    assert _egress_of({**_USER_SW, "mgmt": True}) is True
    assert _egress_of({**_USER_SW, "mgmt": False}) is True


def test_seeded_oob_switch_is_egress_only_for_appliances():
    """The node type is the discriminator on this segment.

    Linux (probe cell `pc`): single-homed on OOB -> no injected gateway, no
    egress. Appliance (faig-lab, read off the live guests): the FGT's default
    route is `via 10.254.254.254, port2` -- the OOB gateway -- and it pings
    8.8.8.8 with 0% loss, as do FMG and FAZ. Scoring OOB non-egress for an
    appliance fails the FortiFlex pre-flight on a working lab."""
    assert _egress_of({**_OOB_SW, "mgmt": True}, "LXC") is False
    assert _egress_of({**_OOB_SW, "mgmt": True}, "BASIC") is False
    for ty in ("FGT", "FMG", "FAZ", "FWB"):
        assert _egress_of({**_OOB_SW, "mgmt": True}, ty) is True, ty


def test_dhcp_served_oob_port_with_oob_network_parameters_is_egress():
    """Live (FS 2.2.35, a BASIC guest): System Host DHCP on OOB Mgmt with Network
    Parameters = OOB Mgmt leased `default via` the OOB gateway and HTTPS went out.
    Network Parameters on another network leave the gateway out of the lease."""
    def state(params_net):
        st = _one_port_state({**_OOB_SW, "mgmt": True}, "BASIC")
        st["vms"][0]["auto_params_network"] = params_net
        st["vms"][0]["ports"][0].update(addrmode="DHCP", dhcp_server=64)
        return st
    egress = lambda st: rec.reachability_report(st, None)["rows"][0].egress
    assert egress(state(23)) is True
    assert egress(state(51)) is False
    static = state(23)
    static["vms"][0]["ports"][0].update(addrmode="STA", dhcp_server=None)
    assert egress(static) is False


def test_unknown_vm_type_is_treated_as_linux_on_oob():
    """Never promise egress we can't back: an unresolvable type gets the
    stricter of the two rules."""
    assert _egress_of({**_OOB_SW, "mgmt": True}, None) is False


def test_seeded_internet_access_switch_is_never_egress():
    """Inert for BOTH families: an LXC guest gets an address and no gateway, and
    an appliance port on it has no address at all in-guest (faig-lab: the FGT's
    port1 and FMG's port3 are 0.0.0.0 while the model claims addresses)."""
    assert _egress_of({**_INT_SW, "mgmt": False}, "LXC") is False
    assert _egress_of({**_INT_SW, "mgmt": False}, "FGT") is False


def test_user_created_switch_on_any_net_is_egress():
    """The control: same flags, a switch the framework made -> egress (cell pg)."""
    assert _egress_of({"id": 1, "nameid": "sw001", "name": "dmz-sw",
                       "mgmt": True, "host_uplinked": True}) is True


def test_floating_switch_is_never_egress():
    """No host uplink -> no route off the segment, for any node type."""
    for ty in ("LXC", "FGT"):
        assert _egress_of({"id": 1, "nameid": "sw001", "name": "floating",
                           "mgmt": False, "host_uplinked": False}, ty) is False


# ── Change.reinstall marking ──────────────────────────────────────────────────

def test_change_reinstall_renders_and_summarizes():
    p = rec.Plan(changes=[
        rec.Change("update", "node", "fgt", "cpu 2→4", reinstall=True),
        rec.Change("create", "link", "fgt.port2→sw", reinstall=True),
        rec.Change("update", "access", "fgt.SSH", "→PUBLIC"),
        rec.Change("noop", "node", "fwb"),
    ])
    assert p.reinstall_nodes == ["fgt"]          # link sub-resource → owning node
    out = p.render()
    assert "[REINSTALL]" in out
    assert "1 node(s) will be REINSTALLED" in out and "fgt" in out


def test_change_reinstall_round_trips_and_defaults_false_on_old_plans():
    ch = rec.Change("update", "node", "n", "cpu 2→4", reinstall=True)
    assert rec.Change.from_dict(ch.to_dict()).reinstall is True
    # A plan file saved before the field existed must still load.
    assert rec.Change.from_dict({"op": "update", "kind": "node",
                                 "name": "n"}).reinstall is False


# ── VLANs: intent schema, static lints, and VLAN-aware reachability ───────────
#
# Every case below is silent on a live pod today: the API stores whatever it is
# handed, the GUI renders it as if it worked, and the only symptom is traffic
# that disappears.

def _vlan_intent(**over):
    """Two hosts on ONE switch in DIFFERENT VLANs, plus an FGT on a trunk."""
    doc = {
        "fabric": "vl",
        "networks": [
            {"name": "n100", "cidr": "10.100.0.0/24", "gateway": "10.100.0.254"},
            {"name": "n200", "cidr": "10.200.0.0/24", "gateway": "10.200.0.254"},
        ],
        "switches": [{"name": "vsw", "networks": ["n100", "n200"]}],
        "nodes": [
            {"name": "h100", "type": "LXC", "image": 1,
             "links": [{"port": "eth1", "switch": "vsw", "vlan": 100,
                        "ip": "10.100.0.1", "netmask": "255.255.255.0"}]},
            {"name": "h200", "type": "LXC", "image": 1,
             "links": [{"port": "eth1", "switch": "vsw", "vlan": 200,
                        "ip": "10.200.0.1", "netmask": "255.255.255.0"}]},
            {"name": "fgt1", "type": "FGT", "image": 1,
             "links": [{"port": "port2", "switch": "vsw", "trunk": [100, 200]}]},
        ],
    }
    doc.update(over)
    return doc


def test_vlan_parses_access_and_trunk_and_derives_mode():
    intent = rec.parse_intent(_vlan_intent())
    by_node = {n.name: n.links[0] for n in intent.nodes}
    assert by_node["h100"].vlan == 100 and by_node["h100"].switchport_mode == "access"
    assert by_node["fgt1"].trunk == (100, 200)
    assert by_node["fgt1"].switchport_mode == "trunk"
    # No tag at all means "leave the switchport alone" -- VLAN-unaware, which is
    # the right state for a single-VLAN segment.
    plain = rec.parse_intent(_vlan_intent(nodes=[
        {"name": "a", "type": "LXC", "image": 1,
         "links": [{"port": "eth1", "switch": "vsw"}]}]))
    assert plain.nodes[0].links[0].switchport_mode is None


def test_vlan_trunk_list_accepts_ranges_and_strings():
    assert rec.parse_trunk_list("100-102,200", "x") == (100, 101, 102, 200)
    assert rec.parse_trunk_list([200, 100], "x") == (100, 200)


@pytest.mark.parametrize("bad", [4096, -1, 0, 4095, "abc"])
def test_vlan_out_of_range_is_rejected_at_parse(bad):
    # The FS API accepts and STORES every one of these.
    with pytest.raises(ValueError):
        rec.parse_intent(_vlan_intent(nodes=[
            {"name": "a", "type": "LXC", "image": 1,
             "links": [{"port": "eth1", "switch": "vsw", "vlan": bad}]}]))


def test_vlan_malformed_trunk_is_rejected_at_parse():
    with pytest.raises(ValueError):
        rec.parse_intent(_vlan_intent(nodes=[
            {"name": "a", "type": "LXC", "image": 1,
             "links": [{"port": "eth1", "switch": "vsw", "trunk": "not,a,vlan"}]}]))


def test_vlan_and_trunk_are_mutually_exclusive():
    with pytest.raises(ValueError, match="mutually exclusive"):
        rec.parse_intent(_vlan_intent(nodes=[
            {"name": "a", "type": "LXC", "image": 1,
             "links": [{"port": "eth1", "switch": "vsw", "vlan": 100, "trunk": [100]}]}]))


def test_switchport_mode_is_not_an_intent_key():
    # An explicit mode is how two switches configured the same way diverged: a
    # VLAN-unaware port with a tag works by OVS inference, and setting the mode
    # by hand breaks it. So there is no key to set.
    with pytest.raises(ValueError, match="not an intent key"):
        rec.parse_intent(_vlan_intent(nodes=[
            {"name": "a", "type": "LXC", "image": 1,
             "links": [{"port": "eth1", "switch": "vsw", "mode": "trunk"}]}]))


def test_switch_networks_list_allows_a_second_subnet():
    intent = rec.parse_intent(_vlan_intent())
    sw = intent.switches[0]
    assert sw.networks == ["n100", "n200"]
    assert sw.auto_address == "n100"        # FS auto-addresses the first only
    assert sw.carries("n200") and not sw.carries("nope")


def test_switch_networks_must_be_declared_and_contain_auto_address():
    with pytest.raises(ValueError, match="not a declared network"):
        rec.parse_intent(_vlan_intent(switches=[{"name": "vsw", "networks": ["nope"]}]))
    with pytest.raises(ValueError, match="not in its networks list"):
        rec.parse_intent(_vlan_intent(
            switches=[{"name": "vsw", "networks": ["n100"], "auto_address": "n200"}]))


# ── static VLAN lints (tools/fs_topology._lint_vlans) ────────────────────────













# ── VLAN-aware reachability ──────────────────────────────────────────────────

def _vlan_state(h200_vlan=200, fgt_trunk="100,200"):
    """One switch, one subnet-per-VLAN, two hosts and an FGT on a trunk."""
    return {
        "fabric": {"id": 9, "name": "vl"},
        "networks": [{"id": 23, "name": "n100", "ipv4network": "10.100.0.0",
                      "ipv4netmask": "255.255.255.0", "ipv4gateway": "10.100.0.254"}],
        "switches": [{"id": 85, "name": "vsw", "auto_address_network": 23,
                      "mgmt": True, "host_uplinked": True,
                      "ports": [{"id": 51, "name": "p1", "mode": "access", "vlan": 100,
                                 "trunk": "", "cable": 1},
                                {"id": 52, "name": "p2", "mode": "access",
                                 "vlan": h200_vlan, "trunk": "", "cable": 2},
                                {"id": 53, "name": "p3", "mode": "trunk", "vlan": 0,
                                 "trunk": fgt_trunk, "cable": 3}]}],
        "vms": [
            {"id": 86, "name": "h100", "vm_type": "LXC",
             "ports": [{"id": 1, "name": "eth1", "ipv4addr": "10.100.0.1",
                        "network": 23, "cable": 1, "peer": 51}]},
            {"id": 87, "name": "h200", "vm_type": "LXC",
             "ports": [{"id": 2, "name": "eth1", "ipv4addr": "10.100.0.2",
                        "network": 23, "cable": 2, "peer": 52}]},
            {"id": 88, "name": "fgt1", "vm_type": "FGT",
             "ports": [{"id": 3, "name": "port2", "ipv4addr": None,
                        "network": None, "cable": 3, "peer": 53}]},
        ],
        "cables": [], "ports_by_id": {}, "device_by_port": {},
        "links": [
            {"vm_id": 86, "vm_port": 1, "vm_port_name": "eth1", "switch_id": 85,
             "switch_port": 51, "cable_id": 1},
            {"vm_id": 87, "vm_port": 2, "vm_port_name": "eth1", "switch_id": 85,
             "switch_port": 52, "cable_id": 2},
            {"vm_id": 88, "vm_port": 3, "vm_port_name": "port2", "switch_id": 85,
             "switch_port": 53, "cable_id": 3},
        ],
    }


def test_reach_same_subnet_different_vlan_is_not_same_l2():
    # Both hosts are 10.100.0.x on ONE switch. VLAN-blind, this reads "same L2"
    # and green -- which is exactly how the FAZ fault passed a reach check.
    # Routing via the FGT trunk is only claimed for a routing vm_type, and an
    # untagged Linux guest on the same trunk would not be.
    pairs = rec.reachability_report(_vlan_state(), None)["pairs"]
    p = next(p for p in pairs if p["src"] == "h100" and p["dst"] == "h200")
    assert p["reachable"] and "L3 via" in p["why"]   # the FGT trunk routes it

    # Take vlan 200 off the FGT's trunk and the pair goes dark, with the reason.
    pairs = rec.reachability_report(_vlan_state(fgt_trunk="100,101"), None)["pairs"]
    p = next(p for p in pairs if p["src"] == "h100" and p["dst"] == "h200")
    assert not p["reachable"]
    assert "VLAN mismatch" in p["why"] and "vlan 200" in p["why"]


def test_reach_same_vlan_is_same_l2():
    pairs = rec.reachability_report(_vlan_state(h200_vlan=100), None)["pairs"]
    p = next(p for p in pairs if p["src"] == "h100" and p["dst"] == "h200")
    assert p["reachable"] and "same L2" in p["why"]


def test_reach_rows_carry_the_switchport_tag():
    rows = {r.node: r for r in rec.reachability_report(_vlan_state(), None)["rows"]}
    assert rows["h100"].vlan == "100"
    assert rows["h200"].vlan == "200"
    assert rows["fgt1"].vlan == "trunk 100,200"


def test_plan_sees_switchport_vlan_drift():
    # Drift here is invisible to every other check -- the runtime row and the
    # GUI both render whatever is stored -- so without this, plan reports "no
    # changes" and apply short-circuits before it can repair anything.
    intent = rec.parse_intent(_vlan_intent())
    st = _vlan_state(h200_vlan=100, fgt_trunk="100,101")     # both faults at once
    st["vms"][2]["ports"][0]["auto_config"] = False          # trunk already clean
    details = {(ch.name, ch.detail) for ch in rec._plan_switchport_vlans(intent, st)}
    assert any(n == "h200.eth1" and "vlan=200" in d for n, d in details)
    assert any(n == "fgt1.port2" and "trunk=100,200" in d for n, d in details)
    # and it is quiet once the fabric matches
    clean = _vlan_state()
    clean["vms"][2]["ports"][0]["auto_config"] = False
    assert rec._plan_switchport_vlans(intent, clean) == []


def test_plan_flags_an_untagged_address_on_a_trunk_port():
    # FS auto-addresses any cabled port with no IP AT INSTALL, so one appears on
    # a trunk by itself and is then dropped at the uplink. Observed live.
    intent = rec.parse_intent(_vlan_intent())
    st = _vlan_state()
    st["vms"][2]["ports"][0]["ipv4addr"] = "10.100.0.3"
    changes = rec._plan_switchport_vlans(intent, st)
    assert any("clear untagged address 10.100.0.3" in ch.detail for ch in changes)


def test_reach_row_trunk_without_an_address_is_not_a_miss():
    # A trunk terminates no VLAN, so it carries no untagged address. Judging it
    # by "has an IP" flunks a correctly configured trunk -- and with
    # require_reachable that would fail the very apply that configured it.
    st = _vlan_state()
    st["vms"][2]["ports"][0]["ipv4addr"] = None
    rows = {r.node: r for r in rec.reachability_report(st, None)["rows"]}
    assert rows["fgt1"].ok and rows["fgt1"].ip is None


def test_reach_probes_every_addressed_port_not_just_the_first():
    # A node with a management NIC used to be probed only on that NIC, so the
    # data ports -- the VLANs, the whole point -- were never examined.
    st = _vlan_state()
    st["vms"][0]["ports"].append({"id": 9, "name": "eth0", "ipv4addr": "10.254.254.1",
                                  "network": None, "cable": 9, "peer": None})
    pairs = rec.reachability_report(st, None)["pairs"]
    dsts = {(p["dst"], p["dst_port"]) for p in pairs if p["src"] == "h200"}
    assert ("h100", "eth1") in dsts and ("h100", "eth0") in dsts


# ── _lint_topology: the blocking L3 checks ───────────────────────────────────
# Every case here is a generalisation of the fortiaigate_lab incident
# (2026-08-25): an FS-seeded "ISP Router" held the `Internet Access` gateway
# 203.0.113.254 with its upstream port uncabled and no default route, on the same
# segment as the System Host port configured with that same address. The router
# won the ARP and the segment black-holed -- FortiAIGate licensing returned
# `Server Error`, the FGT's FortiGuard DB was stuck at 0.00000, FMG flex
# activation failed with an empty reason -- while `plan` reported the fabric
# clean throughout, because routers were invisible to state and nothing checked
# gateway ownership for exclusivity.

def _lint_state(**over):
    st = {"networks": [], "switches": [], "vms": [], "host": {"ports": []},
          "routers": []}
    st.update(over)
    return st


def test_lint_flags_two_intent_networks_on_one_subnet():
    i = rec.parse_intent({"fabric": "t", "networks": [
        {"name": "a", "cidr": "203.0.113.0/24", "gateway": "203.0.113.254"},
        {"name": "b", "cidr": "203.0.113.0/24", "gateway": "203.0.113.254"},
    ]})
    errs = rec._lint_topology(i, None)
    assert any("all declare subnet 203.0.113.0/24" in e for e in errs), errs


def test_lint_flags_declared_network_duplicating_a_live_one():
    """The real fortiaigate_lab shape: intent hand-declares `Internet Access` on
    the subnet the pod already seeded as `Internet`."""
    i = rec.parse_intent({"fabric": "t", "networks": [
        {"name": "Internet Access", "cidr": "203.0.113.0/24"}]})
    st = _lint_state(networks=[{"name": "Internet", "ipv4network": "203.0.113.0",
                                "ipv4netmask": "255.255.255.0",
                                "ipv4gateway": "203.0.113.254"}])
    errs = rec._lint_topology(i, st)
    assert any("duplicates the subnet" in e and "'Internet'" in e for e in errs), errs


def test_lint_flags_contended_gateway_address():
    """Two devices owning one gateway IP -- the ARP race that black-holed the
    segment. The System Host and the router both answer for .254."""
    i = rec.parse_intent({"fabric": "t", "networks": [
        {"name": "Internet", "cidr": "203.0.113.0/24", "gateway": "203.0.113.254"}]})
    st = _lint_state(
        host={"ports": [{"name": "int2", "ipv4addr": "203.0.113.254",
                         "forwarding": True}]},
        routers=[{"id": 1, "name": "ISP Router", "ipv4gateway": None, "ports": [
            {"name": "port1", "ipv4addr": "203.0.113.254", "cable": 196},
            {"name": "port2", "ipv4addr": "198.51.100.253", "cable": 99}]}],
    )
    errs = rec._lint_topology(i, st)
    assert any("claimed by 2 devices" in e and "203.0.113.254" in e for e in errs), errs


def test_lint_flags_black_hole_router():
    """Cabled on one addressed leg, no second cable, no default route. (Not the seeded ISP Router, which apply
    removes on its own: see test_the_seeded_black_hole_router_is_removed_without_prune.)"""
    i = rec.parse_intent({"fabric": "t"})
    st = _lint_state(routers=[{"id": 1, "name": "Edge Router", "ipv4gateway": None,
                               "ports": [
                                   {"name": "port1", "ipv4addr": "203.0.113.254", "cable": 196},
                                   {"name": "port2", "ipv4addr": "198.51.100.253", "cable": None}]}])
    errs = rec._lint_topology(i, st)
    assert any("black hole" in e for e in errs), errs


# ── prune-aware lint: the run that cleans up must not be blocked by what it
#    cleans (the _survives/doomed pattern, applied to routers) ─────────────────
#
# The pod state that produced this rule: an undeclared, leftover ISP Router
# holding the egress gateway next to the System Host port that needs it. Both
# gateway-owner and black-hole checks fire -- correctly -- but a `--prune` run
# deletes that same router, so firing on it turns the ONLY self-healing run
# into a refused one and strands the fabric behind --force-lint.

def _leftover_router_state():
    """The contended-gateway + black-hole shape the leftover router makes."""
    return _lint_state(
        host={"ports": [{"name": "int1", "ipv4addr": "203.0.113.254",
                         "forwarding": True}]},
        routers=[{"id": 1, "name": "ISP Router", "ipv4gateway": None, "ports": [
            {"name": "port1", "ipv4addr": "203.0.113.254", "cable": 196},
            {"name": "port2", "ipv4addr": "198.51.100.253", "cable": 99}]}],
    )


def test_lint_prune_unblocks_the_gateway_router_it_deletes():
    """prune=True schedules the undeclared router for deletion (plan: 'delete
    router ... not declared in intent'), so it must not count as a gateway
    claimant -- the same rule that keeps doomed VM ports out of check 3."""
    i = rec.parse_intent({"fabric": "t", "networks": [
        {"name": "Internet", "cidr": "203.0.113.0/24", "gateway": "203.0.113.254"}]})
    st = _leftover_router_state()
    assert any("claimed by 2 devices" in e for e in rec._lint_topology(i, st))
    assert not any("claimed by 2 devices" in e
                   for e in rec._lint_topology(i, st, prune=True))


def test_lint_prune_unblocks_the_black_hole_router_it_deletes():
    i = rec.parse_intent({"fabric": "t"})
    st = _lint_state(routers=[{"id": 1, "name": "Edge Router", "ipv4gateway": None,
                               "ports": [
                                   {"name": "port1", "ipv4addr": "203.0.113.254", "cable": 196},
                                   {"name": "port2", "ipv4addr": "198.51.100.253", "cable": None}]}])
    assert any("black hole" in e for e in rec._lint_topology(i, st))
    assert not any("black hole" in e for e in rec._lint_topology(i, st, prune=True))


def test_lint_prune_still_flags_a_declared_router_claimant():
    """A router the intent DECLARES (and therefore keeps) is never doomed:
    contention on it survives the pruning run and must keep blocking it."""
    i = rec.parse_intent({"fabric": "t",
                          "routers": ["ISP Router"],
                          "networks": [
                              {"name": "Internet", "cidr": "203.0.113.0/24",
                               "gateway": "203.0.113.254"}]})
    st = _leftover_router_state()
    errs = rec._lint_topology(i, st, prune=True)
    assert any("claimed by 2 devices" in e for e in errs), errs


def test_lint_prune_still_flags_a_protected_router_claimant():
    """Ditto for ``protected: true`` -- prune refuses to delete it (the
    SEEED/inventory prevent_destroy rule), so it is not doomed either."""
    i = rec.parse_intent({"fabric": "t",
                          "routers": [{"name": "ISP Router", "protected": True}],
                          "networks": [
                              {"name": "Internet", "cidr": "203.0.113.0/24",
                               "gateway": "203.0.113.254"}]})
    st = _leftover_router_state()
    errs = rec._lint_topology(i, st, prune=True)
    assert any("claimed by 2 devices" in e for e in errs), errs


def test_lint_accepts_router_with_upstream_and_gateway():
    """A properly-wired router is not a fault -- the check must not fire on it."""
    i = rec.parse_intent({"fabric": "t"})
    st = _lint_state(routers=[{"id": 1, "name": "ISP Router",
                               "ipv4gateway": "198.51.100.254", "ports": [
                                   {"name": "port1", "ipv4addr": "203.0.113.254", "cable": 196},
                                   {"name": "port2", "ipv4addr": "198.51.100.253", "cable": 197}]}])
    assert rec._lint_topology(i, st) == []


def test_lint_flags_intent_redefining_a_seeded_shared_name():
    i = rec.parse_intent({"fabric": "t", "networks": [
        {"name": "OOB Mgmt", "cidr": "10.9.9.0/24", "gateway": "10.9.9.254"}]})
    st = _lint_state(networks=[{"name": "OOB Mgmt", "ipv4network": "10.254.254.0",
                                "ipv4netmask": "255.255.255.0",
                                "ipv4gateway": "10.254.254.254"}])
    errs = rec._lint_topology(i, st)
    assert any("FS-seeded shared name but redefines it" in e for e in errs), errs


def test_lint_clean_topology_produces_no_errors():
    i = rec.parse_intent({"fabric": "t", "networks": [
        {"name": "Internet", "cidr": "203.0.113.0/24", "gateway": "203.0.113.254"}]})
    st = _lint_state(
        networks=[{"name": "Internet", "ipv4network": "203.0.113.0",
                   "ipv4netmask": "255.255.255.0", "ipv4gateway": "203.0.113.254"}],
        host={"ports": [{"name": "int2", "ipv4addr": "203.0.113.254", "forwarding": True}]},
    )
    assert rec._lint_topology(i, st) == []


# ── routers: intent key ──────────────────────────────────────────────────────

def test_routers_key_parses_string_and_mapping_forms():
    i = rec.parse_intent({"fabric": "t",
                          "routers": ["ISP Router", {"name": "Edge", "protected": True}]})
    assert [(r.name, r.protected) for r in i.routers] == [
        ("ISP Router", False), ("Edge", True)]


def test_routers_key_defaults_empty():
    assert rec.parse_intent({"fabric": "t"}).routers == []


def test_seeded_network_allowlist_excludes_the_switch_name():
    """`Internet Access` is a seeded SWITCH name, not a seeded NETWORK name.

    The flat allowlist protected it as both, so a tenant-minted network called
    `Internet Access` (a duplicate of the seeded `Internet` subnet -- what the
    `internet-egress` preset used to create) was permanently immune to --prune
    and indistinguishable from real shared infra. Regression-guard the split."""
    assert not rec._is_protected_name("Internet Access", set(),
                                      rec.SEEDED_SHARED_NETWORK_NAMES)
    assert rec._is_protected_name("Internet", set(),
                                  rec.SEEDED_SHARED_NETWORK_NAMES)
    # Switch side stays permissive -- under-protecting a switch is the
    # catastrophic direction (it tears down another tenant's egress).
    assert rec._is_protected_name("Internet Access", set(),
                                  rec.SEEDED_SHARED_SWITCH_NAMES)


def test_plan_prune_deletes_a_non_seeded_network(fake_state):
    """The other half of the protection filter: an undeclared network whose name
    is NOT seeded shared infra still shows up as a delete."""
    # fake_state IS the dict the canned read_fabric_state returns -- mutate it
    # in place; a copy would not reach plan().
    fake_state["networks"].append(
        {"id": 99, "name": "tenant-net", "ipv4network": "10.77.77.0",
         "ipv4netmask": "255.255.255.0"})
    intent = rec.parse_intent({"fabric": "topo-test"})
    plan = rec.plan(FakeClient(), intent, prune=True)
    deletes = {(c.kind, c.name) for c in plan.changes if c.op == "delete"}
    assert ("network", "tenant-net") in deletes


def test_ensure_license_auto_reuses_the_pods_existing_flex_pool(monkeypatch):
    """A pod already mapped for FGT keeps that config; the account is not asked to pick one
    (with several ACTIVE FortiGate configs it cannot, and the build used to stop there)."""
    from fabric_studio.topology import flex
    monkeypatch.setattr(rec.fa, "list_flex_pool", lambda c: [{"fp_type": 1, "config": 84186}])
    monkeypatch.setattr(flex, "get_config", lambda cid, **kw: {"productType": {"name": "FortiGate-VM"}})
    monkeypatch.setattr(flex, "autodetect_config_for_vm_type",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("asked the account")))
    pooled = {}
    monkeypatch.setattr(rec.fa, "set_flex_pool", lambda c, t, cid: pooled.setdefault(t, cid))
    monkeypatch.setattr(rec.fa, "get_vm_license_mode", lambda c, fid, vid: {"mode": "AUTO"})
    nd = rec.NodeSpec(name="fgt", type="FGT", license=rec.LicenseSpec(mode="AUTO"))
    rec._ensure_license(None, 1, nd, 50, lambda m: None)
    assert pooled == {"FGT": 84186}


def test_floating_warning_counts_declared_host_uplinks():
    intent = rec.Intent(fabric="f", switches=[rec.SwitchSpec(name="Egress", host_uplink=True),
                                              rec.SwitchSpec(name="LAN")],
                        nodes=[rec.NodeSpec(name="fgt", type="FGT",
                                            links=[rec.LinkSpec(port="port1", switch="Egress"),
                                                   rec.LinkSpec(port="port2", switch="LAN")])])
    w = rec._floating_switch_warnings(intent, [])
    assert len(w) == 1 and "'LAN'" in w[0] and "'Egress'" in w[0]   # hint names the uplinked one


def test_plan_says_a_switch_that_gains_a_port_on_a_running_fabric_is_reinstalled(fake_state, monkeypatch):
    monkeypatch.setattr(rec.fa, "runtime_vms", lambda c, fid: [{"id": 86}])
    plan = rec.plan(FakeClient(), _intent_two_nodes())
    assert ("update", "switch", "mgmtsw") in {(c.op, c.kind, c.name) for c in plan.changes}
    assert any("mgmtsw" in w and "reinstalled" in w for w in plan.warnings)


def test_plan_on_a_fabric_not_running_yet_does_not_reinstall_switches(fake_state):
    plan = rec.plan(FakeClient(), _intent_two_nodes())   # fixture: no runtime VMs
    assert not any(c.kind == "switch" and c.op == "update" for c in plan.changes)


def test_plan_warns_a_new_generic_vm_link_without_dhcp_gets_no_address(fake_state):
    intent = rec.parse_intent({
        "fabric": "topo-test",
        "networks": [{"name": "mgmt", "cidr": "198.51.100.0/24", "gateway": "198.51.100.254"}],
        "switches": [{"name": "mgmtsw", "auto_address": "mgmt"}],
        "nodes": [{"name": "h1", "type": "LXC", "firmware": 865, "links": [{"port": "eth0", "switch": "mgmtsw"}]},
                  {"name": "vm9", "type": "BASIC", "firmware": 881,
                   "links": [{"port": "eth0", "switch": "mgmtsw", "dhcp": "System Host"},
                             {"port": "eth1", "switch": "mgmtsw"}]}],
    })
    plan = rec.plan(FakeClient(), intent)
    hits = [w for w in plan.warnings if "NO address" in w]
    assert len(hits) == 1 and hits[0].startswith("vm9.eth1")



def test_the_seeded_black_hole_router_is_removed_without_prune():
    i = rec.parse_intent({"fabric": "t"})
    seeded = {"id": 1, "name": "ISP Router", "ipv4gateway": None,
              "ports": [{"name": "port1", "ipv4addr": "203.0.113.254", "cable": 196},
                        {"name": "port2", "ipv4addr": "198.51.100.253", "cable": None}]}
    assert rec._seeded_black_hole(seeded, i)
    assert not any("black hole" in e for e in rec._lint_topology(i, _lint_state(routers=[seeded])))
    declared = rec.parse_intent({"fabric": "t", "routers": ["ISP Router"]})
    assert not rec._seeded_black_hole(seeded, declared)          # declared: kept, and lint still applies
    routed = {**seeded, "ipv4gateway": "198.51.100.254"}
    assert not rec._seeded_black_hole(routed, i)                 # has a way out: not a black hole
