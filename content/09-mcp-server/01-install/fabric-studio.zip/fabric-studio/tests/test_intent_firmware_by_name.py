"""`firmware:` by name / version string (resolved to a home-repo id at plan time).

A numeric `firmware:` is still a literal FS id (unchanged). A string is resolved
against `list_home_firmwares`, scoped to the node's vm_type: exact name/filename
wins, else a version prefix ("9.7" → latest 9.7.x) picks the newest by build.
"""
from __future__ import annotations

import pytest

from fabric_studio.topology import reconciler as rec


def _home(rows):
    # Real signature is list_home_firmwares(c, vm_type=None); honor the type scope.
    def _list(c, vm_type=None):
        return [r for r in rows if vm_type in (None, r.get("vm_type"))]
    return _list


SOAR_ROWS = [
    {"id": 10, "vm_type": "SOAR", "name": None, "major": 9, "minor": 7, "patch": 1,
     "build": 100, "path": "firmwares/FSR-v9.7.1-build100.qcow2", "size": 5},
    {"id": 11, "vm_type": "SOAR", "name": None, "major": 9, "minor": 7, "patch": 2,
     "build": 300, "path": "firmwares/FSR-v9.7.2-build300.qcow2", "size": 5},
    {"id": 12, "vm_type": "SOAR", "name": "golden-fsr", "major": 8, "minor": 0,
     "patch": 0, "build": 42, "path": "firmwares/fsr-golden.qcow2", "size": 5},
    {"id": 99, "vm_type": "FGT", "name": None, "major": 9, "minor": 7, "patch": 9,
     "build": 999, "path": "firmwares/FGT-v9.7.9-build999.zip", "size": 5},
]


def test_numeric_firmware_is_a_literal_id(monkeypatch):
    monkeypatch.setattr(rec.fa, "list_home_firmwares", _home([]))
    nd = rec.NodeSpec(name="h", type="SOAR", firmware=865)
    assert rec._resolve_firmware_id(object(), nd) == 865


def test_all_digit_string_is_a_literal_id(monkeypatch):
    # YAML-quoted numeric id must not be treated as a version reference.
    monkeypatch.setattr(rec.fa, "list_home_firmwares", _home([]))
    nd = rec.NodeSpec(name="h", type="SOAR", firmware="865")
    assert rec._resolve_firmware_id(object(), nd) == 865


def test_minor_version_prefix_picks_latest_patch_and_build(monkeypatch):
    monkeypatch.setattr(rec.fa, "list_home_firmwares", _home(SOAR_ROWS))
    nd = rec.NodeSpec(name="h", type="SOAR", firmware="9.7")
    assert rec._resolve_firmware_id(object(), nd) == 11   # 9.7.2 build300 beats 9.7.1


def test_pinned_patch_version(monkeypatch):
    monkeypatch.setattr(rec.fa, "list_home_firmwares", _home(SOAR_ROWS))
    nd = rec.NodeSpec(name="h", type="SOAR", firmware="9.7.1")
    assert rec._resolve_firmware_id(object(), nd) == 10


def test_version_scoped_by_vm_type(monkeypatch):
    # "9.7" on a SOAR node must not resolve the FGT 9.7.9 image.
    monkeypatch.setattr(rec.fa, "list_home_firmwares", _home(SOAR_ROWS))
    nd = rec.NodeSpec(name="h", type="SOAR", firmware="9.7")
    assert rec._resolve_firmware_id(object(), nd) != 99


def test_resolve_by_firmware_name(monkeypatch):
    monkeypatch.setattr(rec.fa, "list_home_firmwares", _home(SOAR_ROWS))
    nd = rec.NodeSpec(name="h", type="SOAR", firmware="golden-fsr")
    assert rec._resolve_firmware_id(object(), nd) == 12


def test_resolve_by_filename_basename(monkeypatch):
    monkeypatch.setattr(rec.fa, "list_home_firmwares", _home(SOAR_ROWS))
    nd = rec.NodeSpec(name="h", type="SOAR", firmware="FSR-v9.7.2-build300.qcow2")
    assert rec._resolve_firmware_id(object(), nd) == 11


def test_unresolvable_version_raises_with_available(monkeypatch):
    monkeypatch.setattr(rec.fa, "list_home_firmwares", _home(SOAR_ROWS))
    nd = rec.NodeSpec(name="h", type="SOAR", firmware="5.5")
    with pytest.raises(rec.fa.FabricStudioAdminError, match="not found in home repo"):
        rec._resolve_firmware_id(object(), nd)


# Modeled on a real FS home repo: SOAR rows whose ``patch`` field is uniformly 1
# regardless of the real version, which lives in ``version_s``. The synthetic
# SOAR_ROWS above have internally-consistent patch fields and so can't catch the
# FS quirk that broke version-prefix resolution on a live pod.
SOAR_REAL_ROWS = [
    {"id": 1245, "vm_type": "SOAR",
     "version_s": "fortisoar-7-6-5-Jan-15-26-ztp-updated",
     "major": 7, "minor": 6, "patch": 1, "build": 5275,
     "path": "firmwares/fortisoar-7-6-5-Jan-15-26-ztp-updated"},
    {"id": 1249, "vm_type": "SOAR",
     "version_s": "FortiSOAR-7.6.5-decouple-may-21-26",
     "major": 7, "minor": 6, "patch": 1, "build": 5275,
     "path": "firmwares/FortiSOAR-7.6.5-decouple-may-21-26"},
    {"id": 1250, "vm_type": "SOAR", "version_s": "FSR-7.6.6-decouple-may21-26",
     "major": 7, "minor": 6, "patch": 1, "build": 5275,
     "path": "firmwares/FSR-7.6.6-decouple-may21-26"},
]


def test_bogus_patch_field_resolved_from_name(monkeypatch):
    # FS reports patch=1 for all three rows; the real 7.6.6 image must still
    # resolve from its version_s when asked for "7.6.6".
    monkeypatch.setattr(rec.fa, "list_home_firmwares", _home(SOAR_REAL_ROWS))
    nd = rec.NodeSpec(name="h", type="SOAR", firmware="7.6.6")
    assert rec._resolve_firmware_id(object(), nd) == 1250


def test_version_prefix_picks_newest_by_name_not_field(monkeypatch):
    # "7.6" matches all three (all 7.6.x); newest by real version is 7.6.6 (1250),
    # not the first row (1245) that a path-blind sort key would tie-break to.
    monkeypatch.setattr(rec.fa, "list_home_firmwares", _home(SOAR_REAL_ROWS))
    nd = rec.NodeSpec(name="h", type="SOAR", firmware="7.6")
    assert rec._resolve_firmware_id(object(), nd) == 1250


@pytest.mark.parametrize("ref,expected", [
    ("9.7", (9, 7, None, None)),
    ("v9.7.2", (9, 7, 2, None)),
    ("7.6.6-build3652", (7, 6, 6, 3652)),
    ("not-a-version", None),
])
def test_parse_version_ref(ref, expected):
    assert rec._parse_version_ref(ref) == expected


def test_a_version_the_home_repo_lacks_resolves_to_an_image_the_pod_downloads(monkeypatch):
    home = [{"id": 1, "name": "FGT 7.4.9", "version_s": "7.4.9", "size": 5, "vm_type": "FGT",
             "path": "FGT_VM64_KVM-v7.4.9-build2800-FORTINET.out.kvm.zip", "repository": "home"}]
    remote = {"id": 9, "name": "FGT 7.6.6", "version_s": "7.6.6", "size": 5, "vm_type": "FGT",
              "path": "FGT_VM64_KVM-v7.6.6.M-build3652-FORTINET.out.kvm.zip", "repository": "fortinet"}
    monkeypatch.setattr(rec.fa, "list_home_firmwares", lambda c, vm_type=None: home)
    monkeypatch.setattr(rec.fa, "list_all_firmwares", lambda c, vm_type=None: [*home, remote])
    nd = rec.NodeSpec(name="g", type="FGT", image="7.6")
    assert rec._resolve_firmware_id(object(), nd) == 9
    nd = rec.NodeSpec(name="g", type="FGT", image="FGT_VM64_KVM-v7.6.6.M-build3652-FORTINET.out.kvm.zip")
    assert rec._resolve_firmware_id(object(), nd) == 9
    assert rec._resolve_firmware_id(object(), rec.NodeSpec(name="g", type="FGT", image="7.4")) == 1   # home wins
    with pytest.raises(rec.fa.FabricStudioAdminError, match=r"not found.*have: .*7\.4\.9"):
        rec._resolve_firmware_id(object(), rec.NodeSpec(name="g", type="FGT", image="9.9"))


def test_a_zero_byte_home_stub_does_not_hide_the_image_the_pod_downloads(monkeypatch):
    """A 7.6 stub in the home repository (never uploaded) used to win the prefix match, fail the stub check and be
    reported as 'image not found', while a usable 7.6.6 image sat in another repository."""
    stub = {"id": 5, "name": None, "version_s": "F", "major": 7, "minor": 6, "patch": 4, "build": 3596, "size": 0,
            "vm_type": "FGT", "path": "firmwares/FGT_VM64_KVM-v7.6.4.F-build3596.zip", "repository": "home"}
    remote = {"id": 9, "name": "FGT 7.6.6", "version_s": "7.6.6", "size": 5, "vm_type": "FGT",
              "path": "FGT_VM64_KVM-v7.6.6.M-build3652-FORTINET.out.kvm.zip", "repository": "fortinet"}
    monkeypatch.setattr(rec.fa, "list_home_firmwares", lambda c, vm_type=None: [stub])
    monkeypatch.setattr(rec.fa, "list_all_firmwares", lambda c, vm_type=None: [stub, remote])
    assert rec._resolve_firmware_id(object(), rec.NodeSpec(name="g", type="FGT", image="7.6")) == 9
