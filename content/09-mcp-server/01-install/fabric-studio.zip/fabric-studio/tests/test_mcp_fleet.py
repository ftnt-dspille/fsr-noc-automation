"""Offline tests for the cross-instance MCP tools (``tools/fs_mcp/fleet`` and the server wrappers)."""
from __future__ import annotations

import importlib
import json
from types import SimpleNamespace

import pytest

from fabric_studio.mcp import fleet
from fabric_studio.mcp import instances as inst


@pytest.fixture
def fake(monkeypatch):
    fa = SimpleNamespace(
        ACCESS_FORWARD_BASE={"SSH": 11000, "HTTPS": 13000},
        runtime_vms=lambda c: [{"id": 1, "port_idx": 5}, {"id": 2, "port_idx": 6}],
        list_fabrics=lambda c: [{"id": 10, "name": "lab"}, {"id": 11, "name": "old"}],
        list_fabric_vms=lambda c, fid: ([{"id": 1, "name": "fgt1", "vm_type": "FGT"},
                                         {"id": 2, "name": "faig", "vm_type": "FAIG"}] if fid == 10
                                        else [{"id": 3, "name": "fgt1", "vm_type": "FGT"}]),
        get_vm_runtime_state=lambda c, vid: {"status": {"powered": True, "post_boot_prepared": True}},
        list_running_tasks=lambda c: [{"id": 9, "name": "install"}],
        get_running_fabric=lambda c: {"name": "lab"},
        hugepages_free=lambda c: 0, hugepages_available=lambda c: 0,
        get_pod_hostname=lambda c: "pod-x",
        list_fs_licenses=lambda c: [{"id": 7, "name": "FGVMSERIAL", "vm_type": "FGT"}],
        forticloud_registered=lambda c: True,
        get_vm_license_mode=lambda c, fid, vid: {"mode": "SERVED", "served": 7} if vid == 1 else {"mode": "NONE"},
        probe_access_port=lambda h, port, kind, timeout=0: (port != 11006, "x"),
    )
    monkeypatch.setattr(fleet, "fs_admin", fa)
    monkeypatch.setattr(fleet, "read_pod_lock", lambda host: None)
    return fa


def test_device_rows_and_match(fake):
    rows = fleet.device_rows(None)
    assert {(r["fabric"], r["name"], r["up"]) for r in rows} == {
        ("lab", "fgt1", True), ("lab", "faig", True), ("old", "fgt1", False)}
    assert [r["fabric"] for r in fleet.match(rows, "FGT")] == ["lab", "old"]  # powered first
    assert [r["name"] for r in fleet.match(rows, "fgt", up_only=True)] == ["fgt1"]
    assert fleet.forwards("h", 5) == {"SSH": "h:11005", "HTTPS": "h:13005"} and fleet.forwards("h", None) == {}


def test_health_busy_and_hugepages_not_reported(fake):
    h = fleet.health(None, "h")
    assert h["busy"] and h["running_fabric"] == "lab" and h["hugepages"] is None


def test_licensing(fake):
    out = fleet.licensing(None)
    assert out["forticloud_registered"] and out["pool"] == {"FGT": 1}
    d = {x["name"]: x for x in out["devices"]}
    assert d["fgt1"]["served_serial"] == "FGVMSERIAL" and d["faig"]["served"] is False


def test_reach_flags_blocked_forward(fake):
    out = fleet.reach(None, "h", devices=True)
    assert out["https_443"]["ok"] and out["ssh_22"]["ok"]
    faig = next(d for d in out["devices"] if d["name"] == "faig")
    assert faig["SSH"]["ok"] is False and faig["HTTPS"]["ok"] is True


def test_credentials_hint_has_no_secret_and_right_user(fake):
    rows = {r["name"]: r for r in fleet.device_rows(None) if r["fabric"] == "lab"}
    h = fleet.credentials_hint("h", rows["faig"])
    assert h["user"] == "fortinet" and "fabric ssh" in h["ssh"] and "password" not in h
    assert "api_token" in fleet.credentials_hint("h", rows["fgt1"])
    assert "api_token" not in h


def test_engage_lockout(tmp_path, monkeypatch):
    monkeypatch.setattr(inst.Path, "home", classmethod(lambda cls: tmp_path))
    assert not inst.engage_lockout("a.example.com", "*", "  ")["ok"]
    out = inst.engage_lockout("a.example.com", "*", "hands off")
    assert out["ok"] and inst.is_locked(inst.lockouts()["a.example.com"], "any")
    again = inst.engage_lockout("a.example.com", "*", "other reason")
    assert not again["ok"] and "already" in again["error"]
    assert inst.lockouts()["a.example.com"][0]["reason"] == "hands off"  # never overwritten


def test_server_wrappers(env_dir_like, monkeypatch):
    s = env_dir_like
    pods = [{"host": "a.example.com", "online": True, "devices": [
        {"fabric": "lab", "name": "fgt1", "vm_type": "FGT", "up": True, "ready": True, "port_idx": 5, "id": 1},
        {"fabric": "old", "name": "fgt1", "vm_type": "FGT", "up": False, "ready": False, "port_idx": None, "id": 3}]},
        {"host": "b.example.com", "online": False, "error": "down"}]
    monkeypatch.setattr(s, "_each", lambda hosts, fn, timeout_s=20: pods)
    found = s.find_device("fgt1")
    assert [f.get("fabric") for f in found[:2]] == ["lab", "old"] and found[0]["forwards"]["SSH"] == "a.example.com:11005"
    assert found[-1]["host"] == "b.example.com" and found[-1]["error"] == "down"
    hint = s.device_credentials_hint("a.example.com", "fgt1")  # two fgt1: the powered one is meant
    assert hint["ok"] and hint["fabric"] == "lab"
    assert not s.engage_lockout("zzz.example.com", "r")["ok"]  # not managed


@pytest.fixture
def env_dir_like(tmp_path, monkeypatch):
    monkeypatch.setenv("FSH_INSTANCES_FILE", str(tmp_path / "instances.json"))
    from conftest import import_server

    s = import_server()
    return s
