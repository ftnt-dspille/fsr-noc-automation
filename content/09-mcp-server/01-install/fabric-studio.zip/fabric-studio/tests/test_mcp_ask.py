"""Mutating tools preview without ``confirm`` and run with it; the client's own prompt (from the annotations) is the approval."""
from __future__ import annotations

import asyncio
from types import SimpleNamespace

import pytest
from conftest import import_server


@pytest.fixture
def tool(monkeypatch):
    s = import_server()
    ran = []

    @s._tool(mutating=True)
    def change_thing(host: str, confirm: bool = False) -> dict:
        ran.append(confirm)
        return {"dry_run": not confirm, "host": host}

    return change_thing, ran


def call(fn, **kw):
    return asyncio.run(fn(**kw))


def test_confirm_runs_the_tool_without_a_server_side_question(tool):
    fn, ran = tool
    assert call(fn, host="h", confirm=True) == {"dry_run": False, "host": "h"}
    assert ran == [True]                               # approval is the client's prompt, not a second form


def test_without_confirm_the_tool_only_previews(tool):
    fn, ran = tool
    assert call(fn, host="h")["dry_run"] is True and ran == [False]


def test_annotations_mark_read_only_local_write_and_mutating():
    s = import_server()
    tools = {t.name: t for t in asyncio.run(s.mcp.list_tools())}
    assert all(tools[n].annotations.read_only_hint for n in ("pods", "fabric", "vm", "tasks", "diagnose"))
    for n in ("set_vm_access_public", "install_system_host", "set_vm_port_dhcp", "set_vm_port_auto"):
        a = tools[n].annotations
        assert a.read_only_hint is False and a.destructive_hint is True
    for n in ("add_instance", "remove_instance", "engage_lockout"):
        assert tools[n].annotations.read_only_hint is False and tools[n].annotations.destructive_hint is False
    assert not [t.name for t in tools.values() if t.annotations is None]


def test_snapshot_vm_previews_validates_and_takes_a_diff_or_full_snapshot(monkeypatch):
    from mcp.server.mcpserver.exceptions import ToolError

    s = import_server()
    taken = []
    monkeypatch.setattr(s, "_resolve", lambda *a, **k: (object(), 1, {"id": 7, "name": "fgt", "vm_type": "FGT"}))
    monkeypatch.setattr(s.fs_admin, "list_all_firmwares", lambda c: [{"path": "firmwares/old"}])
    monkeypatch.setattr(s.fs_admin, "take_diff_snapshot",
                        lambda c, vid, name, link, diff: taken.append((vid, name, link, diff)) or {"id": 9, "path": name})

    dry = s.snapshot_vm("h", "diff", "good-1", vm="fgt")
    assert dry["dry_run"] is True and dry["steps"][0] == "hard power-off" and not taken
    assert s.snapshot_vm("h", "diff", "good-1", vm="fgt", confirm=True)["snapshot"]["id"] == 9
    s.snapshot_vm("h", "full", "good-2", vm="fgt", link=False, confirm=True)
    assert taken == [(7, "good-1", True, True), (7, "good-2", False, False)]
    for bad in (("bad", "n"), ("diff", "../x"), ("diff", "a b"), ("diff", "old"), ("diff", "ok\n")):
        with pytest.raises(ToolError):
            s.snapshot_vm("h", *bad, vm="fgt")


def test_a_library_sys_exit_becomes_a_tool_error_not_a_dropped_connection():
    from mcp.server.mcpserver.exceptions import ToolError
    s = import_server()

    @s._tool
    def sync_lookup(host: str) -> dict:
        raise SystemExit("VM 'x' not found. Available: 1:faz(FAZ)")

    @s._tool
    async def async_lookup(host: str) -> dict:
        raise SystemExit("fabric 'y' not found")

    for fn, text in ((sync_lookup, "VM 'x' not found"), (async_lookup, "fabric 'y' not found")):
        with pytest.raises(ToolError, match=text):
            asyncio.run(s.mcp.call_tool(fn.__name__, {"host": "h"}))


def test_a_changing_tool_keeps_its_own_error_message(tool):
    from mcp.server.mcpserver.exceptions import ToolError
    s = import_server()

    @s._tool(mutating=True)
    def refuses(host: str, confirm: bool = False) -> dict:
        raise ToolError("name must be 1-80 characters")

    with pytest.raises(ToolError, match="name must be 1-80 characters"):
        call(refuses, host="h")


@pytest.mark.parametrize("exc,expect", [
    ("LoginCooldown", "retry in 42s"),
    ("conn", "cannot reach h over HTTPS"),
    ("http404", "does not exist on the pod"),
    ("http409", "Another task is in flight"),
    ("boom", "unexpected RuntimeError: kaboom"),
])
def test_operational_failures_reach_the_client_with_a_hint(exc, expect):
    import requests
    from mcp.server.mcpserver.exceptions import ToolError

    from fabric_studio.client.login_guard import LoginCooldown
    s = import_server()
    errors = {"LoginCooldown": LoginCooldown("not logging in to h: retry in 42s"),
              "conn": requests.exceptions.ConnectTimeout("x"),
              "http404": s.fs_admin.FabricStudioAdminError("get_task: HTTP 404: nope"),
              "http409": s.fs_admin.FabricStudioAdminError("install: HTTP 409: conflict"),
              "boom": RuntimeError("kaboom")}

    @s._tool
    def fails(host: str) -> dict:
        raise errors[exc]

    @s._tool
    async def fails_async(host: str) -> dict:
        raise errors[exc]

    for fn in (fails, fails_async):
        with pytest.raises(ToolError, match=expect):
            asyncio.run(s.mcp.call_tool(fn.__name__, {"host": "h"}))


def test_a_wrong_argument_type_is_one_readable_line():
    from mcp.server.mcpserver.exceptions import ToolError
    s = import_server()

    @s._tool
    def counted(host: str, limit: int = 5) -> dict:
        return {}

    with pytest.raises(ToolError) as err:
        asyncio.run(s.mcp.call_tool("counted", {"host": "h", "limit": "lots"}))
    msg = str(err.value)
    assert msg.startswith("counted: invalid arguments. limit:") and "you sent 'lots'" in msg
    assert "pydantic.dev" not in msg and "\n" not in msg
    with pytest.raises(ToolError, match="host: Field required"):
        asyncio.run(s.mcp.call_tool("counted", {}))


def test_a_wrapped_connection_failure_says_the_pod_is_unreachable():
    from mcp.server.mcpserver.exceptions import ToolError
    s = import_server()

    @s._tool
    def down(host: str) -> dict:
        raise Exception("Request failed: HTTPSConnectionPool(host='h', port=443): Max retries exceeded "
                        "(Caused by ConnectTimeoutError('Connection to h timed out. (connect timeout=15)'))")

    with pytest.raises(ToolError, match=r"cannot reach h over HTTPS: it timed out"):
        asyncio.run(s.mcp.call_tool("down", {"host": "h"}))


def test_changing_tools_take_no_approval_parameter_and_ask_no_form():
    """Approval is the client's own prompt, driven by the tool's annotations; the server asks nothing."""
    s = import_server()
    tools = {t.name: t for t in asyncio.run(s.mcp.list_tools())}
    for n in ("vm_lifecycle", "set_vm_license", "snapshot_vm"):
        assert "approval" not in tools[n].input_schema["properties"]
        assert tools[n].annotations.destructive_hint is True


def test_the_server_describes_itself_and_every_tool_has_a_title():
    s = import_server()
    assert s.mcp.title == "Fabric Studio" and "confirm=true" in s.mcp.instructions
    tools = asyncio.run(s.mcp.list_tools())
    assert all(t.title for t in tools)
    assert next(t for t in tools if t.name == "set_vm_port_dhcp").title == "Set VM Port DHCP"
