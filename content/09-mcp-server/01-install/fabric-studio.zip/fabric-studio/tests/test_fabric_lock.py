"""Unit tests for the per-pod reconciler lock (backend/engine/lock.py).

Offline: the lock is a controller-side file mutex, no pod involved.
"""
import os

import pytest

from fabric_studio.topology import lock as L


@pytest.fixture(autouse=True)
def _isolate_lock_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(L, "_LOCK_DIR", str(tmp_path / "locks"))
    monkeypatch.setattr(L, "_LOCKOUT_DIR", str(tmp_path / "lockouts"))
    monkeypatch.delenv("FSH_LOCKOUT", raising=False)


def test_acquire_release_roundtrip():
    h = L.acquire("podA", fabric="f1")
    assert os.path.exists(h.path)
    L.release(h)
    assert not os.path.exists(h.path)


def test_second_acquire_blocks_while_held():
    h = L.acquire("podA", fabric="f1")
    with pytest.raises(L.LockError):
        L.acquire("podA", fabric="f2")
    L.release(h)
    # freed → re-acquire succeeds
    h2 = L.acquire("podA", fabric="f3")
    L.release(h2)


def test_force_breaks_live_lock():
    h = L.acquire("podA", fabric="f1")
    h2 = L.acquire("podA", fabric="f2", force=True)
    assert h2.fabric == "f2"
    L.release(h2)


def test_stale_by_ttl_is_broken():
    h = L.acquire("podA", fabric="f1")
    # ttl_s=0 makes any existing lock immediately stale.
    h2 = L.acquire("podA", fabric="f2", ttl_s=0)
    assert h2.fabric == "f2"
    L.release(h2)


def test_dead_holder_pid_is_broken(monkeypatch):
    h = L.acquire("podA", fabric="f1")
    # Rewrite the on-disk lock to claim a dead pid, then acquire should break it.
    import json
    info = json.loads(open(h.path).read())
    info["pid"] = 2 ** 22  # implausible pid
    with open(h.path, "w") as fh:
        json.dump(info, fh)
    h2 = L.acquire("podA", fabric="f2")
    assert h2.fabric == "f2"
    L.release(h2)


def test_release_does_not_delete_someone_elses_lock():
    h = L.acquire("podA", fabric="f1")
    # Simulate our lock being broken + retaken by another holder.
    other = L.acquire("podA", fabric="other", force=True)
    L.release(h)  # must NOT remove the other holder's lock
    assert os.path.exists(other.path)
    L.release(other)


def test_different_hosts_dont_collide():
    a = L.acquire("podA", fabric="f1")
    b = L.acquire("podB", fabric="f1")  # different host, independent lock
    assert a.path != b.path
    L.release(a)
    L.release(b)


def test_context_manager_releases():
    with L.pod_lock("podA", fabric="f1") as h:
        assert os.path.exists(h.path)
    assert not os.path.exists(h.path)


def test_lockout_engage_blocks_the_named_fabric():
    L.lockout_engage("podA", "fab1", reason="live lab")
    with pytest.raises(L.LockoutError, match="live lab"):
        L.check_lockout("podA", "fab1")


def test_lockout_does_not_touch_other_fabrics_or_pods():
    L.lockout_engage("podA", "fab1")
    L.check_lockout("podA", "fab2")
    L.check_lockout("podB", "fab1")


def test_lockout_wildcard_freezes_every_fabric_on_the_pod():
    L.lockout_engage("podA", "*", reason="pod frozen")
    with pytest.raises(L.LockoutError, match="every fabric"):
        L.check_lockout("podA", "any-fabric-name")
    L.check_lockout("podB", "any-fabric-name")


def test_lockout_release_clears_and_status_reports():
    assert L.lockout_status("podA", "fab1") is None
    L.lockout_engage("podA", "fab1")
    assert L.lockout_status("podA", "fab1") is not None
    assert L.lockout_release("podA", "fab1") is True
    L.check_lockout("podA", "fab1")


def test_lockout_env_var_blocks_pod_fabric_pair(monkeypatch):
    monkeypatch.setenv("FSH_LOCKOUT", "podA:fab1")
    with pytest.raises(L.LockoutError, match="FSH_LOCKOUT"):
        L.check_lockout("podA", "fab1")
    L.check_lockout("podA", "fab2")


def test_a_lock_is_identified_by_a_token_not_by_pid_and_time(monkeypatch):
    """Two acquisitions inside one clock tick (Windows before Python 3.13) must still be told apart."""
    monkeypatch.setattr(L.time, "time", lambda: 1_700_000_000.0)
    h = L.acquire("podA", fabric="f1")
    other = L.acquire("podA", fabric="other", force=True)
    assert h.pid == other.pid and h.created == other.created and h.token != other.token
    L.release(h)   # not ours any more: must leave the other holder's lock in place
    assert os.path.exists(other.path)
    L.release(other)
    assert not os.path.exists(other.path)
