"""pytest fixtures: isolate every test from the developer's real ~/.fsh and keychain."""
import sys

import pytest


@pytest.fixture(autouse=True)
def _isolated_data_dir(monkeypatch, tmp_path):
    monkeypatch.setenv("FSH_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("FSH_LOGIN_GUARD_DIR", str(tmp_path / "login_guard"))
    monkeypatch.setenv("FSH_INSTANCES_FILE", str(tmp_path / "instances.json"))
    monkeypatch.setenv("FSH_POD_GROUPS_FILE", str(tmp_path / "pod-groups.toml"))   # none unless a test writes one
    monkeypatch.setenv("FS_WORKSPACE", "")   # no workspace, not the real ~/fabric-studio
    monkeypatch.delenv("FS_ENV_DIRS", raising=False)
    from cryptography.fernet import Fernet
    monkeypatch.setenv("FSH_MASTER_KEY", Fernet.generate_key().decode())

    from sqlmodel import SQLModel
    SQLModel.metadata.clear()
    stateful = {"fabric_studio.settings", "fabric_studio.db", "fabric_studio.crypto", "fabric_studio.models", "fabric_studio.credentials", "fabric_studio.keychain"}
    for mod in list(sys.modules):
        if mod in stateful:
            del sys.modules[mod]
    yield tmp_path


@pytest.fixture(autouse=True)
def _stub_pod_type_detection(monkeypatch):
    import fabric_studio.pod.runtime_factory as rf
    monkeypatch.setattr(rf, "detect_pod_type", lambda host, username, password, timeout=8: "fs")


def import_server():
    """Import the MCP server fresh. ``_tool`` registers each sync tool as an async wrapper that
    runs it in a worker thread; the shape tests call tools directly, so put the plain functions
    back on the module (the wrapper keeps the original as ``__wrapped__``)."""
    import importlib
    import inspect

    import fabric_studio.mcp.server as m
    importlib.reload(m)
    for name, obj in list(vars(m).items()):
        inner = getattr(obj, "__wrapped__", None)
        if inner and inspect.iscoroutinefunction(obj) and not inspect.iscoroutinefunction(inner):
            setattr(m, name, inner)
    return m
