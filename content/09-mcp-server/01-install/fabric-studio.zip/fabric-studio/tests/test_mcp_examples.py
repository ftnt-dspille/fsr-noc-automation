"""build action=examples: patterns matched over the visible intents, secrets masked."""
from fabric_studio.mcp.examples import examples

INTENT = """
fabric: t
nodes:
  - name: gw
    type: FGT
    license: {mode: auto}
    links:
      - {port: port2, switch: Mgmt, mgmt: true}
      - {port: port3, switch: LAN}
  - name: client
    type: LXC
    deviceconfig:
      device: host
      inject:
        fabric/setup.d/06-key: |
          echo key >> /root/.ssh/authorized_keys
          password=hunter2
    links:
      - {port: eth0, switch: Mgmt, mgmt: true}
      - {port: eth1, switch: LAN, vlan: 10}
"""


def _intents(tmp_path):
    d = tmp_path / "lab"
    d.mkdir()
    (d / "intent.yaml").write_text(INTENT)
    return [("workspace", d / "intent.yaml")]


def test_listing_names_the_topologies_per_pattern(tmp_path):
    rows = {r["pattern"]: r["topologies"] for r in examples(_intents(tmp_path))["patterns"]}
    assert rows["client_behind_gate"] == ["lab"]
    assert rows["lxc_key_access"] == ["lab"]
    assert rows["licensed_fortigate"] == ["lab"]
    assert rows["vlan_switchport"] == ["lab"]
    assert rows["windows"] == []


def test_snippet_is_yaml_with_secrets_masked(tmp_path):
    ex = examples(_intents(tmp_path), "lxc_key_access")["examples"]
    assert ex[0]["topology"] == "lab" and ex[0]["node"] == "client"
    assert "authorized_keys" in ex[0]["yaml"]
    assert "hunter2" not in ex[0]["yaml"]


def test_unknown_pattern_lists_the_known_ones(tmp_path):
    r = examples(_intents(tmp_path), "nope")
    assert "error" in r and "client_behind_gate" in r["patterns"]


def test_fortios_set_lines_and_psk_are_masked(tmp_path):
    d = tmp_path / "vpn"
    d.mkdir()
    (d / "intent.yaml").write_text("""
nodes:
  - name: c
    type: LXC
    deviceconfig:
      inject:
        fabric/setup.d/06-key: |
          echo k >> /root/.ssh/authorized_keys
          set psksecret S3cretPSK
          psk: other1
""")
    y = examples([("w", d / "intent.yaml")], "lxc_key_access")["examples"][0]["yaml"]
    assert "S3cretPSK" not in y and "other1" not in y
