"""A keyring read that never returns (a macOS access dialog waiting) fails fast."""
import threading

import pytest

from fabric_studio import keychain


@pytest.fixture(autouse=True)
def no_security_cli(monkeypatch):
    """These tests exercise the keyring path (Linux and Windows): the security tool answers nothing unless a
    test says so, and macOS tests set the platform themselves."""
    monkeypatch.setattr(keychain.sys, "platform", "linux")
    monkeypatch.setattr(keychain, "_KEYRING_STUCK", False)
    monkeypatch.setattr(keychain, "_security_cli", lambda a, s: (False, None))
    monkeypatch.setattr(keychain, "_security_set", lambda a, p, s: False)
    monkeypatch.setattr(keychain, "_security_delete", lambda a, s: None)


def test_blocked_keyring_raises_instead_of_hanging(monkeypatch):
    gate = threading.Event()
    monkeypatch.setattr(keychain.keyring, "get_password", lambda s, a: gate.wait(5) and None)
    monkeypatch.setenv("FSH_KEYCHAIN_TIMEOUT_S", "0.2")
    monkeypatch.setattr(keychain, "_security_cli", lambda a, s: (False, None))   # it blocks too
    with pytest.raises(keychain.KeychainBlocked, match="did not answer"):
        keychain.get_secret("pod-default")
    gate.set()


def test_blocked_keyring_falls_back_to_security_cli(monkeypatch):
    gate = threading.Event()
    monkeypatch.setattr(keychain.keyring, "get_password", lambda s, a: gate.wait(5) and None)
    monkeypatch.setenv("FSH_KEYCHAIN_TIMEOUT_S", "0.2")
    monkeypatch.setattr(keychain, "_security_cli", lambda a, s: (True, "from-security"))
    assert keychain.get_secret("x") == "from-security"
    gate.set()


def test_answering_keyring_returns_value(monkeypatch):
    monkeypatch.setattr(keychain.keyring, "get_password", lambda s, a: "pw")
    assert keychain.get_secret("x") == "pw"


def test_keyring_error_degrades_to_none(monkeypatch):
    def boom(s, a):
        raise keychain.keyring.errors.KeyringError("locked")
    monkeypatch.setattr(keychain.keyring, "get_password", boom)
    assert keychain.get_secret("x") is None


def test_blocked_write_raises_instead_of_hanging(monkeypatch):
    monkeypatch.setattr(keychain.sys, "platform", "linux")   # the keyring write path; macOS writes with security
    gate = threading.Event()
    monkeypatch.setattr(keychain.keyring, "set_password", lambda s, a, p: gate.wait(5))
    monkeypatch.setenv("FSH_KEYCHAIN_TIMEOUT_S", "0.2")
    with pytest.raises(keychain.KeychainBlocked):
        keychain.set_secret("x", "v")
    gate.set()


def test_delete_of_a_missing_item_is_false(monkeypatch):
    def gone(s, a):
        raise keychain.keyring.errors.PasswordDeleteError("none")
    monkeypatch.setattr(keychain.keyring, "delete_password", gone)
    assert keychain.delete_secret("x") is False


def test_macos_reads_through_security_first_so_always_allow_lasts(monkeypatch):
    # keyring would ask as this Python, a new program after every rebuild; security has one fixed path
    monkeypatch.setattr(keychain, "_security_cli", lambda a, s: (True, "from-security"))
    monkeypatch.setattr(keychain.keyring, "get_password", lambda s, a: pytest.fail("keyring was asked first"))
    assert keychain.get_secret("x") == "from-security"


def test_macos_writes_through_security(monkeypatch):
    monkeypatch.setattr(keychain, "_security_set", lambda a, p, s: True)
    monkeypatch.setattr(keychain.keyring, "set_password", lambda *a: pytest.fail("keyring was used"))
    keychain.set_secret("pod.example.com", "pw")


def test_security_write_keeps_the_password_off_the_command_line(monkeypatch):
    seen = {}

    class P:
        returncode, stdout, stderr = 0, "", ""

    def run(argv, **kw):
        if argv[1] == "-i":
            seen["argv"], seen["input"] = argv, kw.get("input")
            return P()
        r = P()   # the read-back after the write
        r.stderr = 'password: "s3cret!"\n'
        return r
    monkeypatch.undo()   # the real helper, with subprocess faked
    monkeypatch.setattr(keychain.sys, "platform", "darwin")
    monkeypatch.setattr(keychain, "_security_delete", lambda a, s: False)
    monkeypatch.setattr(keychain.subprocess, "run", run)
    assert keychain._security_set("pod.example.com", "s3cret!", "fabric-studio-fixer")
    assert "s3cret" not in " ".join(seen["argv"]) and "s3cret" not in seen["input"]
    assert b"s3cret!".hex() in seen["input"] and "-T /usr/bin/security" in seen["input"]
    assert not keychain._security_set("bad account; rm", "pw", "fabric-studio-fixer")


@pytest.mark.parametrize("stderr,want", [
    ('password: "plain"\n', "plain"),
    ('password: "q"uote"\n', 'q"uote'),
    ('password: 0x636166C3A9  "caf\\303\\251"\n', "caf\u00e9"),
    ("password: \n", ""),
])
def test_both_g_output_forms_parse(stderr, want):
    assert keychain._parse_g(stderr) == want


def test_a_refused_read_is_final_on_macos(monkeypatch):
    class P:
        returncode, stdout, stderr = 51, "", "User interaction is not allowed."
    monkeypatch.undo()
    monkeypatch.setattr(keychain.sys, "platform", "darwin")
    monkeypatch.setattr(keychain.subprocess, "run", lambda *a, **k: P())
    monkeypatch.setattr(keychain.keyring, "get_password", lambda *a: pytest.fail("keyring asked after a refusal"))
    with pytest.raises(keychain.CredsError, match="unlock-keychain"):
        keychain.get_secret("x")


def test_pod_creds_turns_a_blocked_read_into_a_message(monkeypatch):
    import importlib

    from fabric_studio import resolve
    kc = importlib.import_module("fabric_studio.keychain")   # conftest gives each test a fresh module

    def blocked(account, service=kc.SERVICE):
        raise kc.KeychainBlocked("dialog waiting")
    monkeypatch.setattr(kc, "get_secret", blocked)
    with pytest.raises(SystemExit, match="dialog waiting"):
        resolve.pod_creds("pod.example.com", None, None)


def test_an_empty_password_is_refused():
    with pytest.raises(keychain.CredsError, match="empty"):
        keychain.set_secret("pod.example.com", "")


@pytest.fixture
def groups(tmp_path, monkeypatch):
    f = tmp_path / "pod-groups.toml"
    f.write_text('[groups]\n"*.cloud.example.com" = "pod-default-cloud"\n"10.99.*" = "pod-default-lab"\n')
    monkeypatch.setenv("FSH_POD_GROUPS_FILE", str(f))


@pytest.mark.parametrize("host,want", [
    ("pod1.cloud.example.com", "pod-default-cloud"),
    ("POD1.Cloud.Example.com", "pod-default-cloud"),
    ("10.99.1.2", "pod-default-lab"),
    ("fabric-studio.example.com", None),
])
def test_pod_group_account(groups, host, want):
    assert keychain.pod_group_account(host) == want


def test_no_groups_file_means_no_groups(tmp_path, monkeypatch):
    monkeypatch.setenv("FSH_POD_GROUPS_FILE", str(tmp_path / "absent.toml"))
    assert keychain.pod_group_account("10.99.1.2") is None


def test_group_login_comes_before_the_shared_one(groups, monkeypatch):
    import importlib
    kc = importlib.import_module("fabric_studio.keychain")
    store = {"pod-default-lab": "lab-pw", "pod-default": "shared-pw", "pod-default-cloud": "cloud-pw"}
    monkeypatch.setattr(kc, "get_secret", lambda account, service=kc.SERVICE: store.get(account))
    monkeypatch.delenv("POD_PASSWORD", raising=False)
    assert kc.resolve_pod_login("10.99.1.2")[1] == "lab-pw"
    assert kc.resolve_pod_login("x.cloud.example.com")[1] == "cloud-pw"
    assert kc.resolve_pod_login("fabric-studio.example.com")[1] == "shared-pw"
    store["10.99.1.2"] = "own-pw"
    assert kc.resolve_pod_login("10.99.1.2")[1] == "own-pw"


def test_macos_never_falls_back_to_keyring(monkeypatch):
    # keyring would ask as this Python: the dialog that came back after every reinstall
    monkeypatch.setattr(keychain.sys, "platform", "darwin")
    monkeypatch.setattr(keychain.keyring, "get_password", lambda *a: pytest.fail("keyring asked on macOS"))
    with pytest.raises(keychain.KeychainBlocked, match="security"):
        keychain.get_secret("x")


@pytest.mark.parametrize("pattern,host,want", [
    ("*.cloud.example.com", "p1.cloud.example.com", True),
    ("*.cloud.example.com", "a.b.cloud.example.com", False),       # * does not span a dot
    ("*.cloud.example.com", "p1.cloud.example.com.evil.net", False),
    ("10.99.*", "10.99.1.2", True),
    ("10.99.*", "10.99.evil.com", False),                           # an IP pattern matches only IP addresses
    ("10.99.*", "10.990.1.2", False),
])
def test_group_patterns_are_strict(pattern, host, want):
    assert keychain._pattern_matches(pattern, host) is want
