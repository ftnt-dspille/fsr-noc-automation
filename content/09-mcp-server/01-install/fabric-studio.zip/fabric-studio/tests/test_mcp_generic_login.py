"""Generic guests (LXC, BASIC, VyOS) sign in with their image's login from the firmware metadata."""
from conftest import import_server

import_server()
from fabric_studio.mcp import device as dev
from fabric_studio.mcp import server


class C:
    def __init__(self, cred):
        self.cred = cred

    def get(self, path):
        cred = self.cred

        class R:
            def json(self):
                return {"object": [{"json_meta": {"model": {"credentials": cred}}}]}
        return R()


def test_generic_guest_uses_the_image_login():
    c = C({"@login": "vyos", "@password": "imgpw1"})
    assert dev.login_for(c, {"vm_type": "VYOS"}, {"firmware": 7}, {"password": "fabpw"}) == \
        ("vyos", "imgpw1", "the image's login (firmware metadata)", "fabpw")


def test_lxc_tries_the_fabric_password_first():
    # Fabric Studio writes the fabric's password into an LXC; the image's login is the fallback
    c = C({"@login": "root", "@password": "imgpw1"})
    assert dev.login_for(c, {"vm_type": "LXC"}, {"firmware": 7}, {"password": "fabpw"}) == \
        ("root", "fabpw", "the fabric's password", "imgpw1")


def test_logins_cover_both_users_and_both_passwords():
    from fabric_studio.mcp import fortios as fos
    t = fos.Target(host="h", name="n", fabric="f", https_port=1, ssh_port=2, user="root", password="a",
                   alt_user="admin", alt_password="b")
    assert t.logins() == [("root", "a"), ("admin", "a"), ("root", "b"), ("admin", "b")]
    assert fos.Target(host="h", name="n", fabric="f", https_port=1, ssh_port=2, password="a").logins() == [("admin", "a")]


def test_fortinet_device_uses_the_fabric_password_even_with_metadata():
    c = C({"@login": "x", "@password": "imgpw1"})
    assert dev.login_for(c, {"vm_type": "FGT"}, {"firmware": 7}, {"password": "fabpw"})[:2] == ("admin", "fabpw")


def test_empty_metadata_falls_back_to_the_fabric_password():
    c = C({"@login": "", "@password": ""})
    assert dev.login_for(c, {"vm_type": "BASIC"}, {"firmware": 7}, {"password": "fabpw"})[1] == "fabpw"


def test_unsafe_metadata_user_is_ignored():
    c = C({"@login": "root; rm -rf /", "@password": "pw\nx"})
    user, pw = dev.image_login(c, {"firmware": 7})
    assert user is None and pw is None


def test_open_links():
    assert server._open_at("pod", "HTTPS2HTTP", 16004) == "https://pod:16004/"
    assert server._open_at("pod", "SSH", 11004).startswith("ssh -p 11004")


def test_a_vm_password_overrides_the_image_and_the_fabric():
    c = C({"@login": "root", "@password": "imgpw1"})
    assert dev.login_for(c, {"vm_type": "LXC"}, {"firmware": 7, "password": "vmpw1"}, {"password": "fabpw"}) == \
        ("root", "vmpw1", "the VM's password", None)
    assert dev.login_for(C({}), {"vm_type": "FGT"}, {"firmware": 7, "password": "vmpw1"}, {"password": "fabpw"})[1] == "vmpw1"
