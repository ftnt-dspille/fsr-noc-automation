"""``fabric-studio-mcp setup | pods | remove``: the prompts, the login check, where the password goes, and rollback."""
from __future__ import annotations

import argparse
import os
import sys

import pytest

from fabric_studio.mcp import cli, instances

SECRET = "s3cret-pw-not-in-any-output"


class FakeKeychain:
    def __init__(self, usable=True):
        self.store, self.usable = {}, usable

    def get(self, host):
        return self.store.get(host)

    def set(self, host, password):
        if not self.usable:
            raise RuntimeError("no keychain backend")
        self.store[host] = password

    def delete(self, host):
        return self.store.pop(host, None) is not None


@pytest.fixture(autouse=True)
def kc(monkeypatch):
    """A fake keychain for every test: nothing here may read or write the developer's real one."""
    import fabric_studio.keychain as real
    fake = FakeKeychain()
    monkeypatch.setattr(real, "get_secret", lambda account, service=real.SERVICE: fake.get(account))
    monkeypatch.setattr(real, "set_secret", lambda account, pw, service=real.SERVICE: fake.set(account, pw))
    monkeypatch.setattr(real, "delete_secret", lambda account, service=real.SERVICE: fake.delete(account))
    return fake


@pytest.fixture
def home(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("FSH_INSTANCES_FILE", str(tmp_path / ".fsh" / "instances.json"))
    monkeypatch.delenv("FS_WORKSPACE", raising=False)
    monkeypatch.delenv("FS_ENV_DIRS", raising=False)
    return tmp_path


def _args(**kw):
    base = dict(host=None, user=None, name=None, tag=None, password_stdin=False, no_verify=False)
    return argparse.Namespace(**{**base, **kw})


def _register(ok=True):
    """The real register(), with the pod login stubbed (no network)."""
    def fake_connect(host, user, password):
        if not ok:
            raise PermissionError("login rejected")
        return object()

    def reg(*a, **kw):
        import fabric_studio.admin as adm
        orig = adm.get_pod_hostname
        adm.get_pod_hostname = lambda c: "fabric-studio"
        try:
            return instances.register(*a, connect=fake_connect, **kw)
        finally:
            adm.get_pod_hostname = orig
    return reg


def _run(args, answers, *, keychain, ok=True):
    lines, it = [], iter(answers)
    code = cli.setup(args, ask=lambda _p: next(it), ask_secret=lambda _p: SECRET, out=lines.append,
                     keychain=keychain, register=_register(ok))
    return code, "\n".join(lines)


def test_setup_asks_checks_and_keeps_the_password_in_the_keychain(home, kc):
    code, text = _run(_args(), ["pod.example.com", "", "mypod"], keychain=kc)
    assert code == 0 and "Registered 'mypod'" in text and "system keychain" in text
    assert kc.store["pod.example.com"] == SECRET
    assert SECRET not in text
    reg = instances.load_registry()
    assert reg["pod.example.com"]["name"] == "mypod" and reg["pod.example.com"]["user"] == "admin"
    assert SECRET not in instances.registry_path().read_text(encoding="utf-8")


def test_a_rejected_login_registers_nothing_and_restores_the_previous_password(home, kc):
    kc.store["pod.example.com"] = "the-old-password"
    code, text = _run(_args(), ["pod.example.com", "admin", "mypod"], keychain=kc, ok=False)
    assert code == 1 and "Not registered" in text and "login" in text
    assert kc.store["pod.example.com"] == "the-old-password"
    assert not instances.load_registry()


def test_a_rejected_login_leaves_no_password_behind_for_a_new_pod(home, kc):
    _run(_args(), ["pod.example.com", "admin", "mypod"], keychain=kc, ok=False)
    assert "pod.example.com" not in kc.store


def test_without_a_keychain_the_login_goes_to_a_private_file(home, kc):
    kc.usable = False
    code, text = _run(_args(), ["pod.example.com", "admin", "mypod"], keychain=kc)
    assert code == 0 and ".env.mypod" in text
    f = home / ".fsh" / ".env.mypod"
    assert f.exists() and "FS_POD_PASS=" + SECRET in f.read_text(encoding="utf-8")
    if os.name != "nt":
        assert (f.stat().st_mode & 0o777) == 0o600
    assert instances.load_registry()["pod.example.com"]["env_file"] == str(f)
    assert SECRET not in text


def test_a_rejected_login_removes_the_file_it_wrote(home, kc):
    kc.usable = False
    code, _ = _run(_args(), ["pod.example.com", "admin", "mypod"], keychain=kc, ok=False)
    assert code == 1 and not (home / ".fsh" / ".env.mypod").exists()


@pytest.mark.parametrize("host", ["", "bad host", "x/y", "a;b"])
def test_bad_hosts_are_refused_before_asking_for_a_password(home, kc, host):
    asked = []
    code = cli.setup(_args(host=host or None), ask=lambda p: host, ask_secret=lambda p: asked.append(p) or "x",
                     out=lambda _l: None, keychain=kc, register=_register())
    assert code == 2 and not asked


def test_flags_skip_the_prompts(home, kc):
    code = cli.setup(_args(host="pod.example.com", user="ops", name="lab", tag=["a"]),
                     ask=lambda p: pytest.fail("should not ask"), ask_secret=lambda p: SECRET,
                     out=lambda _l: None, keychain=kc, register=_register())
    assert code == 0 and instances.load_registry()["pod.example.com"]["tags"] == ["a"]


def test_password_stdin_for_scripts(home, kc, monkeypatch):
    import io
    monkeypatch.setattr(sys, "stdin", io.StringIO(SECRET + "\n"))
    code = cli.setup(_args(host="pod.example.com", name="lab", password_stdin=True), ask=lambda p: "",
                     ask_secret=lambda p: pytest.fail("must not prompt"), out=lambda _l: None, keychain=kc,
                     register=_register())
    assert code == 0 and kc.store["pod.example.com"] == SECRET


def test_pods_lists_without_any_password(home, kc):
    _run(_args(), ["pod.example.com", "admin", "mypod"], keychain=kc)
    lines = []
    assert cli.pods(argparse.Namespace(), out=lines.append) == 0
    text = "\n".join(lines)
    assert "mypod" in text and "pod.example.com" in text and SECRET not in text


def test_remove_by_name_forgets_the_password(home, kc):
    _run(_args(), ["pod.example.com", "admin", "mypod"], keychain=kc)
    lines = []
    assert cli.remove(argparse.Namespace(pod="mypod", yes=True, keep_password=False), out=lines.append) == 0
    assert not instances.load_registry() and "pod.example.com" not in kc.store


def test_remove_declined_changes_nothing(home, kc):
    _run(_args(), ["pod.example.com", "admin", "mypod"], keychain=kc)
    code = cli.remove(argparse.Namespace(pod="mypod", yes=False, keep_password=False), out=lambda _l: None,
                      ask=lambda _p: "n")
    assert code == 1 and instances.load_registry()


def test_the_server_command_still_starts_the_server_with_no_arguments(monkeypatch):
    from fabric_studio.mcp import server
    started = []
    monkeypatch.setattr(server.mcp, "run", lambda: started.append(True))
    monkeypatch.setattr(sys, "argv", ["fabric-studio-mcp"])
    server.main()
    assert started == [True]
