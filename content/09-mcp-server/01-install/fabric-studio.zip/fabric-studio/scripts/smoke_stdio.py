"""Start the installed `fabric-studio-mcp` command, speak MCP to it over stdio, and list its tools.

CI runs this after installing the package the way the docs say (from an unzipped copy), on Linux, macOS and
Windows, so the whole user-facing path (the console script, the stdio transport, the tool registry) is proven
and not just the in-process tests.   python scripts/smoke_stdio.py [path-to-fabric-studio-mcp]
"""
from __future__ import annotations

import asyncio
import os
import shutil
import sys
import tempfile

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

EXPECTED = {"pods", "fabric", "vm", "tasks", "diagnose", "build", "device", "run", "register"}


async def main(command: str) -> int:
    with tempfile.TemporaryDirectory() as tmp:
        env = {**os.environ, "FSH_INSTANCES_FILE": os.path.join(tmp, "instances.json")}   # an empty, throwaway registry
        params = StdioServerParameters(command=command, args=[], env=env)
        async with stdio_client(params) as (read, write), ClientSession(read, write) as session:
            await session.initialize()
            names = {t.name for t in (await session.list_tools()).tools}
            missing = EXPECTED - names
            print(f"{len(names)} tools; missing: {sorted(missing) or 'none'}")
            if missing:
                return 1
            result = await session.call_tool("build", {"action": "topologies"})
            text = "".join(getattr(c, "text", "") for c in result.content)
            ok = not result.is_error and "fgt_fmg_faz" in text
            print("build topologies:", "ok" if ok else f"FAILED: {text[:200]}")
            return 0 if ok else 1


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else shutil.which("fabric-studio-mcp")
    if not cmd:
        sys.exit("fabric-studio-mcp is not on PATH")
    sys.exit(asyncio.run(main(cmd)))
